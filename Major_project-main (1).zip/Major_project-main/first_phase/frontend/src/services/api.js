import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000';

export const startTraining = async () => {
    return axios.post(`${API_BASE_URL}/train/start`);
};

export const getTrainingStatus = async () => {
    return axios.get(`${API_BASE_URL}/train/status`);
};

export const manualStep = async (action) => {
    return axios.post(`${API_BASE_URL}/env/step`, { action });
};

export const getNetworkState = async () => {
    return axios.get(`${API_BASE_URL}/env/state`);
};
