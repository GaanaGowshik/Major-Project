import React, { useState, useEffect } from 'react';
import { startTraining, getTrainingStatus } from './services/api';
import NetworkView from './components/NetworkView';
import ActionLog from './components/ActionLog';
import RewardChart from './components/RewardChart';
import { Play, Activity, Target, ShieldAlert, Cpu, Download, RefreshCcw, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

function App() {
  const [stats, setStats] = useState({
    episode: 0,
    total_reward: 0,
    steps: 0,
    done: false,
    last_action: 'Simulation Standby',
    network_state: [],
    reward_history: [],
    training_complete: false,
    total_detection: 0
  });
  const [isTraining, setIsTraining] = useState(false);

  useEffect(() => {
    let interval;
    if (isTraining) {
      interval = setInterval(async () => {
        try {
          const response = await getTrainingStatus();
          setStats(response.data);
          
          if (response.data.training_complete) {
            setIsTraining(false);
            clearInterval(interval);
          }
        } catch (err) {
          console.error("Link Failure", err);
        }
      }, 800);
    }
    return () => clearInterval(interval);
  }, [isTraining]);

  const handleStart = async () => {
    // Reset local state before starting
    setStats(prev => ({ ...prev, episode: 0, reward_history: [], training_complete: false }));
    await startTraining();
    setIsTraining(true);
  };

  return (
    <div className="min-h-screen p-6 bg-[#050508] text-gray-200">
      <header className="flex justify-between items-center mb-8 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-cyan-500/10 rounded-xl border border-cyan-500/20">
            <Cpu size={28} className="text-cyan-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight glow-text uppercase font-mono">
              PPO Pentest Simulator <span className="text-cyan-500/50 font-light">v2.1</span>
            </h1>
            <p className="text-gray-500 text-[10px] uppercase tracking-[0.2em] mt-1 flex items-center gap-2">
              {stats.training_complete ? (
                <span className="text-green-400 flex items-center gap-1"><CheckCircle2 size={10}/> Analysis Finalized</span>
              ) : isTraining ? (
                <span className="text-cyan-400 animate-pulse">● Infiltration Engine Active</span>
              ) : (
                "○ System Ready for Deployment"
              )}
            </p>
          </div>
        </div>

        <div className="flex gap-4">
          {stats.training_complete && (
            <button className="btn-primary !bg-green-600/10 !text-green-400 !border-green-500/30 flex items-center gap-2 hover:!bg-green-600/20">
              <Download size={16} /> Download Intelligence Summary
            </button>
          )}
          <button 
            onClick={handleStart}
            disabled={isTraining}
            className={`btn-primary flex items-center gap-2 px-6 ${
              isTraining ? 'opacity-70 cursor-not-allowed' : ''
            }`}
          >
            {isTraining ? (
              <><RefreshCcw size={16} className="animate-spin" /> Training: {Math.min(stats.episode, 25)} / 25</>
            ) : stats.training_complete ? (
              <><RefreshCcw size={16} /> Re-Initialize Engine</>
            ) : (
              <><Play size={16} fill="currentColor" /> Deploy Agent</>
            )}
          </button>
        </div>
      </header>

      <div className="grid-layout !p-0">
        <div className="col-12 grid grid-cols-4 gap-4 mb-6">
          <StatCard 
             label="Batch Progress" 
             value={`${Math.min(stats.episode, 25)} / 25`} 
             icon={<Activity size={18} className="text-blue-400" />}
             progress={(Math.min(stats.episode, 25) / 25) * 100}
          />
          <StatCard 
             label="Current Episode Reward" 
             value={stats.total_reward} 
             icon={<Target size={18} className="text-emerald-400" />}
             trend={stats.total_reward > 0 ? "up" : "down"}
          />
          <StatCard 
             label="Detection Risk" 
             value={`${Math.round(stats.total_detection * 100)}%`} 
             icon={<ShieldAlert size={18} className="text-rose-400" />}
             alert={stats.total_detection > 0.6}
          />
          <StatCard 
             label="System Efficiency" 
             value={stats.reward_history.length > 0 ? `${Math.round((stats.network_state.filter(h => h.is_compromised).length / 6) * 100)}%` : "0%"} 
             icon={<Cpu size={18} className="text-violet-400" />}
          />
        </div>

        <div className="col-8 space-y-6">
          <div className="glass-card h-[420px] flex flex-col !p-0 overflow-hidden border-cyan-500/10">
            <div className="px-4 py-3 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
              <h2 className="text-[10px] font-bold uppercase tracking-widest text-cyan-400 flex items-center gap-2">
                <Target size={12} /> Network Topology & Node Status
              </h2>
              <div className="flex gap-4 text-[9px] text-gray-500 font-mono">
                <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 bg-cyan-400 rounded-full" /> DISCOVERED</span>
                <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 bg-green-400 rounded-full" /> COMPROMISED</span>
              </div>
            </div>
            <div className="flex-1 bg-gradient-to-b from-transparent to-cyan-950/5">
              <NetworkView hosts={stats.network_state} />
            </div>
          </div>
          
          <div className="glass-card h-48 flex flex-col !p-4 border-blue-500/10">
             <h2 className="text-[10px] font-bold uppercase tracking-widest text-blue-400 mb-4">RL Intelligence Trend (Reward Convergence)</h2>
             <div className="flex-1">
                <RewardChart data={stats.reward_history} />
             </div>
          </div>
        </div>

        <div className="col-4">
          <ActionLog 
            currentAction={stats.last_action}
            isTraining={isTraining}
          />
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, progress, alert, trend }) {
  return (
    <div className={`glass-card flex flex-col gap-2 relative overflow-hidden transition-all duration-500 ${alert ? 'border-rose-500/30 bg-rose-500/5' : 'border-white/5'}`}>
      <div className="flex justify-between items-start">
        <div className="p-2 bg-white/5 rounded-lg">{icon}</div>
        {trend && (
           <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded ${trend === 'up' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
             {trend === 'up' ? '↑ GAIN' : '↓ LOSS'}
           </span>
        )}
      </div>
      <div>
        <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest mb-1">{label}</p>
        <p className="text-xl font-bold font-mono tracking-tighter tabular-nums text-white">
          {value}
        </p>
      </div>
      {progress !== undefined && (
        <div className="h-0.5 w-full bg-white/5 absolute bottom-0 left-0">
          <motion.div 
            className="h-full bg-gradient-to-r from-blue-500 to-cyan-400" 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
          />
        </div>
      )}
    </div>
  );
}

export default App;
