import React, { useState, useEffect } from 'react';
import { Terminal, ChevronRight } from 'lucide-react';

const ActionLog = ({ currentAction }) => {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    if (currentAction && currentAction !== 'Waiting...') {
      setHistory(prev => [
        { msg: currentAction, time: new Date().toLocaleTimeString() },
        ...prev.slice(0, 14)
      ]);
    }
  }, [currentAction]);

  return (
    <div className="glass-card flex-1 overflow-hidden flex flex-col h-full">
      <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Terminal size={18} className="text-cyan-400" /> Action Console
      </h2>
      
      <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
        {history.map((log, i) => (
          <div key={i} className="flex gap-2 text-sm border-l-2 border-cyan-500/30 pl-3 py-1 bg-white/5 rounded-r-md">
            <span className="text-gray-500 font-mono text-[10px] w-16">{log.time}</span>
            <ChevronRight size={14} className="text-cyan-500 shrink-0 mt-0.5" />
            <span className={`font-mono ${log.msg.includes('✅') ? 'text-green-400' : 'text-gray-300'}`}>
              {log.msg}
            </span>
          </div>
        ))}
        
        {history.length === 0 && (
          <div className="text-gray-600 italic text-sm text-center mt-10">
            Waiting for agent initialization...
          </div>
        )}
      </div>
    </div>
  );
};

export default ActionLog;
