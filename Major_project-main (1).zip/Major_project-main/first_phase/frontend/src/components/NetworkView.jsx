import React from 'react';
import { Server, Database, Globe, Shield, Wifi, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

const NetworkView = ({ hosts }) => {
  const getIcon = (type) => {
    switch (type) {
      case 'Database': return <Database size={24} />;
      case 'Web Server': return <Globe size={24} />;
      case 'Firewall': return <Shield size={24} />;
      default: return <Server size={24} />;
    }
  };

  return (
    <div className="relative w-full h-full p-4 overflow-hidden">
      {/* Visual background grid/lines could go here */}
      <div className="grid grid-cols-3 gap-6 relative z-10 scale-90 origin-center">
        {hosts.map((host, idx) => (
          <motion.div
            key={host.id}
            layout
            className={`glass-card flex flex-col items-center gap-2 p-4 relative group transition-all duration-500 ${
              host.is_compromised ? 'ring-2 ring-green-500/30' : 'hover:bg-white/5'
            }`}
          >
            {/* Connection Wire Indicator (Visual only) */}
            <div className="absolute -top-4 left-1/2 w-0.5 h-4 bg-gradient-to-b from-cyan-500/20 to-transparent" />
            
            {/* Host Icon Container */}
            <div className={`p-4 rounded-xl transition-all duration-500 shadow-lg ${
              host.is_compromised 
                ? 'bg-green-500/20 text-green-400' 
                : host.is_discovered 
                  ? 'bg-cyan-500/10 text-cyan-400' 
                  : 'bg-white/5 text-gray-600'
            }`}>
              {getIcon(host.type)}
            </div>
            
            <div className="text-center">
              <p className={`font-bold text-xs uppercase tracking-tighter ${
                host.is_compromised ? 'text-green-400' : 'text-gray-300'
              }`}>
                {host.name}
              </p>
              <p className="text-[10px] text-gray-500 font-mono">{host.ip}</p>
            </div>

            {/* Detection Meter */}
            <div className="w-full mt-2">
              <div className="flex justify-between items-center text-[8px] text-gray-500 mb-1">
                <span>NOISE LEVEL</span>
                <span className={host.detection > 0.6 ? 'text-red-400' : 'text-cyan-600'}>
                  {Math.round(host.detection * 100)}%
                </span>
              </div>
              <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  className={`h-full ${host.detection > 0.6 ? 'bg-red-500' : 'bg-cyan-500'}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${host.detection * 100}%` }}
                />
              </div>
            </div>

            {/* Status Badges */}
            <div className="flex gap-1 mt-2">
               <span className={`w-2 h-2 rounded-full ${host.is_discovered ? 'bg-cyan-400 shadow-[0_0_5px_rgba(0,255,255,0.5)]' : 'bg-gray-800'}`} />
               <span className={`w-2 h-2 rounded-full ${host.is_enumerated ? 'bg-blue-400 shadow-[0_0_5px_rgba(0,180,255,0.5)]' : 'bg-gray-800'}`} />
               <span className={`w-2 h-2 rounded-full ${host.is_compromised ? 'bg-green-400 shadow-[0_0_5px_rgba(0,255,130,0.5)]' : 'bg-gray-800'}`} />
            </div>

            {/* Difficulty Marker */}
            {host.difficulty > 1.2 && (
               <div className="absolute top-2 right-2 flex items-center gap-1">
                 <AlertTriangle size={10} className="text-yellow-500/50" />
                 <span className="text-[8px] text-yellow-500/30">HARD</span>
               </div>
            )}
          </motion.div>
        ))}
      </div>
      
      {/* Topology Background Decoration */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-10">
        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5"/>
        </pattern>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>
    </div>
  );
};

export default NetworkView;
