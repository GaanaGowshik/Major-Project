import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

const RewardChart = ({ data }) => {
  // Ensure data is always an array
  const safeData = Array.isArray(data) ? data : [];
  
  // Map reward history to chart format
  const chartData = safeData.map((val, idx) => ({ 
    episode: idx + 1, 
    reward: parseFloat(val).toFixed(2) 
  }));

  if (safeData.length === 0) {
    return (
      <div className="w-full h-full flex items-center justify-center text-gray-500 italic text-sm">
        Gathering data from first episode...
      </div>
    );
  }

  return (
    <div className="w-full h-full pb-4">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
          <XAxis 
            dataKey="episode" 
            stroke="#555" 
            fontSize={10} 
            tickLine={false} 
            axisLine={false}
            label={{ value: 'Episodes', position: 'insideBottom', offset: -5, fontSize: 10, fill: '#444' }}
          />
          <YAxis 
            stroke="#555" 
            fontSize={10} 
            tickLine={false} 
            axisLine={false}
            tickFormatter={(val) => Math.round(val)}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#111', 
              border: 'none',
              borderRadius: '8px',
              fontSize: '12px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.5)'
            }}
            itemStyle={{ color: '#00f2fe' }}
            cursor={{ stroke: '#00f2fe20', strokeWidth: 2 }}
          />
          <Line 
            type="monotone" 
            dataKey="reward" 
            stroke="url(#colorReward)" 
            strokeWidth={3}
            dot={{ r: 2, fill: '#00f2fe' }}
            activeDot={{ r: 4, stroke: '#00f2fe', strokeWidth: 2, fill: '#fff' }}
            animationDuration={800}
          />
          <defs>
            <linearGradient id="colorReward" x1="0" y1="0" x2="1" y2="0">
              <stop offset="5%" stopColor="#4facfe" stopOpacity={1}/>
              <stop offset="95%" stopColor="#00f2fe" stopOpacity={1}/>
            </linearGradient>
          </defs>
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default RewardChart;
