import threading
import time
from ..env.pentest_env import PentestEnv
from ..agent.rl_agent import create_model
import numpy as np

class TrainerService:
    def __init__(self):
        self.env = PentestEnv(num_hosts=6)
        self.model = create_model(self.env)
        self.is_training = False
        self.max_episodes = 25
        self.status = {
            "episode": 0,
            "total_reward": 0.0,
            "steps": 0,
            "done": False,
            "last_action": "Application Ready",
            "network_state": self.env.network.get_state(),
            "reward_history": [],
            "training_complete": False,
            "total_detection": 0.0
        }
        self.thread = None

    def start_training(self):
        # Reset for a fresh run
        if not self.is_training:
            self.status["episode"] = 0
            self.status["reward_history"] = []
            self.status["training_complete"] = False
            self.is_training = True
            
            # Create a NEW model/env thread to ensure no stale state
            self.thread = threading.Thread(target=self._run_training_loop, daemon=True)
            self.thread.start()

    def _run_training_loop(self):
        while self.is_training and self.status["episode"] < self.max_episodes:
            obs, _ = self.env.reset()
            done = False
            episode_reward = 0
            steps = 0
            self.status["episode"] += 1
            
            # Inner loop for steps within an episode
            while not done and self.is_training:
                # Step limit check
                if self.status["episode"] > self.max_episodes:
                    break

                action, _states = self.model.predict(obs, deterministic=False)
                obs, reward, done, truncated, info = self.env.step(action)
                
                episode_reward += reward
                steps += 1
                
                self.status["total_reward"] = round(episode_reward, 2)
                self.status["steps"] = steps
                self.status["done"] = done
                self.status["last_action"] = info["action_taken"]
                self.status["network_state"] = info["network_state"]
                self.status["total_detection"] = info["total_detection"]
                
                time.sleep(0.4) 

            # Push history
            self.status["reward_history"].append(float(episode_reward))
            time.sleep(0.5)

        # Finalize
        self.is_training = False
        self.status["training_complete"] = True
        self.status["last_action"] = f"ANALYSIS COMPLETE: {self.max_episodes} Episodes evaluated."

    def get_status(self):
        return self.status

    def manual_step(self, action_pair):
        obs, reward, done, truncated, info = self.env.step(action_pair)
        return {
            "reward": round(reward, 2),
            "done": done,
            "state": obs.tolist(),
            "action_taken": info["action_taken"],
            "network_state": info["network_state"]
        }

trainer_service = TrainerService()
