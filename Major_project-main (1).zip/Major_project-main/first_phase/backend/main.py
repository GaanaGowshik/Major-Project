from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from .services.trainer import trainer_service
from .models.schemas import StepRequest, StepResponse, TrainingStatus

app = FastAPI(title="RL Pentest Sim API")

# Enable CORS for React
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Pentest Sim Backend Running"}

@app.post("/train/start")
def start_training():
    trainer_service.start_training()
    return {"status": "training_started"}

@app.get("/train/status")
def get_status():
    return trainer_service.get_status()

@app.post("/env/step", response_model=StepResponse)
def env_step(request: StepRequest):
    result = trainer_service.manual_step(request.action)
    return result

@app.get("/env/state")
def get_state():
    return {"hosts": trainer_service.get_status()["network_state"]}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
