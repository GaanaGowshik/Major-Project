from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class HostState(BaseModel):
    id: int
    name: str
    ip: str
    is_discovered: bool
    is_enumerated: bool
    is_compromised: bool

class TrainingStatus(BaseModel):
    episode: int
    total_reward: float
    steps: int
    done: bool
    last_action: Optional[str] = None
    network_state: List[HostState]

class StepRequest(BaseModel):
    action: List[int] # [host_idx, action_type]

class StepResponse(BaseModel):
    reward: float
    done: bool
    state: List[List[float]]
    action_taken: str
    network_state: List[HostState]
