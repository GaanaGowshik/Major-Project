from stable_baselines3 import PPO
from ..env.pentest_env import PentestEnv

def create_model(env):
    """
    Initialize a PPO model for the pentest environment.
    """
    model = PPO("MlpPolicy", env, verbose=0, learning_rate=0.0003)
    return model

def load_model(path, env):
    return PPO.load(path, env=env)
