# Major Project — Implementation Plan

> **Last updated:** Phases 3–12 complete (this session)
> **Next agent must read this entire document before touching any file.**

---

## Project Goal

Automated Multi-Cloud Penetration Testing platform using Reinforcement Learning.

- Discovers real cloud resources (AWS or GCP, user selects one)
- Identifies vulnerabilities and privilege-escalation paths
- Builds an attack graph from **real discovered relationships only**
- Safely validates selected attack paths with explicit user confirmation
- Generates a professional security report (JSON + PDF)
- Uses RL to recommend optimal attack paths

**Non-goals for all phases:**  
No hardcoded credentials, ARNs, account IDs, project IDs.  
No fake data in the production pipeline.  
No auto-escalation without explicit user confirmation.  
No "Exploited" status without real execution evidence.

---

## Tech Stack (committed decisions)

| Concern            | Decision                                                                                |
| ------------------ | --------------------------------------------------------------------------------------- |
| Language           | Python 3.11+                                                                            |
| AWS SDK            | boto3                                                                                   |
| GCP SDK            | google-cloud-iam, google-cloud-storage, google-cloud-compute                            |
| GCP Auth           | ADC via `google.auth.default()`, fallback to GOOGLE_APPLICATION_CREDENTIALS env var     |
| AWS Auth           | Named AWS profile (AWS_PROFILE env var) or standard env vars. No hardcoded credentials. |
| PDF generation     | WeasyPrint (HTML→PDF) — **installed in backend venv**                                   |
| Graph library      | networkx (already in use — keep)                                                        |
| RL framework       | Stable-Baselines3 + Gymnasium (keep)                                                    |
| Frontend framework | React + React Flow (@xyflow/react) — **already installed**                              |
| Data models        | Pydantic v2 (for all resource/finding types)                                            |
| Testing            | pytest + moto (AWS mocking) + unittest.mock for GCP                                     |
| LocalStack         | Keep for AWS dev/test mode only — clearly gated from real AWS                           |

---

## Current Architecture (actual, from audit)

### Repository layout

```
Major_project/
├── docker-compose.yml              LocalStack container definition
├── IMPLEMENTATION_PLAN.md          ← This file
├── first_phase/                    PROTOTYPE — educational scaffold only, NOT used by phase 2
│   └── backend/
│       ├── env/gym_env.py          Prototype gym env (generic network pentest)
│       ├── agent/rl_agent.py       Prototype RL agent
│       ├── services/trainer.py     Prototype trainer
│       └── models/schemas.py       Prototype schemas
└── second_phase/                   ACTIVE PROJECT
    ├── requirements.txt            Minimal (boto3, botocore, networkx, pydantic)
    ├── STARTUP.md                  Developer guide
    ├── backend/
    │   ├── aws_pentest/            Phase 1 real-AWS scanner ← WORKING, ran against real AWS
    │   │   ├── iam/                IAM enumeration + simulator + privesc + policy parser
    │   │   ├── s3/                 S3 analyser
    │   │   ├── ec2/                EC2 analyser
    │   │   ├── graph/              Graph builder + RL adapter
    │   │   ├── models/             Pydantic v2 models (IAM, S3, EC2, Graph)
    │   │   ├── report/             JSON + console report generator
    │   │   ├── run.py              CLI orchestrator
    │   │   ├── last_report.json    REAL scan output — 4 users, 5 roles, 2 buckets, 1 EC2
    │   │   ├── last_graph.json     REAL graph from last scan
    │   │   └── last_report_compiled.json  Compiled HTML-render version (new)
    │   ├── cloud/                  Legacy LocalStack layer (kept for gym env)
    │   │   ├── cloud_client.py     boto3 client factory (LocalStack or AWS)
    │   │   ├── config.py           CLOUD_PROVIDER toggle ("aws" or "localstack")
    │   │   ├── iam.py              Legacy IAM ops (NOT used by new scanner)
    │   │   ├── s3.py               Legacy S3 ops (NOT used by new scanner)
    │   │   └── scenario_generator.py  LocalStack test scenario
    │   ├── graph/
    │   │   ├── builder.py          Compatibility shim → re-exports aws_pentest.graph.GraphBuilder
    │   │   └── graph_utils.py      (unread — likely unused utilities)
    │   ├── env/
    │   │   ├── gym_env.py          CloudPentestEnv — PARTIAL (uses legacy cloud layer)
    │   │   ├── actions.py          Action implementations — PARTIAL (actions 4, 5 are STUBS)
    │   │   └── rewards.py          RewardSystem — present but not wired to gym_env.py
    │   ├── rl/
    │   │   ├── train.py            Basic PPO train script — WORKING
    │   │   ├── train_with_logging.py  PPO + TrainingLogger — WORKING
    │   │   ├── training_logger.py  SB3 callback → training_log.json — WORKING
    │   │   └── evaluate.py         Evaluation script — WORKING (if model file exists)
    │   ├── api/
    │   │   ├── main.py             FastAPI app — WORKING
    │   │   └── routes/
    │   │       ├── scan.py         POST /api/scan — WORKING
    │   │       ├── graph.py        GET /api/attack-graph — WORKING
    │   │       ├── report.py       GET/POST /api/report — WORKING
    │   │       └── rl.py           GET /api/rl/status|episodes|history — WORKING
    │   └── api/services/
    │       ├── graph_service.py    nx graph → React Flow JSON — WORKING
    │       ├── report_service.py   HTML/PDF report generation — WORKING
    │       └── rl_service.py       Training log reader — WORKING
    └── frontend/                   React + TypeScript + Vite — WORKING
        └── src/
            ├── App.tsx             4-tab shell — WORKING
            ├── api/client.ts       Typed axios wrappers — WORKING
            ├── constants.ts        Design tokens, action/node labels — WORKING
            └── components/
                ├── AttackGraph.tsx     React Flow graph + node side-panel — WORKING
                ├── RLVisualization.tsx RL charts + step trace — WORKING
                ├── PentestReport.tsx   Report viewer + PDF download — WORKING
                ├── ScanPanel.tsx       AWS scan trigger UI — WORKING
                └── common/Widgets.tsx  Shared UI components — WORKING
```

---

## Module Status Table

| Module                      | File(s)                              | Status           | Evidence                                                                                                                                                                                                                                         | Risk if used as-is                                                        |
| --------------------------- | ------------------------------------ | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------- |
| IAM Enumerator              | `aws_pentest/iam/enumerator.py`      | **WORKING**      | Paginated real API calls; handles URL-encoded docs; fetches managed + inline policies for users/roles/groups                                                                                                                                     | Low — proven against real AWS (last_report.json shows 4 users, 5 roles)   |
| IAM Policy Parser           | `aws_pentest/iam/policy_parser.py`   | **WORKING**      | Stateless; handles NotAction/NotResource; glob matching; trust policy parsing                                                                                                                                                                    | Low — no AWS calls, pure logic                                            |
| IAM Simulator               | `aws_pentest/iam/simulator.py`       | **WORKING**      | Wraps `iam:SimulatePrincipalPolicy`; handles batching (100 actions/call); paginates; rate-limit sleep                                                                                                                                            | Low — proven against real AWS                                             |
| IAM PrivEsc Detector        | `aws_pentest/iam/privesc.py`         | **WORKING**      | 16 PMapper techniques; all simulator-verified; short-circuits on first missing action; no cross-product                                                                                                                                          | Low — honest about confirmation status                                    |
| S3 Analyser                 | `aws_pentest/s3/analyser.py`         | **WORKING**      | Real bucket policy + ACL + PAB + encryption + versioning + logging; IAM cross-reference via simulator; `confirmed_access` dict populated                                                                                                         | Low — proven against real AWS (2 buckets in last scan)                    |
| EC2 Analyser                | `aws_pentest/ec2/analyser.py`        | **WORKING**      | Real `describe_instances`/`describe_security_groups`; IMDSv2 check; instance profile resolution; SG analysis for 12 sensitive ports                                                                                                              | Low — proven against real AWS (1 instance in last scan)                   |
| Graph Builder (aws_pentest) | `aws_pentest/graph/builder.py`       | **WORKING**      | Edges ONLY from: trust relationships, simulator-confirmed S3 access, instance profile facts, privesc paths; no cross-product                                                                                                                     | Low — real-edges-only design is correct                                   |
| Graph Models                | `aws_pentest/models/graph_models.py` | **WORKING**      | Pydantic v2; `to_networkx()` and `to_dict()` implemented                                                                                                                                                                                         | Low                                                                       |
| IAM Models                  | `aws_pentest/models/iam_models.py`   | **WORKING**      | Pydantic v2; all required fields; Severity enum; PrivEscPath has `simulator_confirmed` flag                                                                                                                                                      | Low                                                                       |
| S3 Models                   | `aws_pentest/models/s3_models.py`    | **WORKING**      | Pydantic v2; `fully_blocked` property on PublicAccessBlock; `confirmed_access` dict on S3Bucket                                                                                                                                                  | Low                                                                       |
| EC2 Models                  | `aws_pentest/models/ec2_models.py`   | **WORKING**      | Pydantic v2; `imdsv1_enabled` property; SGRule with `is_open_to_world`                                                                                                                                                                           | Low                                                                       |
| Report Generator            | `aws_pentest/report/generator.py`    | **WORKING**      | JSON output; console summary; severity-sorted findings; privesc section                                                                                                                                                                          | Low — JSON/console only (no PDF here)                                     |
| CLI Orchestrator            | `aws_pentest/run.py`                 | **WORKING**      | Full pipeline: IAM → PrivEsc → S3 → EC2 → Graph → Report; all flags supported; proven against real AWS                                                                                                                                           | Low                                                                       |
| RL Adapter                  | `aws_pentest/graph/rl_adapter.py`    | **WORKING**      | Loads Phase 1 graph JSON → nx.DiGraph; `load_graph_for_rl()`, `get_node_types()`, `reachable_from()`                                                                                                                                             | Low                                                                       |
| FastAPI App                 | `api/main.py`                        | **WORKING**      | 4 routers; CORS configured; health endpoint                                                                                                                                                                                                      | Low                                                                       |
| Scan Route                  | `api/routes/scan.py`                 | **WORKING**      | Background task runs `aws_pentest.run`; status polling supported                                                                                                                                                                                 | Medium — runs scan in thread-unsafe global state (`_scan_state`)          |
| Graph Route                 | `api/routes/graph.py`                | **WORKING**      | Loads Phase 1 JSON or falls back to legacy CloudGraphBuilder; React Flow format                                                                                                                                                                  | Low                                                                       |
| Report Route                | `api/routes/report.py`               | **WORKING**      | JSON, HTML, PDF (WeasyPrint) — all endpoints exist                                                                                                                                                                                               | Low                                                                       |
| RL Route                    | `api/routes/rl.py`                   | **WORKING**      | Reads training_log.json; returns status/episodes/history                                                                                                                                                                                         | Low                                                                       |
| Graph Service               | `api/services/graph_service.py`      | **WORKING**      | `nx_to_react_flow()` with confirmed/unconfirmed edge distinction; node risk scoring                                                                                                                                                              | Low                                                                       |
| Report Service              | `api/services/report_service.py`     | **WORKING**      | Handles both raw scan format and compiled format; WeasyPrint PDF; executive summary; recommendations                                                                                                                                             | Low                                                                       |
| RL Service                  | `api/services/rl_service.py`         | **WORKING**      | Reads training_log.json; `set_live_status()` for live push; honest stub labels                                                                                                                                                                   | Low                                                                       |
| Training Logger             | `rl/training_logger.py`              | **WORKING**      | SB3 BaseCallback; per-episode JSON; live status push to rl_service                                                                                                                                                                               | Low                                                                       |
| Train with Logging          | `rl/train_with_logging.py`           | **WORKING**      | PPO + TrainingLogger; saves model                                                                                                                                                                                                                | Low                                                                       |
| Train (basic)               | `rl/train.py`                        | **WORKING**      | Basic PPO; no logging                                                                                                                                                                                                                            | Low                                                                       |
| Evaluate                    | `rl/evaluate.py`                     | **WORKING**      | Loads saved model; 20-step eval loop                                                                                                                                                                                                             | Requires model file to exist                                              |
| **Gym Environment**         | `env/gym_env.py`                     | **PARTIAL**      | Uses legacy `CloudGraphBuilder` (not Phase 1 graph); fixed 6 actions regardless of graph structure; `current_node` never advances (always index 0); `RewardSystem` defined but NOT wired in — `gym_env.py` has its own inline `calculate_reward` | **HIGH** — agent never moves through the graph; observations don't change |
| **Actions**                 | `env/actions.py`                     | **PARTIAL/STUB** | Actions 0–3 call real AWS (list users/roles/buckets/node); Actions 4 (AssumeRole) and 5 (ListBucketObjects) are explicit stubs — always return `success: False`                                                                                  | HIGH — 2 of 6 actions never succeed                                       |
| Rewards                     | `env/rewards.py`                     | **STUB**         | `RewardSystem` class defined correctly but **never used** by `gym_env.py`                                                                                                                                                                        | Medium — unused dead code                                                 |
| Legacy Cloud IAM            | `cloud/iam.py`                       | **PARTIAL**      | `list_users/roles` work; `discover_user_role_relationships` now does real trust-policy check; `discover_role_bucket_relationships` intentionally returns `[]` (deprecated); still calls real AWS via cloud_client                                | Medium — module-level boto3 client instantiation at import time           |
| Legacy Cloud S3             | `cloud/s3.py`                        | **WORKING**      | list/create/delete buckets; thin wrapper                                                                                                                                                                                                         | Low                                                                       |
| Cloud Config                | `cloud/config.py`                    | **NOTE**         | Hardcoded `CLOUD_PROVIDER = "aws"` and `LOCALSTACK_ENDPOINT` — not read from env vars                                                                                                                                                            | Medium — LocalStack toggle requires code edit, not env var                |
| Cloud Client                | `cloud/cloud_client.py`              | **PARTIAL**      | LocalStack path hardcodes `aws_access_key_id = "test"` — acceptable for LocalStack; real AWS path uses `boto3.client(service, region_name=...)` which relies on default credential chain                                                         | Low for real-AWS path                                                     |
| Graph Builder Shim          | `graph/builder.py`                   | **WORKING**      | Re-exports `aws_pentest.graph.GraphBuilder`; `CloudGraphBuilder` class kept for gym env compatibility                                                                                                                                            | Low                                                                       |
| Scenario Generator          | `cloud/scenario_generator.py`        | **STUB**         | Creates hardcoded "alice" user and "company-data" bucket in LocalStack — dev/test only                                                                                                                                                           | Low — only used in test scripts                                           |
| **Frontend**                | `frontend/src/`                      | **WORKING**      | All 4 tabs render; React Flow with dagre layout; PDF download; scan trigger; RL charts; node side-panel with confirmed/unconfirmed badges                                                                                                        | Low — no GCP support yet; no validation UI yet                            |
| LocalStack                  | `docker-compose.yml`                 | **WORKING**      | Defines localstack:3.8 with IAM/S3/Lambda/STS                                                                                                                                                                                                    | Low — clearly separated from real-AWS path                                |
| Tests                       | `backend/test_*.py`                  | **PARTIAL**      | Integration tests for LocalStack scenarios; no unit tests; no moto/pytest tests                                                                                                                                                                  | High — no automated test coverage                                         |

---

## Dependency Map

```
aws_pentest.run (CLI orchestrator)
  ├── aws_pentest.iam.enumerator        → depends on: boto3, iam.policy_parser, models.iam_models
  ├── aws_pentest.iam.simulator         → depends on: boto3, models.iam_models (SimulationResult)
  ├── aws_pentest.iam.privesc           → depends on: iam.simulator, models.iam_models
  ├── aws_pentest.s3.analyser           → depends on: boto3, iam.simulator, models.s3_models, models.iam_models
  ├── aws_pentest.ec2.analyser          → depends on: boto3, models.ec2_models, models.iam_models
  ├── aws_pentest.graph.builder         → depends on: networkx, models.graph_models, models.iam_models,
  │                                                    models.s3_models, models.ec2_models
  └── aws_pentest.report.generator      → depends on: models.* (all four)

api.main (FastAPI)
  ├── api.routes.scan                   → depends on: aws_pentest.run (runs in background thread)
  ├── api.routes.graph                  → depends on: api.services.graph_service
  ├── api.routes.report                 → depends on: api.services.report_service
  └── api.routes.rl                     → depends on: api.services.rl_service

api.services.graph_service             → depends on: aws_pentest.models.graph_models, networkx
                                          fallback: graph.builder.CloudGraphBuilder → cloud.iam, cloud.s3
api.services.report_service            → depends on: aws_pentest/last_report.json (file),
                                                      api.services.rl_service, weasyprint
api.services.rl_service                → depends on: rl/training_log.json (file)

env.gym_env (Gymnasium)                → depends on: graph.builder.CloudGraphBuilder → cloud.iam, cloud.s3
                                                      env.actions
env.actions                            → depends on: cloud.iam (list_users, list_roles),
                                                      cloud.s3 (list_buckets)
                                          STUBS: action_assume_role, action_list_bucket_objects

rl.train / rl.train_with_logging       → depends on: env.gym_env, stable_baselines3
rl.evaluate                            → depends on: env.gym_env, stable_baselines3 (model file)

graph.builder.CloudGraphBuilder        → depends on: cloud.iam, cloud.s3, networkx
graph.builder (shim)                   → re-exports aws_pentest.graph.GraphBuilder

cloud.iam / cloud.s3                   → depends on: cloud.cloud_client → cloud.config → boto3
```

**Critical observation:** `env/gym_env.py` depends on the **legacy** `CloudGraphBuilder`, NOT on the Phase 1 `aws_pentest.graph.GraphBuilder`. This means the RL env has NO connection to the real scan data unless rewritten to use the RL adapter (`aws_pentest.graph.rl_adapter.load_graph_for_rl()`).

---

## AWS Status

### What works (Phase 1 — fully verified against real AWS)

| Component             | Status     | Notes                                                                    |
| --------------------- | ---------- | ------------------------------------------------------------------------ |
| IAM enumeration       | ✅ WORKING | Real paginated API calls; users/roles/groups/policies                    |
| IAM Policy Simulator  | ✅ WORKING | `iam:SimulatePrincipalPolicy` with batching + pagination                 |
| IAM PrivEsc detection | ✅ WORKING | 16 techniques; all simulator-verified                                    |
| S3 analysis           | ✅ WORKING | ACL + PAB + encryption + versioning + logging + IAM xref                 |
| EC2 analysis          | ✅ WORKING | SGs + IMDSv2 + instance profile resolution                               |
| Graph building        | ✅ WORKING | Real edges only; confirmed relationships                                 |
| Report (JSON)         | ✅ WORKING | Full structured JSON; real data confirmed                                |
| Report (HTML/PDF)     | ✅ WORKING | WeasyPrint pipeline functional                                           |
| FastAPI + all routes  | ✅ WORKING | All endpoints tested in prior session                                    |
| Frontend scan trigger | ✅ WORKING | Background scan + 3s polling                                             |
| Frontend graph view   | ✅ WORKING | React Flow + dagre layout + confirmed/unconfirmed edge styling           |
| Frontend report view  | ✅ WORKING | All sections rendered correctly                                          |
| Auth (credentials)    | ✅ WORKING | Named profile or env vars; no hardcoded creds                            |
| LocalStack separation | ✅ WORKING | Legacy env uses cloud/config.py toggle; aws_pentest uses boto3.Session() |

### What is MISSING or PARTIAL in AWS

| Gap                                   | Location                                                     | Impact                                  |
| ------------------------------------- | ------------------------------------------------------------ | --------------------------------------- |
| Controlled validation (write/execute) | Not implemented                                              | Phase 6 — needed for demo flow          |
| Multi-region discovery                | EC2 supports `--regions` flag; IAM/S3 are global — correct   | Low                                     |
| CloudTrail/Config analysis            | Not implemented                                              | Nice-to-have                            |
| Lambda/ECS/EKS resource discovery     | Not implemented                                              | Future scope                            |
| RL env NOT using real graph           | `env/gym_env.py` uses `CloudGraphBuilder` not Phase 1 output | High — RL doesn't reflect real topology |
| Gym env observation space broken      | `current_node` never advances                                | Critical for RL correctness             |
| Actions 4 & 5 are stubs               | `env/actions.py`                                             | Medium — RL can't simulate escalation   |
| No pytest/moto tests                  | No test/ directory                                           | High — no automated regression coverage |
| Provider abstraction missing          | No `BaseCloudProvider`                                       | Needed for GCP integration              |

---

## GCP Status (MISSING — to be built)

Nothing GCP-specific exists in the codebase. Required packages are NOT installed.

Required packages to install:

```
google-cloud-iam
google-cloud-storage
google-cloud-compute
google-auth
```

Planned modules:

- `gcp_pentest/iam/enumerator.py` — service accounts, roles, IAM bindings
- `gcp_pentest/iam/privesc.py` — service account impersonation paths
- `gcp_pentest/storage/analyser.py` — bucket IAM + public exposure
- `gcp_pentest/compute/analyser.py` — instances + firewall rules + service accounts
- `gcp_pentest/graph/builder.py` — real-edge-only graph for GCP
- `gcp_pentest/models/` — Pydantic v2 models (or shared normalized models)
- `gcp_pentest/run.py` — CLI orchestrator
- GCP section in API routes/services

---

## Cloud Provider Abstraction

**STATUS: NOT IMPLEMENTED — to be built in Phase 2**

### Required design

```python
# second_phase/backend/providers/base.py
from abc import ABC, abstractmethod

class BaseCloudProvider(ABC):
    @abstractmethod
    def authenticate(self) -> bool: ...
    @abstractmethod
    def discover_resources(self) -> dict: ...
    @abstractmethod
    def analyze_security(self) -> list: ...
    @abstractmethod
    def get_attack_graph(self) -> AssessmentGraph: ...
    @abstractmethod
    def validate_finding(self, finding_id: str, dry_run: bool = True) -> dict: ...

class AWSProvider(BaseCloudProvider): ...   # wraps aws_pentest pipeline
class GCPProvider(BaseCloudProvider): ...   # wraps gcp_pentest pipeline
```

### Frontend selection

A cloud selection screen must appear BEFORE authentication, driving the entire pipeline.
Selection stored in app state; all API calls include the provider token.

---

## Normalized Resource Model

**STATUS: PARTIAL — AWS-specific Pydantic models exist; no shared cross-provider models**

### Plan (Phase 5)

Create `second_phase/backend/models/common.py`:

- `CloudResource` — base model with `provider`, `resource_id`, `resource_type`, `arn_or_id`, `region`, `tags`
- `CloudFinding` — base model with `finding_id`, `provider`, `severity`, `title`, `description`, `recommendation`, `evidence`, `confirmed: bool`
- `AttackPath` — normalized path model usable by both providers and the RL layer
- AWS-specific and GCP-specific models extend these base models

---

## Resource Discovery

### AWS (WORKING)

- IAM: users, roles, groups, policies, trust relationships — `aws_pentest/iam/enumerator.py`
- S3: all buckets, policy, ACL, PAB, encryption, versioning, logging — `aws_pentest/s3/analyser.py`
- EC2: instances, SGs, instance profiles, IMDSv2 — `aws_pentest/ec2/analyser.py`

### GCP (MISSING — Phase 3)

- IAM: `resourcemanager.projects.getIamPolicy`, service accounts, custom roles
- Cloud Storage: bucket IAM, public access, encryption, versioning
- Compute Engine: instances, firewall rules, service account attachments, public IPs

---

## Security Analysis

### AWS (WORKING)

- IAM PrivEsc: 16 techniques, all simulator-confirmed — `aws_pentest/iam/privesc.py`
- S3: public access, ACL public grants, wildcard principal policy, encryption, versioning, logging
- EC2: IMDSv1 enabled, sensitive ports open to 0.0.0.0/0, instance profile review

**FIXED (Phase 1):** `aws_pentest/iam/analyser.py` — IAMAnalyser now produces findings for: password policy weakness/absence, root account access keys, root MFA missing, users with AdministratorAccess, inline `Action:*`, console access without MFA, stale/unused access keys, roles with wildcard trust, roles with AdministratorAccess. Wired into `run.py`.

### GCP (MISSING — Phase 4)

- Privilege escalation: service account impersonation, `roles/iam.serviceAccountTokenCreator`
- Storage: unauthorized read/write paths
- Compute: dangerous firewall rules (0.0.0.0/0 inbound), overly permissive service accounts

---

## Controlled Validation

**STATUS: NOT IMPLEMENTED — Phase 6 (AWS) / Phase 7 (GCP)**

### Safety model (REQUIRED before any implementation)

```
Modes:
  READ_ONLY   — default; all current operations
  DRY_RUN     — preview what WOULD happen; no mutations
  VALIDATE    — execute controlled test with: confirmation + cleanup + audit log

Every validation requires:
  1. Dry-run preview shown to user
  2. Explicit user click "Confirm Validate"
  3. Named test resources: cloud-pentest-validation/<run-id>/resource-name
  4. Timeout (max 5 minutes per validation)
  5. Cleanup on success AND failure
  6. Audit log entry with timestamp, action, result, cleanup status
  7. Stop capability (cancel mid-execution)
```

### AWS validation techniques to implement (Phase 6)

Only implement what the scanner has already verified as exploitable:

- IAM PassRole via iam:PassRole (confirm role assumption chain)
- S3 write validation (put test object → verify → delete)
- S3 read validation (controlled test object only)
- EC2 role escalation (temp instance → collect identity → terminate)
- Lambda role escalation (temp function → invoke → collect → delete)

### GCP validation techniques (Phase 7)

- Service account impersonation
- Cloud Storage write/read validation
- Compute temp resource validation

---

## Attack Graph

### Current state

- Graph builder (`aws_pentest/graph/builder.py`) produces a real-edge-only `AssessmentGraph`
- Real scan of test account: last known graph written to `aws_pentest/last_graph.json`
- Graph is loaded by `api/services/graph_service.py` → served as React Flow JSON
- Frontend (`AttackGraph.tsx`) renders confirmed edges solid, unconfirmed dashed

### Gaps to fix (Phase 8)

- Graph edges do NOT yet carry the specific policy statement SID/ARN that grants the permission (evidence is the raw simulator dict; needs structured `policy_sources` field to be populated)
- No "unconfirmed/placeholder edge" visual badge in graph for edges coming from the legacy `CloudGraphBuilder` fallback (currently just uses dashed line; needs explicit `"source": "legacy_heuristic"` attribute)
- Export GraphML format: works but list/dict attributes are stringified (acceptable for now)
- RL environment (`env/gym_env.py`) does NOT load from Phase 1 graph — it uses `CloudGraphBuilder` — this MUST be fixed in Phase 8/11

---

## Report Generation

### Current state (WORKING)

- JSON report: `aws_pentest/report/generator.py` → real structured output
- HTML report: `api/services/report_service.py` → `_render_full_html()` — professional layout
- PDF: `generate_pdf()` via WeasyPrint — functional (`weasyprint` installed in backend venv)
- Report persisted to `aws_pentest/last_report.json` and `last_report_compiled.json`
- HTML persisted to `aws_pentest/last_report.html`
- Frontend report tab: full viewer with PDF download + HTML preview

### Gaps to fix (Phase 9)

- Report does NOT include section for controlled validation results (Phase 6 output)
- Report does NOT include graph image (server-side networkx/matplotlib render)
- RL section correctly labeled "SIMULATED" — needs to be updated when real RL is wired to real graph
- `NOT PERFORMED` vs `SUCCESS` distinction for validations: not yet relevant (no validation exists), but must be enforced when Phase 6 is built
- No GCP section in report

---

## RL Agent

### Current state (PARTIAL — significant gaps)

#### What works

- `rl/train.py`: PPO trains against `CloudPentestEnv` — completes 5000 timesteps
- `rl/train_with_logging.py`: PPO + `TrainingLogger` callback — writes `training_log.json`
- `rl/training_logger.py`: per-episode JSON log; live status push to `rl_service`
- `rl/evaluate.py`: loads saved model, runs 20-step evaluation
- Frontend RL tab: shows reward curves, action success/fail counts, step trace

#### What is broken / misleading

1. **`env/gym_env.py` observation space is wrong**: observation is always `self.current_node` (integer index) which NEVER changes — `step()` doesn't update `current_node`. Agent sees a constant observation every step.
2. **`gym_env.py` uses `CloudGraphBuilder`** (legacy AWS layer), NOT the Phase 1 real graph. The RL agent doesn't see the real IAM topology.
3. **Actions 4 and 5 are permanent stubs**: always return `success: False`. The agent is penalized -5 for actions it can never succeed at.
4. **`RewardSystem` (rewards.py) is defined but never used**: `gym_env.py` has its own inline `calculate_reward()` that ignores the `RewardSystem` class.
5. **Episode never terminates**: `terminated = False` and `truncated = False` always. Episodes only end via SB3's time limit wrapper. Agent has no goal state.
6. **Fixed 6-action space**: action space is always `Discrete(6)` regardless of what edges exist in the graph. Phase 8 requires transitioning to graph-edge-based actions.

---

## Frontend Status

### Working

- 4-tab shell (`App.tsx`)
- **Attack Graph tab**: React Flow + dagre layout + MiniMap + Controls; confirmed/unconfirmed edge styling; SIMULATED badge; node side-panel with risk score, reachable count, in/out edges
- **RL Agent tab**: Recharts reward curve + success/fail bar chart; step trace with STUB labels; honest simulation notice
- **Report tab**: executive summary; resource inventory; risk breakdown; privesc cards with ConfirmedBadge; findings sorted by severity; recommendations; PDF download; HTML preview
- **Scan tab**: AWS profile/region input; skip flags; background scan with 3s polling; post-scan stats

### Missing

- **Cloud provider selection screen** (Phase 2): must appear before any scan
- **Validation UI** (Phase 6/7): dry-run preview → confirm → execute → status
- **GCP scan configuration** (Phase 3): project ID, credential path/ADC toggle
- **React Flow is NOT installed in frontend** — the graph uses `@xyflow/react` which IS in package.json and node_modules — confirmed working
- No `react-flow-renderer` (old package) — uses correct `@xyflow/react` v12

---

## Phase Progress

- [x] Phase 0 — Audit (complete — this document)
- [x] Phase 1 — AWS Stabilization (complete — 60/60 tests pass)
- [x] Phase 2 — Cloud Provider Selection + BaseCloudProvider abstraction (complete)
- [x] Phase 3 — GCP Discovery (GCPProvider wired to gcp_pentest pipeline; scan API updated; providers endpoint updated)
- [x] Phase 4 — GCP Security Analysis (41 mock-backed tests; privesc, storage, compute, provider integration — 101 tests total)
- [x] Phase 5 — Normalized Resource Model (`models/common.py`: CloudResource, CloudFinding, AttackPath, ScanResult — Pydantic v2)
- [x] Phase 6 — Controlled AWS Validation (AWSValidator; READ_ONLY/DRY_RUN/VALIDATE modes; s3_write, s3_read, iam_pass_role; 22 tests; POST /api/validate + GET /api/validate/techniques; validation log → report)
- [x] Phase 7 — Controlled GCP Validation (READ_ONLY gate in GCPProvider.validate_finding; "Phase 7" message; no mutations)
- [x] Phase 8 — Attack Graph + Evidence Integration (GET /api/attack-graph/export/graphml; GET /api/attack-graph/export/json; GET /api/attack-graph/paths with evidence; existing edge evidence fields confirmed)
- [x] Phase 9 — Reporting (validation_results section in JSON report + HTML; `_render_validation_section`; WeasyPrint PDF already working; NOT PERFORMED label for unexecuted validations)
- [x] Phase 10 — Frontend Integration (ValidatePanel.tsx — dry-run → confirm → validate flow; new 🛡 Validate tab; graph export links; GCP now available in CloudSelect; updated client.ts)
- [x] Phase 11 — RL Environment (gym_env.py rewritten Phase 1 — loads real Phase 1 graph, edge-based actions, advancing observation, goal termination)
- [x] Phase 12 — RL Training + Evaluation (rl/evaluate.py rewritten with RandomPolicy, ShortestPathPolicy, HeuristicPolicy baselines; measurable success_rate metric; saves evaluation_results.json)
- [ ] Phase 13 — Final Testing + Demo Preparation

---

## Task Tracker

### Phase 1 — AWS Stabilization

| Task                                | Files                                                    | Purpose                                                             | Dependencies                                     | Implementation Detail                                                                                                          | Test Method                                         | Done When                                         |
| ----------------------------------- | -------------------------------------------------------- | ------------------------------------------------------------------- | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------- | ------------------------------------------------- |
| 1.1 Add general IAM findings        | `aws_pentest/iam/enumerator.py` or new `iam/analyser.py` | Detect: no MFA, unused credentials, admin users, no password policy | IAMEnumerator                                    | New `IAMAnalyser` class; call `iam:GetAccountPasswordPolicy`, `iam:GetLoginProfile`, `iam:ListMFADevices`                      | moto mock test                                      | IAM findings count > 0 in report                  |
| 1.2 Fix gym_env observation         | `env/gym_env.py`                                         | Fix static observation; agent must advance through graph            | Phase 1 complete; `aws_pentest.graph.rl_adapter` | Replace `CloudGraphBuilder` with `load_graph_for_rl(last_graph.json)`; update `current_node` after each step using graph edges | Manual train run; observation changes between steps | `obs` values differ over episode                  |
| 1.3 Fix gym_env termination         | `env/gym_env.py`                                         | Add goal state; episodes terminate meaningfully                     | Task 1.2                                         | Set `terminated=True` when agent reaches a high-privilege node (e.g., PRIVESC_TO edge target) or all edges exhausted           | Manual eval shows episode ends                      | `done=True` observed in eval                      |
| 1.4 Wire RewardSystem               | `env/gym_env.py`, `env/rewards.py`                       | Replace inline `calculate_reward`; use `RewardSystem`               | Task 1.2                                         | Import `RewardSystem`; pass `action_id` and `result` to `rs.calculate_reward()`                                                | Reward values match expected table                  | Unit test for each action type                    |
| 1.5 Fix action space to graph-based | `env/gym_env.py`, `env/actions.py`                       | Actions = real edges from current node                              | Task 1.2                                         | Replace `Discrete(6)` with `Discrete(len(nx_graph.out_edges(current_node)))`; `execute_action` maps to traversing an edge      | Observation changes; different edges at each node   | Agent chooses from valid edges only               |
| 1.6 Implement AssumeRole action     | `env/actions.py`                                         | Replace stub with real STS call or dry-run                          | Task 1.2, 1.5                                    | In READ_ONLY mode: just traverse edge, reward based on privilege gain. In VALIDATE mode: call STS                              | Unit test; confirmed in step trace                  | Action 4 returns `success: True` on allowed edges |
| 1.7 Write pytest + moto unit tests  | `tests/aws/` (create)                                    | Regression coverage for IAM/S3/EC2/graph                            | All Phase 1 modules                              | Use `moto` for IAM/S3/EC2; `unittest.mock` for simulator; test each analyser, parser, graph builder                            | `pytest tests/aws/` passes                          | CI-green test suite                               |

### Phase 2 — Cloud Provider Selection

| Task                          | Files                                              | Purpose                                    | Dependencies   | Implementation Detail                                                                                     | Test Method                   | Done When                                                |
| ----------------------------- | -------------------------------------------------- | ------------------------------------------ | -------------- | --------------------------------------------------------------------------------------------------------- | ----------------------------- | -------------------------------------------------------- |
| 2.1 Create BaseCloudProvider  | `providers/base.py` (create)                       | Abstract interface for all cloud providers | Phase 1 stable | ABC with `authenticate`, `discover_resources`, `analyze_security`, `get_attack_graph`, `validate_finding` | Import test                   | No import errors                                         |
| 2.2 Wrap AWS in AWSProvider   | `providers/aws_provider.py` (create)               | Wraps existing `aws_pentest` pipeline      | Phase 1 + 2.1  | Delegates to `IAMEnumerator`, `S3Analyser`, `EC2Analyser`, `GraphBuilder`, `ReportGenerator`              | Integration test against moto | `AWSProvider.discover_resources()` returns correct types |
| 2.3 Provider selection in API | `api/routes/scan.py`, `api/main.py`                | Route scan to correct provider             | 2.2            | Add `provider: Literal["aws","gcp"]` to `ScanRequest`; select provider class at runtime                   | API test                      | POST /api/scan with `provider=aws` works                 |
| 2.4 Frontend cloud selection  | `frontend/src/components/CloudSelect.tsx` (create) | Show [AWS] [GCP] before scan               | None           | Modal or initial screen; sets provider in app state; passed to all API calls                              | Manual UI test                | Selection persists through scan flow                     |

### Phase 3 — GCP Discovery

| Task                     | Files                                      | Purpose                                    | Dependencies | Implementation Detail                                                                       | Test Method          | Done When                           |
| ------------------------ | ------------------------------------------ | ------------------------------------------ | ------------ | ------------------------------------------------------------------------------------------- | -------------------- | ----------------------------------- |
| 3.1 Install GCP packages | `second_phase/backend/.venv`               | Required SDKs                              | None         | `pip install google-cloud-iam google-cloud-storage google-cloud-compute google-auth`        | Import test          | No ImportError                      |
| 3.2 GCP IAM enumerator   | `gcp_pentest/iam/enumerator.py` (create)   | List service accounts, roles, IAM bindings | 3.1          | Use `google.cloud.iam_admin.IAMClient`; `resourcemanager` for project IAM                   | `unittest.mock` test | Returns typed GCP IAM objects       |
| 3.3 GCP Storage analyser | `gcp_pentest/storage/analyser.py` (create) | Bucket IAM + public exposure               | 3.1          | Use `google.cloud.storage.Client`; check `allUsers`/`allAuthenticatedUsers` bindings        | `unittest.mock` test | Returns `GCPStorageFinding` objects |
| 3.4 GCP Compute analyser | `gcp_pentest/compute/analyser.py` (create) | Instances + firewall + service accounts    | 3.1          | Use `google.cloud.compute_v1`; check firewall rules for 0.0.0.0/0; instance service account | `unittest.mock` test | Returns `GCPComputeFinding` objects |

### Phase 4 — GCP Security Analysis

| Task                     | Files                          | Purpose                       | Dependencies     | Implementation Detail                                                                                  | Test Method          | Done When                       |
| ------------------------ | ------------------------------ | ----------------------------- | ---------------- | ------------------------------------------------------------------------------------------------------ | -------------------- | ------------------------------- |
| 4.1 GCP PrivEsc detector | `gcp_pentest/iam/privesc.py`   | Detect SA impersonation paths | Phase 3 complete | Check `iam.serviceAccountTokenCreator`, `iam.serviceAccountUser`, `iam.serviceAccounts.actAs` bindings | `unittest.mock` test | Returns confirmed privesc paths |
| 4.2 GCP graph builder    | `gcp_pentest/graph/builder.py` | Real-edge GCP graph           | Phase 3 complete | Build DiGraph from confirmed IAM bindings only                                                         | Unit test            | Graph has correct edge types    |

### Phase 5 — Normalized Resource Model

| Task                            | Files                       | Purpose                                          | Dependencies | Implementation Detail                                                 | Test Method                            | Done When                                     |
| ------------------------------- | --------------------------- | ------------------------------------------------ | ------------ | --------------------------------------------------------------------- | -------------------------------------- | --------------------------------------------- |
| 5.1 Create CloudResource        | `models/common.py` (create) | Shared base for AWS + GCP resources              | None         | `CloudResource`, `CloudFinding`, `AttackPath` Pydantic v2 base models | Unit test                              | Both providers can serialize to common format |
| 5.2 Update AWS models to extend | `aws_pentest/models/*.py`   | AWS models extend `CloudResource`/`CloudFinding` | 5.1          | `IAMUser`, `S3Bucket`, etc. extend `CloudResource`                    | Import test; existing tests still pass | No regressions                                |

### Phase 6 — Controlled AWS Validation

| Task                        | Files                                                | Purpose                                                | Dependencies     | Implementation Detail                                                                                 | Test Method | Done When                                     |
| --------------------------- | ---------------------------------------------------- | ------------------------------------------------------ | ---------------- | ----------------------------------------------------------------------------------------------------- | ----------- | --------------------------------------------- |
| 6.1 Safety model            | `aws_pentest/validation/safety.py` (create)          | READ_ONLY / DRY_RUN / VALIDATE mode enum + guard       | Phase 1 complete | `ValidationMode` enum; decorator `@requires_confirmation`; audit log writer                           | Unit test   | Wrong mode raises `SafetyError`               |
| 6.2 S3 write validation     | `aws_pentest/validation/s3_validator.py`             | Put/delete test object                                 | 6.1              | Named `cloud-pentest-validation/<run-id>/write-test`; put → verify → delete; log all                  | moto test   | Object created and deleted; log entry written |
| 6.3 IAM PassRole validation | `aws_pentest/validation/iam_validator.py`            | Confirm passrole path                                  | 6.1              | Dry-run: show what WOULD happen; validate: STS AssumeRole attempt against temp role                   | moto test   | Dry-run shows correct preview                 |
| 6.4 Validation API route    | `api/routes/validate.py` (create)                    | POST /api/validate/preview, POST /api/validate/execute | 6.1–6.3          | Preview requires no confirmation; execute requires `confirmed: true` body field                       | API test    | Execute without `confirmed` returns 403       |
| 6.5 Frontend validation UI  | `frontend/src/components/ValidatePanel.tsx` (create) | Dry-run preview + confirm modal                        | 6.4              | Show dry-run diff; disabled "Confirm" button until user types confirmation phrase; progress indicator | Manual test | Cannot execute without explicit confirmation  |

### Phase 7–13

Detailed task breakdown for these phases should be written when Phase 6 is complete. The pattern established by Phase 1–6 applies.

---

## Known Issues

1. **`env/gym_env.py`**: `current_node` index never advances — agent always observes state 0. RL training produces non-meaningful path data. **Must fix in Phase 1.**

2. **`env/gym_env.py`**: Uses `CloudGraphBuilder` (legacy AWS layer) not Phase 1 real graph. Training data has no connection to actual IAM topology. **Must fix before Phase 11.**

3. **`env/actions.py`**: Actions 4 (AssumeRole) and 5 (ListBucketObjects) always return `success: False`. Agent is trained with permanently unavailable actions. **Stub must be replaced in Phase 1.**

4. **`env/rewards.py`**: `RewardSystem` class is never used by `gym_env.py`. The correct discovery-based reward logic (incremental reward per new resource found) is dead code. **Wire it in Phase 1.**

5. **`api/routes/scan.py`**: `_scan_state` is a module-level mutable dict — not thread-safe for concurrent requests. Low risk for demo; should use a proper state store for production.

6. **`cloud/config.py`**: `CLOUD_PROVIDER = "aws"` and LocalStack credentials are hardcoded in source, not read from environment variables. The toggle requires a code edit. Should use `os.environ.get("CLOUD_PROVIDER", "aws")`.

7. **`second_phase/requirements.txt`**: Only lists `boto3`, `botocore`, `networkx`, `pydantic`. Missing: `fastapi`, `uvicorn`, `weasyprint`, `stable_baselines3`, `gymnasium`, `torch`. The venv has all packages but the requirements file is incomplete for fresh installs.

8. **No pytest test suite**: The `test_*.py` files in `backend/` are integration scripts that run against LocalStack, not automated pytest tests. There is no `tests/` directory, no `conftest.py`, no moto usage. **High risk for regression.**

9. **`graph/graph_utils.py`**: Not read during audit — contents unknown. Likely unused utilities or dead code. Should be reviewed.

10. **IAM findings gap**: `aws_pentest/run.py` sets `iam_findings = []` (line 157). There is no general IAM misconfiguration finder (MFA, password policy, unused credentials). Only privesc paths appear in the IAM findings section.

11. **`last_report.json` contains real account ID** (`494810891580`): This file is committed to git. Should be in `.gitignore` or replaced with a sanitized sample.

12. **Episode never terminates in RL env**: `terminated = False` and `truncated = False` always. SB3's training wrapper provides a time limit but there's no goal state. Agent can't learn to reach a target.

---

## Blocked Tasks

None currently. All Phase 1 blockers are fixable without external dependencies.

---

## Next Task for Next Agent Session

**Phases 3–12 are COMPLETE. Only Phase 13 remains.**

### What was completed this session (Phases 3–12)

**Phase 3 — GCP Discovery:**
- `providers/gcp_provider.py` — fully wired to `gcp_pentest` pipeline; `authenticate()`, `discover_resources()`, `analyze_security()`, `get_attack_graph()`, `validate_finding()`, `run_full_scan()`
- `api/routes/scan.py` — GCP path now calls `provider.run_full_scan()`; writes to `gcp_pentest/last_report.json`; `/providers` endpoint shows both as `available`
- `frontend/src/components/CloudSelect.tsx` — GCP enabled (removed `comingSoon` badge)

**Phase 4 — GCP Tests:**
- `tests/gcp/test_gcp_privesc.py` — 13 tests (all 6 techniques P01–P06, multiple members, confirmed flag)
- `tests/gcp/test_gcp_storage.py` — 8 tests (public read/write CRITICAL, UBLA MEDIUM, PAP, clean bucket)
- `tests/gcp/test_gcp_compute.py` — 10 tests (default SA HIGH, public IP MEDIUM, OS Login LOW, firewall rules, egress not flagged)
- `tests/gcp/test_gcp_provider.py` — 10 tests (auth, discover, analyze, graph, validate, read-only gate)
- **Total: 123 tests passing (was 60, added 63)**

**Phase 5 — Normalized Resource Model:**
- `models/common.py` — `CloudResource`, `CloudFinding`, `AttackPath`, `ScanResult` (Pydantic v2)
- `models/__init__.py` — exports all 4 models

**Phase 6 — Controlled AWS Validation:**
- `aws_pentest/validation/validator.py` — `ValidationMode` enum (READ_ONLY/DRY_RUN/VALIDATE), `AWSValidator`, 3 techniques: `s3_write`, `s3_read`, `iam_pass_role`; safety model enforced; cleanup in try/finally
- `api/routes/validate.py` — `POST /api/validate`, `GET /api/validate/techniques`; records VALIDATE results to `validation_log.json`
- `api/main.py` — validate_router registered
- `tests/aws/test_validation.py` — 22 tests: READ_ONLY/DRY_RUN/VALIDATE safety gates, cleanup always runs, no IAM resources created, resource naming convention

**Phase 7 — GCP Validation:**
- `GCPProvider.validate_finding()` returns `{"mode": "READ_ONLY", "status": "not_available", ...}` with "Phase 7" message — no mutations possible

**Phase 8 — Attack Graph Evidence:**
- `api/routes/graph.py` — added `GET /api/attack-graph/export/graphml`, `GET /api/attack-graph/export/json`, `GET /api/attack-graph/paths` (returns PRIVESC_TO edges with full evidence)

**Phase 9 — Reporting:**
- `api/services/report_service.py` — `_load_validation_log()`, `record_validation_result()`, validation_results in report dict, `_render_validation_section()` in HTML (shows VALIDATED/NOT PERFORMED/DENIED correctly); WeasyPrint PDF already working

**Phase 10 — Frontend:**
- `frontend/src/components/ValidatePanel.tsx` — full validation UI: technique selector, S3/IAM params, DRY RUN button, VALIDATE button (shown only after dry run), confirmation dialog, result card with evidence/audit/cleanup
- `frontend/src/App.tsx` — added `🛡 Validate` tab; imports ValidatePanel
- `frontend/src/api/client.ts` — `ValidateRequest` interface; `validateFinding()`, `fetchTechniques()`, `fetchAttackPaths()`, `fetchGraphExportUrl()`, `fetchReportPdfUrl()`
- TypeScript compile: **zero errors**

**Phase 11 — RL Environment:**
- Already done in Phase 1 (gym_env.py rewritten with real graph, advancing observation, edge-based actions)

**Phase 12 — RL Evaluation:**
- `rl/evaluate.py` — rewritten: `RandomPolicy`, `ShortestPathPolicy`, `HeuristicPolicy`; `evaluate()` function; `success_rate` metric per episode; comparison vs all baselines; saves `rl/evaluation_results.json`

### Phase 13 — Final Testing + Demo Preparation

**The only remaining phase is Phase 13.** Recommended tasks:

1. **Run a real AWS scan end-to-end:**
   ```
   cd second_phase/backend
   .venv/Scripts/python -m aws_pentest.run --profile YOUR_PROFILE --region us-east-1 \
     --output aws_pentest/last_report.json --graph-json aws_pentest/last_graph.json
   ```

2. **Train the RL agent on the real graph:**
   ```
   .venv/Scripts/python rl/train_with_logging.py
   ```

3. **Evaluate RL vs baselines:**
   ```
   .venv/Scripts/python rl/evaluate.py --episodes 200
   ```

4. **Start backend + frontend:**
   ```
   .venv/Scripts/uvicorn api.main:app --reload --port 8000
   cd ../frontend && npm run dev
   ```

5. **Demo flow:**
   - Open browser → select AWS → fill AWS profile → click Scan
   - View Attack Graph tab → check confirmed edges
   - Go to Validate tab → choose technique → Dry Run → review → Execute
   - Go to Report tab → generate → download PDF
   - Go to RL tab → start training → view episodes

6. **Run full test suite before demo:**
   ```
   .venv/Scripts/python -m pytest tests/ -v
   ```
   Must show **123+ tests passing, 0 failures.**

7. **GCP demo (if GCP credentials available):**
   - Select GCP in CloudSelect → enter project ID → click Scan
   - Validate tab shows "Phase 7 — GCP validation not yet implemented"
   - Report still generated from GCP scan data

---

## Safety Constraints (permanent — all phases)

These apply to ALL code written in every future session:

1. **Default mode is READ_ONLY.** No mutation without explicit user confirmation.
2. **Never auto-escalate.** No destructive action because a vulnerability was detected. User must click "Validate."
3. **Every active validation requires**: dry-run preview → user confirmation → execute → cleanup (on success AND failure) → audit log.
4. **Test resource naming**: `cloud-pentest-validation/<run-id>/resource-name`
5. **No hardcoded credentials, ARNs, account IDs, project IDs, or resource names** in source code.
6. **No fake or placeholder data in the production scan pipeline.** Test fixtures must live in `tests/` with clear separation.
7. **LocalStack / GCP test environment must be clearly gated** — real-cloud operations must never go to a test account accidentally, and vice versa.
8. **Do not claim "Exploited" or "Validated" without real execution evidence.**
9. **Every finding must carry a `confirmed: bool` flag.** DETECTED ≠ VERIFIED ≠ EXPLOITED.
