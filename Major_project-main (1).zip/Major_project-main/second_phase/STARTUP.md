# AWS Pentest RL — Developer Startup Guide

## Project layout after this session

```
second_phase/
├── backend/
│   ├── api/
│   │   ├── main.py                    ← FastAPI app (uvicorn entry point)
│   │   ├── routes/
│   │   │   ├── graph.py               GET /api/attack-graph[/node/{id}]
│   │   │   ├── rl.py                  GET /api/rl/status|episodes|history
│   │   │   ├── report.py              GET|POST /api/report[/pdf|/html]
│   │   │   └── scan.py                POST /api/scan, GET /api/scan/status
│   │   └── services/
│   │       ├── graph_service.py       NetworkX → React Flow JSON
│   │       ├── rl_service.py          Training log reader
│   │       └── report_service.py      HTML/PDF report generator
│   ├── rl/
│   │   ├── train.py                   Original (unchanged)
│   │   ├── train_with_logging.py      ← Use this to generate RL data
│   │   ├── training_logger.py         SB3 callback → training_log.json
│   │   └── training_log.json          Written at runtime
│   ├── aws_pentest/
│   │   ├── last_graph.json            Written by aws_pentest.run
│   │   └── last_report.json           Written by aws_pentest.run
│   └── cloud/ env/ graph/             (unchanged — RL env still uses these)
└── frontend/
    └── src/
        ├── components/
        │   ├── AttackGraph.tsx         React Flow graph, node side panel
        │   ├── RLVisualization.tsx     Training charts, step trace
        │   ├── PentestReport.tsx       Report viewer + PDF download
        │   ├── ScanPanel.tsx           Scan trigger UI
        │   └── common/Widgets.tsx      Shared UI primitives
        ├── api/client.ts               Typed axios wrappers
        ├── constants.ts                Design tokens, action names
        └── App.tsx                     Tab navigation shell
```

---

## Running the backend

```powershell
cd second_phase/backend
.venv/Scripts/uvicorn api.main:app --reload --port 8000
```

API docs auto-generated at: http://localhost:8000/docs

---

## Running the frontend

```powershell
cd second_phase/frontend
npm run dev
```

Opens at: http://localhost:5173

---

## Running an RL training session (with logging)

```powershell
cd second_phase/backend
.venv/Scripts/python rl/train_with_logging.py
```

This writes `rl/training_log.json` which the RL Visualization tab reads live.

---

## Running a real AWS scan

```powershell
cd second_phase/backend
.venv/Scripts/python -m aws_pentest.run --profile aws-pentest --output aws_pentest/last_report.json --graph-json aws_pentest/last_graph.json
```

Or trigger it from the frontend Scan tab (fills in the same files).

---

## What each UI tab shows

| Tab | Data source | Data status |
|---|---|---|
| Attack Graph | `last_graph.json` (Phase 1) or live CloudGraphBuilder | Confirmed edges shown solid; simulated edges dashed with SIMULATED badge |
| RL Agent | `rl/training_log.json` | Real training numbers; stubs labeled STUB in the step trace |
| Report | `last_report.json` (Phase 1) | All findings labeled with confirmation status; PDF download via WeasyPrint |
| Scan | Triggers `aws_pentest.run` in background | Progress polled every 3 seconds |
