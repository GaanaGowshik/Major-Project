/**
 * AppContext — single source of truth for the selected cloud provider.
 *
 * All components read `provider` from here.  When the provider changes every
 * consumer is re-rendered with the new value and fetches fresh data.
 */

import React, { createContext, useContext, useState, useCallback } from 'react';
import type { CloudProvider } from './components/CloudSelect';

interface AppState {
  /** Currently selected cloud provider (null = not yet chosen). */
  provider: CloudProvider | null;
  /**
   * Incrementing counter bumped after every completed scan.
   * Components that depend on scan results should include this in their
   * useEffect dependency arrays so they automatically reload.
   */
  scanVersion: number;
  /** Select a new provider.  Automatically increments scanVersion so all
   *  downstream components know stale data must be discarded. */
  setProvider: (p: CloudProvider) => void;
  /** Call this when a scan completes so every consumer refetches. */
  notifyScanComplete: () => void;
}

const AppContext = createContext<AppState>({
  provider: null,
  scanVersion: 0,
  setProvider: () => {},
  notifyScanComplete: () => {},
});

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [provider, setProviderState] = useState<CloudProvider | null>(() => {
    const saved = localStorage.getItem('selectedProvider') as CloudProvider | null;
    return saved === 'aws' || saved === 'gcp' ? saved : null;
  });

  const [scanVersion, setScanVersion] = useState(0);

  const setProvider = useCallback((p: CloudProvider) => {
    localStorage.setItem('selectedProvider', p);
    setProviderState(p);
    // Bump version so downstream components know to discard stale data
    setScanVersion((v) => v + 1);
  }, []);

  const notifyScanComplete = useCallback(() => {
    setScanVersion((v) => v + 1);
  }, []);

  return (
    <AppContext.Provider value={{ provider, scanVersion, setProvider, notifyScanComplete }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => useContext(AppContext);
