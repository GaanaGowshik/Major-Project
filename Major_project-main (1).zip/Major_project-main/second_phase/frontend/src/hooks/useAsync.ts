import { useState, useCallback } from 'react';

export function useAsync<T>(fn: (...args: any[]) => Promise<T>) {
  const [data, setData]     = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState<string | null>(null);

  const run = useCallback(async (...args: any[]) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fn(...args);
      setData((res as any).data ?? res);
      return (res as any).data ?? res;
    } catch (e: any) {
      setError(e?.response?.data?.detail ?? e.message ?? 'Unknown error');
      return null;
    } finally {
      setLoading(false);
    }
  }, [fn]);

  return { data, loading, error, run };
}
