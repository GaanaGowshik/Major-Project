// Centralised design tokens — no external CSS framework needed

export const COLORS = {
  bg:          '#ffffff',
  surface:     '#f7f8fa',
  border:      '#e5e7eb',
  text:        '#1f2328',
  muted:       '#57606a',
  accent:      '#3b82d4',
  success:     '#16a34a',
  warning:     '#ca8a04',
  danger:      '#dc2626',
  orange:      '#ea580c',

  CRITICAL:    '#dc2626',
  HIGH:        '#ea580c',
  MEDIUM:      '#ca8a04',
  LOW:         '#16a34a',
  INFO:        '#2563eb',

  nodeUser:    '#3b82d4',
  nodeRole:    '#7c3aed',
  nodeBucket:  '#0891b2',
  nodeEC2:     '#0d9488',
  nodeCap:     '#dc2626',
};

export const NODE_TYPE_LABEL: Record<string, string> = {
  IAMUser:   'IAM User',
  user:      'IAM User',
  IAMRole:   'IAM Role',
  role:      'IAM Role',
  S3Bucket:  'S3 Bucket',
  bucket:    'S3 Bucket',
  EC2Instance: 'EC2',
  Capability: 'Capability',
};

export const ACTION_NAMES: Record<number, string> = {
  0: 'List IAM Users',
  1: 'List IAM Roles',
  2: 'List S3 Buckets',
  3: 'Enumerate Node',
  4: 'Assume Role',
  5: 'List Bucket Objects',
};

export const ACTION_IS_STUB: Record<number, boolean> = {
  4: true,
  5: true,
};
