import React, { useEffect, useState, useCallback } from 'react';
import { triggerScan, fetchScanStatus } from '../api/client';
import { COLORS } from '../constants';
import { Spinner, ErrorBox, Card, StatCard } from './common/Widgets';
import { useAppContext } from '../AppContext';

export const ScanPanel: React.FC = () => {
  const { provider, notifyScanComplete } = useAppContext();
  // Derive effective provider — default to 'aws' if none chosen yet
  const effectiveProvider = provider ?? 'aws';
  const isGCP = effectiveProvider === 'gcp';

  const [profile,        setProfile]        = useState('');
  const [region,         setRegion]         = useState('us-east-1');
  const [regions,        setRegions]        = useState('');
  const [gcpProjectId,   setGcpProjectId]   = useState('');
  const [skipPrivesc,    setSkipPrivesc]    = useState(false);
  const [skipS3,         setSkipS3]         = useState(false);
  const [submitting,     setSubmitting]     = useState(false);
  const [scanStatus,     setScanStatus]     = useState<any>(null);
  const [error,          setError]          = useState<string | null>(null);

  /**
   * Poll /api/scan/status until it reaches a terminal state.
   * When complete, call notifyScanComplete() so AttackGraph and
   * PentestReport automatically reload with fresh data.
   */
  const pollStatus = useCallback(async () => {
    try {
      const r = await fetchScanStatus();
      setScanStatus(r.data);
      if (r.data.status === 'running') {
        setTimeout(pollStatus, 3000);
      } else if (r.data.status === 'complete') {
        // Notify context — bumps scanVersion so all consumers reload
        notifyScanComplete();
      }
    } catch (_) {
      // polling failure — silently stop
    }
  }, [notifyScanComplete]);

  // Fetch current scan status when the panel first mounts
  useEffect(() => { pollStatus(); }, []);   // intentionally only on mount

  const handleScan = async () => {
    setSubmitting(true);
    setError(null);
    try {
      await triggerScan({
        provider: effectiveProvider,
        profile:          profile || undefined,
        region:           region  || undefined,
        regions:          regions || undefined,
        skip_privesc:     skipPrivesc,
        skip_s3_iam_xref: skipS3,
        gcp_project_id:   isGCP ? (gcpProjectId || undefined) : undefined,
      });
      setTimeout(pollStatus, 1000);
    } catch (e: any) {
      setError(e.response?.data?.detail ?? e.message);
    } finally {
      setSubmitting(false);
    }
  };

  const statusColorMap: Record<string, string> = {
    idle:     COLORS.muted,
    running:  COLORS.accent,
    complete: COLORS.success,
    error:    COLORS.danger,
  };
  const statusColor = statusColorMap[scanStatus?.status ?? 'idle'] ?? COLORS.muted;

  return (
    <div style={{ padding: '20px 24px', overflowY: 'auto', height: '100%', maxWidth: 620 }}>
      <strong style={{ fontSize: 17, display: 'block', marginBottom: 20 }}>
        Run {isGCP ? 'GCP' : 'AWS'} Scan
      </strong>

      <div style={{ background: '#fff8ed', border: '1px solid #fed7aa', borderLeft: `4px solid ${COLORS.warning}`, padding: '10px 14px', borderRadius: '0 6px 6px 0', fontSize: 13, marginBottom: 20 }}>
        <strong>Read-only mode only.</strong> This scan uses{' '}
        {isGCP
          ? 'GCP IAM, Cloud Storage, and Compute Engine APIs.'
          : <><code style={{ fontSize: 11 }}>iam:SimulatePrincipalPolicy</code> and other read-only APIs.</>
        }{' '}
        No cloud resources are created, modified, or deleted.
        Run only against accounts you own.
      </div>

      {error && <div style={{ marginBottom: 16 }}><ErrorBox message={error} /></div>}

      {/* Status */}
      {scanStatus && (
        <Card style={{ marginBottom: 20 }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: scanStatus.summary ? 12 : 0 }}>
            <span style={{ width: 10, height: 10, borderRadius: '50%', background: statusColor, display: 'inline-block' }} />
            <span style={{ fontSize: 13, fontWeight: 600, color: statusColor, textTransform: 'capitalize' }}>
              {scanStatus.status}
            </span>
            {scanStatus.status === 'running' && <Spinner />}
          </div>
          {scanStatus.message && (
            <div style={{ fontSize: 13, color: COLORS.muted, marginTop: 6 }}>{scanStatus.message}</div>
          )}
          {scanStatus.summary && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginTop: 14 }}>
              <StatCard label="Users"    value={scanStatus.summary.iam_users    ?? scanStatus.summary.service_accounts ?? 0} />
              <StatCard label="Roles"    value={scanStatus.summary.iam_roles    ?? 0} />
              <StatCard label="Buckets"  value={scanStatus.summary.s3_buckets   ?? scanStatus.summary.storage_buckets ?? 0} />
              <StatCard label="Findings" value={scanStatus.summary.total_findings ?? 0} accent={COLORS.warning} />
            </div>
          )}
        </Card>
      )}

      {/* Form */}
      <Card>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

          {/* GCP-specific: Project ID */}
          {isGCP && (
            <label style={{ fontSize: 13 }}>
              <div style={{ fontWeight: 600, marginBottom: 5 }}>
                GCP Project ID <span style={{ color: COLORS.danger }}>*</span>
              </div>
              <input
                value={gcpProjectId}
                onChange={(e) => setGcpProjectId(e.target.value)}
                placeholder="e.g. my-project-123456"
                style={{ width: '100%', padding: '7px 10px', borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 13 }}
              />
              <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 3 }}>
                Uses Application Default Credentials (ADC) or GOOGLE_APPLICATION_CREDENTIALS env var.
              </div>
            </label>
          )}

          {/* AWS-specific: Profile */}
          {!isGCP && (
            <label style={{ fontSize: 13 }}>
              <div style={{ fontWeight: 600, marginBottom: 5 }}>AWS Profile (optional)</div>
              <input
                value={profile}
                onChange={(e) => setProfile(e.target.value)}
                placeholder="e.g. aws-pentest"
                style={{ width: '100%', padding: '7px 10px', borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 13 }}
              />
            </label>
          )}

          {/* AWS-specific: Region */}
          {!isGCP && (
            <label style={{ fontSize: 13 }}>
              <div style={{ fontWeight: 600, marginBottom: 5 }}>Primary Region</div>
              <input
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                placeholder="us-east-1"
                style={{ width: '100%', padding: '7px 10px', borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 13 }}
              />
            </label>
          )}

          {/* AWS-specific: Multi-region EC2 */}
          {!isGCP && (
            <label style={{ fontSize: 13 }}>
              <div style={{ fontWeight: 600, marginBottom: 5 }}>EC2 Regions (comma-separated, optional)</div>
              <input
                value={regions}
                onChange={(e) => setRegions(e.target.value)}
                placeholder="us-east-1,eu-west-1"
                style={{ width: '100%', padding: '7px 10px', borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 13 }}
              />
            </label>
          )}

          <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
              <input type="checkbox" checked={skipPrivesc} onChange={(e) => setSkipPrivesc(e.target.checked)} />
              Skip PrivEsc detection (faster)
            </label>
            {!isGCP && (
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
                <input type="checkbox" checked={skipS3} onChange={(e) => setSkipS3(e.target.checked)} />
                Skip S3 × IAM cross-reference
              </label>
            )}
          </div>

          <button
            onClick={handleScan}
            disabled={submitting || scanStatus?.status === 'running' || (isGCP && !gcpProjectId.trim())}
            style={{
              padding: '9px 0', borderRadius: 6, border: 'none',
              background: (submitting || scanStatus?.status === 'running' || (isGCP && !gcpProjectId.trim())) ? COLORS.muted : COLORS.accent,
              color: '#fff', fontWeight: 700, fontSize: 14, cursor: 'pointer',
            }}
          >
            {submitting ? 'Starting…' : scanStatus?.status === 'running' ? `⏳ ${isGCP ? 'GCP ' : ''}Scan Running…` : `▶ Start ${isGCP ? 'GCP' : 'AWS'} Scan`}
          </button>
        </div>
      </Card>
    </div>
  );
};
