/**
 * CloudSelect — Cloud provider selection screen.
 *
 * Shown as a modal overlay before the user can access any scan or graph tab.
 * The selected provider is stored in parent app state and passed to all API calls.
 */

import React, { useState } from 'react';
import { COLORS } from '../constants';

export type CloudProvider = 'aws' | 'gcp';

interface ProviderCard {
  id: CloudProvider;
  name: string;
  description: string;
  icon: string;
  available: boolean;
  comingSoon?: string;
}

const PROVIDERS: ProviderCard[] = [
  {
    id: 'aws',
    name: 'Amazon Web Services',
    description:
      'IAM users, roles & groups · S3 buckets · EC2 instances · ' +
      'Real IAM Policy Simulator verification · Privilege escalation detection',
    icon: '☁',
    available: true,
  },
  {
    id: 'gcp',
    name: 'Google Cloud Platform',
    description:
      'Service accounts · IAM bindings · Cloud Storage · Compute Engine · ' +
      'Privilege escalation via service account impersonation',
    icon: '🌐',
    available: true,
  },
];

interface CloudSelectProps {
  onSelect: (provider: CloudProvider) => void;
}

export const CloudSelect: React.FC<CloudSelectProps> = ({ onSelect }) => {
  const [hovered, setHovered] = useState<CloudProvider | null>(null);

  return (
    /* Full-screen overlay */
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.55)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
      }}
    >
      <div
        style={{
          background: '#fff',
          borderRadius: 12,
          padding: '36px 40px',
          width: 560,
          boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
        }}
      >
        {/* Header */}
        <div style={{ marginBottom: 28 }}>
          <div
            style={{
              fontSize: 22,
              fontWeight: 800,
              letterSpacing: -0.5,
              marginBottom: 6,
            }}
          >
            ☁ Multi-Cloud Pentest Platform
          </div>
          <div style={{ fontSize: 14, color: COLORS.muted, lineHeight: 1.5 }}>
            Select a cloud provider to begin the security assessment.
            Discovery is <strong>read-only</strong> by default — no resources
            will be created or modified.
          </div>
        </div>

        {/* Provider cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {PROVIDERS.map((p) => {
            const isHovered = hovered === p.id;
            return (
              <button
                key={p.id}
                onClick={() => p.available && onSelect(p.id)}
                onMouseEnter={() => setHovered(p.id)}
                onMouseLeave={() => setHovered(null)}
                disabled={!p.available}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: 16,
                  padding: '18px 20px',
                  border: `2px solid ${
                    isHovered && p.available ? COLORS.accent : COLORS.border
                  }`,
                  borderRadius: 8,
                  background: p.available
                    ? isHovered
                      ? '#f0f7ff'
                      : '#fff'
                    : COLORS.surface,
                  cursor: p.available ? 'pointer' : 'not-allowed',
                  textAlign: 'left',
                  transition: 'border-color 0.15s, background 0.15s',
                  opacity: p.available ? 1 : 0.6,
                }}
              >
                <span style={{ fontSize: 28, lineHeight: 1 }}>{p.icon}</span>
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 8,
                      marginBottom: 5,
                    }}
                  >
                    <span
                      style={{ fontSize: 15, fontWeight: 700, color: COLORS.text }}
                    >
                      {p.name}
                    </span>
                    {p.comingSoon && (
                      <span
                        style={{
                          fontSize: 10,
                          background: '#e0f2fe',
                          color: '#0369a1',
                          padding: '2px 7px',
                          borderRadius: 10,
                          fontWeight: 600,
                        }}
                      >
                        {p.comingSoon}
                      </span>
                    )}
                    {p.available && (
                      <span
                        style={{
                          fontSize: 10,
                          background: '#dcfce7',
                          color: '#15803d',
                          padding: '2px 7px',
                          borderRadius: 10,
                          fontWeight: 600,
                        }}
                      >
                        Available
                      </span>
                    )}
                  </div>
                  <div
                    style={{
                      fontSize: 12,
                      color: COLORS.muted,
                      lineHeight: 1.5,
                    }}
                  >
                    {p.description}
                  </div>
                </div>
                {p.available && (
                  <span
                    style={{
                      fontSize: 20,
                      color: isHovered ? COLORS.accent : COLORS.border,
                      alignSelf: 'center',
                      flexShrink: 0,
                      transition: 'color 0.15s',
                    }}
                  >
                    →
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer note */}
        <div
          style={{
            marginTop: 20,
            fontSize: 11,
            color: COLORS.muted,
            textAlign: 'center',
            borderTop: `1px solid ${COLORS.border}`,
            paddingTop: 14,
          }}
        >
          Run only against accounts you own or have written authorisation to test.
        </div>
      </div>
    </div>
  );
};
