/**
 * ValidatePanel — Controlled Finding Validation UI.
 *
 * Implements the three-level safety model:
 *   READ_ONLY  — describe what would be tested (default)
 *   DRY_RUN    — show exact AWS calls, no execution
 *   VALIDATE   — execute with user confirmation after dry-run preview
 *
 * Safety UX invariants:
 *   1. Technique + params are filled in first.
 *   2. Always start with DRY_RUN to show preview.
 *   3. VALIDATE button only appears after dry-run completes.
 *   4. A confirmation dialog appears before VALIDATE executes.
 *   5. Result shows confirmed: true ONLY when execution succeeded.
 *   6. "NOT PERFORMED" is shown for unexecuted actions.
 */

import React, { useState } from 'react';
import { COLORS } from '../constants';
import { validateFinding, fetchGraphExportUrl } from '../api/client';
import type { ValidateRequest } from '../api/client';

type Technique = 's3_write' | 's3_read' | 'iam_pass_role';
type Mode = 'READ_ONLY' | 'DRY_RUN' | 'VALIDATE';

interface ValidationResult {
  finding_id: string;
  technique: string;
  mode: string;
  status: string;
  confirmed: boolean;
  description: string;
  dry_run_preview: string[];
  evidence: Record<string, unknown>[];
  cleanup_done: boolean;
  audit_log: Record<string, unknown>[];
  run_id?: string;
  error?: string;
}

const TECHNIQUE_LABELS: Record<Technique, string> = {
  s3_write: 'S3 Write Validation',
  s3_read: 'S3 Read Validation',
  iam_pass_role: 'IAM PassRole Validation',
};

const STATUS_STYLES: Record<string, { color: string; label: string }> = {
  success: { color: '#16a34a', label: '✓ VALIDATED' },
  failure: { color: '#ea580c', label: '✗ DENIED (access blocked)' },
  dry_run_preview: { color: '#2563eb', label: 'DRY RUN PREVIEW' },
  not_performed: { color: '#ca8a04', label: 'NOT PERFORMED' },
  error: { color: '#dc2626', label: 'ERROR' },
};

export const ValidatePanel: React.FC = () => {
  const [technique, setTechnique] = useState<Technique>('s3_write');
  const [findingId, setFindingId] = useState('');
  const [bucketName, setBucketName] = useState('');
  const [roleArn, setRoleArn] = useState('');
  const [profile, setProfile] = useState('');
  const [region, setRegion] = useState('us-east-1');

  const [loading, setLoading] = useState(false);
  const [dryRunResult, setDryRunResult] = useState<ValidationResult | null>(null);
  const [validateResult, setValidateResult] = useState<ValidationResult | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const buildRequest = (mode: Mode, confirmed = false): ValidateRequest => ({
    finding_id: findingId || `manual-${technique}`,
    technique,
    mode,
    confirmed,
    profile: profile || undefined,
    region: region || 'us-east-1',
    bucket_name: (technique === 's3_write' || technique === 's3_read') ? bucketName : undefined,
    role_arn: technique === 'iam_pass_role' ? roleArn : undefined,
  });

  const handleDryRun = async () => {
    setLoading(true);
    setError(null);
    setDryRunResult(null);
    setValidateResult(null);
    try {
      const resp = await validateFinding(buildRequest('DRY_RUN'));
      setDryRunResult(resp.data as ValidationResult);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  const handleValidate = () => {
    setShowConfirmDialog(true);
  };

  const handleConfirmedValidate = async () => {
    setShowConfirmDialog(false);
    setLoading(true);
    setError(null);
    try {
      const resp = await validateFinding(buildRequest('VALIDATE', true));
      setValidateResult(resp.data as ValidationResult);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: 24, maxWidth: 800, margin: '0 auto' }}>

      {/* Title */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>
          🛡 Controlled Validation
        </div>
        <div style={{ fontSize: 13, color: COLORS.muted, lineHeight: 1.5 }}>
          Test specific attack paths with explicit confirmation.
          Default mode is <strong>DRY Run</strong> — no resources are created until you confirm.
          All validations are cleaned up automatically.
        </div>
      </div>

      {/* Safety banner */}
      <div style={{
        background: '#fff8ed', border: '1px solid #e6a817', borderRadius: 6,
        padding: '10px 14px', marginBottom: 20, fontSize: 12,
      }}>
        <strong>Safety Model:</strong> READ_ONLY (default) → DRY_RUN (preview) → VALIDATE (execute with cleanup).
        No AWS resource is created or modified without explicit confirmation.
      </div>

      {/* Form */}
      <div style={{
        background: COLORS.surface, border: `1px solid ${COLORS.border}`,
        borderRadius: 8, padding: 20, marginBottom: 20,
      }}>
        <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>
          Validation Parameters
        </div>

        {/* Technique selector */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
            Technique
          </label>
          <select
            value={technique}
            onChange={e => setTechnique(e.target.value as Technique)}
            style={{
              width: '100%', padding: '7px 10px', border: `1px solid ${COLORS.border}`,
              borderRadius: 6, fontSize: 13, background: '#fff',
            }}
          >
            {(Object.entries(TECHNIQUE_LABELS) as [Technique, string][]).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </select>
        </div>

        {/* Finding ID */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
            Finding ID (optional — for tracking in report)
          </label>
          <input
            type="text"
            value={findingId}
            onChange={e => setFindingId(e.target.value)}
            placeholder="e.g. finding-001"
            style={{
              width: '100%', padding: '7px 10px', border: `1px solid ${COLORS.border}`,
              borderRadius: 6, fontSize: 13, boxSizing: 'border-box',
            }}
          />
        </div>

        {/* S3 bucket name */}
        {(technique === 's3_write' || technique === 's3_read') && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              S3 Bucket Name <span style={{ color: COLORS.danger }}>*</span>
            </label>
            <input
              type="text"
              value={bucketName}
              onChange={e => setBucketName(e.target.value)}
              placeholder="e.g. my-test-bucket"
              style={{
                width: '100%', padding: '7px 10px', border: `1px solid ${COLORS.border}`,
                borderRadius: 6, fontSize: 13, boxSizing: 'border-box',
              }}
            />
          </div>
        )}

        {/* Role ARN */}
        {technique === 'iam_pass_role' && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              Role ARN <span style={{ color: COLORS.danger }}>*</span>
            </label>
            <input
              type="text"
              value={roleArn}
              onChange={e => setRoleArn(e.target.value)}
              placeholder="arn:aws:iam::ACCOUNT:role/ROLE-NAME"
              style={{
                width: '100%', padding: '7px 10px', border: `1px solid ${COLORS.border}`,
                borderRadius: 6, fontSize: 13, boxSizing: 'border-box',
              }}
            />
          </div>
        )}

        {/* AWS profile + region */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
          <div>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              AWS Profile (optional)
            </label>
            <input
              type="text"
              value={profile}
              onChange={e => setProfile(e.target.value)}
              placeholder="default"
              style={{
                width: '100%', padding: '7px 10px', border: `1px solid ${COLORS.border}`,
                borderRadius: 6, fontSize: 13, boxSizing: 'border-box',
              }}
            />
          </div>
          <div>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              AWS Region
            </label>
            <input
              type="text"
              value={region}
              onChange={e => setRegion(e.target.value)}
              placeholder="us-east-1"
              style={{
                width: '100%', padding: '7px 10px', border: `1px solid ${COLORS.border}`,
                borderRadius: 6, fontSize: 13, boxSizing: 'border-box',
              }}
            />
          </div>
        </div>

        {/* DRY RUN button */}
        <button
          onClick={handleDryRun}
          disabled={loading}
          style={{
            padding: '8px 20px', background: COLORS.accent, color: '#fff',
            border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
            cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1,
            marginRight: 10,
          }}
        >
          {loading ? 'Running…' : '🔍 Dry Run Preview'}
        </button>

        {/* VALIDATE button — only shown after dry run */}
        {dryRunResult && !validateResult && (
          <button
            onClick={handleValidate}
            disabled={loading}
            style={{
              padding: '8px 20px', background: '#dc2626', color: '#fff',
              border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
              cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1,
            }}
          >
            ⚡ Execute Validation
          </button>
        )}
      </div>

      {/* Error */}
      {error && (
        <div style={{
          background: '#fef2f2', border: '1px solid #fca5a5', borderRadius: 6,
          padding: '10px 14px', marginBottom: 16, fontSize: 13, color: '#dc2626',
        }}>
          Error: {error}
        </div>
      )}

      {/* Dry run result */}
      {dryRunResult && (
        <ResultCard result={dryRunResult} title="Dry Run Preview" />
      )}

      {/* Validate result */}
      {validateResult && (
        <ResultCard result={validateResult} title="Validation Result" />
      )}

      {/* Graph export links */}
      <div style={{
        marginTop: 28, paddingTop: 16, borderTop: `1px solid ${COLORS.border}`,
        display: 'flex', gap: 12, alignItems: 'center',
      }}>
        <span style={{ fontSize: 12, color: COLORS.muted }}>Export graph:</span>
        <a
          href={fetchGraphExportUrl('graphml')}
          download="attack_graph.graphml"
          style={{ fontSize: 12, color: COLORS.accent }}
        >
          GraphML (Gephi/yEd)
        </a>
        <a
          href={fetchGraphExportUrl('json')}
          download="attack_graph.json"
          style={{ fontSize: 12, color: COLORS.accent }}
        >
          JSON
        </a>
        <a
          href="http://localhost:8000/api/report/pdf"
          download="pentest_report.pdf"
          style={{ fontSize: 12, color: COLORS.accent }}
        >
          PDF Report
        </a>
      </div>

      {/* Confirmation dialog */}
      {showConfirmDialog && dryRunResult && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2000,
        }}>
          <div style={{
            background: '#fff', borderRadius: 10, padding: 28, width: 480,
            boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
          }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 12, color: '#dc2626' }}>
              ⚠ Confirm Controlled Validation
            </div>
            <div style={{ fontSize: 13, marginBottom: 16, color: COLORS.text, lineHeight: 1.5 }}>
              This will execute the following AWS API calls against real cloud resources.
              Test objects will be created under <code>cloud-pentest-validation/</code> and
              cleaned up automatically.
            </div>
            <div style={{
              background: COLORS.surface, borderRadius: 6, padding: 12, marginBottom: 16,
            }}>
              {dryRunResult.dry_run_preview.map((step, i) => (
                <div key={i} style={{ fontFamily: 'monospace', fontSize: 12, padding: '2px 0' }}>
                  {step}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button
                onClick={() => setShowConfirmDialog(false)}
                style={{
                  padding: '7px 18px', border: `1px solid ${COLORS.border}`,
                  borderRadius: 6, background: '#fff', cursor: 'pointer', fontSize: 13,
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmedValidate}
                style={{
                  padding: '7px 18px', background: '#dc2626', color: '#fff',
                  border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13,
                  fontWeight: 600,
                }}
              >
                Confirm — Execute
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface ResultCardProps {
  result: ValidationResult;
  title: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, title }) => {
  const statusInfo = STATUS_STYLES[result.status] ?? { color: COLORS.muted, label: result.status };

  return (
    <div style={{
      border: `1px solid ${COLORS.border}`, borderRadius: 8,
      marginBottom: 16, overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 16px', background: COLORS.surface,
        borderBottom: `1px solid ${COLORS.border}`,
      }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>{title}</div>
        <div style={{ fontWeight: 700, fontSize: 13, color: statusInfo.color }}>
          {statusInfo.label}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 13, color: COLORS.text, marginBottom: 12 }}>
          {result.description}
        </div>

        {/* Dry run steps */}
        {result.dry_run_preview?.length > 0 && (
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.muted, marginBottom: 6 }}>
              AWS API Calls
            </div>
            <div style={{
              background: '#f8f9fa', borderRadius: 4, padding: '8px 12px',
              fontFamily: 'Consolas, monospace', fontSize: 11.5,
            }}>
              {result.dry_run_preview.map((step, i) => (
                <div key={i} style={{ padding: '1px 0', color: '#374151' }}>{step}</div>
              ))}
            </div>
          </div>
        )}

        {/* Confirmed flag */}
        {result.mode === 'VALIDATE' && (
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 10px', borderRadius: 14, fontSize: 12, fontWeight: 600,
            background: result.confirmed ? '#dcfce7' : '#fef2f2',
            color: result.confirmed ? '#15803d' : '#dc2626',
            marginBottom: 10,
          }}>
            {result.confirmed ? '✓ Execution confirmed' : '✗ Execution not confirmed'}
          </div>
        )}

        {/* Evidence */}
        {result.evidence?.length > 0 && (
          <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.muted, marginBottom: 4 }}>
              Evidence ({result.evidence.length} item{result.evidence.length !== 1 ? 's' : ''})
            </div>
            {result.evidence.map((ev, i) => (
              <div key={i} style={{
                fontFamily: 'monospace', fontSize: 11, background: '#f0f0f0',
                padding: '4px 8px', borderRadius: 4, marginBottom: 4,
              }}>
                {JSON.stringify(ev)}
              </div>
            ))}
          </div>
        )}

        {/* Cleanup status */}
        <div style={{ fontSize: 12, color: COLORS.muted }}>
          Cleanup: {result.cleanup_done
            ? <span style={{ color: '#16a34a' }}>Complete</span>
            : <span style={{ color: '#dc2626' }}>Not completed — check audit log</span>
          }
          {result.run_id && <span style={{ marginLeft: 12 }}>Run ID: <code>{result.run_id}</code></span>}
        </div>

        {/* Error */}
        {result.error && (
          <div style={{
            marginTop: 8, padding: '6px 10px', background: '#fef2f2',
            borderRadius: 4, fontSize: 12, color: '#dc2626',
            fontFamily: 'monospace',
          }}>
            {result.error}
          </div>
        )}
      </div>
    </div>
  );
};
