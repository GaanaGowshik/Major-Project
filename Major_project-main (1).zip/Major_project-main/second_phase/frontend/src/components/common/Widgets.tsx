import React from 'react';
import { COLORS } from '../../constants';

type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export const SeverityBadge: React.FC<{ severity: string }> = ({ severity }) => {
  const color = COLORS[severity as Severity] ?? COLORS.muted;
  return (
    <span style={{
      background: color, color: '#fff', padding: '2px 9px',
      borderRadius: 10, fontSize: 11, fontWeight: 700, whiteSpace: 'nowrap',
    }}>
      {severity}
    </span>
  );
};

export const ConfirmedBadge: React.FC<{ confirmed: boolean }> = ({ confirmed }) => (
  <span style={{
    background: confirmed ? '#dcfce7' : '#fef9c3',
    color: confirmed ? '#166534' : '#854d0e',
    border: `1px solid ${confirmed ? '#86efac' : '#fde047'}`,
    padding: '1px 7px', borderRadius: 8, fontSize: 11, fontWeight: 600,
  }}>
    {confirmed ? '✓ Confirmed' : '⚠ Simulated'}
  </span>
);

export const Spinner: React.FC = () => (
  <div style={{ display: 'flex', justifyContent: 'center', padding: 32 }}>
    <div style={{
      width: 32, height: 32, borderRadius: '50%',
      border: `3px solid ${COLORS.border}`,
      borderTopColor: COLORS.accent,
      animation: 'spin 0.7s linear infinite',
    }} />
    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
  </div>
);

export const ErrorBox: React.FC<{ message: string }> = ({ message }) => (
  <div style={{
    background: '#fee2e2', border: '1px solid #fca5a5',
    borderRadius: 6, padding: '10px 14px', color: '#991b1b', fontSize: 13,
  }}>
    ⚠ {message}
  </div>
);

export const Card: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <div style={{
    background: COLORS.surface, border: `1px solid ${COLORS.border}`,
    borderRadius: 8, padding: 16, ...style,
  }}>
    {children}
  </div>
);

export const StatCard: React.FC<{ label: string; value: string | number; accent?: string }> = ({
  label, value, accent,
}) => (
  <div style={{
    background: COLORS.surface, border: `1px solid ${COLORS.border}`,
    borderRadius: 8, padding: '12px 16px', textAlign: 'center',
  }}>
    <div style={{ fontSize: 26, fontWeight: 700, color: accent ?? COLORS.accent }}>{value}</div>
    <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>{label}</div>
  </div>
);
