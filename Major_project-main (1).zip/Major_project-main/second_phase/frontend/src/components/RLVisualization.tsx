import React, { useEffect, useState, useCallback } from 'react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip,
  CartesianGrid, ResponsiveContainer, ReferenceLine,
} from 'recharts';
import { fetchRLStatus, fetchRLEpisodes, fetchRLHistory } from '../api/client';
import { COLORS, ACTION_NAMES, ACTION_IS_STUB } from '../constants';
import { Spinner, ErrorBox, Card, StatCard } from './common/Widgets';

// ── Sub-components ────────────────────────────────────────────────────────

const SimulationNotice: React.FC = () => (
  <div style={{
    background: '#fff8ed', border: '1px solid #fed7aa',
    borderLeft: `4px solid ${COLORS.warning}`, borderRadius: 6,
    padding: '10px 14px', marginBottom: 16, fontSize: 13,
  }}>
    <strong>Simulation Notice:</strong>{' '}
    Actions <code style={{ fontSize: 11 }}>4 (AssumeRole)</code> and{' '}
    <code style={{ fontSize: 11 }}>5 (ListBucketObjects)</code> are stubs that
    always fail and never call real AWS APIs. All reward and path data reflects
    this limitation. The agent navigates nodes but does not change AWS state.
  </div>
);

const StepRow: React.FC<{ step: any; index: number }> = ({ step, index }) => {
  const isStub = ACTION_IS_STUB[step.action as number] ?? false;

  return (
    <div style={{
      display: 'flex', gap: 12, padding: '8px 12px',
      background: index % 2 === 0 ? '#fff' : COLORS.surface,
      borderBottom: `1px solid ${COLORS.border}`,
      alignItems: 'flex-start',
    }}>
      <div style={{ minWidth: 28, color: COLORS.muted, fontSize: 12, paddingTop: 2 }}>
        {step.step ?? index}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 3 }}>
          <span style={{ fontSize: 12, fontWeight: 700 }}>
            {ACTION_NAMES[step.action as number] ?? `Action ${step.action}`}
          </span>
          {isStub && (
            <span style={{ fontSize: 10, background: '#fef9c3', color: '#854d0e', padding: '1px 6px', borderRadius: 6, border: '1px solid #fde047' }}>
              STUB
            </span>
          )}
          <span style={{
            fontSize: 11, fontWeight: 700,
            color: step.reward >= 0 ? COLORS.success : COLORS.danger,
          }}>
            {step.reward >= 0 ? '+' : ''}{typeof step.reward === 'number' ? step.reward.toFixed(1) : step.reward}
          </span>
        </div>
        {step.node && (
          <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 2 }}>
            Node: <code style={{ fontSize: 11 }}>{step.node}</code>
          </div>
        )}
        <div style={{ fontSize: 11, color: COLORS.muted, fontStyle: 'italic' }}>
          {step.actionReason}
        </div>
      </div>
    </div>
  );
};

const PathViz: React.FC<{ steps: any[] }> = ({ steps }) => {
  const pathNodes = steps.filter((s) => s.node).map((s) => s.node);
  if (!pathNodes.length) return null;

  const unique = [...new Set(pathNodes)];
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.muted, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 }}>
        Decision Path
      </div>
      <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 0 }}>
        {unique.map((node, i) => (
          <React.Fragment key={i}>
            <div style={{
              background: '#e0f2fe', border: '1px solid #7dd3fc',
              borderRadius: 6, padding: '4px 10px', fontSize: 12, fontWeight: 600, color: '#0369a1',
            }}>
              {String(node).split('/').pop()}
            </div>
            {i < unique.length - 1 && (
              <span style={{ color: COLORS.muted, fontSize: 18, margin: '0 4px' }}>→</span>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

// ── Main component ────────────────────────────────────────────────────────

export const RLVisualization: React.FC = () => {
  const [status, setStatus]         = useState<any>(null);
  const [episodes, setEpisodes]     = useState<any[]>([]);
  const [history, setHistory]       = useState<any[]>([]);
  const [selectedEp, setSelectedEp] = useState<number | null>(null);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [sRes, eRes] = await Promise.all([fetchRLStatus(), fetchRLEpisodes()]);
      setStatus(sRes.data);
      setEpisodes(eRes.data ?? []);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const loadHistory = useCallback(async (ep?: number) => {
    try {
      const r = await fetchRLHistory(ep);
      setHistory(r.data ?? []);
    } catch (_) {}
  }, []);

  useEffect(() => {
    if (episodes.length) {
      const ep = selectedEp ?? episodes[episodes.length - 1]?.episode;
      loadHistory(ep);
    }
  }, [episodes, selectedEp]);

  const rewardData = episodes.map((ep) => ({
    episode: ep.episode,
    reward: parseFloat(ep.totalReward?.toFixed(1)),
    avg: parseFloat(ep.avgReward?.toFixed(1)),
  }));

  const successData = episodes.map((ep) => ({
    episode: ep.episode,
    success: ep.successActions,
    failed: ep.failedActions,
  }));

  if (loading) return <Spinner />;
  if (error)   return <div style={{ padding: 20 }}><ErrorBox message={error} /></div>;

  const noData = !status?.is_trained && episodes.length === 0;

  return (
    <div style={{ padding: '20px 24px', overflowY: 'auto', height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <strong style={{ fontSize: 17 }}>RL Agent Visualization</strong>
        <button onClick={load} style={{ padding: '5px 14px', borderRadius: 6, border: `1px solid ${COLORS.border}`, background: COLORS.accent, color: '#fff', cursor: 'pointer', fontSize: 13 }}>
          ↺ Refresh
        </button>
      </div>

      <SimulationNotice />

      {noData ? (
        <Card>
          <div style={{ color: COLORS.muted, fontSize: 14, textAlign: 'center', padding: 32 }}>
            No training data found. Run <code>rl/train_with_logging.py</code> to generate RL data.
          </div>
        </Card>
      ) : (
        <>
          {/* Status summary */}
          {status && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
              <StatCard label="Episodes" value={episodes.length} />
              <StatCard label="Total Timesteps" value={status.total_timesteps ?? 0} />
              <StatCard label="Last Reward" value={(status.reward ?? 0).toFixed(1)} accent={COLORS.accent} />
              <StatCard label="Cumulative Reward" value={(status.cumulative_reward ?? 0).toFixed(1)} accent={COLORS.success} />
            </div>
          )}

          {/* Reward chart */}
          {rewardData.length > 0 && (
            <Card style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Reward per Episode</div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={rewardData} margin={{ top: 4, right: 16, bottom: 4, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
                  <XAxis dataKey="episode" tick={{ fontSize: 11 }} label={{ value: 'Episode', position: 'insideBottomRight', offset: -5, fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <ReferenceLine y={0} stroke={COLORS.muted} strokeDasharray="4 2" />
                  <Line type="monotone" dataKey="reward" stroke={COLORS.accent} dot={false} strokeWidth={2} name="Total Reward" />
                  <Line type="monotone" dataKey="avg" stroke={COLORS.success} dot={false} strokeWidth={1.5} strokeDasharray="4 2" name="Avg Reward/Step" />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          )}

          {/* Success/fail chart */}
          {successData.length > 0 && (
            <Card style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Action Outcomes per Episode</div>
              <div style={{ fontSize: 11, color: COLORS.warning, marginBottom: 8 }}>
                ⚠ Actions 4 & 5 always fail (stubs) — their failures are included in the counts below.
              </div>
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={successData} margin={{ top: 4, right: 16, bottom: 4, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
                  <XAxis dataKey="episode" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="success" fill={COLORS.success} name="Successful" />
                  <Bar dataKey="failed" fill={COLORS.danger} name="Failed" />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          )}

          {/* Episode history */}
          {episodes.length > 0 && (
            <Card style={{ marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>Step Trace</div>
                <select
                  value={selectedEp ?? ''}
                  onChange={(e) => {
                    const v = parseInt(e.target.value);
                    setSelectedEp(isNaN(v) ? null : v);
                    loadHistory(isNaN(v) ? undefined : v);
                  }}
                  style={{ padding: '4px 8px', borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 12 }}
                >
                  {episodes.map((ep) => (
                    <option key={ep.episode} value={ep.episode}>Episode {ep.episode} (reward {ep.totalReward?.toFixed(1)})</option>
                  ))}
                </select>
              </div>

              <PathViz steps={history} />

              <div style={{ maxHeight: 360, overflowY: 'auto', border: `1px solid ${COLORS.border}`, borderRadius: 6 }}>
                <div style={{ background: COLORS.surface, borderBottom: `1px solid ${COLORS.border}`, padding: '6px 12px', display: 'grid', gridTemplateColumns: '28px 1fr', gap: 12, fontSize: 11, fontWeight: 700, color: COLORS.muted }}>
                  <span>#</span><span>Action / Result</span>
                </div>
                {history.map((step, i) => <StepRow key={i} step={step} index={i} />)}
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  );
};
