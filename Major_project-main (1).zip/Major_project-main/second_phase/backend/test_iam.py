from cloud.iam import *

print("\nCreating User")
create_user("alice")

print("\nCreating Role")
create_role("developer-role")

print("\nAttaching Policy")
attach_policy(
    "developer-role",
    "arn:aws:iam::aws:policy/AdministratorAccess"
)

print("\nUsers")
for user in list_users():
    print(user["UserName"])

print("\nRoles")
for role in list_roles():
    print(role["RoleName"])