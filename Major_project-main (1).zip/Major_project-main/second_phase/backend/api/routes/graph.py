"""
GET /api/attack-graph                    — full graph for React Flow
GET /api/attack-graph/node/{node_id}     — detail panel for a single node
GET /api/attack-graph/export/graphml     — download GraphML file
GET /api/attack-graph/export/json        — download JSON graph
GET /api/attack-graph/paths              — all attack paths with evidence

All endpoints accept an optional ``provider`` query parameter ("aws" or "gcp").
Defaults to "aws" for backwards compatibility.
"""

import io
import json
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse, JSONResponse
from api.services.graph_service import get_attack_graph, get_node_detail, _load_real_graph

router = APIRouter(prefix="/api/attack-graph", tags=["graph"])


@router.get("")
def attack_graph(provider: Literal["aws", "gcp"] = Query("aws")):
    """Return React Flow nodes + edges JSON from the most recent scan."""
    return get_attack_graph(provider=provider)


@router.get("/node/{node_id:path}")
def node_detail(node_id: str, provider: Literal["aws", "gcp"] = Query("aws")):
    """Return full detail for a single graph node (side-panel data)."""
    detail = get_node_detail(node_id, provider=provider)
    if detail is None:
        raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found in graph.")
    return detail


@router.get("/export/graphml")
def export_graphml(provider: Literal["aws", "gcp"] = Query("aws")):
    """
    Download the attack graph as a GraphML file.

    GraphML can be opened in Gephi, yEd, Cytoscape, and other graph tools.
    Edge evidence and policy_sources are serialised as string attributes.
    """
    import networkx as nx

    nx_graph, source = _load_real_graph(provider=provider)
    if nx_graph.number_of_nodes() == 0:
        raise HTTPException(status_code=404, detail="No graph available. Run a scan first.")

    # Stringify list/dict attributes (GraphML only supports primitives)
    g_copy = nx_graph.copy()
    for _, data in g_copy.nodes(data=True):
        for k, v in list(data.items()):
            if isinstance(v, (list, dict)):
                data[k] = json.dumps(v, default=str)
    for _, _, data in g_copy.edges(data=True):
        for k, v in list(data.items()):
            if isinstance(v, (list, dict)):
                data[k] = json.dumps(v, default=str)

    buf = io.BytesIO()
    nx.write_graphml(g_copy, buf)
    buf.seek(0)

    return StreamingResponse(
        buf,
        media_type="application/xml",
        headers={"Content-Disposition": "attachment; filename=attack_graph.graphml"},
    )


@router.get("/export/json")
def export_json(provider: Literal["aws", "gcp"] = Query("aws")):
    """
    Download the attack graph as JSON (AssessmentGraph schema).

    Includes full edge evidence and policy_sources.
    """
    graph_path = Path(__file__).parent.parent.parent / "aws_pentest" / "last_graph.json"
    if not graph_path.exists():
        raise HTTPException(status_code=404, detail="No graph available. Run a scan first.")

    with open(graph_path, encoding="utf-8") as f:
        data = json.load(f)

    return StreamingResponse(
        io.BytesIO(json.dumps(data, indent=2).encode("utf-8")),
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=attack_graph.json"},
    )


@router.get("/paths")
def attack_paths(provider: Literal["aws", "gcp"] = Query("aws")):
    """
    Return all privilege escalation paths with their evidence.

    Includes only edges with relation=PRIVESC_TO, with full evidence chains.
    """
    nx_graph, source = _load_real_graph(provider=provider)
    paths = []

    for u, v, data in nx_graph.edges(data=True):
        if data.get("relation") == "PRIVESC_TO":
            u_attrs = nx_graph.nodes.get(u, {})
            v_attrs = nx_graph.nodes.get(v, {})
            paths.append({
                "source_id": u,
                "source_label": u_attrs.get("display_name", u.split("/")[-1]),
                "target_id": v,
                "target_label": v_attrs.get("display_name", v.split("/")[-1]),
                "relation": "PRIVESC_TO",
                "actions": data.get("actions", []),
                "evidence": data.get("evidence", []),
                "policy_sources": data.get("policy_sources", []),
                "confirmed": data.get("confirmed", True),
            })

    return {
        "paths": paths,
        "count": len(paths),
        "source": source,
    }
