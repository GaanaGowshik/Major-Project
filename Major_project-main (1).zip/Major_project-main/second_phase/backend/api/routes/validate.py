"""
POST /api/validate — Controlled finding validation endpoint (Phase 6).

This endpoint implements the three-level safety model:

  READ_ONLY (default):
    Returns a description of what would be tested and a dry-run preview.
    No AWS resources are created, modified, or deleted.

  DRY_RUN:
    Describes the exact AWS API calls that WOULD be made.
    No AWS resources are created, modified, or deleted.

  VALIDATE:
    Performs the controlled test with:
      - Explicit user confirmation (confirmed=true in request)
      - Named test resources (cloud-pentest-validation/<run_id>/...)
      - Cleanup on both success AND failure
      - Full audit log in the response

IMPORTANT: Findings are NEVER auto-promoted to VALIDATED status.
The caller must inspect the response.confirmed field to determine
whether validation succeeded.  "status": "failure" means the
attempted action was denied — which may indicate the finding was
a false positive.
"""

from __future__ import annotations

import logging
from typing import Any, Literal, Optional

from fastapi import APIRouter
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/validate", tags=["validate"])


# ---------------------------------------------------------------------------
# Request model
# ---------------------------------------------------------------------------

class ValidateRequest(BaseModel):
    """
    Request body for a validation action.

    Fields
    ------
    finding_id:
        ID of the finding to validate (from scan output).
    technique:
        Validation technique to execute.
        Supported: "s3_write" | "s3_read" | "iam_pass_role"
    mode:
        Safety level.
        "READ_ONLY" — describe only (default)
        "DRY_RUN"   — describe exact AWS calls, no execution
        "VALIDATE"  — execute controlled test (requires confirmed=true)
    confirmed:
        Must be True for mode="VALIDATE" to proceed.
        The UI must show the dry_run_preview to the user before this is set.
    provider:
        Cloud provider. Only "aws" is supported in Phase 6.
    profile:
        AWS profile name (optional — falls back to standard credential chain).
    region:
        AWS region for the session.
    run_id:
        Optional run identifier for test resource naming.
        Auto-generated if not provided.
    kwargs:
        Technique-specific parameters:
          s3_write / s3_read: bucket_name (required)
          iam_pass_role: role_arn (required)
    """
    finding_id: str
    technique: Literal["s3_write", "s3_read", "iam_pass_role"]
    mode: Literal["READ_ONLY", "DRY_RUN", "VALIDATE"] = "READ_ONLY"
    confirmed: bool = False
    provider: Literal["aws"] = "aws"
    profile: Optional[str] = None
    region: Optional[str] = "us-east-1"
    run_id: Optional[str] = None
    # Technique-specific kwargs embedded in the request
    bucket_name: Optional[str] = None
    role_arn: Optional[str] = None
    test_object_key: Optional[str] = None


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------

@router.post("")
def validate_finding(req: ValidateRequest) -> dict[str, Any]:
    """
    Validate a security finding using a controlled technique.

    Returns a ValidationResult dict.  The response always includes:
      - mode: the safety level used
      - status: "not_performed" | "dry_run_preview" | "success" | "failure" | "error"
      - confirmed: True ONLY when mode=VALIDATE and execution succeeded
      - dry_run_preview: list of AWS calls that would/did execute
      - evidence: list of execution evidence dicts (empty unless VALIDATE ran)
      - cleanup_done: True when test resources were deleted
      - audit_log: list of audit entries for every AWS API call made
    """
    import boto3
    from botocore.exceptions import NoCredentialsError, ProfileNotFound, ClientError
    from aws_pentest.validation.validator import AWSValidator, ValidationMode

    # Build boto3 session
    try:
        session_kwargs: dict[str, Any] = {}
        if req.profile:
            session_kwargs["profile_name"] = req.profile
        if req.region:
            session_kwargs["region_name"] = req.region
        session = boto3.Session(**session_kwargs)
        # Verify credentials are present
        session.client("sts").get_caller_identity()
    except (NoCredentialsError, ProfileNotFound) as exc:
        return {
            "finding_id": req.finding_id,
            "technique": req.technique,
            "mode": req.mode,
            "status": "error",
            "confirmed": False,
            "description": f"AWS credential error: {exc}. Cannot validate.",
            "error": str(exc),
        }
    except ClientError as exc:
        return {
            "finding_id": req.finding_id,
            "technique": req.technique,
            "mode": req.mode,
            "status": "error",
            "confirmed": False,
            "description": f"AWS STS error: {exc}. Cannot validate.",
            "error": str(exc),
        }

    # Build validator
    mode = ValidationMode(req.mode)
    validator = AWSValidator(session=session, mode=mode, run_id=req.run_id)

    # Dispatch
    kwargs: dict[str, Any] = {}
    if req.bucket_name:
        kwargs["bucket_name"] = req.bucket_name
    if req.role_arn:
        kwargs["role_arn"] = req.role_arn
    if req.test_object_key:
        kwargs["test_object_key"] = req.test_object_key

    result = validator.validate(
        finding_id=req.finding_id,
        technique=req.technique,
        confirmed=req.confirmed,
        **kwargs,
    )

    result_dict = result.model_dump()

    # Persist VALIDATE mode results to the report's validation log
    # (DRY_RUN and READ_ONLY are not persisted — they're preview-only)
    if req.mode == "VALIDATE":
        try:
            from api.services.report_service import record_validation_result
            record_validation_result(result_dict)
        except Exception as exc:
            logger.warning("Could not record validation result: %s", exc)

    return result_dict


# ---------------------------------------------------------------------------
# GET /api/validate/techniques — list available techniques
# ---------------------------------------------------------------------------

@router.get("/techniques")
def list_techniques():
    """Return the list of available validation techniques and their requirements."""
    return {
        "techniques": [
            {
                "id": "s3_write",
                "name": "S3 Write Validation",
                "description": (
                    "Tests whether the current principal can write to the specified S3 bucket "
                    "by creating a temporary test object and verifying it exists, then deleting it."
                ),
                "required_params": ["bucket_name"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": True,
                "cleanup": "Automatic — test object is always deleted on success and failure.",
            },
            {
                "id": "s3_read",
                "name": "S3 Read Validation",
                "description": (
                    "Tests whether the current principal can list and read objects in the specified "
                    "S3 bucket using s3:ListObjectsV2 against the validation prefix only."
                ),
                "required_params": ["bucket_name"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": "No resources created — list operation only.",
            },
            {
                "id": "iam_pass_role",
                "name": "IAM PassRole Validation",
                "description": (
                    "Uses the IAM Policy Simulator (non-mutating) to verify whether the current "
                    "principal has iam:PassRole permission on the specified role ARN."
                ),
                "required_params": ["role_arn"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": "No resources created — IAM simulator is read-only.",
            },
        ]
    }
