"""
GET /api/rl/status    — current/most-recent RL step
GET /api/rl/episodes  — per-episode summary list
GET /api/rl/history   — full step trace for a given episode
"""

from typing import Optional
from fastapi import APIRouter, Query
from api.services.rl_service import get_rl_status, get_episodes, get_history

router = APIRouter(prefix="/api/rl", tags=["rl"])


@router.get("/status")
def rl_status():
    return get_rl_status()


@router.get("/episodes")
def rl_episodes():
    return get_episodes()


@router.get("/history")
def rl_history(episode: Optional[int] = Query(default=None)):
    return get_history(episode=episode)
