"""
POST /api/report/generate  — run report generation from latest scan data
GET  /api/report           — return the report JSON
GET  /api/report/pdf       — return the report as a PDF file (valid binary PDF)
GET  /api/report/html      — return the report HTML (browser preview)

All endpoints accept an optional ``provider`` query parameter ("aws" or "gcp").
Defaults to "aws" for backwards compatibility.
"""

from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response, HTMLResponse
from api.services.report_service import (
    generate_report,
    generate_html,
    generate_pdf,
    save_report,
)

router = APIRouter(prefix="/api/report", tags=["report"])


@router.post("/generate")
def generate(provider: Literal["aws", "gcp"] = Query("aws")):
    report = generate_report(provider=provider)
    save_report(report, provider=provider)
    return {
        "status": "ok",
        "message": "Report generated.",
        "summary": report.get("executive_summary", ""),
    }


@router.get("")
def get_report(provider: Literal["aws", "gcp"] = Query("aws")):
    return generate_report(provider=provider)


@router.get("/html", response_class=HTMLResponse)
def get_report_html(provider: Literal["aws", "gcp"] = Query("aws")):
    report = generate_report(provider=provider)
    return generate_html(report)


@router.get("/pdf")
def get_report_pdf(provider: Literal["aws", "gcp"] = Query("aws")):
    report = generate_report(provider=provider)
    if report.get("status") == "no_scan":
        raise HTTPException(
            status_code=404,
            detail=f"No {provider.upper()} scan results available. Run a scan first.",
        )
    html = generate_html(report)
    pdf_bytes = generate_pdf(html)

    # Safety check: if generate_pdf() returned something that is not a PDF,
    # return HTTP 500 instead of sending corrupt data to the browser.
    if not pdf_bytes.startswith(b"%PDF-"):
        raise HTTPException(
            status_code=500,
            detail=(
                "PDF generation failed on the server. "
                "The generated content is not a valid PDF. "
                "Check server logs for details."
            ),
        )

    filename = f"{provider}-security-report.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(pdf_bytes)),
        },
    )
