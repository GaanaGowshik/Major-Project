"""
POST /api/scan  — trigger a provider scan (background task)
GET  /api/scan/status — poll scan progress

The scan route is now provider-agnostic: the caller specifies
``provider: "aws" | "gcp"`` in the request body.  The appropriate
BaseCloudProvider implementation is selected and the full pipeline
(auth → discover → analyse → graph → report) is run.
"""

import logging
from pathlib import Path
from typing import Literal, Optional

from fastapi import APIRouter, BackgroundTasks
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/scan", tags=["scan"])

_GRAPH_OUT = Path(__file__).parent.parent.parent / "aws_pentest" / "last_graph.json"
_REPORT_OUT = Path(__file__).parent.parent.parent / "aws_pentest" / "last_report.json"
_GCP_REPORT_OUT = Path(__file__).parent.parent.parent / "gcp_pentest" / "last_report.json"

_scan_state: dict = {"status": "idle", "message": "No scan run yet."}


class ScanRequest(BaseModel):
    provider: Literal["aws", "gcp"] = "aws"
    # AWS-specific options
    profile: Optional[str] = None
    region: Optional[str] = "us-east-1"
    regions: Optional[str] = None
    skip_privesc: bool = False
    skip_s3_iam_xref: bool = False
    # GCP-specific options (Phase 3)
    gcp_project_id: Optional[str] = None


def _run_scan(req: ScanRequest) -> None:
    global _scan_state
    _scan_state = {"status": "running", "message": f"Scan in progress ({req.provider.upper()})…"}
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))

        from providers import get_provider, ProviderAuthError
        import json

        provider = get_provider(req.provider)

        if req.provider == "aws":
            # Authenticate
            try:
                provider.authenticate(
                    profile_name=req.profile or None,
                    region=req.region or None,
                )
            except ProviderAuthError as exc:
                _scan_state = {"status": "error", "message": f"Authentication failed: {exc}"}
                return

            # Run full pipeline via AWSProvider
            regions = req.regions.split(",") if req.regions else None
            report = provider.run_full_scan(  # type: ignore[attr-defined]
                profile_name=req.profile or None,
                region=req.region or None,
                regions=regions,
                skip_privesc=req.skip_privesc,
                skip_s3_iam_xref=req.skip_s3_iam_xref,
            )

            # Also save graph JSON for graph service + RL env
            resources = provider.discover_resources(  # type: ignore[attr-defined]
                # Note: run_full_scan already authenticated; we rebuild to get resources
                # but this is a second call. Use the existing report output instead.
            ) if False else None  # skip — report already written

            # Write report JSON
            _REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
            with open(_REPORT_OUT, "w", encoding="utf-8") as f:
                json.dump(report, f, indent=2, default=str)

        elif req.provider == "gcp":
            if not req.gcp_project_id:
                _scan_state = {
                    "status": "error",
                    "message": "GCP scan requires gcp_project_id in the request body.",
                }
                return
            try:
                provider.authenticate(project_id=req.gcp_project_id)
            except ProviderAuthError as exc:
                _scan_state = {"status": "error", "message": f"GCP authentication failed: {exc}"}
                return

            report = provider.run_full_scan(  # type: ignore[attr-defined]
                project_id=req.gcp_project_id,
            )

            # Write GCP report to its own output path (does not overwrite AWS report)
            _GCP_REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
            with open(_GCP_REPORT_OUT, "w", encoding="utf-8") as f:
                json.dump(report, f, indent=2, default=str)
        else:
            _scan_state = {"status": "error", "message": f"Unknown provider: {req.provider}"}
            return

        summary = report.get("summary", {})
        _scan_state = {
            "status": "complete",
            "provider": req.provider,
            "message": (
                f"Scan complete ({req.provider.upper()}). "
                f"{summary.get('iam_users', 0)} users, "
                f"{summary.get('iam_roles', 0)} roles, "
                f"{summary.get('s3_buckets', 0)} buckets, "
                f"{summary.get('ec2_instances', 0)} instances. "
                f"{summary.get('total_findings', 0)} findings."
            ),
            "summary": summary,
        }

    except Exception as exc:
        logger.error("Scan failed: %s", exc, exc_info=True)
        _scan_state = {"status": "error", "message": str(exc)}


# ---------------------------------------------------------------------------
# Fallback: also expose the original aws_pentest.run path so existing
# integrations (graph service fallback) still work without breaking.
# ---------------------------------------------------------------------------

def _run_scan_legacy(req: ScanRequest) -> None:
    """
    Direct aws_pentest.run call — kept as the proven path until AWSProvider
    is fully validated in production.  The new provider path above is the
    preferred path but both write to the same output files.
    """
    global _scan_state
    _scan_state = {"status": "running", "message": "Scan in progress…"}
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))
        from aws_pentest.run import run as pentest_run
        regions = req.regions.split(",") if req.regions else None
        report = pentest_run(
            profile=req.profile,
            region=req.region,
            regions=regions,
            output_json=str(_REPORT_OUT),
            output_graph_json=str(_GRAPH_OUT),
            skip_privesc=req.skip_privesc,
            skip_s3_iam_xref=req.skip_s3_iam_xref,
        )
        summary = report.get("summary", {})
        _scan_state = {
            "status": "complete",
            "message": (
                f"Scan complete. "
                f"{summary.get('iam_users', 0)} users, "
                f"{summary.get('iam_roles', 0)} roles, "
                f"{summary.get('s3_buckets', 0)} buckets, "
                f"{summary.get('ec2_instances', 0)} instances. "
                f"{summary.get('total_findings', 0)} findings."
            ),
            "summary": summary,
        }
    except Exception as exc:
        logger.error("Scan failed: %s", exc)
        _scan_state = {"status": "error", "message": str(exc)}


@router.post("")
def trigger_scan(req: ScanRequest, background_tasks: BackgroundTasks):
    if _scan_state.get("status") == "running":
        return {"status": "already_running", "message": "A scan is already in progress."}
    # Use the proven legacy aws_pentest.run path for AWS (validated against real AWS).
    # Switch to provider path once AWSProvider.run_full_scan has been end-to-end tested.
    if req.provider == "aws":
        background_tasks.add_task(_run_scan_legacy, req)
    else:
        background_tasks.add_task(_run_scan, req)
    return {"status": "started", "message": f"Scan started ({req.provider.upper()})."}


@router.get("/status")
def scan_status():
    return _scan_state


@router.get("/providers")
def list_providers():
    """Return available cloud providers and their status."""
    return {
        "providers": [
            {
                "id": "aws",
                "name": "Amazon Web Services",
                "status": "available",
                "description": "IAM, S3, EC2 discovery with real IAM Policy Simulator verification.",
            },
            {
                "id": "gcp",
                "name": "Google Cloud Platform",
                "status": "available",
                "description": "IAM, Cloud Storage, Compute Engine discovery with privilege escalation detection.",
            },
        ]
    }
