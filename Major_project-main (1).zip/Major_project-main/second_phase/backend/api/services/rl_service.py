"""
RL service — reads the structured training log produced by
rl/training_logger.py and provides typed access for the API routes.

If no log file exists yet (training hasn't been run), every function
returns sensible empty/default values rather than crashing.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

_LOG_PATH = Path(__file__).parent.parent.parent / "rl" / "training_log.json"

# In-memory cache of latest live status (written by the live training callback)
_LIVE_STATUS: dict[str, Any] = {}


def _load_log() -> list[dict[str, Any]]:
    if not _LOG_PATH.exists():
        return []
    try:
        with open(_LOG_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception as exc:
        logger.warning("Could not load training log: %s", exc)
        return []


def get_rl_status() -> dict[str, Any]:
    """Current / most-recent RL step status."""
    if _LIVE_STATUS:
        return _LIVE_STATUS

    episodes = _load_log()
    if not episodes:
        return {
            "episode": 0,
            "step": 0,
            "current_node": None,
            "last_action": None,
            "last_action_name": None,
            "reward": 0.0,
            "cumulative_reward": 0.0,
            "is_trained": False,
            "total_timesteps": 0,
            "message": "No training log found. Run rl/train_with_logging.py first.",
        }

    last_ep = episodes[-1]
    steps = last_ep.get("steps", [])
    last_step = steps[-1] if steps else {}
    return {
        "episode": last_ep.get("episode", len(episodes)),
        "step": last_step.get("step", 0),
        "current_node": last_step.get("node"),
        "last_action": last_step.get("action"),
        "last_action_name": _action_name(last_step.get("action")),
        "reward": last_step.get("reward", 0.0),
        "cumulative_reward": last_ep.get("total_reward", 0.0),
        "is_trained": True,
        "total_timesteps": sum(ep.get("steps_count", 0) for ep in episodes),
    }


def get_episodes() -> list[dict[str, Any]]:
    """Per-episode summary list."""
    episodes = _load_log()
    summaries = []
    for ep in episodes:
        steps = ep.get("steps", [])
        rewards = [s.get("reward", 0) for s in steps]
        summaries.append(
            {
                "episode": ep.get("episode", 0),
                "totalReward": ep.get("total_reward", sum(rewards)),
                "stepsCount": ep.get("steps_count", len(steps)),
                "successActions": sum(1 for s in steps if s.get("success", False)),
                "failedActions": sum(1 for s in steps if not s.get("success", True)),
                "maxReward": max(rewards) if rewards else 0,
                "minReward": min(rewards) if rewards else 0,
                "avgReward": sum(rewards) / len(rewards) if rewards else 0,
                "path": [s.get("node") for s in steps if s.get("node")],
            }
        )
    return summaries


def get_history(episode: Optional[int] = None) -> list[dict[str, Any]]:
    """Full step trace for a given episode (or most recent)."""
    episodes = _load_log()
    if not episodes:
        return []

    if episode is not None:
        matches = [e for e in episodes if e.get("episode") == episode]
        ep = matches[-1] if matches else episodes[-1]
    else:
        ep = episodes[-1]

    steps = ep.get("steps", [])
    return [
        {
            "step": s.get("step", i),
            "node": s.get("node"),
            "action": s.get("action"),
            "actionName": _action_name(s.get("action")),
            "actionReason": _action_reason(s),
            "reward": s.get("reward", 0),
            "success": s.get("success", False),
            "result": s.get("result", {}),
        }
        for i, s in enumerate(steps)
    ]


def set_live_status(status: dict[str, Any]) -> None:
    """Called by training_logger to push live updates."""
    _LIVE_STATUS.update(status)


# ---------------------------------------------------------------------------
# Human-readable action labels
# ---------------------------------------------------------------------------

_ACTION_NAMES = {
    0: "List IAM Users",
    1: "List IAM Roles",
    2: "List S3 Buckets",
    3: "Enumerate Node",
    4: "Assume Role",
    5: "List Bucket Objects",
}


def _action_name(action_id: Any) -> str:
    if action_id is None:
        return "—"
    try:
        return _ACTION_NAMES.get(int(action_id), f"Action {action_id}")
    except (TypeError, ValueError):
        return str(action_id)


def _action_reason(step: dict) -> str:
    """
    Build a plain-language reason string from real step data.
    We only describe what we actually know — no fabricated model explanations.
    """
    action_id = step.get("action")
    reward = step.get("reward", 0)
    success = step.get("success", False)

    if action_id is None:
        return "No action taken."

    name = _action_name(action_id)

    # Stubs are honest
    if not success and action_id in (4, 5):
        return (
            f"{name} — this action is a simulation stub and always returns failure. "
            "No real AWS API call was made."
        )

    if not success:
        return f"{name} — returned failure (reward {reward:.1f})."

    result = step.get("result", {})
    count = result.get("count", 0)
    if count:
        return (
            f"{name} — discovered {count} resource(s). "
            f"Reward {reward:.1f}."
        )
    return f"{name} — succeeded. Reward {reward:.1f}."
