"""
Report service — generates HTML and PDF penetration test reports.

Supports both AWS and GCP providers.  The ``provider`` parameter selects
which scan result to load.

PDF generation uses ReportLab (pure-Python, works on Windows without GTK/Pango).
WeasyPrint is no longer used as it requires the GTK3 runtime which is not
reliably available on Windows.
"""

from __future__ import annotations

import io
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Optional

logger = logging.getLogger(__name__)

# ── File paths ────────────────────────────────────────────────────────────────

_AWS_REPORT_JSON_PATH  = Path(__file__).parent.parent.parent / "aws_pentest" / "last_report.json"
_AWS_COMPILED_JSON_PATH = Path(__file__).parent.parent.parent / "aws_pentest" / "last_report_compiled.json"
_AWS_REPORT_HTML_PATH  = Path(__file__).parent.parent.parent / "aws_pentest" / "last_report.html"
_VALIDATION_LOG_PATH   = Path(__file__).parent.parent.parent / "aws_pentest" / "validation_log.json"
_GCP_REPORT_JSON_PATH  = Path(__file__).parent.parent.parent / "gcp_pentest" / "last_report.json"
_GCP_COMPILED_JSON_PATH = Path(__file__).parent.parent.parent / "gcp_pentest" / "last_report_compiled.json"
_GCP_REPORT_HTML_PATH  = Path(__file__).parent.parent.parent / "gcp_pentest" / "last_report.html"

_SEVERITY_COLORS = {
    "CRITICAL": "#dc2626",
    "HIGH":     "#ea580c",
    "MEDIUM":   "#ca8a04",
    "LOW":      "#16a34a",
    "INFO":     "#2563eb",
}


# ── Data loaders ──────────────────────────────────────────────────────────────

def _load_aws_pentest_report() -> Optional[dict[str, Any]]:
    if _AWS_REPORT_JSON_PATH.exists():
        try:
            with open(_AWS_REPORT_JSON_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            logger.warning("Could not load AWS pentest report: %s", exc)
    return None


def _load_gcp_pentest_report() -> Optional[dict[str, Any]]:
    if _GCP_REPORT_JSON_PATH.exists():
        try:
            with open(_GCP_REPORT_JSON_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            logger.warning("Could not load GCP pentest report: %s", exc)
    return None


def _load_rl_episodes() -> list[dict]:
    from api.services.rl_service import get_episodes
    return get_episodes()


def _load_validation_log() -> list[dict]:
    """Load validation results recorded during Phase 6 controlled testing."""
    if _VALIDATION_LOG_PATH.exists():
        try:
            with open(_VALIDATION_LOG_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            logger.warning("Could not load validation log: %s", exc)
    return []


def record_validation_result(result: dict[str, Any]) -> None:
    """Append a validation result to the persistent validation log."""
    log = _load_validation_log()
    log.append(result)
    _VALIDATION_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(_VALIDATION_LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2, default=str)


# ── Report generators ─────────────────────────────────────────────────────────

def generate_report(provider: Literal["aws", "gcp"] = "aws") -> dict[str, Any]:
    """
    Build the full report dict from available data sources for the given provider.
    Returns a dict that can be serialized to JSON or passed to the HTML template.
    """
    if provider == "gcp":
        return _generate_gcp_report()
    return _generate_aws_report()


def _generate_aws_report() -> dict[str, Any]:
    pt = _load_aws_pentest_report()
    rl_episodes = _load_rl_episodes()
    now = datetime.now(timezone.utc).isoformat()

    if pt is None:
        return {
            "provider": "aws",
            "generated_at": now,
            "status": "no_scan",
            "message": "No AWS scan results found. Run an AWS scan first.",
            "sections": {},
        }

    findings = pt.get("findings", {})
    privesc  = pt.get("privilege_escalation_paths", [])

    if isinstance(findings, list):
        # Compiled/transformed format
        all_findings = findings
        risk_assessment = pt.get("risk_assessment", {})
        sev = risk_assessment.get("severity_breakdown", {})
        risk_level = risk_assessment.get("overall_risk", "LOW")
        resources = pt.get("resource_inventory", {})
        total_findings = risk_assessment.get("total_findings", len(all_findings))
    else:
        # Raw scan format
        summary   = pt.get("summary", {})
        resources = pt.get("resources", {})
        sev       = summary.get("severity_breakdown", {})
        risk_level = (
            "CRITICAL" if sev.get("CRITICAL", 0) > 0 else
            "HIGH"     if sev.get("HIGH",     0) > 0 else
            "MEDIUM"   if sev.get("MEDIUM",   0) > 0 else
            "LOW"
        )
        all_findings = (
            findings.get("iam", []) +
            findings.get("s3",  []) +
            findings.get("ec2", [])
        )
        total_findings = summary.get("total_findings", len(all_findings))

    rl_summary = None
    if rl_episodes:
        rewards = [ep["totalReward"] for ep in rl_episodes]
        rl_summary = {
            "total_episodes":      len(rl_episodes),
            "avg_reward":          sum(rewards) / len(rewards),
            "max_reward":          max(rewards),
            "convergence_episode": _find_convergence(rewards),
            "is_simulated":        True,
        }

    validation_results = _load_validation_log()
    inv_users    = resources.get("iam_users",    [])
    inv_roles    = resources.get("iam_roles",    [])
    inv_buckets  = resources.get("s3_buckets",   [])
    inv_ec2      = resources.get("ec2_instances",[])

    return {
        "provider":        "aws",
        "generated_at":    now,
        "status":          "complete",
        "account_id":      pt.get("account_id", "UNKNOWN"),
        "scan_timestamp":  pt.get("scan_timestamp", now),
        "executive_summary": _build_aws_executive_summary(
            {
                "iam_users":   len(inv_users),
                "iam_roles":   len(inv_roles),
                "s3_buckets":  len(inv_buckets),
                "ec2_instances": len(inv_ec2),
                "total_findings": total_findings,
                "severity_breakdown": sev,
            },
            risk_level,
            privesc,
        ),
        "resource_inventory": {
            "iam_users":    inv_users,
            "iam_roles":    inv_roles,
            "iam_groups":   resources.get("iam_groups", []),
            "s3_buckets":   inv_buckets,
            "ec2_instances": inv_ec2,
        },
        "findings":                all_findings,
        "privilege_escalation_paths": privesc,
        "risk_assessment": {
            "overall_risk":       risk_level,
            "severity_breakdown": sev,
            "total_findings":     total_findings,
            "privesc_count":      len(privesc),
        },
        "validation_results": validation_results,
        "rl_analysis":        rl_summary,
        "graph_summary":      pt.get("graph_summary", {}),
        "recommendations":    _build_aws_recommendations(all_findings, privesc),
    }


def _generate_gcp_report() -> dict[str, Any]:
    pt  = _load_gcp_pentest_report()
    now = datetime.now(timezone.utc).isoformat()

    if pt is None:
        return {
            "provider": "gcp",
            "generated_at": now,
            "status": "no_scan",
            "message": "No GCP scan results found. Run a GCP scan first.",
            "sections": {},
        }

    summary  = pt.get("summary", {})
    resources = pt.get("resources", {})
    raw_findings = pt.get("findings", {})
    privesc   = pt.get("privilege_escalation_paths", [])
    sev       = summary.get("severity_breakdown", {})

    risk_level = (
        "CRITICAL" if sev.get("CRITICAL", 0) > 0 else
        "HIGH"     if sev.get("HIGH",     0) > 0 else
        "MEDIUM"   if sev.get("MEDIUM",   0) > 0 else
        "LOW"
    )

    # Flatten all GCP findings into a single list
    if isinstance(raw_findings, list):
        all_findings = raw_findings
    else:
        all_findings = (
            raw_findings.get("iam",     []) +
            raw_findings.get("storage", []) +
            raw_findings.get("compute", [])
        )
    total_findings = summary.get("total_findings", len(all_findings))

    sa_list      = resources.get("service_accounts", [])
    bucket_list  = resources.get("storage_buckets",  [])
    compute_list = resources.get("compute_instances",[])
    iam_bindings = summary.get("iam_bindings", 0)

    return {
        "provider":       "gcp",
        "generated_at":   now,
        "status":         "complete",
        "project_id":     pt.get("project_id", "UNKNOWN"),
        "scan_timestamp": pt.get("scan_timestamp", now),
        "executive_summary": _build_gcp_executive_summary(
            {
                "service_accounts":  len(sa_list),
                "iam_bindings":      iam_bindings,
                "storage_buckets":   len(bucket_list),
                "compute_instances": len(compute_list),
                "total_findings":    total_findings,
                "severity_breakdown": sev,
            },
            risk_level,
            privesc,
        ),
        "resource_inventory": {
            "service_accounts":  sa_list,
            "storage_buckets":   bucket_list,
            "compute_instances": compute_list,
            "iam_bindings":      iam_bindings,
        },
        "findings":                   all_findings,
        "privilege_escalation_paths": privesc,
        "risk_assessment": {
            "overall_risk":       risk_level,
            "severity_breakdown": sev,
            "total_findings":     total_findings,
            "privesc_count":      len(privesc),
        },
        "recommendations": _build_gcp_recommendations(all_findings, privesc),
    }


# ── HTML / PDF generation ─────────────────────────────────────────────────────

def generate_html(report: dict[str, Any]) -> str:
    """Render the report dict as a full HTML document."""
    if report.get("status") == "no_scan":
        return _no_scan_html(report)
    provider = report.get("provider", "aws")
    if provider == "gcp":
        return _render_gcp_html(report)
    return _render_aws_html(report)


def generate_pdf(html: str) -> bytes:
    """
    Convert the HTML report to a real PDF using ReportLab.

    ReportLab is a pure-Python PDF library — no GTK, no native DLLs required.
    It works on Windows, macOS, and Linux without additional system dependencies.

    We render a structured PDF (title page + sections) from the report data
    rather than trying to render HTML→PDF, which avoids all WeasyPrint/GTK issues.

    The returned bytes are guaranteed to start with b'%PDF-' (a valid PDF header).
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
            HRFlowable, KeepTogether,
        )
        from reportlab.lib.enums import TA_CENTER, TA_LEFT

        buf = io.BytesIO()
        doc = SimpleDocTemplate(
            buf,
            pagesize=A4,
            rightMargin=2*cm, leftMargin=2*cm,
            topMargin=2*cm,   bottomMargin=2*cm,
        )

        styles    = getSampleStyleSheet()
        style_h1  = ParagraphStyle("H1",  parent=styles["Heading1"],  fontSize=20, spaceAfter=6)
        style_h2  = ParagraphStyle("H2",  parent=styles["Heading2"],  fontSize=14, spaceAfter=4, spaceBefore=14)
        style_body = ParagraphStyle("Body", parent=styles["Normal"],  fontSize=10, leading=14)
        style_meta = ParagraphStyle("Meta", parent=styles["Normal"],  fontSize=9,
                                    textColor=colors.HexColor("#57606a"))
        style_mono = ParagraphStyle("Mono", parent=styles["Normal"],  fontSize=8,
                                    fontName="Courier",
                                    textColor=colors.HexColor("#374151"))

        SEV_COLORS = {
            "CRITICAL": colors.HexColor("#dc2626"),
            "HIGH":     colors.HexColor("#ea580c"),
            "MEDIUM":   colors.HexColor("#ca8a04"),
            "LOW":      colors.HexColor("#16a34a"),
            "INFO":     colors.HexColor("#2563eb"),
        }

        def sev_color(sev: str):
            return SEV_COLORS.get(sev, colors.HexColor("#6b7280"))

        story = []

        # ── Extract data from HTML (it already has all data embedded) ──────
        # We parse the HTML for the report data instead of re-running the service.
        # Actually, generate_pdf is called with the HTML but we need the raw report.
        # Since we can't easily pass both, we parse the key info from the HTML or
        # use a minimal approach: render the HTML content as text paragraphs.
        # The simplest correct approach: use BeautifulSoup-free text extraction.

        # Strip HTML tags with a simple regex-free approach using html.parser
        import html as html_module
        from html.parser import HTMLParser

        class TextExtractor(HTMLParser):
            def __init__(self):
                super().__init__()
                self.text_parts: list[str] = []
                self._skip = False
                self._in_style = False
            def handle_starttag(self, tag, attrs):
                if tag in ("style", "script"):
                    self._in_style = True
                if tag in ("br", "p", "div", "h1", "h2", "h3", "tr", "li"):
                    self.text_parts.append("\n")
                if tag == "td":
                    self.text_parts.append(" | ")
            def handle_endtag(self, tag):
                if tag in ("style", "script"):
                    self._in_style = False
            def handle_data(self, data):
                if not self._in_style:
                    self.text_parts.append(data)
            def get_text(self):
                return "".join(self.text_parts)

        extractor = TextExtractor()
        extractor.feed(html)
        raw_text = extractor.get_text()

        # Split into lines, strip each, drop blanks
        lines = [ln.strip() for ln in raw_text.splitlines()]
        lines = [ln for ln in lines if ln]

        # Determine provider from HTML title
        is_gcp = "GCP" in html[:500] or "Google Cloud" in html[:500]
        provider_label = "GCP" if is_gcp else "AWS"

        # ── Title page ──────────────────────────────────────────────────────
        story.append(Spacer(1, 1*cm))
        story.append(Paragraph(
            f"{provider_label} Security Assessment Report",
            style_h1,
        ))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#e5e7eb")))
        story.append(Spacer(1, 0.3*cm))

        # ── Render lines as paragraphs ───────────────────────────────────────
        in_table_header = False
        table_rows: list[list[str]] = []
        current_section = ""
        SEV_KEYWORDS = {"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"}

        for line in lines:
            if not line:
                continue

            # Detect section headings (ALL-CAPS or title-like lines found in report)
            if line.isupper() and len(line) < 60 and line not in SEV_KEYWORDS:
                if table_rows:
                    _emit_table(story, table_rows, styles)
                    table_rows = []
                story.append(Spacer(1, 0.2*cm))
                story.append(Paragraph(line.title(), style_h2))
                story.append(HRFlowable(width="100%", thickness=0.5,
                                        color=colors.HexColor("#e5e7eb")))
                story.append(Spacer(1, 0.1*cm))
                current_section = line
                continue

            # Table-like lines (contain " | ")
            if " | " in line:
                parts = [p.strip() for p in line.split(" | ") if p.strip()]
                if parts:
                    table_rows.append(parts)
                continue

            # Flush table if we hit a non-table line
            if table_rows:
                _emit_table(story, table_rows, styles)
                table_rows = []

            # Severity keywords on their own line → coloured badge text
            if line in SEV_KEYWORDS:
                story.append(Paragraph(
                    f'<font color="{_SEVERITY_COLORS.get(line,"#6b7280")}">'
                    f'<b>{line}</b></font>',
                    style_body,
                ))
                continue

            # Long lines (findings, descriptions)
            safe_line = html_module.escape(line)
            story.append(Paragraph(safe_line, style_body))
            story.append(Spacer(1, 0.05*cm))

        # Flush any remaining table
        if table_rows:
            _emit_table(story, table_rows, styles)

        # ── Footer ───────────────────────────────────────────────────────────
        story.append(Spacer(1, 1*cm))
        story.append(HRFlowable(width="100%", thickness=0.5,
                                color=colors.HexColor("#e5e7eb")))
        story.append(Paragraph(
            "Generated by Multi-Cloud Pentest RL — For authorized use only",
            ParagraphStyle("Footer", parent=styles["Normal"], fontSize=8,
                           textColor=colors.HexColor("#57606a"),
                           alignment=TA_CENTER),
        ))

        doc.build(story)
        pdf_bytes = buf.getvalue()
        logger.info("PDF generated successfully: %d bytes", len(pdf_bytes))
        return pdf_bytes

    except Exception as exc:
        logger.error("ReportLab PDF generation failed: %s", exc, exc_info=True)
        # Return an empty-but-valid minimal PDF so the safety check in the route
        # can detect the failure (it won't start with %PDF- if we raise here,
        # so let the exception propagate to the route which returns HTTP 500).
        raise


def _emit_table(story, rows: list[list[str]], styles):
    """Helper: render accumulated pipe-delimited rows as a ReportLab Table."""
    from reportlab.platypus import Table, TableStyle, Spacer
    from reportlab.lib import colors
    from reportlab.lib.units import cm

    if not rows:
        return

    # Pad rows to equal column count
    max_cols = max(len(r) for r in rows)
    padded = [r + [""] * (max_cols - len(r)) for r in rows]

    tbl = Table(padded, repeatRows=1, hAlign="LEFT")
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f7f8fa")),
        ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",   (0, 0), (-1, -1), 8),
        ("GRID",       (0, 0), (-1, -1), 0.5, colors.HexColor("#e5e7eb")),
        ("VALIGN",     (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",(0, 0), (-1, -1), 4),
        ("RIGHTPADDING",(0,0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING",(0,0),(-1, -1), 3),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 0.15 * cm))


def save_report(report: dict[str, Any], provider: Literal["aws", "gcp"] = "aws") -> None:
    """Persist the compiled report JSON + HTML for later retrieval."""
    if provider == "gcp":
        compiled_path = _GCP_COMPILED_JSON_PATH
        html_path     = _GCP_REPORT_HTML_PATH
    else:
        compiled_path = _AWS_COMPILED_JSON_PATH
        html_path     = _AWS_REPORT_HTML_PATH

    compiled_path.parent.mkdir(parents=True, exist_ok=True)
    with open(compiled_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)

    html = generate_html(report)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _build_aws_executive_summary(summary: dict, risk_level: str, privesc: list) -> str:
    users     = summary.get("iam_users",   0)
    roles     = summary.get("iam_roles",   0)
    buckets   = summary.get("s3_buckets",  0)
    instances = summary.get("ec2_instances", 0)
    total     = summary.get("total_findings", 0)
    sev       = summary.get("severity_breakdown", {})
    privesc_note = (
        f" {len(privesc)} confirmed privilege escalation path(s) were detected."
        if privesc else " No confirmed privilege escalation paths were found."
    )
    return (
        f"This automated AWS security assessment identified {users} IAM users, "
        f"{roles} roles, {buckets} S3 buckets, and {instances} EC2 instances. "
        f"A total of {total} findings were recorded with an overall risk rating of "
        f"{risk_level}. Critical: {sev.get('CRITICAL',0)}, "
        f"High: {sev.get('HIGH',0)}, Medium: {sev.get('MEDIUM',0)}, "
        f"Low: {sev.get('LOW',0)}." + privesc_note
    )


def _build_gcp_executive_summary(summary: dict, risk_level: str, privesc: list) -> str:
    sas      = summary.get("service_accounts",  0)
    bindings = summary.get("iam_bindings",       0)
    buckets  = summary.get("storage_buckets",    0)
    compute  = summary.get("compute_instances",  0)
    total    = summary.get("total_findings",     0)
    sev      = summary.get("severity_breakdown", {})
    privesc_note = (
        f" {len(privesc)} privilege escalation path(s) were detected."
        if privesc else " No privilege escalation paths were found."
    )
    return (
        f"This automated GCP security assessment identified {sas} service accounts, "
        f"{bindings} IAM bindings, {buckets} Cloud Storage buckets, and "
        f"{compute} Compute Engine instances. "
        f"A total of {total} findings were recorded with an overall risk rating of "
        f"{risk_level}. Critical: {sev.get('CRITICAL',0)}, "
        f"High: {sev.get('HIGH',0)}, Medium: {sev.get('MEDIUM',0)}, "
        f"Low: {sev.get('LOW',0)}." + privesc_note
    )


def _build_aws_recommendations(findings: list, privesc: list) -> list[dict]:
    recs: list[dict] = []
    if privesc:
        recs.append({
            "priority": "CRITICAL",
            "title":    "Remediate Privilege Escalation Paths Immediately",
            "detail":   (
                f"The IAM Policy Simulator confirmed {len(privesc)} privilege "
                "escalation path(s). Remove the required IAM actions from the "
                "offending principals or apply permission boundaries."
            ),
        })
    critical = [f for f in findings if f.get("severity") == "CRITICAL"]
    if critical:
        recs.append({
            "priority": "CRITICAL",
            "title":    "Address Critical Misconfigurations",
            "detail":   f"{len(critical)} critical finding(s) require immediate remediation.",
        })
    high = [f for f in findings if f.get("severity") == "HIGH"]
    if high:
        recs.append({
            "priority": "HIGH",
            "title":    "Resolve High-Severity Findings",
            "detail":   f"{len(high)} high-severity finding(s) should be remediated within 7 days.",
        })
    recs.append({
        "priority": "MEDIUM",
        "title":    "Enable S3 Server-Side Encryption and Logging",
        "detail":   "Ensure all S3 buckets have default encryption and access logging enabled.",
    })
    recs.append({
        "priority": "LOW",
        "title":    "Enforce IMDSv2 on All EC2 Instances",
        "detail":   "Set HttpTokens=required on all instances to prevent SSRF credential theft.",
    })
    return recs


def _build_gcp_recommendations(findings: list, privesc: list) -> list[dict]:
    recs: list[dict] = []
    if privesc:
        recs.append({
            "priority": "CRITICAL",
            "title":    "Remediate Service Account Privilege Escalation Paths",
            "detail":   (
                f"{len(privesc)} privilege escalation path(s) detected. "
                "Review and restrict service account IAM bindings that allow "
                "impersonation or token creation."
            ),
        })
    critical = [f for f in findings if f.get("severity") == "CRITICAL"]
    if critical:
        recs.append({
            "priority": "CRITICAL",
            "title":    "Address Critical GCP Misconfigurations",
            "detail":   f"{len(critical)} critical finding(s) require immediate remediation.",
        })
    high = [f for f in findings if f.get("severity") == "HIGH"]
    if high:
        recs.append({
            "priority": "HIGH",
            "title":    "Resolve High-Severity GCP Findings",
            "detail":   f"{len(high)} high-severity finding(s) should be remediated within 7 days.",
        })
    recs.append({
        "priority": "MEDIUM",
        "title":    "Restrict Firewall Rules to Known IP Ranges",
        "detail":   "Remove 0.0.0.0/0 ingress rules for sensitive ports (22, 3389, etc.).",
    })
    recs.append({
        "priority": "LOW",
        "title":    "Enable Cloud Audit Logs for All Services",
        "detail":   "Ensure Admin Activity and Data Access audit logs are enabled for all APIs.",
    })
    return recs


def _find_convergence(rewards: list[float]) -> Optional[int]:
    """Return episode index where reward stabilized (simple moving avg)."""
    if len(rewards) < 10:
        return None
    window = 5
    for i in range(window, len(rewards) - window):
        prev_avg = sum(rewards[i - window:i]) / window
        curr_avg = sum(rewards[i:i + window]) / window
        if abs(curr_avg - prev_avg) < 2.0:
            return i
    return None


# ── HTML templates ────────────────────────────────────────────────────────────

def _no_scan_html(report: dict) -> str:
    provider = report.get("provider", "aws").upper()
    return f"""<!DOCTYPE html><html><body>
<h1>No {provider} scan results available</h1>
<p>{report.get('message', '')}</p>
</body></html>"""


def _sev_badge(sev: str) -> str:
    color = _SEVERITY_COLORS.get(sev, "#6b7280")
    return (
        f'<span style="background:{color};color:#fff;padding:2px 8px;'
        f'border-radius:10px;font-size:11px;font-weight:700">{sev}</span>'
    )


def _render_validation_section(validation_results: list[dict]) -> str:
    """Render the Controlled Validation Results section for the HTML report."""
    if not validation_results:
        return (
            "<h2>Controlled Validation Results</h2>"
            "<p style='color:#57606a'>No controlled validations were performed. "
            "All findings above are DETECTED but NOT VALIDATED. "
            "Use the validation API (POST /api/validate) to perform controlled tests.</p>"
        )

    rows = ""
    for v in validation_results:
        status    = v.get("status",    "not_performed")
        confirmed = v.get("confirmed", False)
        mode      = v.get("mode",      "READ_ONLY")

        if status == "success" and confirmed:
            status_html = '<span style="color:#16a34a;font-weight:700">✓ VALIDATED</span>'
        elif status == "failure":
            status_html = '<span style="color:#ea580c;font-weight:700">✗ DENIED (false positive?)</span>'
        elif status == "dry_run_preview":
            status_html = '<span style="color:#2563eb">DRY RUN ONLY</span>'
        else:
            status_html = '<span style="color:#ca8a04">NOT PERFORMED</span>'

        evidence_count = len(v.get("evidence", []))
        cleanup = "Yes" if v.get("cleanup_done") else '<span style="color:#dc2626">No</span>'

        rows += f"""<tr>
          <td><code style="font-size:11px">{v.get('finding_id','')}</code></td>
          <td>{v.get('technique','')}</td>
          <td>{mode}</td>
          <td>{status_html}</td>
          <td>{evidence_count} item(s)</td>
          <td>{cleanup}</td>
          <td style="font-size:11px;color:#57606a">{v.get('timestamp','')[:19] if v.get('timestamp') else ''}</td>
        </tr>"""

    return (
        "<h2>Controlled Validation Results</h2>"
        "<p style='font-size:12px;color:#57606a;margin-bottom:8px'>"
        "Status: VALIDATED = confirmed by real execution · "
        "NOT PERFORMED = read-only mode · "
        "DENIED = access was blocked (may indicate finding is mitigated)"
        "</p>"
        "<table>"
        "<tr><th>Finding ID</th><th>Technique</th><th>Mode</th>"
        "<th>Result</th><th>Evidence</th><th>Cleanup</th><th>Timestamp</th></tr>"
        + rows
        + "</table>"
    )


def _common_html_styles(risk_color: str) -> str:
    return f"""<style>
  body {{ font-family: -apple-system, "Segoe UI", sans-serif; font-size: 14px;
         line-height: 1.6; color: #1f2328; margin: 0; padding: 32px 48px; }}
  h1 {{ font-size: 24px; margin-bottom: 4px; }}
  h2 {{ font-size: 16px; margin: 28px 0 10px; border-bottom: 1px solid #e5e7eb;
        padding-bottom: 5px; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; margin: 10px 0; }}
  th {{ background: #f7f8fa; text-align: left; padding: 7px 10px;
        border: 1px solid #e5e7eb; font-weight: 600; }}
  td {{ padding: 6px 10px; border: 1px solid #e5e7eb; vertical-align: top; }}
  tr:nth-child(even) td {{ background: #fafafa; }}
  .meta {{ color: #57606a; font-size: 13px; margin-bottom: 24px; }}
  .exec {{ background: #f7f8fa; border-left: 4px solid #3b82d4;
           padding: 12px 16px; border-radius: 0 6px 6px 0; margin: 10px 0 20px; }}
  .risk-badge {{ display:inline-block; padding: 4px 14px; border-radius: 20px;
                 color: #fff; font-weight: 700; font-size: 15px;
                 background: {risk_color}; }}
  .stat-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 12px 0; }}
  .stat {{ background: #f7f8fa; border: 1px solid #e5e7eb; border-radius: 6px;
           padding: 10px 14px; text-align: center; }}
  .stat-num {{ font-size: 26px; font-weight: 700; color: #3b82d4; }}
  .stat-label {{ font-size: 12px; color: #57606a; }}
  code {{ font-family: Consolas, monospace; font-size: 11.5px;
          background: #f0f0f0; padding: 1px 4px; border-radius: 3px; }}
  @media print {{ body {{ padding: 16px 24px; }} }}
</style>"""


def _render_aws_html(r: dict) -> str:
    findings  = r.get("findings", [])
    privesc   = r.get("privilege_escalation_paths", [])
    recs      = r.get("recommendations", [])
    rl        = r.get("rl_analysis")
    validation_results = r.get("validation_results", [])
    graph_sum = r.get("graph_summary", {})
    risk      = r.get("risk_assessment", {})
    inv       = r.get("resource_inventory", {})

    # findings table rows
    finding_rows = ""
    for f in sorted(findings, key=lambda x: ["CRITICAL","HIGH","MEDIUM","LOW","INFO"].index(x.get("severity","INFO"))):
        sev = f.get("severity", "INFO")
        finding_rows += f"""<tr>
          <td>{_sev_badge(sev)}</td>
          <td>{f.get('title','')}</td>
          <td style="font-size:12px;color:#57606a">{f.get('resource_arn') or f.get('bucket_name') or f.get('instance_id','')}</td>
          <td style="font-size:12px">{f.get('recommendation','')}</td>
        </tr>"""

    # privesc rows
    pe_rows = ""
    for p in privesc:
        confirmed_label = (
            '<span style="color:#16a34a;font-size:11px">✓ Simulator-confirmed</span>'
            if p.get("simulator_confirmed") else
            '<span style="color:#ca8a04;font-size:11px">⚠ Unconfirmed</span>'
        )
        pe_rows += f"""<tr>
          <td>{_sev_badge(p.get('severity','HIGH'))}</td>
          <td><code style="font-size:11px">{p.get('source_arn','')}</code></td>
          <td>{p.get('technique','')}</td>
          <td><code style="font-size:11px">{', '.join(p.get('required_actions',[]))}</code></td>
          <td>{confirmed_label}</td>
        </tr>"""

    rec_rows = ""
    for rec in recs:
        rec_rows += f"""<tr>
          <td>{_sev_badge(rec.get('priority','LOW'))}</td>
          <td><strong>{rec.get('title','')}</strong><br>
          <span style="font-size:12px;color:#57606a">{rec.get('detail','')}</span></td>
        </tr>"""

    rl_section = ""
    if rl:
        rl_section = f"""<h2>RL Agent Analysis</h2>
        <div style="background:#fff8ed;border-left:4px solid #e6a817;padding:8px 12px;margin-bottom:12px;font-size:13px">
          ⚠ Actions 4 and 5 are stubs. RL reward data is real but reflects this limitation.
        </div>
        <table>
          <tr><td><strong>Total Episodes</strong></td><td>{rl.get('total_episodes',0)}</td></tr>
          <tr><td><strong>Average Reward</strong></td><td>{rl.get('avg_reward',0):.2f}</td></tr>
          <tr><td><strong>Max Reward</strong></td><td>{rl.get('max_reward',0):.2f}</td></tr>
          <tr><td><strong>Convergence Episode</strong></td><td>{rl.get('convergence_episode') or 'N/A'}</td></tr>
        </table>"""

    overall_risk = risk.get("overall_risk", "UNKNOWN")
    risk_color   = _SEVERITY_COLORS.get(overall_risk, "#6b7280")

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AWS Security Assessment Report</title>
{_common_html_styles(risk_color)}
</head>
<body>

<h1>AWS Security Assessment Report</h1>
<div class="meta">
  Account: <strong>{r.get('account_id','UNKNOWN')}</strong> &nbsp;|&nbsp;
  Scan: {r.get('scan_timestamp','')} &nbsp;|&nbsp;
  Generated: {r.get('generated_at','')} &nbsp;|&nbsp;
  Overall Risk: <span class="risk-badge">{overall_risk}</span>
</div>

<h2>Executive Summary</h2>
<div class="exec">{r.get('executive_summary','')}</div>

<h2>Resource Inventory</h2>
<div class="stat-grid">
  <div class="stat"><div class="stat-num">{len(inv.get('iam_users',[]))}</div><div class="stat-label">IAM Users</div></div>
  <div class="stat"><div class="stat-num">{len(inv.get('iam_roles',[]))}</div><div class="stat-label">IAM Roles</div></div>
  <div class="stat"><div class="stat-num">{len(inv.get('s3_buckets',[]))}</div><div class="stat-label">S3 Buckets</div></div>
  <div class="stat"><div class="stat-num">{len(inv.get('ec2_instances',[]))}</div><div class="stat-label">EC2 Instances</div></div>
</div>

<h2>Risk Assessment</h2>
<table>
  <tr><th>Severity</th><th>Count</th></tr>
  {"".join(f'<tr><td>{_sev_badge(s)}</td><td>{risk.get("severity_breakdown",{}).get(s,0)}</td></tr>' for s in ["CRITICAL","HIGH","MEDIUM","LOW","INFO"])}
  <tr><td><strong>Privilege Escalation Paths</strong></td><td>{risk.get('privesc_count',0)}</td></tr>
</table>

{"<h2>Privilege Escalation Paths</h2><table><tr><th>Severity</th><th>Source ARN</th><th>Technique</th><th>Required Actions</th><th>Verification</th></tr>" + pe_rows + "</table>" if privesc else "<h2>Privilege Escalation Paths</h2><p style='color:#16a34a'>No confirmed privilege escalation paths detected.</p>"}

<h2>Findings ({len(findings)})</h2>
{"<table><tr><th>Severity</th><th>Title</th><th>Resource</th><th>Recommendation</th></tr>" + finding_rows + "</table>" if findings else "<p style='color:#57606a'>No findings recorded.</p>"}

{rl_section}

{_render_validation_section(validation_results)}

<h2>Recommendations</h2>
<table><tr><th>Priority</th><th>Recommendation</th></tr>{rec_rows}</table>

{"<h2>Graph Summary</h2><p>Nodes: <strong>" + str(graph_sum.get('nodes',0)) + "</strong> &nbsp; Edges: <strong>" + str(graph_sum.get('edges',0)) + "</strong></p>" if graph_sum else ""}

<div style="margin-top:48px;padding-top:12px;border-top:1px solid #e5e7eb;text-align:center;font-size:11px;color:#57606a">
  Generated by aws_pentest — Automated Multi-Cloud Penetration Testing via RL &nbsp;|&nbsp;
  For authorized use only
</div>

</body>
</html>"""


def _render_gcp_html(r: dict) -> str:
    findings  = r.get("findings", [])
    privesc   = r.get("privilege_escalation_paths", [])
    recs      = r.get("recommendations", [])
    risk      = r.get("risk_assessment", {})
    inv       = r.get("resource_inventory", {})

    finding_rows = ""
    for f in sorted(findings, key=lambda x: ["CRITICAL","HIGH","MEDIUM","LOW","INFO"].index(x.get("severity","INFO"))):
        sev = f.get("severity", "INFO")
        resource_ref = (
            f.get("resource_arn") or
            f.get("bucket_name") or
            f.get("instance_name") or
            f.get("instance_id") or ""
        )
        finding_rows += f"""<tr>
          <td>{_sev_badge(sev)}</td>
          <td>{f.get('title','')}</td>
          <td style="font-size:12px;color:#57606a">{resource_ref}</td>
          <td style="font-size:12px">{f.get('recommendation','')}</td>
        </tr>"""

    pe_rows = ""
    for p in privesc:
        pe_rows += f"""<tr>
          <td>{_sev_badge(p.get('severity','HIGH'))}</td>
          <td><code style="font-size:11px">{p.get('source_service_account', p.get('source_arn',''))}</code></td>
          <td>{p.get('technique','')}</td>
          <td><code style="font-size:11px">{', '.join(p.get('required_permissions', p.get('required_actions',[])))}</code></td>
        </tr>"""

    rec_rows = ""
    for rec in recs:
        rec_rows += f"""<tr>
          <td>{_sev_badge(rec.get('priority','LOW'))}</td>
          <td><strong>{rec.get('title','')}</strong><br>
          <span style="font-size:12px;color:#57606a">{rec.get('detail','')}</span></td>
        </tr>"""

    overall_risk = risk.get("overall_risk", "UNKNOWN")
    risk_color   = _SEVERITY_COLORS.get(overall_risk, "#6b7280")

    sa_count      = len(inv.get("service_accounts",  []))
    bucket_count  = len(inv.get("storage_buckets",   []))
    compute_count = len(inv.get("compute_instances", []))
    binding_count = inv.get("iam_bindings", 0)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>GCP Security Assessment Report</title>
{_common_html_styles(risk_color)}
</head>
<body>

<h1>GCP Security Assessment Report</h1>
<div class="meta">
  Project: <strong>{r.get('project_id','UNKNOWN')}</strong> &nbsp;|&nbsp;
  Scan: {r.get('scan_timestamp','')} &nbsp;|&nbsp;
  Generated: {r.get('generated_at','')} &nbsp;|&nbsp;
  Overall Risk: <span class="risk-badge">{overall_risk}</span>
</div>

<h2>Executive Summary</h2>
<div class="exec">{r.get('executive_summary','')}</div>

<h2>Resource Inventory</h2>
<div class="stat-grid">
  <div class="stat"><div class="stat-num">{sa_count}</div><div class="stat-label">Service Accounts</div></div>
  <div class="stat"><div class="stat-num">{binding_count}</div><div class="stat-label">IAM Bindings</div></div>
  <div class="stat"><div class="stat-num">{bucket_count}</div><div class="stat-label">Storage Buckets</div></div>
  <div class="stat"><div class="stat-num">{compute_count}</div><div class="stat-label">Compute Instances</div></div>
</div>

<h2>Risk Assessment</h2>
<table>
  <tr><th>Severity</th><th>Count</th></tr>
  {"".join(f'<tr><td>{_sev_badge(s)}</td><td>{risk.get("severity_breakdown",{}).get(s,0)}</td></tr>' for s in ["CRITICAL","HIGH","MEDIUM","LOW","INFO"])}
  <tr><td><strong>Privilege Escalation Paths</strong></td><td>{risk.get('privesc_count',0)}</td></tr>
</table>

{"<h2>Privilege Escalation Paths</h2><table><tr><th>Severity</th><th>Source Service Account</th><th>Technique</th><th>Required Permissions</th></tr>" + pe_rows + "</table>" if privesc else "<h2>Privilege Escalation Paths</h2><p style='color:#16a34a'>No privilege escalation paths detected.</p>"}

<h2>Findings ({len(findings)})</h2>
{"<table><tr><th>Severity</th><th>Title</th><th>Resource</th><th>Recommendation</th></tr>" + finding_rows + "</table>" if findings else "<p style='color:#57606a'>No findings recorded.</p>"}

<h2>Recommendations</h2>
<table><tr><th>Priority</th><th>Recommendation</th></tr>{rec_rows}</table>

<div style="margin-top:48px;padding-top:12px;border-top:1px solid #e5e7eb;text-align:center;font-size:11px;color:#57606a">
  Generated by gcp_pentest — Automated Multi-Cloud Penetration Testing via RL &nbsp;|&nbsp;
  For authorized use only
</div>

</body>
</html>"""
