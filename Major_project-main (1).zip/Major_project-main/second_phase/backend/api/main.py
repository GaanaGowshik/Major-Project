"""
FastAPI application entry point.

Run with:
    cd second_phase/backend
    .venv/Scripts/uvicorn api.main:app --reload --port 8000
"""

import sys
import os
from pathlib import Path

# Make sure all backend packages are importable
_BACKEND = Path(__file__).parent.parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routes.graph import router as graph_router
from api.routes.rl import router as rl_router
from api.routes.report import router as report_router
from api.routes.scan import router as scan_router
from api.routes.validate import router as validate_router

app = FastAPI(
    title="Multi-Cloud Pentest RL — API",
    description="Automated Multi-Cloud Penetration Testing via Reinforcement Learning",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(graph_router)
app.include_router(rl_router)
app.include_router(report_router)
app.include_router(scan_router)
app.include_router(validate_router)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "aws-pentest-rl"}
