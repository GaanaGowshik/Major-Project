"""
Phase 4 tests — GCPProvider integration (fully mocked).

All GCP SDK calls are mocked via unittest.mock.patch.
No real GCP API calls are made.

Tests verify:
  - authenticate() succeeds with mocked Resource Manager
  - authenticate() raises ProviderAuthError on GCP exceptions
  - discover_resources() returns correctly structured dict
  - analyze_security() flattens findings from discover_resources output
  - get_attack_graph() returns an AssessmentGraph
  - validate_finding() returns READ_ONLY status (Phase 7 gate)
  - Not authenticated before authenticate() raises RuntimeError
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch, patch as mock_patch

import pytest

from providers.gcp_provider import GCPProvider
from providers.base import ProviderAuthError
from aws_pentest.models.graph_models import AssessmentGraph
from gcp_pentest.models import (
    GCPComputeFinding,
    GCPFirewallRule,
    GCPInstance,
    GCPIAMBinding,
    GCPPrivEscPath,
    GCPServiceAccount,
    GCPStorageBucket,
    GCPStorageFinding,
    GCPRole,
    Severity,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_provider() -> GCPProvider:
    return GCPProvider()


def _patch_auth(project_id: str = "test-project"):
    """Context manager that mocks out the GCP auth + Resource Manager call."""
    mock_creds = MagicMock()
    mock_rm_client = MagicMock()
    mock_rm_client.get_project.return_value = MagicMock()

    patches = [
        patch("providers.gcp_provider.os.environ.get", return_value=None),
        patch("google.auth.default", return_value=(mock_creds, project_id)),
        patch(
            "providers.gcp_provider.resourcemanager_v3",
            MagicMock(ProjectsClient=MagicMock(return_value=mock_rm_client)),
        ),
    ]
    return patches, mock_creds


def _minimal_resources() -> dict:
    """Minimal discover_resources result for downstream tests."""
    sa = GCPServiceAccount(
        name="projects/test-project/serviceAccounts/test@test-project.iam.gserviceaccount.com",
        email="test@test-project.iam.gserviceaccount.com",
        project_id="test-project",
    )
    bucket = GCPStorageBucket(
        name="test-bucket",
        location="US",
        storage_class="STANDARD",
        is_public_read=False,
        is_public_write=False,
    )
    instance = GCPInstance(
        name="test-vm",
        zone="us-central1-a",
        machine_type="n1-standard-1",
        status="RUNNING",
        project_id="test-project",
    )
    fw = GCPFirewallRule(
        name="allow-ssh",
        network="global/networks/default",
        direction="INGRESS",
        source_ranges=["10.0.0.0/8"],
        allowed=[{"protocol": "tcp", "ports": ["22"]}],
    )
    return {
        "provider": "gcp",
        "project_id": "test-project",
        "resources": {
            "service_accounts": [sa],
            "iam_roles": [],
            "iam_bindings": [],
            "storage_buckets": [bucket],
            "compute_instances": [instance],
            "firewall_rules": [fw],
        },
        "findings": {
            "storage": [],
            "compute": [],
        },
        "privesc_paths": [],
    }


# ---------------------------------------------------------------------------
# Tests: authenticate
# ---------------------------------------------------------------------------

class TestAuthenticate:
    def test_authenticate_sets_authenticated(self):
        import sys
        provider = _make_provider()
        mock_creds = MagicMock()
        mock_rm_client = MagicMock()
        mock_rm_client.get_project.return_value = MagicMock()
        mock_rm_module = MagicMock()
        mock_rm_module.ProjectsClient.return_value = mock_rm_client

        with patch.dict(sys.modules, {"google.cloud.resourcemanager_v3": mock_rm_module}), \
             patch("google.auth.default", return_value=(mock_creds, "test-project")):
            result = provider.authenticate(project_id="test-project")

        assert result is True
        assert provider._authenticated is True
        assert provider._project_id == "test-project"

    def test_authenticate_raises_on_failure(self):
        provider = _make_provider()
        with patch("google.auth.default", side_effect=Exception("no credentials")):
            with pytest.raises(ProviderAuthError):
                provider.authenticate(project_id="test-project")

    def test_require_auth_raises_before_authenticate(self):
        provider = _make_provider()
        with pytest.raises(RuntimeError, match="authenticate()"):
            provider._require_auth()


# ---------------------------------------------------------------------------
# Tests: discover_resources
# ---------------------------------------------------------------------------

class TestDiscoverResources:
    def _make_authenticated_provider(self) -> GCPProvider:
        provider = _make_provider()
        provider._authenticated = True
        provider._project_id = "test-project"
        provider._credentials = MagicMock()
        return provider

    def test_discover_resources_structure(self):
        provider = self._make_authenticated_provider()

        mock_iam_enum = MagicMock()
        mock_iam_enum.enumerate_all.return_value = ([], [], [])

        mock_detector = MagicMock()
        mock_detector.detect_all.return_value = []

        mock_storage = MagicMock()
        mock_storage.enumerate_buckets.return_value = []
        mock_storage.check_findings.return_value = []

        mock_compute = MagicMock()
        mock_compute.enumerate_instances.return_value = []
        mock_compute.enumerate_firewall_rules.return_value = []
        mock_compute.check_findings.return_value = []

        with patch("gcp_pentest.iam.enumerator.GCPIAMEnumerator", return_value=mock_iam_enum), \
             patch("gcp_pentest.iam.privesc.GCPPrivEscDetector", return_value=mock_detector), \
             patch("gcp_pentest.storage.analyser.GCPStorageAnalyser", return_value=mock_storage), \
             patch("gcp_pentest.compute.analyser.GCPComputeAnalyser", return_value=mock_compute):
            result = provider.discover_resources()

        assert result["provider"] == "gcp"
        assert result["project_id"] == "test-project"
        assert "resources" in result
        assert "findings" in result
        assert "privesc_paths" in result
        assert "service_accounts" in result["resources"]
        assert "storage_buckets" in result["resources"]
        assert "compute_instances" in result["resources"]

    def test_skip_privesc(self):
        provider = self._make_authenticated_provider()

        mock_iam_enum = MagicMock()
        mock_iam_enum.enumerate_all.return_value = ([], [], [])
        mock_detector = MagicMock()
        mock_storage = MagicMock()
        mock_storage.enumerate_buckets.return_value = []
        mock_storage.check_findings.return_value = []
        mock_compute = MagicMock()
        mock_compute.enumerate_instances.return_value = []
        mock_compute.enumerate_firewall_rules.return_value = []
        mock_compute.check_findings.return_value = []

        with patch("gcp_pentest.iam.enumerator.GCPIAMEnumerator", return_value=mock_iam_enum), \
             patch("gcp_pentest.iam.privesc.GCPPrivEscDetector", return_value=mock_detector), \
             patch("gcp_pentest.storage.analyser.GCPStorageAnalyser", return_value=mock_storage), \
             patch("gcp_pentest.compute.analyser.GCPComputeAnalyser", return_value=mock_compute):
            provider.discover_resources(skip_privesc=True)

        mock_detector.detect_all.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: analyze_security
# ---------------------------------------------------------------------------

class TestAnalyzeSecurity:
    def test_flattens_findings(self):
        provider = _make_provider()
        storage_finding = MagicMock(spec=GCPStorageFinding)
        compute_finding = MagicMock(spec=GCPComputeFinding)
        privesc_path = MagicMock(spec=GCPPrivEscPath)

        resources = {
            "findings": {
                "storage": [storage_finding],
                "compute": [compute_finding],
            },
            "privesc_paths": [privesc_path],
        }
        result = provider.analyze_security(resources)
        assert storage_finding in result
        assert compute_finding in result
        assert privesc_path in result
        assert len(result) == 3

    def test_empty_resources(self):
        provider = _make_provider()
        result = provider.analyze_security({"findings": {}, "privesc_paths": []})
        assert result == []


# ---------------------------------------------------------------------------
# Tests: get_attack_graph
# ---------------------------------------------------------------------------

class TestGetAttackGraph:
    def test_returns_assessment_graph(self):
        provider = _make_provider()
        provider._authenticated = True
        provider._project_id = "test-project"
        provider._credentials = MagicMock()

        resources = _minimal_resources()
        mock_builder = MagicMock()
        mock_graph = MagicMock(spec=AssessmentGraph)
        mock_builder.build.return_value = mock_graph

        with patch("gcp_pentest.graph.builder.GCPGraphBuilder", return_value=mock_builder):
            result = provider.get_attack_graph(resources, [])

        assert result is mock_graph
        mock_builder.build.assert_called_once()


# ---------------------------------------------------------------------------
# Tests: validate_finding
# ---------------------------------------------------------------------------

class TestValidateFinding:
    def test_returns_read_only_status(self):
        provider = _make_provider()
        result = provider.validate_finding("gcp-finding-001")
        assert result["mode"] == "READ_ONLY"
        assert result["status"] == "not_available"
        assert result["finding_id"] == "gcp-finding-001"
        assert result["cleanup_done"] is False
        assert "Phase 7" in result["description"]

    def test_no_gcp_resources_mutated(self):
        """validate_finding must not call any GCP SDK."""
        provider = _make_provider()
        # Credentials not set — any GCP call would fail
        result = provider.validate_finding("test-id", dry_run=True)
        assert result["status"] == "not_available"
