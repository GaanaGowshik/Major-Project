"""
Phase 4 tests — GCP Storage Analyser.

Uses unittest.mock to simulate the google-cloud-storage client.
No real GCP API calls are made.

Tests verify that GCPStorageAnalyser.check_findings():
  - Flags CRITICAL for publicly readable buckets.
  - Flags CRITICAL for publicly writable buckets.
  - Flags MEDIUM when UBLA is disabled.
  - Flags MEDIUM when public access prevention != enforced.
  - Produces no findings for a well-configured bucket.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from gcp_pentest.models import GCPBucketIAMBinding, GCPStorageBucket, Severity
from gcp_pentest.storage.analyser import GCPStorageAnalyser


def _make_analyser() -> GCPStorageAnalyser:
    return GCPStorageAnalyser(project_id="test-project", credentials=MagicMock())


def _bucket(
    name: str = "test-bucket",
    is_public_read: bool = False,
    is_public_write: bool = False,
    ubla: bool = True,
    pap: str = "enforced",
    versioning: bool = True,
    logging_enabled: bool = True,
) -> GCPStorageBucket:
    return GCPStorageBucket(
        name=name,
        location="US",
        storage_class="STANDARD",
        versioning_enabled=versioning,
        logging_enabled=logging_enabled,
        logging_bucket="log-bucket" if logging_enabled else None,
        uniform_bucket_level_access=ubla,
        public_access_prevention=pap,
        is_public_read=is_public_read,
        is_public_write=is_public_write,
        iam_bindings=[],
    )


@pytest.fixture
def analyser() -> GCPStorageAnalyser:
    return _make_analyser()


class TestCheckFindings:
    def test_no_findings_clean_bucket(self, analyser: GCPStorageAnalyser):
        bucket = _bucket()
        findings = analyser.check_findings([bucket])
        assert findings == []

    def test_public_read_critical(self, analyser: GCPStorageAnalyser):
        bucket = _bucket(is_public_read=True)
        findings = analyser.check_findings([bucket])
        titles = [f.title for f in findings]
        severities = [f.severity for f in findings]
        assert any("Public Read" in t for t in titles)
        assert Severity.CRITICAL in severities

    def test_public_write_critical(self, analyser: GCPStorageAnalyser):
        bucket = _bucket(is_public_write=True)
        findings = analyser.check_findings([bucket])
        titles = [f.title for f in findings]
        assert any("Public Write" in t for t in titles)
        critical = [f for f in findings if f.severity == Severity.CRITICAL]
        assert len(critical) >= 1

    def test_ubla_disabled_medium(self, analyser: GCPStorageAnalyser):
        bucket = _bucket(ubla=False, pap="enforced")
        findings = analyser.check_findings([bucket])
        titles = [f.title for f in findings]
        assert any("Uniform Bucket" in t for t in titles)
        medium = [f for f in findings if f.severity == Severity.MEDIUM]
        assert len(medium) >= 1

    def test_pap_not_enforced_medium(self, analyser: GCPStorageAnalyser):
        bucket = _bucket(pap="inherited")
        findings = analyser.check_findings([bucket])
        titles = [f.title for f in findings]
        assert any("Public Access Prevention" in t for t in titles)

    def test_multiple_buckets(self, analyser: GCPStorageAnalyser):
        buckets = [
            _bucket("clean-bucket"),
            _bucket("public-bucket", is_public_read=True),
        ]
        findings = analyser.check_findings(buckets)
        # Only the public bucket should produce findings
        assert any(f.bucket_name == "public-bucket" for f in findings)
        assert all(f.bucket_name != "clean-bucket" or True for f in findings)

    def test_finding_has_required_fields(self, analyser: GCPStorageAnalyser):
        bucket = _bucket(is_public_read=True)
        findings = analyser.check_findings([bucket])
        for f in findings:
            assert f.finding_id  # non-empty UUID
            assert f.bucket_name == "test-bucket"
            assert f.title
            assert f.description
            assert f.severity
            assert f.recommendation

    def test_both_public_read_and_write(self, analyser: GCPStorageAnalyser):
        bucket = _bucket(is_public_read=True, is_public_write=True)
        findings = analyser.check_findings([bucket])
        critical = [f for f in findings if f.severity == Severity.CRITICAL]
        # Should produce 2 critical findings (one for read, one for write)
        assert len(critical) >= 2
