"""
Phase 4 tests — GCP Compute Engine Analyser (check_findings only).

Tests GCPComputeAnalyser.check_findings() using pre-built model objects.
No real GCP API calls are made.

Covers:
  - Default service account detection (HIGH)
  - Public IP detection (MEDIUM)
  - OS Login not enabled (LOW)
  - Firewall rule open to 0.0.0.0/0 on sensitive port (HIGH/CRITICAL)
  - Firewall rule open to 0.0.0.0/0 on all ports (CRITICAL)
  - Disabled firewall rules are ignored
  - Clean instance and clean firewall produce no findings
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from gcp_pentest.compute.analyser import GCPComputeAnalyser
from gcp_pentest.models import GCPFirewallRule, GCPInstance, Severity


def _analyser() -> GCPComputeAnalyser:
    return GCPComputeAnalyser(project_id="test-project", credentials=MagicMock())


def _instance(
    name: str = "test-vm",
    zone: str = "us-central1-a",
    public_ips: list[str] | None = None,
    service_accounts: list[dict] | None = None,
    metadata: dict | None = None,
) -> GCPInstance:
    if public_ips is None:
        public_ips = []
    if service_accounts is None:
        service_accounts = []
    if metadata is None:
        metadata = {}
    # GCPInstance.service_accounts is list[dict[str, str]]; scopes must be a string
    normalised_sas = [
        {k: (str(v) if not isinstance(v, str) else v) for k, v in sa.items()}
        for sa in service_accounts
    ]
    return GCPInstance(
        name=name,
        zone=zone,
        machine_type="n1-standard-1",
        status="RUNNING",
        network_interfaces=[],
        service_accounts=normalised_sas,
        metadata=metadata,
        labels={},
        public_ips=public_ips,
        project_id="test-project",
    )


def _firewall(
    name: str = "test-fw",
    direction: str = "INGRESS",
    source_ranges: list[str] | None = None,
    allowed: list[dict] | None = None,
    disabled: bool = False,
) -> GCPFirewallRule:
    if source_ranges is None:
        source_ranges = []
    if allowed is None:
        allowed = []
    return GCPFirewallRule(
        name=name,
        network="global/networks/default",
        direction=direction,
        priority=1000,
        source_ranges=source_ranges,
        destination_ranges=[],
        source_tags=[],
        target_tags=[],
        allowed=allowed,
        denied=[],
        disabled=disabled,
    )


@pytest.fixture
def analyser() -> GCPComputeAnalyser:
    return _analyser()


# ---------------------------------------------------------------------------
# Clean cases — no findings expected
# ---------------------------------------------------------------------------

class TestCleanInstance:
    def test_clean_instance_no_findings(self, analyser: GCPComputeAnalyser):
        # Custom SA (not default), private IP, OS Login enabled
        inst = _instance(
            service_accounts=[{"email": "custom-sa@test-project.iam.gserviceaccount.com", "scopes": []}],
            metadata={"enable-oslogin": "TRUE"},
        )
        findings = analyser.check_findings([inst], [])
        assert findings == []

    def test_disabled_firewall_no_findings(self, analyser: GCPComputeAnalyser):
        fw = _firewall(
            source_ranges=["0.0.0.0/0"],
            allowed=[{"protocol": "tcp", "ports": ["22"]}],
            disabled=True,
        )
        findings = analyser.check_findings([], [fw])
        assert findings == []

    def test_restricted_firewall_no_findings(self, analyser: GCPComputeAnalyser):
        fw = _firewall(
            source_ranges=["10.0.0.0/8"],
            allowed=[{"protocol": "tcp", "ports": ["22"]}],
        )
        findings = analyser.check_findings([], [fw])
        assert findings == []


# ---------------------------------------------------------------------------
# Default service account
# ---------------------------------------------------------------------------

class TestDefaultServiceAccount:
    def test_default_sa_high(self, analyser: GCPComputeAnalyser):
        inst = _instance(
            service_accounts=[
                {"email": "123456789-compute@developer.gserviceaccount.com", "scopes": []}
            ],
            metadata={"enable-oslogin": "TRUE"},
        )
        findings = analyser.check_findings([inst], [])
        titles = [f.title for f in findings]
        assert any("Default Compute Service Account" in t for t in titles)
        high = [f for f in findings if f.severity == Severity.HIGH]
        assert len(high) >= 1


# ---------------------------------------------------------------------------
# Public IP
# ---------------------------------------------------------------------------

class TestPublicIP:
    def test_public_ip_medium(self, analyser: GCPComputeAnalyser):
        inst = _instance(
            public_ips=["34.56.78.90"],
            metadata={"enable-oslogin": "TRUE"},
            service_accounts=[{"email": "custom@p.iam.gserviceaccount.com", "scopes": []}],
        )
        findings = analyser.check_findings([inst], [])
        titles = [f.title for f in findings]
        assert any("Public IP" in t for t in titles)
        med = [f for f in findings if f.severity == Severity.MEDIUM]
        assert len(med) >= 1


# ---------------------------------------------------------------------------
# Firewall: sensitive port open to internet
# ---------------------------------------------------------------------------

class TestFirewallSensitivePorts:
    def test_ssh_open_to_internet(self, analyser: GCPComputeAnalyser):
        fw = _firewall(
            source_ranges=["0.0.0.0/0"],
            allowed=[{"protocol": "tcp", "ports": ["22"]}],
        )
        findings = analyser.check_findings([], [fw])
        assert len(findings) >= 1
        titles = [f.title for f in findings]
        assert any("SSH" in t or "22" in t for t in titles)

    def test_rdp_open_to_internet(self, analyser: GCPComputeAnalyser):
        fw = _firewall(
            source_ranges=["0.0.0.0/0"],
            allowed=[{"protocol": "tcp", "ports": ["3389"]}],
        )
        findings = analyser.check_findings([], [fw])
        titles = [f.title for f in findings]
        assert any("RDP" in t or "3389" in t for t in titles)

    def test_all_ports_open_to_internet(self, analyser: GCPComputeAnalyser):
        fw = _firewall(
            source_ranges=["0.0.0.0/0"],
            allowed=[{"protocol": "tcp", "ports": []}],
        )
        findings = analyser.check_findings([], [fw])
        assert len(findings) >= 1

    def test_egress_not_flagged(self, analyser: GCPComputeAnalyser):
        fw = _firewall(
            direction="EGRESS",
            source_ranges=["0.0.0.0/0"],
            allowed=[{"protocol": "tcp", "ports": ["22"]}],
        )
        findings = analyser.check_findings([], [fw])
        assert findings == []


# ---------------------------------------------------------------------------
# Combined: multiple issues on one instance
# ---------------------------------------------------------------------------

class TestMultipleIssues:
    def test_default_sa_and_public_ip(self, analyser: GCPComputeAnalyser):
        inst = _instance(
            public_ips=["34.1.2.3"],
            service_accounts=[
                {"email": "999-compute@developer.gserviceaccount.com", "scopes": []}
            ],
        )
        findings = analyser.check_findings([inst], [])
        # Should have HIGH (default SA) + MEDIUM (public IP) + LOW (no oslogin)
        severities = {f.severity for f in findings}
        assert Severity.HIGH in severities
        assert Severity.MEDIUM in severities
