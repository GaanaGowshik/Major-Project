"""
Phase 4 tests — GCP Privilege Escalation Detector.

All tests use unittest.mock — no real GCP API calls are made.
Tests verify that GCPPrivEscDetector:
  - Detects each of the 6 known techniques from real IAM bindings.
  - Does NOT produce false positives for benign bindings.
  - Sets confirmed=True on every returned path.
  - Produces no paths when bindings list is empty.
  - Handles multiple members per binding.
"""

from __future__ import annotations

import pytest

from gcp_pentest.iam.privesc import GCPPrivEscDetector
from gcp_pentest.models import GCPIAMBinding, GCPPrivEscPath, Severity


def _binding(role: str, members: list[str]) -> GCPIAMBinding:
    return GCPIAMBinding(
        role=role,
        members=members,
        resource="projects/test-project",
        resource_type="project",
    )


@pytest.fixture
def detector() -> GCPPrivEscDetector:
    return GCPPrivEscDetector()


# ---------------------------------------------------------------------------
# Empty / benign cases
# ---------------------------------------------------------------------------

class TestNoPaths:
    def test_empty_bindings(self, detector: GCPPrivEscDetector):
        paths = detector.detect_all([])
        assert paths == []

    def test_benign_role_no_paths(self, detector: GCPPrivEscDetector):
        bindings = [_binding("roles/viewer", ["user:alice@example.com"])]
        paths = detector.detect_all(bindings)
        assert paths == []

    def test_storage_object_viewer_no_paths(self, detector: GCPPrivEscDetector):
        bindings = [_binding("roles/storage.objectViewer", ["serviceAccount:sa@p.iam.gserviceaccount.com"])]
        paths = detector.detect_all(bindings)
        assert paths == []


# ---------------------------------------------------------------------------
# P01 — ServiceAccountTokenCreator
# ---------------------------------------------------------------------------

class TestP01TokenCreator:
    def test_detects_token_creator(self, detector: GCPPrivEscDetector):
        bindings = [
            _binding("roles/iam.serviceAccountTokenCreator", ["user:attacker@example.com"])
        ]
        paths = detector.detect_all(bindings)
        assert len(paths) == 1
        p = paths[0]
        assert p.technique == "ServiceAccountTokenCreator"
        assert p.severity == Severity.CRITICAL
        assert p.confirmed is True
        assert p.source_member == "user:attacker@example.com"

    def test_evidence_contains_binding(self, detector: GCPPrivEscDetector):
        bindings = [
            _binding("roles/iam.serviceAccountTokenCreator", ["user:attacker@example.com"])
        ]
        paths = detector.detect_all(bindings)
        ev = paths[0].evidence[0]
        assert ev["role"] == "roles/iam.serviceAccountTokenCreator"
        assert ev["member"] == "user:attacker@example.com"
        assert ev["technique_id"] == "P01"


# ---------------------------------------------------------------------------
# P02 — ServiceAccountUser
# ---------------------------------------------------------------------------

class TestP02ServiceAccountUser:
    def test_detects_sa_user(self, detector: GCPPrivEscDetector):
        bindings = [
            _binding("roles/iam.serviceAccountUser", ["serviceAccount:app@p.iam.gserviceaccount.com"])
        ]
        paths = detector.detect_all(bindings)
        assert len(paths) == 1
        assert paths[0].technique == "ServiceAccountUser"
        assert paths[0].severity == Severity.HIGH


# ---------------------------------------------------------------------------
# P04 — ProjectOwner / Editor
# ---------------------------------------------------------------------------

class TestP04OwnerEditor:
    def test_detects_project_owner(self, detector: GCPPrivEscDetector):
        bindings = [_binding("roles/owner", ["user:owner@example.com"])]
        paths = detector.detect_all(bindings)
        techniques = [p.technique for p in paths]
        assert "ProjectOwnerOrEditor" in techniques
        for p in paths:
            if p.technique == "ProjectOwnerOrEditor":
                assert p.severity == Severity.CRITICAL

    def test_detects_project_editor(self, detector: GCPPrivEscDetector):
        bindings = [_binding("roles/editor", ["user:editor@example.com"])]
        paths = detector.detect_all(bindings)
        techniques = [p.technique for p in paths]
        assert "ProjectOwnerOrEditor" in techniques


# ---------------------------------------------------------------------------
# P05 — IAMAdmin
# ---------------------------------------------------------------------------

class TestP05IAMAdmin:
    def test_detects_iam_security_admin(self, detector: GCPPrivEscDetector):
        bindings = [_binding("roles/iam.securityAdmin", ["user:sec-admin@example.com"])]
        paths = detector.detect_all(bindings)
        techniques = [p.technique for p in paths]
        assert "IAMAdminRole" in techniques
        for p in paths:
            if p.technique == "IAMAdminRole":
                assert p.severity == Severity.CRITICAL

    def test_detects_project_iam_admin(self, detector: GCPPrivEscDetector):
        bindings = [
            _binding("roles/resourcemanager.projectIamAdmin", ["serviceAccount:tf@p.iam.gserviceaccount.com"])
        ]
        paths = detector.detect_all(bindings)
        techniques = [p.technique for p in paths]
        assert "IAMAdminRole" in techniques


# ---------------------------------------------------------------------------
# P06 — WorkloadIdentityUser
# ---------------------------------------------------------------------------

class TestP06WorkloadIdentity:
    def test_detects_workload_identity_user(self, detector: GCPPrivEscDetector):
        bindings = [
            _binding("roles/iam.workloadIdentityUser", ["serviceAccount:wi@p.iam.gserviceaccount.com"])
        ]
        paths = detector.detect_all(bindings)
        techniques = [p.technique for p in paths]
        assert "WorkloadIdentityUser" in techniques
        for p in paths:
            if p.technique == "WorkloadIdentityUser":
                assert p.severity == Severity.HIGH


# ---------------------------------------------------------------------------
# Multiple members per binding
# ---------------------------------------------------------------------------

class TestMultipleMembers:
    def test_one_path_per_member(self, detector: GCPPrivEscDetector):
        bindings = [
            _binding(
                "roles/iam.serviceAccountTokenCreator",
                ["user:alice@example.com", "user:bob@example.com"],
            )
        ]
        paths = detector.detect_all(bindings)
        members_found = {p.source_member for p in paths}
        assert "user:alice@example.com" in members_found
        assert "user:bob@example.com" in members_found


# ---------------------------------------------------------------------------
# confirmed flag always True
# ---------------------------------------------------------------------------

class TestConfirmedFlag:
    def test_all_paths_confirmed(self, detector: GCPPrivEscDetector):
        bindings = [
            _binding("roles/iam.serviceAccountTokenCreator", ["user:a@example.com"]),
            _binding("roles/owner", ["user:b@example.com"]),
        ]
        paths = detector.detect_all(bindings)
        assert all(p.confirmed is True for p in paths)
