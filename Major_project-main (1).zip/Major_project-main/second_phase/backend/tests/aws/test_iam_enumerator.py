"""
Tests for aws_pentest.iam.enumerator using moto (in-process AWS mock).

These tests verify that the enumerator correctly calls real IAM API shapes
and parses the responses into typed Pydantic models.
"""

import json

import boto3
import pytest
from moto import mock_aws

from aws_pentest.iam.enumerator import IAMEnumerator
from aws_pentest.models.iam_models import IAMUser, IAMRole, IAMGroup


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_session(region="us-east-1"):
    return boto3.Session(
        aws_access_key_id="testing",
        aws_secret_access_key="testing",
        aws_session_token="testing",
        region_name=region,
    )


TRUST_DOC = json.dumps({
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "ec2.amazonaws.com"},
            "Action": "sts:AssumeRole",
        }
    ],
})

ADMIN_POLICY_DOC = json.dumps({
    "Version": "2012-10-17",
    "Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}],
})

S3_INLINE_DOC = json.dumps({
    "Version": "2012-10-17",
    "Statement": [{"Effect": "Allow", "Action": ["s3:GetObject"], "Resource": "*"}],
})


# ---------------------------------------------------------------------------
# User enumeration
# ---------------------------------------------------------------------------

@mock_aws
def test_enumerate_users_empty(aws_credentials):
    session = _make_session()
    enumerator = IAMEnumerator(session=session)
    users, _, _ = enumerator.enumerate_all()
    assert users == []


@mock_aws
def test_enumerate_single_user(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_user(UserName="alice")

    enumerator = IAMEnumerator(session=session)
    users, _, _ = enumerator.enumerate_all()

    assert len(users) == 1
    alice = users[0]
    assert isinstance(alice, IAMUser)
    assert alice.username == "alice"
    assert alice.arn.endswith(":user/alice")


@mock_aws
def test_enumerate_user_with_attached_managed_policy(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_user(UserName="bob")

    # Create and attach a managed policy
    resp = iam.create_policy(
        PolicyName="MyManagedPolicy",
        PolicyDocument=ADMIN_POLICY_DOC,
    )
    policy_arn = resp["Policy"]["Arn"]
    iam.attach_user_policy(UserName="bob", PolicyArn=policy_arn)

    enumerator = IAMEnumerator(session=session)
    users, _, _ = enumerator.enumerate_all()

    assert len(users) == 1
    bob = users[0]
    assert len(bob.attached_policies) == 1
    assert bob.attached_policies[0].name == "MyManagedPolicy"


@mock_aws
def test_enumerate_user_with_inline_policy(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_user(UserName="charlie")
    iam.put_user_policy(
        UserName="charlie",
        PolicyName="InlineS3",
        PolicyDocument=S3_INLINE_DOC,
    )

    enumerator = IAMEnumerator(session=session)
    users, _, _ = enumerator.enumerate_all()

    assert len(users) == 1
    charlie = users[0]
    assert len(charlie.inline_policies) == 1
    assert charlie.inline_policies[0].name == "InlineS3"
    assert "s3:GetObject" in charlie.inline_policies[0].statements[0].actions


@mock_aws
def test_enumerate_multiple_users(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    for name in ["user1", "user2", "user3"]:
        iam.create_user(UserName=name)

    enumerator = IAMEnumerator(session=session)
    users, _, _ = enumerator.enumerate_all()
    assert len(users) == 3


# ---------------------------------------------------------------------------
# Role enumeration
# ---------------------------------------------------------------------------

@mock_aws
def test_enumerate_roles_empty(aws_credentials):
    session = _make_session()
    enumerator = IAMEnumerator(session=session)
    _, roles, _ = enumerator.enumerate_all()
    assert roles == []


@mock_aws
def test_enumerate_single_role_with_trust(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_role(
        RoleName="MyRole",
        AssumeRolePolicyDocument=TRUST_DOC,
    )

    enumerator = IAMEnumerator(session=session)
    _, roles, _ = enumerator.enumerate_all()

    assert len(roles) == 1
    role = roles[0]
    assert isinstance(role, IAMRole)
    assert role.role_name == "MyRole"
    assert role.arn.endswith(":role/MyRole")


@mock_aws
def test_enumerate_role_trust_relationships_parsed(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_role(
        RoleName="EC2Role",
        AssumeRolePolicyDocument=TRUST_DOC,
    )

    enumerator = IAMEnumerator(session=session)
    _, roles, _ = enumerator.enumerate_all()

    role = roles[0]
    assert len(role.trust_relationships) == 1
    trust = role.trust_relationships[0]
    assert trust.principal_arn == "ec2.amazonaws.com"
    assert trust.principal_type == "Service"
    assert "sts:AssumeRole" in trust.actions


@mock_aws
def test_enumerate_role_with_attached_policy(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_role(RoleName="DevRole", AssumeRolePolicyDocument=TRUST_DOC)
    resp = iam.create_policy(
        PolicyName="DevPolicy", PolicyDocument=S3_INLINE_DOC
    )
    iam.attach_role_policy(RoleName="DevRole", PolicyArn=resp["Policy"]["Arn"])

    enumerator = IAMEnumerator(session=session)
    _, roles, _ = enumerator.enumerate_all()

    role = roles[0]
    assert len(role.attached_policies) == 1
    assert role.attached_policies[0].name == "DevPolicy"


@mock_aws
def test_enumerate_role_with_inline_policy(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_role(RoleName="InlineRole", AssumeRolePolicyDocument=TRUST_DOC)
    iam.put_role_policy(
        RoleName="InlineRole",
        PolicyName="InlinePolicy",
        PolicyDocument=S3_INLINE_DOC,
    )

    enumerator = IAMEnumerator(session=session)
    _, roles, _ = enumerator.enumerate_all()

    role = roles[0]
    assert len(role.inline_policies) == 1
    assert role.inline_policies[0].name == "InlinePolicy"


# ---------------------------------------------------------------------------
# Group enumeration
# ---------------------------------------------------------------------------

@mock_aws
def test_enumerate_group(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_group(GroupName="Admins")

    enumerator = IAMEnumerator(session=session)
    _, _, groups = enumerator.enumerate_all()

    assert len(groups) == 1
    assert groups[0].group_name == "Admins"


@mock_aws
def test_enumerate_user_group_membership(aws_credentials):
    session = _make_session()
    iam = session.client("iam")
    iam.create_user(UserName="dana")
    iam.create_group(GroupName="Developers")
    iam.add_user_to_group(UserName="dana", GroupName="Developers")

    enumerator = IAMEnumerator(session=session)
    users, _, _ = enumerator.enumerate_all()

    assert "Developers" in users[0].groups
