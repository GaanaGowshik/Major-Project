"""
Tests for aws_pentest.iam.policy_parser — pure Python, no AWS calls.
"""

import pytest
from aws_pentest.iam.policy_parser import PolicyParser
from aws_pentest.models.iam_models import PolicyEffect


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def parser():
    return PolicyParser()


@pytest.fixture
def admin_policy_doc():
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": "*",
                "Resource": "*",
            }
        ],
    }


@pytest.fixture
def s3_read_policy_doc():
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "AllowS3Read",
                "Effect": "Allow",
                "Action": ["s3:GetObject", "s3:ListBucket"],
                "Resource": ["arn:aws:s3:::my-bucket", "arn:aws:s3:::my-bucket/*"],
            }
        ],
    }


@pytest.fixture
def trust_policy_doc():
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {"AWS": "arn:aws:iam::123456789012:user/alice"},
                "Action": "sts:AssumeRole",
            },
            {
                "Effect": "Allow",
                "Principal": {"Service": "ec2.amazonaws.com"},
                "Action": "sts:AssumeRole",
            },
        ],
    }


# ---------------------------------------------------------------------------
# parse_policy_document
# ---------------------------------------------------------------------------

def test_parse_admin_policy_has_one_statement(parser, admin_policy_doc):
    policy = parser.parse_policy_document(admin_policy_doc, name="AdminPolicy")
    assert len(policy.statements) == 1


def test_parse_admin_policy_effect_allow(parser, admin_policy_doc):
    policy = parser.parse_policy_document(admin_policy_doc, name="AdminPolicy")
    assert policy.statements[0].effect == PolicyEffect.ALLOW


def test_parse_admin_policy_wildcard_action(parser, admin_policy_doc):
    policy = parser.parse_policy_document(admin_policy_doc, name="AdminPolicy")
    assert "*" in policy.statements[0].actions


def test_parse_s3_policy_actions(parser, s3_read_policy_doc):
    policy = parser.parse_policy_document(s3_read_policy_doc, name="S3Read")
    stmt = policy.statements[0]
    assert "s3:GetObject" in stmt.actions
    assert "s3:ListBucket" in stmt.actions


def test_parse_s3_policy_sid(parser, s3_read_policy_doc):
    policy = parser.parse_policy_document(s3_read_policy_doc, name="S3Read")
    assert policy.statements[0].sid == "AllowS3Read"


def test_parse_policy_stores_raw_document(parser, admin_policy_doc):
    policy = parser.parse_policy_document(admin_policy_doc, name="AdminPolicy")
    assert policy.raw_document == admin_policy_doc


def test_parse_inline_policy_type(parser, s3_read_policy_doc):
    policy = parser.parse_policy_document(
        s3_read_policy_doc, name="InlinePolicy", policy_type="inline"
    )
    assert policy.policy_type == "inline"
    assert policy.arn is None


def test_parse_managed_policy_arn(parser, admin_policy_doc):
    arn = "arn:aws:iam::aws:policy/AdministratorAccess"
    policy = parser.parse_policy_document(
        admin_policy_doc, name="AdministratorAccess", policy_type="managed", arn=arn
    )
    assert policy.arn == arn


# ---------------------------------------------------------------------------
# has_wildcard_action / has_wildcard_principal
# ---------------------------------------------------------------------------

def test_has_wildcard_action_true(parser, admin_policy_doc):
    policy = parser.parse_policy_document(admin_policy_doc, name="Admin")
    assert parser.has_wildcard_action(policy) is True


def test_has_wildcard_action_false(parser, s3_read_policy_doc):
    policy = parser.parse_policy_document(s3_read_policy_doc, name="S3")
    assert parser.has_wildcard_action(policy) is False


def test_has_wildcard_principal_true(parser):
    doc = {
        "Version": "2012-10-17",
        "Statement": [
            {"Effect": "Allow", "Principal": "*", "Action": "s3:GetObject", "Resource": "*"},
        ],
    }
    policy = parser.parse_policy_document(doc, name="PublicBucket")
    assert parser.has_wildcard_principal(policy) is True


def test_has_wildcard_principal_false(parser, s3_read_policy_doc):
    policy = parser.parse_policy_document(s3_read_policy_doc, name="S3")
    assert parser.has_wildcard_principal(policy) is False


# ---------------------------------------------------------------------------
# statements_granting
# ---------------------------------------------------------------------------

def test_statements_granting_match(parser, s3_read_policy_doc):
    policy = parser.parse_policy_document(s3_read_policy_doc, name="S3")
    stmts = parser.statements_granting(policy, "s3:GetObject", "arn:aws:s3:::my-bucket/key")
    assert len(stmts) == 1


def test_statements_granting_no_match(parser, s3_read_policy_doc):
    policy = parser.parse_policy_document(s3_read_policy_doc, name="S3")
    stmts = parser.statements_granting(policy, "s3:PutObject", "arn:aws:s3:::my-bucket/key")
    assert len(stmts) == 0


def test_statements_granting_glob_action(parser):
    doc = {
        "Version": "2012-10-17",
        "Statement": [
            {"Effect": "Allow", "Action": "s3:Get*", "Resource": "*"},
        ],
    }
    policy = parser.parse_policy_document(doc, name="S3GetAll")
    stmts = parser.statements_granting(policy, "s3:GetObject", "*")
    assert len(stmts) == 1


def test_statements_granting_deny_not_returned(parser):
    doc = {
        "Version": "2012-10-17",
        "Statement": [
            {"Effect": "Deny", "Action": "s3:GetObject", "Resource": "*"},
        ],
    }
    policy = parser.parse_policy_document(doc, name="S3DenyRead")
    stmts = parser.statements_granting(policy, "s3:GetObject", "*")
    assert len(stmts) == 0


# ---------------------------------------------------------------------------
# parse_trust_policy
# ---------------------------------------------------------------------------

def test_parse_trust_policy_user_principal(parser, trust_policy_doc):
    relationships = parser.parse_trust_policy(trust_policy_doc)
    user_trusts = [r for r in relationships if "user/alice" in r.principal_arn]
    assert len(user_trusts) == 1
    assert user_trusts[0].principal_type == "AWS"


def test_parse_trust_policy_service_principal(parser, trust_policy_doc):
    relationships = parser.parse_trust_policy(trust_policy_doc)
    service_trusts = [r for r in relationships if r.principal_type == "Service"]
    assert len(service_trusts) == 1
    assert service_trusts[0].principal_arn == "ec2.amazonaws.com"


def test_parse_trust_policy_actions_include_assume_role(parser, trust_policy_doc):
    relationships = parser.parse_trust_policy(trust_policy_doc)
    for r in relationships:
        assert "sts:AssumeRole" in r.actions


# ---------------------------------------------------------------------------
# URL-encoded document handling
# ---------------------------------------------------------------------------

def test_parse_url_encoded_document(parser):
    """Policy parser should handle URL-encoded string documents."""
    import json
    from urllib.parse import quote
    doc = {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Action": "s3:*", "Resource": "*"}]}
    encoded = quote(json.dumps(doc))
    policy = parser.parse_policy_document(encoded, name="Encoded")
    assert len(policy.statements) == 1
