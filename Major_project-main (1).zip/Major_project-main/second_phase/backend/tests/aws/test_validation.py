"""
Phase 6 tests — Controlled AWS Validation (AWSValidator).

All AWS API calls are mocked via unittest.mock.patch.
No real AWS resources are created.

Tests verify:
  - READ_ONLY mode returns not_performed for all techniques
  - DRY_RUN mode returns dry_run_preview with correct steps
  - VALIDATE without confirmed=True returns not_performed
  - s3_write VALIDATE success creates and deletes the test object
  - s3_write VALIDATE failure does not leak resources (cleanup in finally)
  - s3_read VALIDATE success uses ListObjectsV2 only
  - iam_pass_role VALIDATE uses IAM simulator (non-mutating)
  - VALIDATION_PREFIX is used in all resource names
  - ValidationResult.confirmed is only True when execution succeeds
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch, call

import pytest

from aws_pentest.validation.validator import (
    AWSValidator,
    ValidationMode,
    VALIDATION_PREFIX,
)


# ---------------------------------------------------------------------------
# Fixture: validator instances for each mode
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_session():
    return MagicMock()


@pytest.fixture
def read_only_validator(mock_session):
    return AWSValidator(session=mock_session, mode=ValidationMode.READ_ONLY, run_id="test-run")


@pytest.fixture
def dry_run_validator(mock_session):
    return AWSValidator(session=mock_session, mode=ValidationMode.DRY_RUN, run_id="test-run")


@pytest.fixture
def validate_validator(mock_session):
    return AWSValidator(session=mock_session, mode=ValidationMode.VALIDATE, run_id="test-run")


# ---------------------------------------------------------------------------
# Tests: ValidationMode safety gate
# ---------------------------------------------------------------------------

class TestReadOnlyMode:
    def test_s3_write_read_only_not_performed(self, read_only_validator: AWSValidator):
        result = read_only_validator.validate(
            "find-001", "s3_write", confirmed=False, bucket_name="test-bucket"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False
        assert result.mode == ValidationMode.READ_ONLY

    def test_s3_read_read_only_not_performed(self, read_only_validator: AWSValidator):
        result = read_only_validator.validate(
            "find-002", "s3_read", confirmed=False, bucket_name="test-bucket"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False

    def test_iam_pass_role_read_only_not_performed(self, read_only_validator: AWSValidator):
        result = read_only_validator.validate(
            "find-003", "iam_pass_role", confirmed=False,
            role_arn="arn:aws:iam::123456789012:role/TestRole"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False

    def test_read_only_no_aws_calls(self, mock_session: MagicMock, read_only_validator: AWSValidator):
        read_only_validator.validate("f", "s3_write", bucket_name="b")
        mock_session.client.assert_not_called()


class TestDryRunMode:
    def test_s3_write_dry_run_preview(self, dry_run_validator: AWSValidator):
        result = dry_run_validator.validate(
            "find-001", "s3_write", confirmed=False, bucket_name="my-bucket"
        )
        assert result.status == "dry_run_preview"
        assert result.confirmed is False
        assert len(result.dry_run_preview) >= 2
        assert any("PutObject" in step for step in result.dry_run_preview)
        assert any("DeleteObject" in step for step in result.dry_run_preview)

    def test_dry_run_no_aws_calls(self, mock_session: MagicMock, dry_run_validator: AWSValidator):
        dry_run_validator.validate("f", "s3_write", bucket_name="b")
        mock_session.client.assert_not_called()

    def test_iam_dry_run_preview(self, dry_run_validator: AWSValidator):
        result = dry_run_validator.validate(
            "find-003", "iam_pass_role", confirmed=False,
            role_arn="arn:aws:iam::123456789012:role/TestRole"
        )
        assert result.status == "dry_run_preview"
        assert any("SimulatePrincipalPolicy" in s for s in result.dry_run_preview)


class TestValidateModeUnconfirmed:
    def test_validate_without_confirmed_not_performed(self, validate_validator: AWSValidator):
        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=False, bucket_name="test-bucket"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False
        assert "confirmed=True" in result.description


# ---------------------------------------------------------------------------
# Tests: S3 Write Validation
# ---------------------------------------------------------------------------

class TestS3WriteValidation:
    def _make_s3_mock(self):
        s3 = MagicMock()
        s3.put_object.return_value = {}
        s3.get_object.return_value = {
            "Body": MagicMock(read=MagicMock(return_value=b"test content"))
        }
        s3.delete_object.return_value = {}
        return s3

    def test_s3_write_success(self, mock_session: MagicMock, validate_validator: AWSValidator):
        s3 = self._make_s3_mock()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="pentest-test-bucket"
        )

        assert result.status == "success"
        assert result.confirmed is True
        assert result.mode == ValidationMode.VALIDATE
        # Verify PutObject was called
        s3.put_object.assert_called_once()
        call_kwargs = s3.put_object.call_args[1]
        assert call_kwargs["Bucket"] == "pentest-test-bucket"
        assert VALIDATION_PREFIX in call_kwargs["Key"]

    def test_s3_write_uses_validation_prefix_in_key(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        s3 = self._make_s3_mock()
        mock_session.client.return_value = s3

        validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        key = s3.put_object.call_args[1]["Key"]
        assert key.startswith(VALIDATION_PREFIX)
        assert "test-run" in key  # run_id embedded

    def test_s3_write_cleanup_always_runs_on_success(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        s3 = self._make_s3_mock()
        mock_session.client.return_value = s3

        validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        s3.delete_object.assert_called_once()
        delete_kwargs = s3.delete_object.call_args[1]
        assert delete_kwargs["Bucket"] == "test-bucket"

    def test_s3_write_cleanup_runs_on_put_failure(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """Even when PutObject succeeds but GetObject fails, cleanup must run."""
        from botocore.exceptions import ClientError
        s3 = MagicMock()
        s3.put_object.return_value = {}
        s3.get_object.side_effect = ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "Denied"}}, "GetObject"
        )
        s3.delete_object.return_value = {}
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        # GetObject failed so we can't verify, but cleanup must still run
        assert result.status == "failure" or result.status == "error"
        # Delete should still be called since object was created
        s3.delete_object.assert_called_once()

    def test_s3_write_confirmed_false_when_put_denied(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        from botocore.exceptions import ClientError
        s3 = MagicMock()
        s3.put_object.side_effect = ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "Denied"}}, "PutObject"
        )
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        assert result.confirmed is False
        assert result.status in ("failure", "error")

    def test_s3_write_audit_log_populated(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        s3 = self._make_s3_mock()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        assert len(result.audit_log) >= 2
        actions = [e.action for e in result.audit_log]
        assert "s3:PutObject" in actions
        assert "s3:GetObject" in actions


# ---------------------------------------------------------------------------
# Tests: S3 Read Validation
# ---------------------------------------------------------------------------

class TestS3ReadValidation:
    def test_s3_read_success_uses_list_only(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        s3 = MagicMock()
        s3.list_objects_v2.return_value = {"KeyCount": 0, "Contents": []}
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-002", "s3_read", confirmed=True, bucket_name="test-bucket"
        )

        assert result.status == "success"
        assert result.confirmed is True
        # Must only call ListObjectsV2 — not GetObject on production keys
        s3.list_objects_v2.assert_called_once()
        s3.get_object.assert_not_called()

    def test_s3_read_prefix_restricted(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        s3 = MagicMock()
        s3.list_objects_v2.return_value = {"KeyCount": 0}
        mock_session.client.return_value = s3

        validate_validator.validate(
            "find-002", "s3_read", confirmed=True, bucket_name="test-bucket"
        )

        call_kwargs = s3.list_objects_v2.call_args[1]
        assert VALIDATION_PREFIX in call_kwargs["Prefix"]


# ---------------------------------------------------------------------------
# Tests: IAM PassRole Validation
# ---------------------------------------------------------------------------

class TestIAMPassRoleValidation:
    def test_iam_pass_role_allowed(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        sts = MagicMock()
        sts.get_caller_identity.return_value = {
            "Arn": "arn:aws:iam::123456789012:user/test-user",
            "Account": "123456789012",
        }
        iam = MagicMock()
        iam.simulate_principal_policy.return_value = {
            "EvaluationResults": [{"EvalDecision": "allowed", "EvalActionName": "iam:PassRole"}]
        }
        mock_session.client.side_effect = lambda svc, **kwargs: (sts if svc == "sts" else iam)

        result = validate_validator.validate(
            "find-003", "iam_pass_role", confirmed=True,
            role_arn="arn:aws:iam::123456789012:role/PrivilegedRole"
        )

        assert result.status == "success"
        assert result.confirmed is True
        assert "ALLOWED" in result.description
        assert result.cleanup_done is True  # IAM simulator is non-mutating

    def test_iam_pass_role_denied(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        sts = MagicMock()
        sts.get_caller_identity.return_value = {
            "Arn": "arn:aws:iam::123456789012:user/limited-user",
            "Account": "123456789012",
        }
        iam = MagicMock()
        iam.simulate_principal_policy.return_value = {
            "EvaluationResults": [{"EvalDecision": "implicitDeny", "EvalActionName": "iam:PassRole"}]
        }
        mock_session.client.side_effect = lambda svc, **kwargs: (sts if svc == "sts" else iam)

        result = validate_validator.validate(
            "find-003", "iam_pass_role", confirmed=True,
            role_arn="arn:aws:iam::123456789012:role/PrivilegedRole"
        )

        assert result.status == "failure"
        assert result.confirmed is False
        assert "DENIED" in result.description

    def test_iam_pass_role_no_iam_resources_created(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """IAM simulator must never create, attach, or modify IAM resources."""
        sts = MagicMock()
        sts.get_caller_identity.return_value = {
            "Arn": "arn:aws:iam::123456789012:user/tester",
            "Account": "123456789012",
        }
        iam = MagicMock()
        iam.simulate_principal_policy.return_value = {"EvaluationResults": []}
        mock_session.client.side_effect = lambda svc, **kwargs: (sts if svc == "sts" else iam)

        validate_validator.validate(
            "find-003", "iam_pass_role", confirmed=True,
            role_arn="arn:aws:iam::123456789012:role/TestRole"
        )

        # These mutating IAM calls must never be made
        iam.create_role.assert_not_called()
        iam.attach_role_policy.assert_not_called()
        iam.put_role_policy.assert_not_called()
        iam.create_user.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: Unknown technique
# ---------------------------------------------------------------------------

class TestUnknownTechnique:
    def test_unknown_technique_returns_error(self, validate_validator: AWSValidator):
        result = validate_validator.validate(
            "find-999", "nonexistent_technique", confirmed=True
        )
        assert result.status == "error"
        assert result.confirmed is False
        assert "Unknown" in result.description


# ---------------------------------------------------------------------------
# Tests: Resource naming convention
# ---------------------------------------------------------------------------

class TestResourceNaming:
    def test_validation_prefix_constant(self):
        assert VALIDATION_PREFIX == "cloud-pentest-validation"

    def test_resource_prefix_includes_run_id(self):
        validator = AWSValidator(
            session=MagicMock(), mode=ValidationMode.READ_ONLY, run_id="abc12345"
        )
        assert "cloud-pentest-validation/abc12345" == validator.resource_prefix
