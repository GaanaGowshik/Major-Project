"""
pytest configuration — adds backend/ to sys.path and provides shared fixtures.

All AWS fixtures use moto's in-process mock so no real AWS calls are made.
"""

import sys
from pathlib import Path

import pytest

# Make every backend package importable
_BACKEND = Path(__file__).parent.parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))


# ---------------------------------------------------------------------------
# Shared moto fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def aws_credentials(monkeypatch):
    """Provide fake AWS credentials so moto/boto3 don't hit real AWS."""
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "testing")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "testing")
    monkeypatch.setenv("AWS_SECURITY_TOKEN", "testing")
    monkeypatch.setenv("AWS_SESSION_TOKEN", "testing")
    monkeypatch.setenv("AWS_DEFAULT_REGION", "us-east-1")
