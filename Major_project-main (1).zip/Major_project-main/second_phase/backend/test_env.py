from env.gym_env import CloudPentestEnv

env = CloudPentestEnv()

state, info = env.reset()

print("Initial State:", state)

env.render()

print("\n")

for action in range(6):

    print("===================================")
    print("Executing Action:", action)

    state, reward, done, truncated, info = env.step(action)

    print("Reward :", reward)

    print("Info")

    print(info)

    print()