from cloud.scenario_generator import ScenarioGenerator

generator = ScenarioGenerator()

generator.generate_easy_scenario()