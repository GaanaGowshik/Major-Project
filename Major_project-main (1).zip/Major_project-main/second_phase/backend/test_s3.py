from cloud.s3 import create_bucket, list_buckets

print("Creating bucket...")
create_bucket("project-demo-bucket")

print("\nBuckets:")
print(list_buckets())