from graph.builder import CloudGraphBuilder

builder = CloudGraphBuilder()

graph = builder.build_graph()

print("\nNodes\n")

for node, data in graph.nodes(data=True):
    print(node, data)

print("\nEdges\n")

for source, target, data in graph.edges(data=True):
    print(source, "-->", target, data)