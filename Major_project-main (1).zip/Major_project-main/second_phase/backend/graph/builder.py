"""
graph/builder.py — Compatibility shim.

The real graph builder is now at aws_pentest.graph.builder.GraphBuilder.
This module re-exports it so any code that imports from 'graph.builder' still
works while the codebase is migrated to the new aws_pentest package.

For all new code, import directly from aws_pentest.graph:
    from aws_pentest.graph import GraphBuilder
"""

from aws_pentest.graph.builder import GraphBuilder  # noqa: F401
import networkx as nx

from cloud.iam import (
    list_users,
    list_roles,
    discover_user_role_relationships,
    discover_role_bucket_relationships,
)
from cloud.s3 import list_buckets

class CloudGraphBuilder:
    def __init__(self):
        self.graph = nx.DiGraph()

    def build_graph(self):
        self.graph.clear()

        # -----------------------------
        # Fetch cloud resources
        # -----------------------------
        users = list_users()
        roles = list_roles()
        buckets = list_buckets()

        # -----------------------------
        # Add User Nodes
        # -----------------------------
        for user in users:
            self.graph.add_node(
                user["UserName"],
                type="user"
            )

        # -----------------------------
        # Add Role Nodes
        # -----------------------------
        for role in roles:
            self.graph.add_node(
                role["RoleName"],
                type="role"
            )

        # -----------------------------
        # Add Bucket Nodes
        # -----------------------------
        for bucket in buckets:
            self.graph.add_node(
                bucket["Name"],
                type="bucket"
            )

        # -----------------------------
        # Discover User -> Role
        # -----------------------------
        user_role_edges = discover_user_role_relationships()
        for edge in user_role_edges:
            self.graph.add_edge(
                edge["user"],
                edge["role"],
                relation="CAN_ASSUME"
            )

        # -----------------------------
        # Discover Role -> Bucket
        # -----------------------------
        role_bucket_edges = discover_role_bucket_relationships()
        for edge in role_bucket_edges:
            self.graph.add_edge(
                edge["role"],
                edge["bucket"],
                relation="CAN_ACCESS"
            )

        return self.graph

__all__ = ["GraphBuilder", "CloudGraphBuilder"]
