"""
cloud/iam.py — Legacy IAM helpers (used by the LocalStack simulation env).

NOTE: These functions operate against LocalStack or a real AWS account
depending on cloud/config.py.  For the real-data security assessment,
use aws_pentest.iam instead:

    from aws_pentest.iam import IAMEnumerator, IAMSimulator, PrivEscDetector

The functions below are kept to avoid breaking the existing gym environment,
graph builder shim, and test scripts.  NEW CODE should not use this module.

The cross-product relationship discovery functions (discover_user_role_relationships,
discover_role_bucket_relationships) have been replaced with real, policy-
simulator-backed equivalents in aws_pentest.graph.builder.GraphBuilder.
"""

import json
import logging

from botocore.exceptions import ClientError
from urllib.parse import unquote

from .cloud_client import get_client

logger = logging.getLogger(__name__)

iam = get_client("iam")


# ============================================================
# USER OPERATIONS
# ============================================================

def create_user(username: str):
    try:
        response = iam.create_user(UserName=username)
        print(f"✅ User '{username}' created.")
        return response
    except ClientError as e:
        if e.response["Error"]["Code"] == "EntityAlreadyExists":
            print(f"⚠️ User '{username}' already exists.")
        else:
            raise


def list_users():
    response = iam.list_users()
    return response.get("Users", [])


def delete_user(username: str):
    try:
        iam.delete_user(UserName=username)
        print(f"🗑️ User '{username}' deleted.")
    except ClientError as e:
        print(e.response["Error"]["Message"])


# ============================================================
# ROLE OPERATIONS
# ============================================================

def create_role(role_name: str):
    trust_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {"Service": "lambda.amazonaws.com"},
                "Action": "sts:AssumeRole",
            }
        ],
    }
    try:
        response = iam.create_role(
            RoleName=role_name,
            AssumeRolePolicyDocument=json.dumps(trust_policy),
        )
        print(f"✅ Role '{role_name}' created.")
        return response
    except ClientError as e:
        if e.response["Error"]["Code"] == "EntityAlreadyExists":
            print(f"⚠️ Role '{role_name}' already exists.")
        else:
            raise


def list_roles():
    response = iam.list_roles()
    return response.get("Roles", [])


def get_role(role_name: str):
    return iam.get_role(RoleName=role_name)["Role"]


def delete_role(role_name: str):
    try:
        iam.delete_role(RoleName=role_name)
        print(f"🗑️ Role '{role_name}' deleted.")
    except ClientError as e:
        print(e.response["Error"]["Message"])


# ============================================================
# POLICY OPERATIONS
# ============================================================

def attach_policy(role_name: str, policy_arn: str):
    try:
        iam.attach_role_policy(RoleName=role_name, PolicyArn=policy_arn)
        print(f"✅ Policy attached to '{role_name}'.")
    except ClientError as e:
        print(e.response["Error"]["Message"])


def detach_policy(role_name: str, policy_arn: str):
    try:
        iam.detach_role_policy(RoleName=role_name, PolicyArn=policy_arn)
        print(f"🗑️ Policy detached from '{role_name}'.")
    except ClientError as e:
        print(e.response["Error"]["Message"])


def list_attached_role_policies(role_name: str):
    response = iam.list_attached_role_policies(RoleName=role_name)
    return response.get("AttachedPolicies", [])


# ============================================================
# ACCESS KEY OPERATIONS
# ============================================================

def create_access_key(username: str):
    try:
        response = iam.create_access_key(UserName=username)
        print(f"✅ Access key created for '{username}'.")
        return response["AccessKey"]
    except ClientError as e:
        print(e.response["Error"]["Message"])


# ============================================================
# POLICY DOCUMENT HELPERS
# ============================================================

def get_policy_document(policy_arn: str):
    policy = iam.get_policy(PolicyArn=policy_arn)["Policy"]
    version = policy["DefaultVersionId"]
    document = iam.get_policy_version(
        PolicyArn=policy_arn, VersionId=version
    )["PolicyVersion"]["Document"]
    return document


def list_attached_user_policies(username: str):
    response = iam.list_attached_user_policies(UserName=username)
    return response.get("AttachedPolicies", [])


def list_inline_user_policies(username: str):
    response = iam.list_user_policies(UserName=username)
    return response.get("PolicyNames", [])


def get_inline_user_policy(username: str, policy_name: str):
    response = iam.get_user_policy(UserName=username, PolicyName=policy_name)
    return response["PolicyDocument"]


# ============================================================
# GRAPH HELPERS — REAL-DATA VERSIONS
# ============================================================

def discover_user_role_relationships():
    """
    REAL implementation: only returns (user → role) pairs where the role's
    trust policy explicitly allows that specific user ARN (or a wildcard that
    would include them).

    NOTE: This performs a static trust-policy check only.  For full
    sts:AssumeRole confirmation use IAMSimulator.check() from aws_pentest.iam.
    """
    from aws_pentest.iam.policy_parser import PolicyParser

    relationships = []
    parser = PolicyParser()
    users = list_users()
    roles = list_roles()

    for role in roles:
        trust_doc = role.get("AssumeRolePolicyDocument", {})
        if isinstance(trust_doc, str):
            import json as _json
            from urllib.parse import unquote as _unquote
            trust_doc = _json.loads(_unquote(trust_doc))

        trust_relationships = parser.parse_trust_policy(trust_doc)

        for user in users:
            user_arn = user["Arn"]
            for tr in trust_relationships:
                if tr.effect.value != "Allow":
                    continue
                # Match: exact ARN, account root, or wildcard
                p = tr.principal_arn
                if p == "*" or p == user_arn or user_arn.startswith(
                    p.replace("*", "")
                ):
                    relationships.append(
                        {
                            "user": user["UserName"],
                            "user_arn": user_arn,
                            "role": role["RoleName"],
                            "role_arn": role["Arn"],
                            "evidence": tr.source_statement,
                        }
                    )
                    break

    return relationships


def discover_role_bucket_relationships():
    """
    DEPRECATED — returns an empty list.

    Real role → bucket relationships are determined by the IAM Policy
    Simulator in aws_pentest.s3.analyser.S3Analyser.cross_reference_iam().
    Using a cross-product fallback here would produce false relationships.
    """
    logger.warning(
        "discover_role_bucket_relationships() is deprecated and returns []. "
        "Use aws_pentest.s3.S3Analyser.cross_reference_iam() instead."
    )
    return []
