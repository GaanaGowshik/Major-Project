import boto3
from .config import *

def get_client(service_name):
    if CLOUD_PROVIDER == "localstack":
        return boto3.client(
            service_name,
            endpoint_url=LOCALSTACK_ENDPOINT,
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY,
            aws_secret_access_key=AWS_SECRET_KEY,
        )

    elif CLOUD_PROVIDER == "aws":
        return boto3.client(
            service_name,
            region_name=AWS_REGION
        )