"""
cloud/policy_parser.py — Compatibility shim.

The real PolicyParser is now at aws_pentest.iam.policy_parser.
"""

from aws_pentest.iam.policy_parser import PolicyParser  # noqa: F401

__all__ = ["PolicyParser"]
