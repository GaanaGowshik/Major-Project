from .cloud_client import get_client

s3 = get_client("s3")


def create_bucket(bucket_name: str):
    """Create an S3 bucket."""
    response = s3.create_bucket(Bucket=bucket_name)
    return response


def list_buckets():
    """List all S3 buckets."""
    response = s3.list_buckets()
    return response.get("Buckets", [])


def delete_bucket(bucket_name: str):
    """Delete an S3 bucket."""
    return s3.delete_bucket(Bucket=bucket_name)