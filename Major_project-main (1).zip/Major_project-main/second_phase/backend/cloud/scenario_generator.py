from cloud.iam import create_user
from cloud.s3 import create_bucket


class ScenarioGenerator:

    def generate_easy_scenario(self):
        """
        Creates a simple AWS environment.

        IAM User:
            alice

        S3 Bucket:
            company-data
        """

        print("Generating Easy Scenario...")

        create_user("alice")

        create_bucket("company-data")

        print("Scenario Created Successfully!")