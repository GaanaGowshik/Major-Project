"""
cloud/config.py — Unified configuration for the cloud layer.

Set CLOUD_PROVIDER to "aws" to run against a real AWS account.
Set to "localstack" to run the legacy simulation environment.

For the new aws_pentest assessment tool, configuration is passed directly
to boto3.Session via CLI flags (--profile, --region) — this file is only
used by the legacy LocalStack environment.
"""

# "aws" | "localstack"
CLOUD_PROVIDER = "aws"

AWS_REGION = "us-east-1"

# LocalStack settings (only used when CLOUD_PROVIDER == "localstack")
LOCALSTACK_ENDPOINT = "http://localhost:4566"
AWS_ACCESS_KEY = "test"
AWS_SECRET_KEY = "test"
