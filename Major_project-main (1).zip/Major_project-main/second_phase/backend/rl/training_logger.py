"""
SB3 training callback that writes a structured JSON log to rl/training_log.json.

Does NOT modify train.py. Use train_with_logging.py instead.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from stable_baselines3.common.callbacks import BaseCallback

logger = logging.getLogger(__name__)

_LOG_PATH = Path(__file__).parent / "training_log.json"


class TrainingLogger(BaseCallback):
    """
    Writes one entry per episode to training_log.json.

    Log format::
        [
          {
            "episode": 1,
            "total_reward": 42.0,
            "steps_count": 50,
            "steps": [
              {"step": 0, "node": "alice", "action": 0, "reward": 10.0,
               "success": true, "result": {...}},
              ...
            ]
          },
          ...
        ]
    """

    def __init__(self, verbose: int = 0) -> None:
        super().__init__(verbose)
        self._episodes: list[dict[str, Any]] = []
        self._current_steps: list[dict[str, Any]] = []
        self._episode_num: int = 0
        self._step_num: int = 0
        self._cumulative_reward: float = 0.0

    # ------------------------------------------------------------------

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", [{}])
        rewards = self.locals.get("rewards", [0.0])
        actions = self.locals.get("actions", [None])
        obs = self.locals.get("obs", [None])
        dones = self.locals.get("dones", [False])

        reward = float(rewards[0]) if rewards else 0.0
        action = int(actions[0]) if actions is not None and len(actions) > 0 else None
        info = infos[0] if infos else {}
        done = bool(dones[0]) if dones else False

        # Try to get node name from env
        try:
            env = self.training_env.envs[0]
            nodes = getattr(env, "nodes", [])
            current_idx = getattr(env, "current_node", 0)
            node_name = nodes[current_idx] if nodes and current_idx < len(nodes) else None
        except Exception:
            node_name = None

        step_record = {
            "step": self._step_num,
            "node": node_name,
            "action": action,
            "reward": reward,
            "success": info.get("success", reward >= 0),
            "result": {k: v for k, v in info.items()
                       if k not in ("terminal_observation",)
                       and not isinstance(v, (list, dict))},
        }
        self._current_steps.append(step_record)
        self._cumulative_reward += reward
        self._step_num += 1

        # Push live status to rl_service
        try:
            from api.services.rl_service import set_live_status
            set_live_status({
                "episode": self._episode_num,
                "step": self._step_num,
                "current_node": node_name,
                "last_action": action,
                "reward": reward,
                "cumulative_reward": self._cumulative_reward,
                "is_trained": False,
            })
        except Exception:
            pass

        if done:
            self._flush_episode()

        return True

    def _flush_episode(self) -> None:
        self._episode_num += 1
        rewards = [s["reward"] for s in self._current_steps]
        self._episodes.append(
            {
                "episode": self._episode_num,
                "total_reward": self._cumulative_reward,
                "steps_count": len(self._current_steps),
                "steps": list(self._current_steps),
            }
        )
        # Persist every episode
        try:
            with open(_LOG_PATH, "w", encoding="utf-8") as f:
                json.dump(self._episodes, f, indent=2, default=str)
        except Exception as exc:
            logger.warning("Could not write training log: %s", exc)

        self._current_steps = []
        self._cumulative_reward = 0.0

    def _on_training_end(self) -> None:
        if self._current_steps:
            self._flush_episode()
