"""
train_with_logging.py — Drop-in replacement for train.py that adds the
TrainingLogger callback. Does NOT modify train.py.

Usage:
    cd second_phase/backend
    .venv/Scripts/python rl/train_with_logging.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from stable_baselines3 import PPO
from env.gym_env import CloudPentestEnv
from rl.training_logger import TrainingLogger

env = CloudPentestEnv()

model = PPO("MlpPolicy", env, verbose=1)

logger_cb = TrainingLogger(verbose=1)

print("Training Started (with structured logging)...")

model.learn(total_timesteps=5000, callback=logger_cb)

model.save("ppo_cloud_agent")

print("Training Complete! Log written to rl/training_log.json")
