from stable_baselines3 import PPO

from env.gym_env import CloudPentestEnv


env = CloudPentestEnv()

model = PPO(
    "MlpPolicy",
    env,
    verbose=1
)

print("Training Started...")

model.learn(
    total_timesteps=5000
)

model.save("ppo_cloud_agent")

print("Training Complete!")