"""
RL Evaluation — Phase 12.

Evaluates a trained PPO agent against the real Phase 1 attack graph and
compares it to three baselines:

  1. Random          — random action selection
  2. Shortest path   — always takes the first (BFS-shortest) outgoing edge
  3. Greedy heuristic — prefer PRIVESC_TO edges, then CAN_ASSUME, then others

Outputs a structured comparison dict saved to rl/evaluation_results.json.

Usage:
    cd second_phase/backend
    .venv/Scripts/python rl/evaluate.py [--model ppo_cloud_agent] [--episodes 100]

Note: If ppo_cloud_agent.zip does not exist, only baselines are evaluated.
A "measurable success rate" is computed per IMPLEMENTATION_PLAN requirements:
  success = episode terminated at a Capability (PRIVESC_TO target) node.
"""

from __future__ import annotations

import argparse
import json
import logging
import random
import sys
from pathlib import Path
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

logger = logging.getLogger(__name__)

_DEFAULT_EPISODES = 100
_MAX_STEPS = 50


# ---------------------------------------------------------------------------
# Baseline policies
# ---------------------------------------------------------------------------

class RandomPolicy:
    """Uniformly random action selection."""
    name = "random"

    def predict(self, obs: np.ndarray, action_space_n: int, **_) -> int:
        return random.randrange(action_space_n)


class ShortestPathPolicy:
    """Always take action 0 (first outgoing edge — typically the graph-order first)."""
    name = "shortest_path"

    def predict(self, obs: np.ndarray, action_space_n: int, **_) -> int:
        return 0


class HeuristicPolicy:
    """
    Prefer edges in this priority order:
      PRIVESC_TO > CAN_ASSUME > CAN_WRITE_BUCKET > CAN_READ_BUCKET > others

    Requires env.nx_graph and current node ID.
    Falls back to action 0 if edge relations are unavailable.
    """
    name = "heuristic"

    _PRIORITY = {
        "PRIVESC_TO": 0,
        "CAN_ASSUME": 1,
        "CAN_WRITE_BUCKET": 2,
        "CAN_READ_BUCKET": 3,
        "CAN_LIST_BUCKET": 4,
        "HAS_INSTANCE_PROFILE": 5,
    }

    def predict(
        self,
        obs: np.ndarray,
        action_space_n: int,
        env: Any = None,
        **_,
    ) -> int:
        if env is None or not hasattr(env, "_current_node") or not hasattr(env, "_nx_graph"):
            return 0
        node = env._current_node
        neighbors = list(env._nx_graph.successors(node))
        if not neighbors:
            return 0
        # Sort by priority (lower = better)
        def _pri(n: str) -> int:
            edge_data = env._nx_graph[node].get(n, {})
            rel = edge_data.get("relation", "OTHER")
            return self._PRIORITY.get(rel, 99)
        sorted_neighbors = sorted(range(len(neighbors)), key=lambda i: _pri(neighbors[i]))
        best_idx = sorted_neighbors[0]
        if best_idx < action_space_n:
            return best_idx
        return 0


# ---------------------------------------------------------------------------
# Episode runner
# ---------------------------------------------------------------------------

def _run_episode(env: Any, policy: Any, policy_name: str) -> dict[str, Any]:
    """Run one episode and return metrics."""
    obs, info = env.reset()
    total_reward = 0.0
    steps = 0
    success = False
    path: list[str] = []

    if hasattr(env, "_current_node"):
        path.append(env._current_node)

    for _ in range(_MAX_STEPS):
        kwargs: dict[str, Any] = {}
        if isinstance(policy, HeuristicPolicy):
            kwargs["env"] = env

        action = policy.predict(obs, env.action_space.n, **kwargs)
        obs, reward, terminated, truncated, info = env.step(int(action))
        total_reward += float(reward)
        steps += 1

        if hasattr(env, "_current_node"):
            path.append(env._current_node)

        if terminated:
            success = info.get("reached_goal", False)
            break
        if truncated:
            break

    return {
        "policy": policy_name,
        "total_reward": total_reward,
        "steps": steps,
        "success": success,
        "path_length": len(path),
    }


# ---------------------------------------------------------------------------
# Evaluation runner
# ---------------------------------------------------------------------------

def evaluate(
    model_path: str = "ppo_cloud_agent",
    n_episodes: int = _DEFAULT_EPISODES,
) -> dict[str, Any]:
    """
    Evaluate PPO agent and baselines over n_episodes.
    Returns structured results dict.
    """
    from env.gym_env import CloudPentestEnv

    env = CloudPentestEnv()

    policies: list[Any] = [RandomPolicy(), ShortestPathPolicy(), HeuristicPolicy()]

    # Load PPO model if available
    ppo_available = False
    ppo_model = None
    model_file = Path(model_path + ".zip")
    if model_file.exists():
        try:
            from stable_baselines3 import PPO
            ppo_model = PPO.load(model_path)
            ppo_available = True
            logger.info("Loaded PPO model from %s", model_file)
        except Exception as exc:
            logger.warning("Could not load PPO model: %s", exc)
    else:
        logger.info("PPO model not found at %s — evaluating baselines only", model_file)

    all_results: dict[str, list[dict[str, Any]]] = {}

    # Evaluate baselines
    for policy in policies:
        episodes_data = []
        for _ in range(n_episodes):
            result = _run_episode(env, policy, policy.name)
            episodes_data.append(result)
        all_results[policy.name] = episodes_data
        success_rate = sum(e["success"] for e in episodes_data) / n_episodes
        avg_reward = sum(e["total_reward"] for e in episodes_data) / n_episodes
        logger.info(
            "[%s] success_rate=%.2f avg_reward=%.2f",
            policy.name, success_rate, avg_reward,
        )

    # Evaluate PPO
    if ppo_available and ppo_model is not None:
        class PPOPolicyWrapper:
            name = "ppo"
            def predict(self, obs, action_space_n, **_):
                action, _ = ppo_model.predict(obs, deterministic=True)
                return int(action)

        ppo_policy = PPOPolicyWrapper()
        ppo_episodes = []
        for _ in range(n_episodes):
            result = _run_episode(env, ppo_policy, "ppo")
            ppo_episodes.append(result)
        all_results["ppo"] = ppo_episodes
        ppo_success = sum(e["success"] for e in ppo_episodes) / n_episodes
        ppo_avg = sum(e["total_reward"] for e in ppo_episodes) / n_episodes
        logger.info("[ppo] success_rate=%.2f avg_reward=%.2f", ppo_success, ppo_avg)

    # Build summary
    summary: dict[str, Any] = {}
    for policy_name, episodes in all_results.items():
        rewards = [e["total_reward"] for e in episodes]
        successes = [e["success"] for e in episodes]
        steps = [e["steps"] for e in episodes]
        summary[policy_name] = {
            "n_episodes": len(episodes),
            "success_rate": sum(successes) / len(successes),
            "avg_reward": sum(rewards) / len(rewards),
            "max_reward": max(rewards),
            "min_reward": min(rewards),
            "avg_steps": sum(steps) / len(steps),
        }

    # RL vs baseline comparison
    comparison: dict[str, Any] = {}
    if "ppo" in summary:
        ppo_sr = summary["ppo"]["success_rate"]
        random_sr = summary["random"]["success_rate"]
        heuristic_sr = summary.get("heuristic", {}).get("success_rate", 0.0)
        comparison = {
            "ppo_vs_random_success_rate_delta": ppo_sr - random_sr,
            "ppo_vs_heuristic_success_rate_delta": ppo_sr - heuristic_sr,
            "ppo_beats_random": ppo_sr > random_sr,
            "ppo_beats_heuristic": ppo_sr > heuristic_sr,
            "conclusion": (
                "PPO outperforms all baselines"
                if ppo_sr > max(random_sr, heuristic_sr)
                else "PPO does not yet outperform all baselines — more training may be needed"
            ),
        }
    else:
        comparison = {
            "conclusion": (
                "PPO model not evaluated — run training first with "
                "'python rl/train_with_logging.py'"
            )
        }

    results = {
        "n_episodes": n_episodes,
        "graph_source": env.graph_source,
        "env_nodes": len(env._nodes) if hasattr(env, "_nodes") else 0,
        "env_edges": env._nx_graph.number_of_edges() if hasattr(env, "_nx_graph") else 0,
        "ppo_available": ppo_available,
        "summary": summary,
        "comparison": comparison,
    }

    return results


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate RL agent and baselines")
    parser.add_argument("--model", default="ppo_cloud_agent", help="Path to saved PPO model (no .zip)")
    parser.add_argument("--episodes", type=int, default=_DEFAULT_EPISODES)
    parser.add_argument("--output", default="rl/evaluation_results.json")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING"])
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    results = evaluate(model_path=args.model, n_episodes=args.episodes)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print("\n" + "=" * 60)
    print("  RL EVALUATION RESULTS")
    print("=" * 60)
    for policy, stats in results["summary"].items():
        print(f"  [{policy}] success_rate={stats['success_rate']:.2f}  "
              f"avg_reward={stats['avg_reward']:.2f}  "
              f"avg_steps={stats['avg_steps']:.1f}")
    print("-" * 60)
    print(f"  Conclusion: {results['comparison']['conclusion']}")
    print("=" * 60)
    print(f"\nFull results saved to: {output_path}")


if __name__ == "__main__":
    main()
