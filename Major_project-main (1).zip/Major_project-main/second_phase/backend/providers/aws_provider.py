"""
AWSProvider — implements BaseCloudProvider for Amazon Web Services.

This class wraps the existing aws_pentest pipeline modules without modifying
them.  All heavy lifting (IAM enumeration, S3 analysis, EC2 analysis, graph
building, report generation) is delegated to the existing modules.

Authentication
--------------
Uses a named AWS profile (profile_name kwarg) or the standard credential
chain (AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY env vars, instance profile,
~/.aws/credentials, etc.).  No credentials are ever stored on this object.

Usage
-----
    provider = AWSProvider()
    if provider.authenticate(profile_name="aws-pentest", region="us-east-1"):
        resources = provider.discover_resources(regions=["us-east-1"])
        findings  = provider.analyze_security(resources)
        graph     = provider.get_attack_graph(resources, findings)
"""

from __future__ import annotations

import logging
from typing import Any, Optional

import boto3
from botocore.exceptions import ClientError, NoCredentialsError, ProfileNotFound

from providers.base import BaseCloudProvider, ProviderAuthError, ProviderDiscoveryError
from aws_pentest.models.graph_models import AssessmentGraph

logger = logging.getLogger(__name__)


class AWSProvider(BaseCloudProvider):

    PROVIDER_ID = "aws"
    PROVIDER_NAME = "Amazon Web Services"

    def __init__(self) -> None:
        super().__init__()
        self._session: Optional[boto3.Session] = None
        self._account_id: str = "UNKNOWN"

    # ------------------------------------------------------------------
    # authenticate
    # ------------------------------------------------------------------

    def authenticate(
        self,
        profile_name: Optional[str] = None,
        region: Optional[str] = None,
        **kwargs: Any,
    ) -> bool:
        """
        Build a boto3 session and verify connectivity via sts:GetCallerIdentity.

        Parameters
        ----------
        profile_name:
            Named AWS profile from ~/.aws/credentials.  None uses the
            default credential chain.
        region:
            AWS region for the session.
        """
        session_kwargs: dict[str, Any] = {}
        if profile_name:
            session_kwargs["profile_name"] = profile_name
        if region:
            session_kwargs["region_name"] = region

        try:
            session = boto3.Session(**session_kwargs)
            identity = session.client("sts").get_caller_identity()
            self._session = session
            self._account_id = identity["Account"]
            self._authenticated = True
            logger.info(
                "AWSProvider authenticated: account=%s user=%s",
                self._account_id,
                identity.get("Arn"),
            )
            return True
        except (NoCredentialsError, ProfileNotFound) as exc:
            raise ProviderAuthError(f"AWS credential error: {exc}") from exc
        except ClientError as exc:
            raise ProviderAuthError(f"AWS STS error: {exc}") from exc

    # ------------------------------------------------------------------
    # discover_resources
    # ------------------------------------------------------------------

    def discover_resources(
        self,
        regions: Optional[list[str]] = None,
        skip_privesc: bool = False,
        skip_s3_iam_xref: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Enumerate all IAM, S3, and EC2 resources from the authenticated account.

        Parameters
        ----------
        regions:
            List of AWS regions for EC2 enumeration.  Defaults to the
            session region or "us-east-1".
        skip_privesc:
            Skip IAM Policy Simulator privilege escalation checks (faster).
        skip_s3_iam_xref:
            Skip per-bucket × per-principal IAM simulator cross-reference.
        """
        self._require_auth()
        assert self._session is not None

        from aws_pentest.iam.enumerator import IAMEnumerator
        from aws_pentest.iam.simulator import IAMSimulator
        from aws_pentest.iam.privesc import PrivEscDetector
        from aws_pentest.iam.analyser import IAMAnalyser
        from aws_pentest.s3.analyser import S3Analyser
        from aws_pentest.ec2.analyser import EC2Analyser

        simulator = IAMSimulator(session=self._session)

        # IAM
        logger.info("AWSProvider: enumerating IAM…")
        iam_enum = IAMEnumerator(session=self._session)
        users, roles, groups = iam_enum.enumerate_all()

        # PrivEsc
        privesc_paths = []
        if not skip_privesc:
            logger.info("AWSProvider: detecting privilege escalation paths…")
            detector = PrivEscDetector(simulator=simulator)
            privesc_paths = detector.detect_all(users=users, roles=roles)

        # IAM general findings
        logger.info("AWSProvider: analysing IAM misconfigurations…")
        iam_analyser = IAMAnalyser(session=self._session)
        iam_findings = iam_analyser.analyse_account(users=users, roles=roles)

        # S3
        logger.info("AWSProvider: enumerating S3…")
        s3_analyser = S3Analyser(session=self._session, simulator=simulator)
        buckets = s3_analyser.enumerate_buckets()
        s3_findings = s3_analyser.check_findings(buckets)
        if not skip_s3_iam_xref:
            s3_analyser.cross_reference_iam(
                buckets=buckets,
                principals=users + roles,  # type: ignore[arg-type]
            )

        # EC2
        session_region = self._session.region_name or "us-east-1"
        ec2_regions = regions or [session_region]
        logger.info("AWSProvider: enumerating EC2 in %s…", ec2_regions)
        ec2_analyser = EC2Analyser(session=self._session, regions=ec2_regions)
        instances = ec2_analyser.enumerate_instances()
        ec2_findings = ec2_analyser.check_findings(instances)

        return {
            "provider": self.PROVIDER_ID,
            "account_id": self._account_id,
            "resources": {
                "iam_users": users,
                "iam_roles": roles,
                "iam_groups": groups,
                "s3_buckets": buckets,
                "ec2_instances": instances,
            },
            "findings": {
                "iam": iam_findings,
                "s3": s3_findings,
                "ec2": ec2_findings,
            },
            "privesc_paths": privesc_paths,
        }

    # ------------------------------------------------------------------
    # analyze_security
    # ------------------------------------------------------------------

    def analyze_security(
        self,
        resources: dict[str, Any],
        **kwargs: Any,
    ) -> list[Any]:
        """
        Flatten all findings from a discover_resources() result into a single list.

        If discover_resources() has already been called with the findings
        embedded, this just collects them — no additional AWS calls are made.
        """
        findings_dict = resources.get("findings", {})
        privesc = resources.get("privesc_paths", [])
        return (
            findings_dict.get("iam", [])
            + findings_dict.get("s3", [])
            + findings_dict.get("ec2", [])
            + privesc
        )

    # ------------------------------------------------------------------
    # get_attack_graph
    # ------------------------------------------------------------------

    def get_attack_graph(
        self,
        resources: dict[str, Any],
        findings: list[Any],
        **kwargs: Any,
    ) -> AssessmentGraph:
        """
        Build the confirmed-edge-only permission graph from discovered resources.
        """
        self._require_auth()
        from aws_pentest.graph.builder import GraphBuilder
        from aws_pentest.models.iam_models import PrivEscPath

        res = resources.get("resources", {})
        privesc_paths = [f for f in resources.get("privesc_paths", []) if isinstance(f, PrivEscPath)]

        builder = GraphBuilder()
        return builder.build(
            users=res.get("iam_users", []),
            roles=res.get("iam_roles", []),
            buckets=res.get("s3_buckets", []),
            instances=res.get("ec2_instances", []),
            privesc_paths=privesc_paths,
        )

    # ------------------------------------------------------------------
    # validate_finding
    # ------------------------------------------------------------------

    def validate_finding(
        self,
        finding_id: str,
        dry_run: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Controlled validation of a finding.

        Phase 6 will implement actual validation actions.
        In READ_ONLY mode (always dry_run=True for now), returns a preview dict.
        """
        # Phase 6 gate — no mutations until explicit implementation
        return {
            "finding_id": finding_id,
            "mode": "READ_ONLY",
            "status": "not_available",
            "description": (
                "Controlled validation is not yet implemented (Phase 6). "
                "This finding has been DETECTED but not VALIDATED. "
                "No AWS resource was created, modified, or deleted."
            ),
            "evidence": [],
            "cleanup_done": False,
        }

    # ------------------------------------------------------------------
    # Convenience: full pipeline shortcut (used by api/routes/scan.py)
    # ------------------------------------------------------------------

    def run_full_scan(
        self,
        profile_name: Optional[str] = None,
        region: Optional[str] = None,
        regions: Optional[list[str]] = None,
        skip_privesc: bool = False,
        skip_s3_iam_xref: bool = False,
    ) -> dict[str, Any]:
        """
        Authenticate + discover + analyse + build graph in one call.
        Returns the same dict shape as aws_pentest.run.run().
        """
        self.authenticate(profile_name=profile_name, region=region)
        resources = self.discover_resources(
            regions=regions,
            skip_privesc=skip_privesc,
            skip_s3_iam_xref=skip_s3_iam_xref,
        )
        graph = self.get_attack_graph(resources, [])

        # Produce the standard JSON report structure
        from aws_pentest.report.generator import ReportGenerator
        res = resources["resources"]
        findings = resources["findings"]
        reporter = ReportGenerator(account_id=self._account_id)
        report = reporter.generate(
            users=res["iam_users"],
            roles=res["iam_roles"],
            groups=res["iam_groups"],
            buckets=res["s3_buckets"],
            instances=res["ec2_instances"],
            iam_findings=findings["iam"],
            s3_findings=findings["s3"],
            ec2_findings=findings["ec2"],
            privesc_paths=resources["privesc_paths"],
            graph=graph,
        )
        return report
