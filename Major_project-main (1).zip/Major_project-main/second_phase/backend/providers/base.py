"""
BaseCloudProvider — abstract interface for all cloud providers.

Every provider (AWS, GCP, Azure, …) implements this interface so the rest of
the application (API routes, graph service, report service) can be
provider-agnostic.

Design rules
------------
- authenticate() MUST be called before any other method.
- discover_resources() returns a raw resources dict passed to analyze_security()
  and get_attack_graph() — the structure is provider-specific but always includes
  typed Pydantic objects accessible via known keys.
- analyze_security() and get_attack_graph() accept the resources dict so they
  can be called independently without re-fetching.
- validate_finding() is READ_ONLY by default (dry_run=True).
  Real mutations require dry_run=False AND explicit user confirmation upstream.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

from aws_pentest.models.graph_models import AssessmentGraph


class BaseCloudProvider(ABC):
    """
    Abstract base class for cloud provider implementations.

    Concrete classes:
        AWSProvider  — wraps the aws_pentest pipeline
        GCPProvider  — to be implemented in Phase 3
    """

    # Provider identifier string — must be unique across all providers
    PROVIDER_ID: str = ""

    # Human-readable name for display in the UI
    PROVIDER_NAME: str = ""

    def __init__(self) -> None:
        self._authenticated: bool = False

    # ------------------------------------------------------------------
    # Required interface
    # ------------------------------------------------------------------

    @abstractmethod
    def authenticate(self, **kwargs: Any) -> bool:
        """
        Validate that credentials are present and the account is reachable.

        Returns True on success; raises ProviderAuthError on failure.
        Must be called before discover_resources().
        """

    @abstractmethod
    def discover_resources(self, **kwargs: Any) -> dict[str, Any]:
        """
        Enumerate all cloud resources (IAM, storage, compute, …).

        Returns a provider-specific dict with at minimum:
          {
            "provider":   str,
            "account_id": str,
            "resources": {
              "<resource_type>": [<Pydantic model instances>],
              ...
            }
          }
        """

    @abstractmethod
    def analyze_security(
        self, resources: dict[str, Any], **kwargs: Any
    ) -> list[Any]:
        """
        Run security checks over the discovered resources.

        Parameters
        ----------
        resources:
            The dict returned by discover_resources().

        Returns a flat list of finding objects (IAMFinding, S3Finding, etc.)
        plus PrivEscPath objects as appropriate for the provider.
        """

    @abstractmethod
    def get_attack_graph(
        self,
        resources: dict[str, Any],
        findings: list[Any],
        **kwargs: Any,
    ) -> AssessmentGraph:
        """
        Build a confirmed-edge-only permission graph.

        Parameters
        ----------
        resources:
            The dict returned by discover_resources().
        findings:
            The list returned by analyze_security().

        Returns an AssessmentGraph whose edges carry evidence of the
        specific policy that grants each permission.
        """

    @abstractmethod
    def validate_finding(
        self,
        finding_id: str,
        dry_run: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Attempt controlled validation of a specific finding.

        Parameters
        ----------
        finding_id:
            ID of the finding to validate.
        dry_run:
            If True (default), return a preview of what WOULD happen without
            performing any mutation.

        Returns a dict with at minimum:
          {
            "finding_id":  str,
            "mode":        "READ_ONLY" | "DRY_RUN" | "VALIDATE",
            "status":      "preview" | "success" | "failed" | "not_available",
            "description": str,
            "evidence":    list,
            "cleanup_done": bool,
          }

        SAFETY: This method MUST never mutate cloud state when dry_run=True.
        SAFETY: Callers must obtain explicit user confirmation before calling
                with dry_run=False.
        """

    # ------------------------------------------------------------------
    # Convenience helpers (shared across all providers)
    # ------------------------------------------------------------------

    def is_authenticated(self) -> bool:
        return self._authenticated

    def _require_auth(self) -> None:
        if not self._authenticated:
            raise ProviderAuthError(
                f"{self.PROVIDER_NAME} provider: authenticate() must be called first."
            )


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ProviderAuthError(RuntimeError):
    """Raised when authentication fails or has not been performed."""


class ProviderDiscoveryError(RuntimeError):
    """Raised when resource discovery fails with a non-recoverable error."""
