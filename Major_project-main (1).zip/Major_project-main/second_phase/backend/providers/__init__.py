"""
providers/ — Cloud provider registry.

Usage:
    from providers import get_provider, PROVIDERS
    provider = get_provider("aws")
    provider.authenticate(profile_name="my-profile")
"""

from providers.base import BaseCloudProvider, ProviderAuthError, ProviderDiscoveryError
from providers.aws_provider import AWSProvider
from providers.gcp_provider import GCPProvider

# Registry: provider_id → provider class
PROVIDERS: dict[str, type[BaseCloudProvider]] = {
    AWSProvider.PROVIDER_ID: AWSProvider,
    GCPProvider.PROVIDER_ID: GCPProvider,
}


def get_provider(provider_id: str) -> BaseCloudProvider:
    """
    Instantiate and return the provider for the given ID.

    Parameters
    ----------
    provider_id:
        "aws" or "gcp"

    Raises
    ------
    ValueError if the provider_id is not registered.
    """
    cls = PROVIDERS.get(provider_id)
    if cls is None:
        raise ValueError(
            f"Unknown provider '{provider_id}'. "
            f"Available providers: {list(PROVIDERS.keys())}"
        )
    return cls()


__all__ = [
    "BaseCloudProvider",
    "AWSProvider",
    "GCPProvider",
    "PROVIDERS",
    "get_provider",
    "ProviderAuthError",
    "ProviderDiscoveryError",
]
