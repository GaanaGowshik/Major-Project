"""
GCPProvider — implements BaseCloudProvider for Google Cloud Platform.

Wraps the gcp_pentest pipeline modules without modifying them.
Authentication uses Application Default Credentials (ADC) or an explicit
service account JSON file via GOOGLE_APPLICATION_CREDENTIALS env var.

Usage
-----
    provider = GCPProvider()
    if provider.authenticate(project_id="my-project-123"):
        resources = provider.discover_resources()
        findings  = provider.analyze_security(resources)
        graph     = provider.get_attack_graph(resources, findings)
"""

from __future__ import annotations

import logging
import os
from typing import Any, Optional

from providers.base import BaseCloudProvider, ProviderAuthError, ProviderDiscoveryError
from aws_pentest.models.graph_models import AssessmentGraph

logger = logging.getLogger(__name__)


class GCPProvider(BaseCloudProvider):

    PROVIDER_ID = "gcp"
    PROVIDER_NAME = "Google Cloud Platform"

    def __init__(self) -> None:
        super().__init__()
        self._project_id: str = ""
        self._credentials: Any = None

    # ------------------------------------------------------------------
    # authenticate
    # ------------------------------------------------------------------

    def authenticate(
        self,
        project_id: Optional[str] = None,
        credentials_path: Optional[str] = None,
        **kwargs: Any,
    ) -> bool:
        """
        Obtain GCP credentials and verify project access.

        Parameters
        ----------
        project_id:
            GCP project ID.  If None, uses the project embedded in ADC.
        credentials_path:
            Path to a service account JSON key file.  If None, uses ADC
            (GOOGLE_APPLICATION_CREDENTIALS env var or gcloud auth).
        """
        try:
            import google.auth
            from google.auth.exceptions import DefaultCredentialsError

            # Resolve credentials_path from env var if not passed directly
            if credentials_path is None:
                credentials_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")

            if credentials_path:
                from google.oauth2 import service_account
                scopes = ["https://www.googleapis.com/auth/cloud-platform"]
                credentials = service_account.Credentials.from_service_account_file(
                    credentials_path, scopes=scopes
                )
                adc_project = None
            else:
                credentials, adc_project = google.auth.default(
                    scopes=["https://www.googleapis.com/auth/cloud-platform"]
                )

            resolved_project = project_id or (adc_project if not credentials_path else None)
            if not resolved_project:
                raise ProviderAuthError(
                    "No GCP project ID provided and none found in Application Default Credentials. "
                    "Pass project_id= or set GOOGLE_CLOUD_PROJECT env var."
                )

            # Verify access: fetch project metadata via Resource Manager
            from google.cloud import resourcemanager_v3
            rm_client = resourcemanager_v3.ProjectsClient(credentials=credentials)
            rm_client.get_project(name=f"projects/{resolved_project}")

            self._credentials = credentials
            self._project_id = resolved_project
            self._authenticated = True
            logger.info("GCPProvider authenticated: project=%s", self._project_id)
            return True

        except ProviderAuthError:
            raise
        except Exception as exc:
            raise ProviderAuthError(f"GCP authentication error: {exc}") from exc

    # ------------------------------------------------------------------
    # discover_resources
    # ------------------------------------------------------------------

    def discover_resources(
        self,
        zones: Optional[list[str]] = None,
        skip_privesc: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Enumerate all GCP IAM, Storage, and Compute resources.

        Parameters
        ----------
        zones:
            List of GCP zones for Compute enumeration (e.g. ["us-central1-a"]).
            If None, defaults to the project's default zones.
        skip_privesc:
            Skip privilege escalation detection (faster, but less complete).
        """
        self._require_auth()

        from gcp_pentest.iam.enumerator import GCPIAMEnumerator
        from gcp_pentest.iam.privesc import GCPPrivEscDetector
        from gcp_pentest.storage.analyser import GCPStorageAnalyser
        from gcp_pentest.compute.analyser import GCPComputeAnalyser

        # IAM enumeration
        logger.info("GCPProvider: enumerating IAM…")
        iam_enum = GCPIAMEnumerator(
            project_id=self._project_id, credentials=self._credentials
        )
        service_accounts, roles, bindings = iam_enum.enumerate_all()

        # Privilege escalation detection
        privesc_paths = []
        if not skip_privesc:
            logger.info("GCPProvider: detecting privilege escalation paths…")
            detector = GCPPrivEscDetector()
            privesc_paths = detector.detect_all(bindings=bindings)

        # Storage enumeration
        logger.info("GCPProvider: enumerating Cloud Storage…")
        storage_analyser = GCPStorageAnalyser(
            project_id=self._project_id, credentials=self._credentials
        )
        buckets = storage_analyser.enumerate_buckets()
        storage_findings = storage_analyser.check_findings(buckets)

        # Compute enumeration
        logger.info("GCPProvider: enumerating Compute Engine…")
        compute_analyser = GCPComputeAnalyser(
            project_id=self._project_id, credentials=self._credentials, zones=zones
        )
        instances = compute_analyser.enumerate_instances()
        firewall_rules = compute_analyser.enumerate_firewall_rules()
        compute_findings = compute_analyser.check_findings(instances, firewall_rules)

        return {
            "provider": self.PROVIDER_ID,
            "project_id": self._project_id,
            "resources": {
                "service_accounts": service_accounts,
                "iam_roles": roles,
                "iam_bindings": bindings,
                "storage_buckets": buckets,
                "compute_instances": instances,
                "firewall_rules": firewall_rules,
            },
            "findings": {
                "storage": storage_findings,
                "compute": compute_findings,
            },
            "privesc_paths": privesc_paths,
        }

    # ------------------------------------------------------------------
    # analyze_security
    # ------------------------------------------------------------------

    def analyze_security(
        self,
        resources: dict[str, Any],
        **kwargs: Any,
    ) -> list[Any]:
        """
        Flatten all findings from a discover_resources() result into a single list.
        No additional GCP API calls are made.
        """
        findings_dict = resources.get("findings", {})
        privesc = resources.get("privesc_paths", [])
        return (
            findings_dict.get("storage", [])
            + findings_dict.get("compute", [])
            + privesc
        )

    # ------------------------------------------------------------------
    # get_attack_graph
    # ------------------------------------------------------------------

    def get_attack_graph(
        self,
        resources: dict[str, Any],
        findings: list[Any],
        **kwargs: Any,
    ) -> AssessmentGraph:
        """
        Build the confirmed-edge-only GCP permission graph from discovered resources.
        """
        self._require_auth()
        from gcp_pentest.graph.builder import GCPGraphBuilder
        from gcp_pentest.models import GCPPrivEscPath

        res = resources.get("resources", {})
        privesc_paths = [
            p for p in resources.get("privesc_paths", [])
            if isinstance(p, GCPPrivEscPath)
        ]

        builder = GCPGraphBuilder()
        return builder.build(
            project_id=resources.get("project_id", self._project_id),
            service_accounts=res.get("service_accounts", []),
            bindings=res.get("iam_bindings", []),
            buckets=res.get("storage_buckets", []),
            instances=res.get("compute_instances", []),
            privesc_paths=privesc_paths,
        )

    # ------------------------------------------------------------------
    # validate_finding
    # ------------------------------------------------------------------

    def validate_finding(
        self,
        finding_id: str,
        dry_run: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Controlled validation of a GCP finding.
        Phase 7 will implement actual validation actions.
        """
        return {
            "finding_id": finding_id,
            "mode": "READ_ONLY",
            "status": "not_available",
            "description": (
                "GCP controlled validation is not yet implemented (Phase 7). "
                "This finding has been DETECTED but not VALIDATED. "
                "No GCP resource was created, modified, or deleted."
            ),
            "evidence": [],
            "cleanup_done": False,
        }

    # ------------------------------------------------------------------
    # Convenience: full pipeline shortcut (mirrors AWSProvider.run_full_scan)
    # ------------------------------------------------------------------

    def run_full_scan(
        self,
        project_id: Optional[str] = None,
        credentials_path: Optional[str] = None,
        zones: Optional[list[str]] = None,
        skip_privesc: bool = False,
    ) -> dict[str, Any]:
        """
        Authenticate + discover + analyse + build graph in one call.
        Returns a structured report dict compatible with the scan API.
        """
        from datetime import datetime, timezone
        from collections import defaultdict
        from gcp_pentest.models import Severity as GCPSeverity

        self.authenticate(project_id=project_id, credentials_path=credentials_path)
        resources = self.discover_resources(zones=zones, skip_privesc=skip_privesc)
        graph = self.get_attack_graph(resources, [])

        res = resources["resources"]
        all_findings = self.analyze_security(resources)

        severity_counts: dict[str, int] = defaultdict(int)
        for f in all_findings:
            if hasattr(f, "severity"):
                severity_counts[f.severity.value] += 1

        return {
            "provider": "gcp",
            "project_id": self._project_id,
            "scan_timestamp": datetime.now(timezone.utc).isoformat(),
            "summary": {
                "service_accounts": len(res.get("service_accounts", [])),
                "iam_roles": len(res.get("iam_roles", [])),
                "iam_bindings": len(res.get("iam_bindings", [])),
                "storage_buckets": len(res.get("storage_buckets", [])),
                "compute_instances": len(res.get("compute_instances", [])),
                "firewall_rules": len(res.get("firewall_rules", [])),
                "total_findings": len(all_findings),
                "privesc_paths": len(resources.get("privesc_paths", [])),
                "severity_breakdown": dict(severity_counts),
            },
            "resources": {
                "service_accounts": [
                    {"email": sa.email, "display_name": sa.display_name, "disabled": sa.disabled}
                    for sa in res.get("service_accounts", [])
                ],
                "storage_buckets": [
                    {"name": b.name, "location": b.location, "is_public_read": b.is_public_read,
                     "is_public_write": b.is_public_write}
                    for b in res.get("storage_buckets", [])
                ],
                "compute_instances": [
                    {"name": i.name, "zone": i.zone, "status": i.status, "has_public_ip": i.has_public_ip}
                    for i in res.get("compute_instances", [])
                ],
            },
            "findings": {
                "storage": [f.model_dump() for f in resources["findings"].get("storage", [])],
                "compute": [f.model_dump() for f in resources["findings"].get("compute", [])],
            },
            "privilege_escalation_paths": [
                p.model_dump() for p in resources.get("privesc_paths", [])
            ],
            "graph_summary": {
                "nodes": len(graph.nodes),
                "edges": len(graph.edges),
            },
        }
