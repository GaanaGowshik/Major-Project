"""
Normalized Resource Model — shared Pydantic v2 base models for the multi-cloud
penetration testing platform.

These models provide a provider-agnostic representation of cloud resources,
security findings, and attack paths.  Both the AWS and GCP pipelines serialize
their provider-specific objects into these normalized forms so that:

  - The attack graph layer is provider-agnostic.
  - The RL environment works with the same types regardless of provider.
  - The report generator has a single input schema.
  - Frontend rendering is provider-agnostic.

Design decisions:
  - BaseModel subclasses use Pydantic v2 (model_config, not class Config).
  - All IDs are strings (provider-scoped, unique within a scan run).
  - confirmed: bool distinguishes detected-from-policy vs simulator-verified.
  - Severity uses a string Enum shared across providers.
  - AttackPath.chain: ordered list of resource IDs representing the path.
  - No hardcoded ARNs, project IDs, account IDs, or resource names.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal, Optional
from pydantic import BaseModel, Field
import uuid


# ---------------------------------------------------------------------------
# Severity
# ---------------------------------------------------------------------------

class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


# ---------------------------------------------------------------------------
# CloudResource — provider-agnostic resource descriptor
# ---------------------------------------------------------------------------

class CloudResource(BaseModel):
    """
    Provider-agnostic descriptor for a single discovered cloud resource.

    Fields
    ------
    resource_id:
        Globally unique identifier within this scan.  Convention:
          AWS: ARN (arn:aws:iam::ACCOUNT:user/NAME)
          GCP: full resource name (//iam.googleapis.com/projects/P/serviceAccounts/E)
    resource_type:
        Normalized type string:
          "iam_user" | "iam_role" | "iam_group"          (AWS)
          "service_account" | "iam_binding"              (GCP)
          "s3_bucket" | "storage_bucket"
          "ec2_instance" | "compute_instance"
          "firewall_rule"
    provider:
        "aws" | "gcp" | "azure" (future)
    name:
        Human-readable name or identifier.
    region:
        AWS region or GCP location.  None for global resources.
    metadata:
        Provider-specific key-value pairs for additional context.
    tags:
        Resource labels / tags.
    """
    resource_id: str
    resource_type: str
    provider: Literal["aws", "gcp", "azure"] = "aws"
    name: str
    region: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    tags: dict[str, str] = Field(default_factory=dict)

    model_config = {"extra": "ignore"}


# ---------------------------------------------------------------------------
# CloudFinding — provider-agnostic security finding
# ---------------------------------------------------------------------------

class CloudFinding(BaseModel):
    """
    Provider-agnostic security finding.

    Status progression:
      DETECTED      — found via static policy analysis (not simulated)
      VERIFIED      — confirmed via IAM Policy Simulator or equivalent
      VALIDATED     — confirmed by actual controlled execution (Phase 6/7)
      FALSE_POSITIVE — review determined this is not exploitable

    Only promote to VALIDATED with real execution evidence.
    Never claim VALIDATED without evidence in the `validation_evidence` field.
    """
    finding_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    provider: Literal["aws", "gcp", "azure"] = "aws"
    resource_id: str
    resource_type: str
    title: str
    description: str
    severity: Severity
    recommendation: str
    status: Literal["DETECTED", "VERIFIED", "VALIDATED", "FALSE_POSITIVE"] = "DETECTED"
    confirmed: bool = False          # True when simulator / policy evaluation confirmed it
    evidence: dict[str, Any] = Field(default_factory=dict)
    validation_evidence: list[dict[str, Any]] = Field(default_factory=list)
    scan_timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    tags: list[str] = Field(default_factory=list)

    model_config = {"extra": "ignore"}


# ---------------------------------------------------------------------------
# AttackPath — provider-agnostic privilege escalation path
# ---------------------------------------------------------------------------

class AttackPath(BaseModel):
    """
    A confirmed or detected privilege escalation / lateral movement path.

    chain:
        Ordered list of resource_ids representing the traversal path.
        chain[0] = starting principal, chain[-1] = target privilege/resource.
    technique:
        Short label matching the detection technique (e.g. "PassRole",
        "ServiceAccountTokenCreator", "AdminPolicy").
    required_permissions:
        IAM actions / GCP permissions needed to traverse this path.
    confirmed:
        True when every edge in the chain has real policy evidence.
        False when path is inferred / hypothetical.
    """
    path_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    provider: Literal["aws", "gcp", "azure"] = "aws"
    source_id: str           # Starting resource_id (principal)
    target_id: str           # Target resource_id (escalation target)
    technique: str
    description: str
    chain: list[str]         # Ordered resource_ids
    required_permissions: list[str] = Field(default_factory=list)
    severity: Severity = Severity.HIGH
    confirmed: bool = False
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    scan_timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = {"extra": "ignore"}


# ---------------------------------------------------------------------------
# ScanResult — top-level normalized scan result container
# ---------------------------------------------------------------------------

class ScanResult(BaseModel):
    """
    Provider-agnostic container for the output of a full scan pipeline.

    Populated by both AWSProvider and GCPProvider to enable provider-agnostic
    downstream processing (report generator, RL environment, graph builder).
    """
    scan_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    provider: Literal["aws", "gcp", "azure"] = "aws"
    account_or_project: str        # AWS account ID or GCP project ID
    scan_timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    resources: list[CloudResource] = Field(default_factory=list)
    findings: list[CloudFinding] = Field(default_factory=list)
    attack_paths: list[AttackPath] = Field(default_factory=list)
    graph_nodes: int = 0
    graph_edges: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "ignore"}

    @property
    def findings_by_severity(self) -> dict[str, list[CloudFinding]]:
        """Group findings by severity level."""
        grouped: dict[str, list[CloudFinding]] = {s.value: [] for s in Severity}
        for f in self.findings:
            grouped[f.severity.value].append(f)
        return grouped

    @property
    def critical_and_high(self) -> list[CloudFinding]:
        """All CRITICAL and HIGH severity findings."""
        return [f for f in self.findings if f.severity in (Severity.CRITICAL, Severity.HIGH)]

    @property
    def confirmed_attack_paths(self) -> list[AttackPath]:
        """Attack paths where all evidence is confirmed."""
        return [p for p in self.attack_paths if p.confirmed]
