from cloud.iam import create_role, list_roles

print("Creating role...")

create_role("developer-role")

print()

for role in list_roles():
    print(role["RoleName"])