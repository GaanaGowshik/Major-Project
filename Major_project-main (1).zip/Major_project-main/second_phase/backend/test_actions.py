from env.actions import execute_action

print("\n========== ACTION 0 ==========")
print(execute_action(0))

print("\n========== ACTION 1 ==========")
print(execute_action(1))

print("\n========== ACTION 2 ==========")
print(execute_action(2))

print("\n========== ACTION 3 ==========")
print(execute_action(3, "developer-role"))

print("\n========== ACTION 4 ==========")
print(execute_action(4, "developer-role"))

print("\n========== ACTION 5 ==========")
print(execute_action(5, "company-data"))