"""
POST /api/report/generate  — run report generation from latest scan data
GET  /api/report           — return the report JSON
GET  /api/report/pdf       — return the report as a PDF file
GET  /api/report/html      — return the report HTML (browser preview)
"""

from fastapi import APIRouter
from fastapi.responses import Response, HTMLResponse
from api.services.report_service import generate_report, generate_html, generate_pdf, save_report

router = APIRouter(prefix="/api/report", tags=["report"])


@router.post("/generate")
def generate():
    report = generate_report()
    save_report(report)
    return {"status": "ok", "message": "Report generated.", "summary": report.get("executive_summary", "")}


@router.get("")
def get_report():
    return generate_report()


@router.get("/html", response_class=HTMLResponse)
def get_report_html():
    report = generate_report()
    return generate_html(report)


@router.get("/pdf")
def get_report_pdf():
    report = generate_report()
    html = generate_html(report)
    pdf_bytes = generate_pdf(html)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=pentest_report.pdf"},
    )
