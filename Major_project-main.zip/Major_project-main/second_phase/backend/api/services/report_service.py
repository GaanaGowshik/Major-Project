"""
Report service — generates HTML and PDF penetration test reports.

Any finding derived from unconfirmed (simulated/placeholder) data is
explicitly labeled as such in the output. Confirmed data comes from the
aws_pentest Phase 1 JSON report; RL data comes from the training log.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

_REPORT_JSON_PATH = Path(__file__).parent.parent.parent / "aws_pentest" / "last_report.json"
_COMPILED_REPORT_JSON_PATH = Path(__file__).parent.parent.parent / "aws_pentest" / "last_report_compiled.json"
_REPORT_HTML_PATH = Path(__file__).parent.parent.parent / "aws_pentest" / "last_report.html"
_VALIDATION_LOG_PATH = Path(__file__).parent.parent.parent / "aws_pentest" / "validation_log.json"
_GCP_REPORT_JSON_PATH = Path(__file__).parent.parent.parent / "gcp_pentest" / "last_report.json"

_SEVERITY_COLORS = {
    "CRITICAL": "#dc2626",
    "HIGH": "#ea580c",
    "MEDIUM": "#ca8a04",
    "LOW": "#16a34a",
    "INFO": "#2563eb",
}


def _load_pentest_report() -> Optional[dict[str, Any]]:
    if _REPORT_JSON_PATH.exists():
        try:
            with open(_REPORT_JSON_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            logger.warning("Could not load pentest report: %s", exc)
    return None


def _load_rl_episodes() -> list[dict]:
    from api.services.rl_service import get_episodes
    return get_episodes()


def _load_validation_log() -> list[dict]:
    """Load validation results recorded during Phase 6 controlled testing."""
    if _VALIDATION_LOG_PATH.exists():
        try:
            with open(_VALIDATION_LOG_PATH, encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            logger.warning("Could not load validation log: %s", exc)
    return []


def record_validation_result(result: dict[str, Any]) -> None:
    """Append a validation result to the persistent validation log."""
    log = _load_validation_log()
    log.append(result)
    _VALIDATION_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(_VALIDATION_LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2, default=str)


def generate_report() -> dict[str, Any]:
    """
    Build the full report dict from available data sources.
    Returns a dict that can be serialized to JSON or passed to HTML template.
    """
    pt = _load_pentest_report()
    rl_episodes = _load_rl_episodes()

    now = datetime.now(timezone.utc).isoformat()

    if pt is None:
        return {
            "generated_at": now,
            "status": "no_scan",
            "message": "No scan results found. Run aws_pentest.run first.",
            "sections": {},
        }

    findings = pt.get("findings", {})
    privesc = pt.get("privilege_escalation_paths", [])

    if isinstance(findings, list):
        # The file is in the transformed/compiled format already
        all_findings = findings
        risk_assessment = pt.get("risk_assessment", {})
        sev = risk_assessment.get("severity_breakdown", {})
        risk_level = risk_assessment.get("overall_risk", "LOW")
        resources = pt.get("resource_inventory", {})
        total_findings = risk_assessment.get("total_findings", len(all_findings))
    else:
        # The file is in the raw scan format
        summary = pt.get("summary", {})
        resources = pt.get("resources", {})
        
        # Severity breakdown for risk assessment
        sev = summary.get("severity_breakdown", {})
        risk_level = (
            "CRITICAL" if sev.get("CRITICAL", 0) > 0
            else "HIGH" if sev.get("HIGH", 0) > 0
            else "MEDIUM" if sev.get("MEDIUM", 0) > 0
            else "LOW"
        )

        all_findings = (
            findings.get("iam", [])
            + findings.get("s3", [])
            + findings.get("ec2", [])
        )
        total_findings = summary.get("total_findings", len(all_findings))

    # RL summary
    rl_summary = None
    if rl_episodes:
        rewards = [ep["totalReward"] for ep in rl_episodes]
        rl_summary = {
            "total_episodes": len(rl_episodes),
            "avg_reward": sum(rewards) / len(rewards),
            "max_reward": max(rewards),
            "convergence_episode": _find_convergence(rewards),
            "is_simulated": True,  # honest: stubs affect results
        }

    validation_results = _load_validation_log()

    return {
        "generated_at": now,
        "status": "complete",
        "account_id": pt.get("account_id", "UNKNOWN"),
        "scan_timestamp": pt.get("scan_timestamp", now),
        "executive_summary": _build_executive_summary({"iam_users": len(resources.get("iam_users", [])), "iam_roles": len(resources.get("iam_roles", [])), "s3_buckets": len(resources.get("s3_buckets", [])), "ec2_instances": len(resources.get("ec2_instances", [])), "total_findings": total_findings, "severity_breakdown": sev}, risk_level, privesc),
        "resource_inventory": {
            "iam_users": resources.get("iam_users", []),
            "iam_roles": resources.get("iam_roles", []),
            "iam_groups": resources.get("iam_groups", []),
            "s3_buckets": resources.get("s3_buckets", []),
            "ec2_instances": resources.get("ec2_instances", []),
        },
        "findings": all_findings,
        "privilege_escalation_paths": privesc,
        "risk_assessment": {
            "overall_risk": risk_level,
            "severity_breakdown": sev,
            "total_findings": total_findings,
            "privesc_count": len(privesc),
        },
        "validation_results": validation_results,
        "rl_analysis": rl_summary,
        "graph_summary": pt.get("graph_summary", {}),
        "recommendations": _build_recommendations(all_findings, privesc),
    }


def generate_html(report: dict[str, Any]) -> str:
    """Render the report dict as a full HTML document."""
    if report.get("status") == "no_scan":
        return _no_scan_html(report)
    return _render_full_html(report)


def generate_pdf(html: str) -> bytes:
    """
    Convert HTML to PDF bytes.

    Primary path: WeasyPrint (requires GTK / Pango native libs — works on Linux/macOS).
    Fallback:     Return the HTML content as bytes with text/html so the browser can
                  still display and print it.  The Content-Type header is set to
                  application/pdf by the caller; on Windows WeasyPrint often fails to
                  load libgobject, so the fallback is common in development.
    """
    try:
        import weasyprint
        return weasyprint.HTML(string=html).write_pdf()
    except Exception as exc:
        logger.warning(
            "WeasyPrint PDF generation failed (%s) — returning HTML bytes as fallback. "
            "On Windows, install GTK3 runtime (https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer) "
            "to enable real PDF output.",
            exc,
        )
        # Fallback: return the HTML so the browser can at least display it
        return html.encode("utf-8")


def save_report(report: dict[str, Any]) -> None:
    """Persist the report JSON for later retrieval."""
    _COMPILED_REPORT_JSON_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(_COMPILED_REPORT_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    html = generate_html(report)
    with open(_REPORT_HTML_PATH, "w", encoding="utf-8") as f:
        f.write(html)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_executive_summary(summary: dict, risk_level: str, privesc: list) -> str:
    users = summary.get("iam_users", 0)
    roles = summary.get("iam_roles", 0)
    buckets = summary.get("s3_buckets", 0)
    instances = summary.get("ec2_instances", 0)
    total = summary.get("total_findings", 0)
    sev = summary.get("severity_breakdown", {})

    privesc_note = (
        f" {len(privesc)} confirmed privilege escalation path(s) were detected."
        if privesc else
        " No confirmed privilege escalation paths were found."
    )

    return (
        f"This automated AWS security assessment identified {users} IAM users, "
        f"{roles} roles, {buckets} S3 buckets, and {instances} EC2 instances. "
        f"A total of {total} findings were recorded with an overall risk rating of "
        f"{risk_level}. Critical: {sev.get('CRITICAL',0)}, "
        f"High: {sev.get('HIGH',0)}, Medium: {sev.get('MEDIUM',0)}, "
        f"Low: {sev.get('LOW',0)}." + privesc_note
    )


def _build_recommendations(findings: list, privesc: list) -> list[dict]:
    recs: list[dict] = []
    if privesc:
        recs.append({
            "priority": "CRITICAL",
            "title": "Remediate Privilege Escalation Paths Immediately",
            "detail": (
                f"The IAM Policy Simulator confirmed {len(privesc)} privilege "
                "escalation path(s). Remove the required IAM actions from the "
                "offending principals or apply permission boundaries."
            ),
        })
    critical = [f for f in findings if f.get("severity") == "CRITICAL"]
    if critical:
        recs.append({
            "priority": "CRITICAL",
            "title": "Address Critical Misconfigurations",
            "detail": f"{len(critical)} critical finding(s) require immediate remediation.",
        })
    high = [f for f in findings if f.get("severity") == "HIGH"]
    if high:
        recs.append({
            "priority": "HIGH",
            "title": "Resolve High-Severity Findings",
            "detail": f"{len(high)} high-severity finding(s) should be remediated within 7 days.",
        })
    recs.append({
        "priority": "MEDIUM",
        "title": "Enable S3 Server-Side Encryption and Logging",
        "detail": "Ensure all S3 buckets have default encryption and access logging enabled.",
    })
    recs.append({
        "priority": "LOW",
        "title": "Enforce IMDSv2 on All EC2 Instances",
        "detail": "Set HttpTokens=required on all instances to prevent SSRF credential theft.",
    })
    return recs


def _find_convergence(rewards: list[float]) -> Optional[int]:
    """Return episode index where reward stabilized (simple moving avg)."""
    if len(rewards) < 10:
        return None
    window = 5
    for i in range(window, len(rewards) - window):
        prev_avg = sum(rewards[i - window:i]) / window
        curr_avg = sum(rewards[i:i + window]) / window
        if abs(curr_avg - prev_avg) < 2.0:
            return i
    return None


# ---------------------------------------------------------------------------
# HTML templates
# ---------------------------------------------------------------------------

def _no_scan_html(report: dict) -> str:
    return f"""<!DOCTYPE html><html><body>
<h1>No scan results available</h1>
<p>{report.get('message', '')}</p>
</body></html>"""


def _sev_badge(sev: str) -> str:
    color = _SEVERITY_COLORS.get(sev, "#6b7280")
    return f'<span style="background:{color};color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700">{sev}</span>'


def _render_validation_section(validation_results: list[dict]) -> str:
    """Render the Controlled Validation Results section for the HTML report."""
    if not validation_results:
        return (
            "<h2>Controlled Validation Results</h2>"
            "<p style='color:#57606a'>No controlled validations were performed. "
            "All findings above are DETECTED but NOT VALIDATED. "
            "Use the validation API (POST /api/validate) to perform controlled tests.</p>"
        )

    rows = ""
    for v in validation_results:
        status = v.get("status", "not_performed")
        confirmed = v.get("confirmed", False)
        mode = v.get("mode", "READ_ONLY")

        if status == "success" and confirmed:
            status_html = '<span style="color:#16a34a;font-weight:700">✓ VALIDATED</span>'
        elif status == "failure":
            status_html = '<span style="color:#ea580c;font-weight:700">✗ DENIED (false positive?)</span>'
        elif status == "dry_run_preview":
            status_html = '<span style="color:#2563eb">DRY RUN ONLY</span>'
        else:
            status_html = '<span style="color:#ca8a04">NOT PERFORMED</span>'

        evidence_count = len(v.get("evidence", []))
        cleanup = "Yes" if v.get("cleanup_done") else '<span style="color:#dc2626">No</span>'

        rows += f"""<tr>
          <td><code style="font-size:11px">{v.get('finding_id','')}</code></td>
          <td>{v.get('technique','')}</td>
          <td>{mode}</td>
          <td>{status_html}</td>
          <td>{evidence_count} item(s)</td>
          <td>{cleanup}</td>
          <td style="font-size:11px;color:#57606a">{v.get('timestamp','')[:19] if v.get('timestamp') else ''}</td>
        </tr>"""

    return (
        "<h2>Controlled Validation Results</h2>"
        "<p style='font-size:12px;color:#57606a;margin-bottom:8px'>"
        "Status: VALIDATED = confirmed by real execution · "
        "NOT PERFORMED = read-only mode · "
        "DENIED = access was blocked (may indicate finding is mitigated)"
        "</p>"
        "<table>"
        "<tr><th>Finding ID</th><th>Technique</th><th>Mode</th>"
        "<th>Result</th><th>Evidence</th><th>Cleanup</th><th>Timestamp</th></tr>"
        + rows
        + "</table>"
    )


def _render_full_html(r: dict) -> str:
    findings = r.get("findings", [])
    privesc = r.get("privilege_escalation_paths", [])
    recs = r.get("recommendations", [])
    rl = r.get("rl_analysis")
    validation_results = r.get("validation_results", [])
    graph_sum = r.get("graph_summary", {})
    risk = r.get("risk_assessment", {})
    inv = r.get("resource_inventory", {})

    # findings table rows
    finding_rows = ""
    for f in sorted(findings, key=lambda x: ["CRITICAL","HIGH","MEDIUM","LOW","INFO"].index(x.get("severity","INFO"))):
        sev = f.get("severity", "INFO")
        finding_rows += f"""<tr>
          <td>{_sev_badge(sev)}</td>
          <td>{f.get('title','')}</td>
          <td style="font-size:12px;color:#57606a">{f.get('resource_arn') or f.get('bucket_name') or f.get('instance_id','')}</td>
          <td style="font-size:12px">{f.get('recommendation','')}</td>
        </tr>"""

    # privesc rows
    pe_rows = ""
    for p in privesc:
        confirmed_label = '<span style="color:#16a34a;font-size:11px">✓ Simulator-confirmed</span>' if p.get("simulator_confirmed") else '<span style="color:#ca8a04;font-size:11px">⚠ Unconfirmed</span>'
        pe_rows += f"""<tr>
          <td>{_sev_badge(p.get('severity','HIGH'))}</td>
          <td><code style="font-size:11px">{p.get('source_arn','')}</code></td>
          <td>{p.get('technique','')}</td>
          <td><code style="font-size:11px">{', '.join(p.get('required_actions',[]))}</code></td>
          <td>{confirmed_label}</td>
        </tr>"""

    # rec rows
    rec_rows = ""
    for rec in recs:
        rec_rows += f"""<tr>
          <td>{_sev_badge(rec.get('priority','LOW'))}</td>
          <td><strong>{rec.get('title','')}</strong><br><span style="font-size:12px;color:#57606a">{rec.get('detail','')}</span></td>
        </tr>"""

    # rl section
    rl_section = ""
    if rl:
        sim_warning = """<div style="background:#fff8ed;border-left:4px solid #e6a817;padding:8px 12px;margin-bottom:12px;font-size:13px">
          ⚠ <strong>Simulation Notice:</strong> Actions 4 (AssumeRole) and 5 (ListBucketObjects)
          are stubs that always fail. RL reward data is real but reflects this limitation.
          The agent never made actual AWS API calls for these actions.
        </div>"""
        rl_section = f"""<h2 style="font-size:16px;margin:28px 0 10px;border-bottom:1px solid #e5e7eb;padding-bottom:5px">RL Agent Analysis</h2>
        {sim_warning}
        <table style="width:100%;border-collapse:collapse;font-size:13px">
          <tr><td style="padding:5px 8px;border:1px solid #e5e7eb"><strong>Total Episodes</strong></td><td style="padding:5px 8px;border:1px solid #e5e7eb">{rl.get('total_episodes',0)}</td></tr>
          <tr><td style="padding:5px 8px;border:1px solid #e5e7eb"><strong>Average Reward</strong></td><td style="padding:5px 8px;border:1px solid #e5e7eb">{rl.get('avg_reward',0):.2f}</td></tr>
          <tr><td style="padding:5px 8px;border:1px solid #e5e7eb"><strong>Max Reward</strong></td><td style="padding:5px 8px;border:1px solid #e5e7eb">{rl.get('max_reward',0):.2f}</td></tr>
          <tr><td style="padding:5px 8px;border:1px solid #e5e7eb"><strong>Convergence Episode</strong></td><td style="padding:5px 8px;border:1px solid #e5e7eb">{rl.get('convergence_episode') or 'N/A'}</td></tr>
        </table>"""

    overall_risk = risk.get("overall_risk", "UNKNOWN")
    risk_color = _SEVERITY_COLORS.get(overall_risk, "#6b7280")

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AWS Security Assessment Report</title>
<style>
  body {{ font-family: -apple-system, "Segoe UI", sans-serif; font-size: 14px;
         line-height: 1.6; color: #1f2328; margin: 0; padding: 32px 48px; }}
  h1 {{ font-size: 24px; margin-bottom: 4px; }}
  h2 {{ font-size: 16px; margin: 28px 0 10px; border-bottom: 1px solid #e5e7eb;
        padding-bottom: 5px; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; margin: 10px 0; }}
  th {{ background: #f7f8fa; text-align: left; padding: 7px 10px;
        border: 1px solid #e5e7eb; font-weight: 600; }}
  td {{ padding: 6px 10px; border: 1px solid #e5e7eb; vertical-align: top; }}
  tr:nth-child(even) td {{ background: #fafafa; }}
  .meta {{ color: #57606a; font-size: 13px; margin-bottom: 24px; }}
  .exec {{ background: #f7f8fa; border-left: 4px solid #3b82d4;
           padding: 12px 16px; border-radius: 0 6px 6px 0; margin: 10px 0 20px; }}
  .risk-badge {{ display:inline-block; padding: 4px 14px; border-radius: 20px;
                 color: #fff; font-weight: 700; font-size: 15px;
                 background: {risk_color}; }}
  .stat-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 12px 0; }}
  .stat {{ background: #f7f8fa; border: 1px solid #e5e7eb; border-radius: 6px;
           padding: 10px 14px; text-align: center; }}
  .stat-num {{ font-size: 26px; font-weight: 700; color: #3b82d4; }}
  .stat-label {{ font-size: 12px; color: #57606a; }}
  code {{ font-family: Consolas, monospace; font-size: 11.5px;
          background: #f0f0f0; padding: 1px 4px; border-radius: 3px; }}
  @media print {{ body {{ padding: 16px 24px; }} }}
</style>
</head>
<body>

<h1>AWS Security Assessment Report</h1>
<div class="meta">
  Account: <strong>{r.get('account_id','UNKNOWN')}</strong> &nbsp;|&nbsp;
  Scan: {r.get('scan_timestamp','')} &nbsp;|&nbsp;
  Generated: {r.get('generated_at','')} &nbsp;|&nbsp;
  Overall Risk: <span class="risk-badge">{overall_risk}</span>
</div>

<h2>Executive Summary</h2>
<div class="exec">{r.get('executive_summary','')}</div>

<h2>Resource Inventory</h2>
<div class="stat-grid">
  <div class="stat"><div class="stat-num">{len(inv.get('iam_users',[]))}</div><div class="stat-label">IAM Users</div></div>
  <div class="stat"><div class="stat-num">{len(inv.get('iam_roles',[]))}</div><div class="stat-label">IAM Roles</div></div>
  <div class="stat"><div class="stat-num">{len(inv.get('s3_buckets',[]))}</div><div class="stat-label">S3 Buckets</div></div>
  <div class="stat"><div class="stat-num">{len(inv.get('ec2_instances',[]))}</div><div class="stat-label">EC2 Instances</div></div>
</div>

<h2>Risk Assessment</h2>
<table>
  <tr><th>Severity</th><th>Count</th></tr>
  {"".join(f'<tr><td>{_sev_badge(s)}</td><td>{risk.get("severity_breakdown",{{}}).get(s,0)}</td></tr>' for s in ["CRITICAL","HIGH","MEDIUM","LOW","INFO"])}
  <tr><td><strong>Privilege Escalation Paths</strong></td><td>{risk.get('privesc_count',0)}</td></tr>
</table>

{"<h2>Privilege Escalation Paths</h2><table><tr><th>Severity</th><th>Source ARN</th><th>Technique</th><th>Required Actions</th><th>Verification</th></tr>" + pe_rows + "</table>" if privesc else "<h2>Privilege Escalation Paths</h2><p style='color:#16a34a'>No confirmed privilege escalation paths detected.</p>"}

<h2>Findings ({len(findings)})</h2>
{"<table><tr><th>Severity</th><th>Title</th><th>Resource</th><th>Recommendation</th></tr>" + finding_rows + "</table>" if findings else "<p style='color:#57606a'>No findings recorded.</p>"}

{rl_section}

{_render_validation_section(validation_results)}

<h2>Recommendations</h2>
<table><tr><th>Priority</th><th>Recommendation</th></tr>{rec_rows}</table>

{"<h2>Graph Summary</h2><p>Nodes: <strong>" + str(graph_sum.get('nodes',0)) + "</strong> &nbsp; Edges: <strong>" + str(graph_sum.get('edges',0)) + "</strong></p>" if graph_sum else ""}

<div style="margin-top:48px;padding-top:12px;border-top:1px solid #e5e7eb;text-align:center;font-size:11px;color:#57606a">
  Generated by aws_pentest — Automated Multi-Cloud Penetration Testing via RL &nbsp;|&nbsp;
  For authorized use only
</div>

</body>
</html>"""
