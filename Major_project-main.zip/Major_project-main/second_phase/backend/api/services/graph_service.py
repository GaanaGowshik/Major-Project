"""
Graph service — converts the aws_pentest AssessmentGraph (or the legacy
CloudGraphBuilder graph) into the React Flow wire format expected by the
frontend.

Every edge carries a `confirmed` boolean:
  True  → backed by IAM Policy Simulator or parsed trust policy
  False → derived from a static heuristic or a deprecated cross-product

The caller must pass the confirmed flag through; this layer never invents data.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Optional

import networkx as nx

logger = logging.getLogger(__name__)

# Where the latest Phase 1 graph JSON is written by aws_pentest.run
_GRAPH_JSON_PATH = Path(__file__).parent.parent.parent / "aws_pentest" / "last_graph.json"


# ---------------------------------------------------------------------------
# Node risk scoring
# ---------------------------------------------------------------------------

_TYPE_BASE_RISK: dict[str, int] = {
    "IAMUser": 60,
    "IAMRole": 70,
    "S3Bucket": 50,
    "EC2Instance": 55,
    "Capability": 100,
    "user": 60,
    "role": 70,
    "bucket": 50,
}

_RELATION_RISK_BOOST: dict[str, int] = {
    "CAN_ASSUME": 20,
    "CAN_READ_BUCKET": 10,
    "CAN_WRITE_BUCKET": 25,
    "CAN_LIST_BUCKET": 10,
    "CAN_DELETE_BUCKET": 20,
    "HAS_INSTANCE_PROFILE": 15,
    "PRIVESC_TO": 50,
    "CAN_ACCESS": 20,
}


def _node_risk(node_id: str, nx_graph: nx.DiGraph) -> int:
    base = _TYPE_BASE_RISK.get(
        nx_graph.nodes[node_id].get("node_type")
        or nx_graph.nodes[node_id].get("type", ""),
        40,
    )
    boost = sum(
        _RELATION_RISK_BOOST.get(nx_graph[u][v].get("relation", ""), 0)
        for u, v in nx_graph.out_edges(node_id)
    )
    return min(base + boost, 100)


# ---------------------------------------------------------------------------
# React Flow conversion
# ---------------------------------------------------------------------------

def nx_to_react_flow(nx_graph: nx.DiGraph) -> dict[str, Any]:
    """
    Convert a networkx DiGraph to React Flow nodes + edges JSON.

    Nodes carry:
      id, type(=nodeType), data{label, nodeType, arn, attributes, riskScore,
      reachableCount, confirmed}

    Edges carry:
      id, source, target, data{relation, actions, confirmed, label}
    """
    rf_nodes: list[dict] = []
    rf_edges: list[dict] = []

    # ---- nodes ----
    for node_id, attrs in nx_graph.nodes(data=True):
        node_type = attrs.get("node_type") or attrs.get("type", "unknown")
        confirmed = attrs.get("confirmed", True)
        risk = _node_risk(node_id, nx_graph)
        reachable = len(list(nx.descendants(nx_graph, node_id)))

        rf_nodes.append(
            {
                "id": str(node_id),
                "type": "cloudNode",
                "position": {"x": 0, "y": 0},  # frontend auto-layouts
                "data": {
                    "label": attrs.get("display_name") or node_id.split("/")[-1],
                    "nodeType": node_type,
                    "arn": attrs.get("arn") or node_id,
                    "attributes": {
                        k: v
                        for k, v in attrs.items()
                        if k not in ("node_type", "type", "display_name", "arn", "confirmed")
                    },
                    "riskScore": risk,
                    "reachableCount": reachable,
                    "confirmed": confirmed,
                },
            }
        )

    # ---- edges ----
    for u, v, eattrs in nx_graph.edges(data=True):
        relation = eattrs.get("relation", "CONNECTED")
        actions = eattrs.get("actions", [])
        confirmed = eattrs.get("confirmed", True)

        # Edges from the legacy CloudGraphBuilder may carry confirmed=False
        rf_edges.append(
            {
                "id": f"{u}--{relation}--{v}",
                "source": str(u),
                "target": str(v),
                "data": {
                    "relation": relation,
                    "actions": actions if isinstance(actions, list) else [actions],
                    "confirmed": confirmed,
                    "label": relation,
                    "evidenceCount": len(eattrs.get("evidence", [])),
                    "policySources": eattrs.get("policy_sources", []),
                },
            }
        )

    return {"nodes": rf_nodes, "edges": rf_edges}


# ---------------------------------------------------------------------------
# Graph loader — tries Phase 1 JSON, falls back to live CloudGraphBuilder
# ---------------------------------------------------------------------------

def _load_real_graph() -> tuple[nx.DiGraph, str]:
    """
    Return (nx_graph, source_label).

    Priority:
    1. last_graph.json produced by aws_pentest.run (real, confirmed)
    2. Live CloudGraphBuilder call (partial — CAN_ASSUME only, no bucket edges)
    """
    if _GRAPH_JSON_PATH.exists():
        try:
            from aws_pentest.models.graph_models import AssessmentGraph
            with open(_GRAPH_JSON_PATH, encoding="utf-8") as f:
                raw = json.load(f)
            ag = AssessmentGraph.model_validate(raw)
            nx_graph = ag.to_networkx()
            # All edges from Phase 1 are confirmed
            for _, _, d in nx_graph.edges(data=True):
                d.setdefault("confirmed", True)
            for _, d in nx_graph.nodes(data=True):
                d.setdefault("confirmed", True)
            logger.info("Loaded Phase 1 graph: %d nodes, %d edges", nx_graph.number_of_nodes(), nx_graph.number_of_edges())
            return nx_graph, "phase1_real"
        except Exception as exc:
            logger.warning("Could not load Phase 1 graph JSON: %s", exc)

    # Fallback: legacy CloudGraphBuilder
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))
        from graph.builder import CloudGraphBuilder
        builder = CloudGraphBuilder()
        nx_graph = builder.build_graph()
        # Mark CAN_ASSUME edges as confirmed (trust-policy backed)
        # Mark CAN_ACCESS edges as unconfirmed (they're empty in current code anyway)
        for u, v, d in nx_graph.edges(data=True):
            relation = d.get("relation", "")
            d["confirmed"] = relation == "CAN_ASSUME"
        for _, d in nx_graph.nodes(data=True):
            d["confirmed"] = True
            d["node_type"] = d.pop("type", "unknown")
        logger.info("Loaded legacy CloudGraphBuilder graph: %d nodes, %d edges",
                    nx_graph.number_of_nodes(), nx_graph.number_of_edges())
        return nx_graph, "legacy_partial"
    except Exception as exc:
        logger.warning("CloudGraphBuilder failed: %s", exc)
        return nx.DiGraph(), "empty"


def get_attack_graph() -> dict[str, Any]:
    nx_graph, source = _load_real_graph()
    rf = nx_to_react_flow(nx_graph)
    rf["meta"] = {
        "source": source,
        "nodeCount": nx_graph.number_of_nodes(),
        "edgeCount": nx_graph.number_of_edges(),
        "confirmedEdges": sum(
            1 for _, _, d in nx_graph.edges(data=True) if d.get("confirmed", False)
        ),
        "unconfirmedEdges": sum(
            1 for _, _, d in nx_graph.edges(data=True) if not d.get("confirmed", False)
        ),
    }
    return rf


def get_node_detail(node_id: str) -> Optional[dict[str, Any]]:
    nx_graph, _ = _load_real_graph()
    if node_id not in nx_graph:
        return None
    attrs = dict(nx_graph.nodes[node_id])
    out_edges = [
        {
            "target": v,
            "relation": d.get("relation"),
            "actions": d.get("actions", []),
            "confirmed": d.get("confirmed", True),
        }
        for _, v, d in nx_graph.out_edges(node_id, data=True)
    ]
    in_edges = [
        {
            "source": u,
            "relation": d.get("relation"),
            "actions": d.get("actions", []),
            "confirmed": d.get("confirmed", True),
        }
        for u, _, d in nx_graph.in_edges(node_id, data=True)
    ]
    reachable = list(nx.descendants(nx_graph, node_id))
    return {
        "id": node_id,
        "attributes": attrs,
        "outEdges": out_edges,
        "inEdges": in_edges,
        "reachableNodes": reachable,
        "riskScore": _node_risk(node_id, nx_graph),
    }
