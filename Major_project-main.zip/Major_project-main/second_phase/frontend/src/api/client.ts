import axios from 'axios';

const BASE = 'http://localhost:8000';

const api = axios.create({ baseURL: BASE });

// ── Graph ────────────────────────────────────────────────
export const fetchGraph       = () => api.get('/api/attack-graph');
export const fetchNodeDetail  = (id: string) => api.get(`/api/attack-graph/node/${encodeURIComponent(id)}`);

// ── Scan ─────────────────────────────────────────────────
export const triggerScan      = (payload: ScanRequest) => api.post('/api/scan', payload);
export const fetchScanStatus  = () => api.get('/api/scan/status');

// ── RL ───────────────────────────────────────────────────
export const fetchRLStatus    = () => api.get('/api/rl/status');
export const fetchRLEpisodes  = () => api.get('/api/rl/episodes');
export const fetchRLHistory   = (ep?: number) =>
  api.get('/api/rl/history', ep !== undefined ? { params: { episode: ep } } : {});

// ── Report ───────────────────────────────────────────────
export const generateReport   = () => api.post('/api/report/generate');
export const fetchReport      = () => api.get('/api/report');
export const fetchReportPdfUrl = () => `${BASE}/api/report/pdf`;

// ── Validate ─────────────────────────────────────────────
export const fetchTechniques  = () => api.get('/api/validate/techniques');
export const validateFinding  = (payload: ValidateRequest) => api.post('/api/validate', payload);
export const fetchAttackPaths = () => api.get('/api/attack-graph/paths');
export const fetchGraphExportUrl = (format: 'graphml' | 'json') =>
  `${BASE}/api/attack-graph/export/${format}`;

// ── Health ───────────────────────────────────────────────
export const fetchHealth      = () => api.get('/api/health');

export interface ScanRequest {
  provider?: 'aws' | 'gcp';
  profile?: string;
  region?: string;
  regions?: string;
  skip_privesc?: boolean;
  skip_s3_iam_xref?: boolean;
  gcp_project_id?: string;
}

export interface ValidateRequest {
  finding_id: string;
  technique: 's3_write' | 's3_read' | 'iam_pass_role';
  mode: 'READ_ONLY' | 'DRY_RUN' | 'VALIDATE';
  confirmed: boolean;
  provider?: 'aws';
  profile?: string;
  region?: string;
  run_id?: string;
  bucket_name?: string;
  role_arn?: string;
  test_object_key?: string;
}
