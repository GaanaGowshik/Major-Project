import React, { useCallback, useEffect, useState } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  MarkerType,
  type Node,
  type Edge,
  type NodeProps,
  Handle,
  Position,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import dagre from '@dagrejs/dagre';
import { fetchGraph, fetchNodeDetail } from '../api/client';
import { COLORS, NODE_TYPE_LABEL } from '../constants';
import { ConfirmedBadge, Spinner, ErrorBox, StatCard } from './common/Widgets';

// ── Dagre auto-layout ─────────────────────────────────────────────────────

function applyLayout(nodes: Node[], edges: Edge[]) {
  const g = new dagre.graphlib.Graph();
  g.setDefaultEdgeLabel(() => ({}));
  g.setGraph({ rankdir: 'LR', nodesep: 60, ranksep: 120 });
  nodes.forEach((n) => g.setNode(n.id, { width: 160, height: 60 }));
  edges.forEach((e) => g.setEdge(e.source, e.target));
  dagre.layout(g);
  return nodes.map((n) => {
    const pos = g.node(n.id);
    return { ...n, position: { x: pos.x - 80, y: pos.y - 30 } };
  });
}

// ── Node colour by type ───────────────────────────────────────────────────

function nodeColor(nodeType: string): string {
  const t = nodeType?.toLowerCase() ?? '';
  if (t.includes('user'))    return COLORS.nodeUser;
  if (t.includes('role'))    return COLORS.nodeRole;
  if (t.includes('bucket'))  return COLORS.nodeBucket;
  if (t.includes('ec2'))     return COLORS.nodeEC2;
  if (t.includes('cap'))     return COLORS.nodeCap;
  return COLORS.muted;
}

function riskColor(score: number): string {
  if (score >= 90) return COLORS.CRITICAL;
  if (score >= 70) return COLORS.HIGH;
  if (score >= 50) return COLORS.MEDIUM;
  return COLORS.LOW;
}

// ── Custom node component ─────────────────────────────────────────────────

const CloudNode: React.FC<NodeProps> = ({ data, selected }) => {
  const d = data as any;
  const color = nodeColor(d.nodeType);
  const isUnconfirmed = d.confirmed === false;

  return (
    <div style={{
      background: '#fff',
      border: `2px solid ${selected ? COLORS.accent : isUnconfirmed ? '#fde047' : color}`,
      borderRadius: 8,
      padding: '8px 12px',
      minWidth: 140,
      boxShadow: selected ? `0 0 0 3px ${COLORS.accent}33` : '0 1px 4px rgba(0,0,0,.1)',
      opacity: isUnconfirmed ? 0.8 : 1,
    }}>
      <Handle type="target" position={Position.Left} style={{ background: color }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{
          display: 'inline-block', width: 10, height: 10, borderRadius: '50%', background: color, flexShrink: 0,
        }} />
        <span style={{ fontSize: 12, fontWeight: 700, color: COLORS.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 110 }}>
          {d.label}
        </span>
      </div>
      <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 2 }}>
        {NODE_TYPE_LABEL[d.nodeType] ?? d.nodeType}
      </div>
      <div style={{ display: 'flex', gap: 4, marginTop: 4, alignItems: 'center' }}>
        <span style={{
          fontSize: 10, background: riskColor(d.riskScore), color: '#fff',
          padding: '1px 5px', borderRadius: 6,
        }}>Risk {d.riskScore}</span>
        {isUnconfirmed && (
          <span style={{ fontSize: 9, background: '#fef9c3', color: '#854d0e', padding: '1px 5px', borderRadius: 6, border: '1px solid #fde047' }}>
            SIMULATED
          </span>
        )}
      </div>
      <Handle type="source" position={Position.Right} style={{ background: color }} />
    </div>
  );
};

const nodeTypes = { cloudNode: CloudNode };

// ── Edge styling ──────────────────────────────────────────────────────────

function styledEdge(e: any): Edge {
  const confirmed: boolean = e.data?.confirmed ?? true;
  const relation: string  = e.data?.relation ?? '';
  const isPrivesc = relation === 'PRIVESC_TO';

  return {
    ...e,
    type: 'smoothstep',
    animated: isPrivesc,
    markerEnd: { type: MarkerType.ArrowClosed },
    style: {
      strokeDasharray: confirmed ? undefined : '6 3',
      stroke: isPrivesc ? COLORS.CRITICAL : confirmed ? COLORS.accent : COLORS.warning,
      strokeWidth: isPrivesc ? 2.5 : 1.5,
    },
    label: relation,
    labelStyle: { fontSize: 10, fill: COLORS.muted },
    labelBgStyle: { fill: '#fff', fillOpacity: 0.85 },
  };
}

// ── Side panel ────────────────────────────────────────────────────────────

const NodePanel: React.FC<{ nodeId: string; onClose: () => void }> = ({ nodeId, onClose }) => {
  const [detail, setDetail] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr]        = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    fetchNodeDetail(nodeId)
      .then((r) => setDetail(r.data))
      .catch((e) => setErr(e.message))
      .finally(() => setLoading(false));
  }, [nodeId]);

  return (
    <div style={{
      position: 'absolute', top: 0, right: 0, width: 340, height: '100%',
      background: '#fff', borderLeft: `1px solid ${COLORS.border}`,
      zIndex: 100, overflowY: 'auto', padding: 20,
      boxShadow: '-4px 0 16px rgba(0,0,0,.08)',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <strong style={{ fontSize: 15 }}>Node Detail</strong>
        <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 18, color: COLORS.muted }}>✕</button>
      </div>

      {loading && <Spinner />}
      {err && <ErrorBox message={err} />}
      {detail && (
        <>
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4 }}>
              {NODE_TYPE_LABEL[detail.attributes?.node_type ?? detail.attributes?.type] ?? detail.attributes?.node_type}
            </div>
            <code style={{ fontSize: 11, background: '#f0f0f0', padding: '2px 6px', borderRadius: 4, wordBreak: 'break-all' }}>
              {nodeId}
            </code>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 16 }}>
            <StatCard label="Risk Score" value={detail.riskScore} accent={riskColor(detail.riskScore)} />
            <StatCard label="Reachable" value={detail.reachableNodes?.length ?? 0} />
          </div>

          {detail.outEdges?.length > 0 && (
            <Section title={`Outgoing Edges (${detail.outEdges.length})`}>
              {detail.outEdges.map((e: any, i: number) => (
                <EdgeRow key={i} relation={e.relation} target={e.target} actions={e.actions} confirmed={e.confirmed} />
              ))}
            </Section>
          )}

          {detail.inEdges?.length > 0 && (
            <Section title={`Incoming Edges (${detail.inEdges.length})`}>
              {detail.inEdges.map((e: any, i: number) => (
                <EdgeRow key={i} relation={e.relation} target={e.source} actions={e.actions} confirmed={e.confirmed} />
              ))}
            </Section>
          )}

          {detail.reachableNodes?.length > 0 && (
            <Section title={`Reachable Resources (${detail.reachableNodes.length})`}>
              {detail.reachableNodes.slice(0, 20).map((n: string, i: number) => (
                <div key={i} style={{ fontSize: 11, color: COLORS.muted, padding: '2px 0', wordBreak: 'break-all' }}>{n}</div>
              ))}
              {detail.reachableNodes.length > 20 && (
                <div style={{ fontSize: 11, color: COLORS.muted }}>…and {detail.reachableNodes.length - 20} more</div>
              )}
            </Section>
          )}
        </>
      )}
    </div>
  );
};

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div style={{ marginBottom: 14 }}>
    <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.muted, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 }}>{title}</div>
    {children}
  </div>
);

const EdgeRow: React.FC<{ relation: string; target: string; actions: string[]; confirmed: boolean }> = ({
  relation, target, actions, confirmed,
}) => (
  <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 6, padding: '6px 10px', marginBottom: 6 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: COLORS.text }}>{relation}</span>
      <ConfirmedBadge confirmed={confirmed} />
    </div>
    <div style={{ fontSize: 11, color: COLORS.muted, wordBreak: 'break-all', marginTop: 2 }}>{target}</div>
    {actions?.length > 0 && (
      <div style={{ marginTop: 4, display: 'flex', flexWrap: 'wrap', gap: 3 }}>
        {actions.map((a: string, i: number) => (
          <code key={i} style={{ fontSize: 10, background: '#e0f2fe', color: '#0369a1', padding: '1px 5px', borderRadius: 4 }}>{a}</code>
        ))}
      </div>
    )}
  </div>
);

// ── Main AttackGraph component ────────────────────────────────────────────

export const AttackGraph: React.FC = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState<Node>([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>([]);
  const [meta, setMeta]             = useState<any>(null);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [rawGraph, setRawGraph]     = useState<{ nodes: any[]; edges: any[] }>({ nodes: [], edges: [] });

  const loadGraph = useCallback(() => {
    setLoading(true);
    setError(null);
    fetchGraph()
      .then((r) => {
        const data = r.data;
        setMeta(data.meta);
        setRawGraph({ nodes: data.nodes, edges: data.edges });
        const laid = applyLayout(data.nodes, data.edges.map(styledEdge));
        setNodes(laid);
        setEdges(data.edges.map(styledEdge));
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { loadGraph(); }, [loadGraph]);

  // Filter nodes by search + type
  useEffect(() => {
    if (!rawGraph.nodes.length) return;
    const term = searchTerm.toLowerCase();
    const filtered = rawGraph.nodes.filter((n) => {
      const matchesType = typeFilter === 'all' || n.data?.nodeType?.toLowerCase().includes(typeFilter.toLowerCase());
      const matchesSearch = !term || n.data?.label?.toLowerCase().includes(term) || n.id?.toLowerCase().includes(term);
      return matchesType && matchesSearch;
    });
    const filteredIds = new Set(filtered.map((n: any) => n.id));
    const filteredEdges = rawGraph.edges.filter((e: any) => filteredIds.has(e.source) && filteredIds.has(e.target));
    const laid = applyLayout(filtered, filteredEdges.map(styledEdge));
    setNodes(laid);
    setEdges(filteredEdges.map(styledEdge));
  }, [searchTerm, typeFilter, rawGraph]);

  const nodeTypes_all = Array.from(new Set(rawGraph.nodes.map((n: any) => n.data?.nodeType).filter(Boolean)));

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Toolbar */}
      <div style={{ display: 'flex', gap: 10, padding: '12px 16px', borderBottom: `1px solid ${COLORS.border}`, background: '#fff', alignItems: 'center', flexWrap: 'wrap' }}>
        <strong style={{ fontSize: 15, marginRight: 8 }}>Attack Graph</strong>

        <input
          placeholder="Search nodes…"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ padding: '5px 10px', borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 13, width: 180 }}
        />

        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          style={{ padding: '5px 10px', borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 13 }}
        >
          <option value="all">All types</option>
          {nodeTypes_all.map((t) => <option key={t} value={t}>{NODE_TYPE_LABEL[t] ?? t}</option>)}
        </select>

        <button onClick={loadGraph} style={{ marginLeft: 'auto', padding: '5px 14px', borderRadius: 6, border: `1px solid ${COLORS.border}`, background: COLORS.accent, color: '#fff', cursor: 'pointer', fontSize: 13 }}>
          ↺ Refresh
        </button>

        {meta && (
          <div style={{ display: 'flex', gap: 12, fontSize: 12, color: COLORS.muted }}>
            <span>{meta.nodeCount} nodes</span>
            <span style={{ color: COLORS.success }}>{meta.confirmedEdges} confirmed edges</span>
            {meta.unconfirmedEdges > 0 && (
              <span style={{ color: COLORS.warning }}>{meta.unconfirmedEdges} simulated</span>
            )}
            <span style={{ fontSize: 11, background: '#f0f7ff', color: '#1e40af', padding: '1px 6px', borderRadius: 6 }}>
              Source: {meta.source}
            </span>
          </div>
        )}
      </div>

      {/* Graph canvas */}
      <div style={{ flex: 1, position: 'relative' }}>
        {loading && <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10, background: '#ffffffcc' }}><Spinner /></div>}
        {error && <div style={{ padding: 20 }}><ErrorBox message={error} /></div>}

        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          nodeTypes={nodeTypes}
          onNodeClick={(_, node) => setSelectedNode(node.id)}
          fitView
          fitViewOptions={{ padding: 0.2 }}
          minZoom={0.1}
          maxZoom={2}
        >
          <Background color={COLORS.border} gap={20} />
          <Controls />
          <MiniMap
            nodeColor={(n) => nodeColor((n.data as any)?.nodeType ?? '')}
            nodeStrokeWidth={2}
            style={{ border: `1px solid ${COLORS.border}` }}
          />
        </ReactFlow>

        {selectedNode && (
          <NodePanel nodeId={selectedNode} onClose={() => setSelectedNode(null)} />
        )}
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: 16, padding: '8px 16px', borderTop: `1px solid ${COLORS.border}`, background: COLORS.surface, fontSize: 11, color: COLORS.muted, flexWrap: 'wrap' }}>
        {[
          { label: 'IAM User', color: COLORS.nodeUser },
          { label: 'IAM Role', color: COLORS.nodeRole },
          { label: 'S3 Bucket', color: COLORS.nodeBucket },
          { label: 'EC2', color: COLORS.nodeEC2 },
          { label: 'Capability', color: COLORS.nodeCap },
        ].map(({ label, color }) => (
          <span key={label} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: color, display: 'inline-block' }} />
            {label}
          </span>
        ))}
        <span style={{ marginLeft: 16 }}>— — Simulated edge</span>
        <span style={{ color: COLORS.CRITICAL }}>——→ PrivEsc path</span>
      </div>
    </div>
  );
};
