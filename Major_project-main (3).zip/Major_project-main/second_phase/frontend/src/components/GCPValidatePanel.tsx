/**
 * GCPValidatePanel — Controlled GCP Finding Validation UI.
 *
 * Implements the same three-level safety model as AWSValidatePanel:
 *   READ_ONLY  — describe what would be tested (default)
 *   DRY_RUN    — show exact GCP API calls, no execution
 *   VALIDATE   — execute with user confirmation after dry-run preview
 *
 * Safety UX invariants (mirroring the AWS panel):
 *   1. Technique + params are filled in first.
 *   2. Always start with DRY_RUN to show preview.
 *   3. VALIDATE button only appears after dry-run completes.
 *   4. A confirmation dialog appears before VALIDATE executes.
 *   5. result.confirmed is true ONLY when execution succeeded.
 *   6. GCS Write: object is NOT auto-deleted — user must press "Clean Up Test Object".
 *   7. Compute Control: requires explicit confirmation checkbox before execution.
 *   8. "NOT PERFORMED" is shown for unexecuted actions.
 */

import React, { useState } from 'react';
import { COLORS } from '../constants';
import { validateFinding, cleanupWriteValidation } from '../api/client';
import type { ValidateRequest, CleanupRequest, GCPTechnique } from '../api/client';

type Mode = 'READ_ONLY' | 'DRY_RUN' | 'VALIDATE';

interface ValidationResult {
  provider: string;
  finding_id: string;
  technique: string;
  mode: string;
  status: string;
  confirmed: boolean;
  description: string;
  dry_run_preview: string[];
  evidence: Record<string, unknown>[];
  cleanup_done: boolean;
  cleanup_status: string;
  audit_log: Record<string, unknown>[];
  run_id?: string;
  gcs_bucket?: string;
  gcs_object_key?: string;
  error?: string;
}

interface CleanupResult {
  run_id: string;
  bucket?: string;
  object_key?: string;
  status: string;
  cleanup_status: string;
  cleanup_done?: boolean;
  deletion_verified?: boolean;
  description: string;
  error?: string;
}

const GCP_TECHNIQUE_LABELS: Record<GCPTechnique, string> = {
  gcs_write:           'Cloud Storage Write Validation',
  gcs_read:            'Cloud Storage Read Validation',
  iam_sa_impersonation: 'IAM Service Account Impersonation Validation',
  compute_access:      'Compute Access Validation',
  compute_control:     'Compute Control Validation',
};

const STATUS_STYLES: Record<string, { color: string; label: string }> = {
  success:          { color: '#16a34a', label: '✓ VALIDATED' },
  failure:          { color: '#ea580c', label: '✗ DENIED (access blocked)' },
  dry_run_preview:  { color: '#2563eb', label: 'DRY RUN PREVIEW' },
  not_performed:    { color: '#ca8a04', label: 'NOT PERFORMED' },
  error:            { color: '#dc2626', label: 'ERROR' },
};

const inputStyle: React.CSSProperties = {
  width: '100%', padding: '7px 10px',
  border: `1px solid ${COLORS.border}`,
  borderRadius: 6, fontSize: 13, boxSizing: 'border-box',
};

interface Props {
  gcpProjectId: string;
}

export const GCPValidatePanel: React.FC<Props> = ({ gcpProjectId: initialProjectId }) => {
  const [technique, setTechnique]               = useState<GCPTechnique>('gcs_write');
  const [findingId, setFindingId]               = useState('');
  const [gcpProjectId, setGcpProjectId]         = useState(initialProjectId);
  const [bucketName, setBucketName]             = useState('');
  const [objectKey, setObjectKey]               = useState('');
  const [serviceAccountEmail, setServiceAccountEmail] = useState('');
  const [instanceName, setInstanceName]         = useState('');
  const [zone, setZone]                         = useState('');
  const [computeConfirmed, setComputeConfirmed] = useState(false);

  const [loading, setLoading]                       = useState(false);
  const [cleanupLoading, setCleanupLoading]         = useState(false);
  const [dryRunResult, setDryRunResult]             = useState<ValidationResult | null>(null);
  const [validateResult, setValidateResult]         = useState<ValidationResult | null>(null);
  const [cleanupResult, setCleanupResult]           = useState<CleanupResult | null>(null);
  const [showConfirmDialog, setShowConfirmDialog]   = useState(false);
  const [error, setError]                           = useState<string | null>(null);

  const handleTechniqueChange = (t: GCPTechnique) => {
    setTechnique(t);
    setDryRunResult(null);
    setValidateResult(null);
    setCleanupResult(null);
    setError(null);
    setComputeConfirmed(false);
  };

  const buildRequest = (mode: Mode, confirmed = false): ValidateRequest => {
    const req: ValidateRequest = {
      finding_id: findingId || `manual-gcp-${technique}`,
      technique,
      mode,
      confirmed,
      provider: 'gcp',
      gcp_project_id: gcpProjectId || undefined,
    };

    if (technique === 'gcs_write' || technique === 'gcs_read') {
      req.bucket_name = bucketName || undefined;
    }
    if (technique === 'gcs_read' && objectKey) {
      req.object_key = objectKey;
    }
    if (technique === 'iam_sa_impersonation') {
      req.service_account_email = serviceAccountEmail || undefined;
    }
    if (technique === 'compute_access' || technique === 'compute_control') {
      if (instanceName) req.instance_name = instanceName;
      if (zone) req.zone = zone;
    }
    return req;
  };

  const handleDryRun = async () => {
    setLoading(true);
    setError(null);
    setDryRunResult(null);
    setValidateResult(null);
    setCleanupResult(null);
    try {
      const resp = await validateFinding(buildRequest('DRY_RUN'));
      setDryRunResult(resp.data as ValidationResult);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  const handleValidate = () => setShowConfirmDialog(true);

  const handleConfirmedValidate = async () => {
    setShowConfirmDialog(false);
    setLoading(true);
    setError(null);
    try {
      const resp = await validateFinding(buildRequest('VALIDATE', true));
      setValidateResult(resp.data as ValidationResult);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  const handleCleanup = async () => {
    if (!validateResult?.run_id) return;
    setCleanupLoading(true);
    setError(null);
    try {
      const req: CleanupRequest = {
        run_id: validateResult.run_id,
        provider: 'gcp',
        gcp_project_id: gcpProjectId || undefined,
      };
      const resp = await cleanupWriteValidation(req);
      setCleanupResult(resp.data as CleanupResult);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setCleanupLoading(false);
    }
  };

  const validateDisabled =
    loading ||
    (technique === 'compute_control' && !computeConfirmed);

  return (
    <div style={{ padding: 24, maxWidth: 820, margin: '0 auto' }}>

      {/* Title */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>
          🛡 GCP Controlled Validation
        </div>
        <div style={{ fontSize: 13, color: COLORS.muted, lineHeight: 1.5 }}>
          Test specific GCP attack paths with explicit confirmation.
          Default mode is <strong>Dry Run</strong> — no resources are created until you confirm.
        </div>
      </div>

      {/* Safety banner */}
      <div style={{
        background: '#f0f7ff', border: '1px solid #93c5fd', borderRadius: 6,
        padding: '10px 14px', marginBottom: 20, fontSize: 12,
      }}>
        <strong>Safety Model (GCP):</strong> READ_ONLY → DRY_RUN (preview) → VALIDATE (execute with explicit confirmation).
        No GCP resource is created or modified without explicit confirmation.
        For Cloud Storage Write, the test object remains in GCS after execution and must be cleaned up manually.
      </div>

      {/* Form */}
      <div style={{
        background: COLORS.surface, border: `1px solid ${COLORS.border}`,
        borderRadius: 8, padding: 20, marginBottom: 20,
      }}>
        <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>
          Validation Parameters
        </div>

        {/* Technique selector */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
            Technique
          </label>
          <select
            value={technique}
            onChange={e => handleTechniqueChange(e.target.value as GCPTechnique)}
            style={{ ...inputStyle, background: '#fff' }}
          >
            {(Object.entries(GCP_TECHNIQUE_LABELS) as [GCPTechnique, string][]).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </select>
        </div>

        {/* Compute Control warning */}
        {technique === 'compute_control' && (
          <div style={{
            background: '#fff5f5', border: '1px solid #fca5a5', borderRadius: 6,
            padding: '10px 14px', marginBottom: 14, fontSize: 12,
          }}>
            <strong>⚠ Warning:</strong> Compute Control Validation will temporarily{' '}
            <strong>stop and start</strong> the designated test GCP VM instance.
            Only proceed against a specifically designated test instance.
            The original RUNNING state will be restored automatically.
          </div>
        )}

        {/* Finding ID */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
            Finding ID (optional — for tracking in report)
          </label>
          <input type="text" value={findingId} onChange={e => setFindingId(e.target.value)}
            placeholder="e.g. finding-001" style={inputStyle} />
        </div>

        {/* GCP Project ID */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
            GCP Project ID{' '}
            {(technique === 'compute_access' || technique === 'compute_control' || technique === 'iam_sa_impersonation')
              && <span style={{ color: COLORS.danger }}>*</span>}
          </label>
          <input type="text" value={gcpProjectId} onChange={e => setGcpProjectId(e.target.value)}
            placeholder="e.g. my-project-123456" style={inputStyle} />
          <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 3 }}>
            Uses Application Default Credentials (ADC) or GOOGLE_APPLICATION_CREDENTIALS env var.
          </div>
        </div>

        {/* GCS bucket name — gcs_write, gcs_read */}
        {(technique === 'gcs_write' || technique === 'gcs_read') && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              GCS Bucket Name <span style={{ color: COLORS.danger }}>*</span>
            </label>
            <input type="text" value={bucketName} onChange={e => setBucketName(e.target.value)}
              placeholder="e.g. my-test-bucket" style={inputStyle} />
          </div>
        )}

        {/* GCS object key — gcs_read only */}
        {technique === 'gcs_read' && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              Object Key (optional — specific object to GetObject, e.g.{' '}
              <code>cloud-pentest-validation/controlled_valid1.txt</code>)
            </label>
            <input type="text" value={objectKey} onChange={e => setObjectKey(e.target.value)}
              placeholder="cloud-pentest-validation/controlled_valid1.txt (leave blank for ListObjects)"
              style={inputStyle} />
          </div>
        )}

        {/* Service account email — iam_sa_impersonation */}
        {technique === 'iam_sa_impersonation' && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              Service Account Email <span style={{ color: COLORS.danger }}>*</span>
            </label>
            <input type="text" value={serviceAccountEmail}
              onChange={e => setServiceAccountEmail(e.target.value)}
              placeholder="sa-name@project-id.iam.gserviceaccount.com" style={inputStyle} />
            <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 3 }}>
              VALIDATE mode calls generateAccessToken via the IAM Credentials API.
              The short-lived token is discarded immediately and never logged or returned.
            </div>
          </div>
        )}

        {/* Instance name + zone — compute_access, compute_control */}
        {(technique === 'compute_access' || technique === 'compute_control') && (
          <>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
                VM Instance Name{technique === 'compute_control'
                  ? <span style={{ color: COLORS.danger }}> *</span>
                  : ' (optional — leave blank to list all instances)'}
              </label>
              <input type="text" value={instanceName} onChange={e => setInstanceName(e.target.value)}
                placeholder="e.g. my-test-vm" style={inputStyle} />
            </div>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
                Zone{technique === 'compute_control'
                  ? <span style={{ color: COLORS.danger }}> *</span>
                  : ' (optional — required with Instance Name)'}
              </label>
              <input type="text" value={zone} onChange={e => setZone(e.target.value)}
                placeholder="e.g. us-central1-a" style={inputStyle} />
            </div>
          </>
        )}

        {/* Compute Control explicit confirmation checkbox */}
        {technique === 'compute_control' && (
          <div style={{
            marginBottom: 14, padding: '10px 12px',
            background: '#fef9ec', border: '1px solid #fcd34d', borderRadius: 6,
          }}>
            <label style={{ fontSize: 13, display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
              <input type="checkbox" checked={computeConfirmed}
                onChange={e => setComputeConfirmed(e.target.checked)} />
              I confirm this is a <strong>designated test GCP VM instance</strong> and I accept
              that it will be temporarily stopped and restarted.
            </label>
          </div>
        )}

        {/* Action buttons */}
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          <button
            onClick={handleDryRun}
            disabled={loading}
            style={{
              padding: '8px 20px', background: '#2563eb', color: '#fff',
              border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
              cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? 'Running…' : '🔍 Dry Run Preview'}
          </button>

          {dryRunResult && !validateResult && (
            <button
              onClick={handleValidate}
              disabled={validateDisabled}
              title={technique === 'compute_control' && !computeConfirmed
                ? 'Check the confirmation box above before executing'
                : undefined}
              style={{
                padding: '8px 20px', background: '#dc2626', color: '#fff',
                border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
                cursor: validateDisabled ? 'not-allowed' : 'pointer',
                opacity: validateDisabled ? 0.5 : 1,
              }}
            >
              ⚡ Execute Validation
            </button>
          )}
        </div>
      </div>

      {/* Error */}
      {error && (
        <div style={{
          background: '#fef2f2', border: '1px solid #fca5a5', borderRadius: 6,
          padding: '10px 14px', marginBottom: 16, fontSize: 13, color: '#dc2626',
        }}>
          Error: {error}
        </div>
      )}

      {/* Dry run result */}
      {dryRunResult && (
        <GCPResultCard result={dryRunResult} title="Dry Run Preview" />
      )}

      {/* Validate result */}
      {validateResult && (
        <>
          <GCPResultCard result={validateResult} title="Validation Result" />

          {/* GCS Write — object left in bucket info box */}
          {technique === 'gcs_write' && validateResult.status === 'success' && (
            <div style={{
              background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 8,
              padding: '14px 16px', marginBottom: 16,
            }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#15803d', marginBottom: 8 }}>
                ✓ VALIDATION SUCCESSFUL — Test object created in GCS
              </div>
              <div style={{ fontSize: 12, color: '#166534', lineHeight: 1.6, marginBottom: 8 }}>
                <strong>storage.objects.create → SUCCESS</strong><br />
                <strong>storage.objects.get → SUCCESS</strong>
              </div>
              <div style={{
                fontFamily: 'monospace', fontSize: 12, background: '#dcfce7',
                padding: '8px 10px', borderRadius: 4, marginBottom: 10,
              }}>
                gs://{validateResult.gcs_bucket || '(bucket)'}/<br />
                &nbsp;&nbsp;{validateResult.gcs_object_key || '(object key)'}
              </div>
              <div style={{ fontSize: 12, color: '#166534', marginBottom: 10 }}>
                The test object has <strong>NOT</strong> been deleted.
                You can now open the GCP Console → Cloud Storage and navigate to the bucket to
                verify the object exists. When you are ready, press the cleanup button below.
              </div>
              {cleanupResult === null && (
                <button
                  onClick={handleCleanup}
                  disabled={cleanupLoading}
                  style={{
                    padding: '8px 18px', background: '#ca8a04', color: '#fff',
                    border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
                    cursor: cleanupLoading ? 'not-allowed' : 'pointer',
                    opacity: cleanupLoading ? 0.7 : 1,
                  }}
                >
                  {cleanupLoading ? 'Cleaning up…' : '🗑 Clean Up Test Object'}
                </button>
              )}
            </div>
          )}

          {/* Cleanup result */}
          {cleanupResult && (
            <GCPCleanupCard result={cleanupResult} />
          )}
        </>
      )}

      {/* Confirmation dialog */}
      {showConfirmDialog && dryRunResult && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2000,
        }}>
          <div style={{
            background: '#fff', borderRadius: 10, padding: 28, width: 520,
            boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
          }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 12, color: '#dc2626' }}>
              ⚠ Confirm GCP Controlled Validation
            </div>
            <div style={{ fontSize: 13, marginBottom: 12, color: COLORS.text, lineHeight: 1.5 }}>
              This will execute the following GCP API calls against real cloud resources.
              {technique === 'compute_control' && (
                <span style={{ color: '#dc2626', fontWeight: 600 }}>
                  {' '}This will temporarily stop the designated test VM instance.
                </span>
              )}
              {technique === 'gcs_write' && (
                <span>
                  {' '}The test object will be created and will remain in GCS until
                  you explicitly press "Clean Up Test Object".
                </span>
              )}
            </div>
            {/* Provider badge */}
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              background: '#dbeafe', color: '#1e40af', fontWeight: 700,
              fontSize: 11, padding: '3px 10px', borderRadius: 10, marginBottom: 12,
            }}>
              ☁ Google Cloud Platform
            </div>
            <div style={{
              background: COLORS.surface, borderRadius: 6, padding: 12, marginBottom: 16,
              maxHeight: 240, overflowY: 'auto',
            }}>
              {dryRunResult.dry_run_preview.map((step, i) => (
                <div key={i} style={{
                  fontFamily: 'monospace', fontSize: 11.5, padding: '1px 0',
                  color: step.startsWith('⚠') ? '#dc2626' : '#374151',
                }}>
                  {step}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button
                onClick={() => setShowConfirmDialog(false)}
                style={{
                  padding: '7px 18px', border: `1px solid ${COLORS.border}`,
                  borderRadius: 6, background: '#fff', cursor: 'pointer', fontSize: 13,
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmedValidate}
                style={{
                  padding: '7px 18px', background: '#dc2626', color: '#fff',
                  border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13,
                  fontWeight: 600,
                }}
              >
                Confirm — Execute
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


// ---------------------------------------------------------------------------
// GCPResultCard
// ---------------------------------------------------------------------------

interface GCPResultCardProps {
  result: ValidationResult;
  title: string;
}

const GCPResultCard: React.FC<GCPResultCardProps> = ({ result, title }) => {
  const statusInfo = STATUS_STYLES[result.status] ?? { color: COLORS.muted, label: result.status };

  return (
    <div style={{
      border: `1px solid ${COLORS.border}`, borderRadius: 8,
      marginBottom: 16, overflow: 'hidden',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 16px', background: COLORS.surface,
        borderBottom: `1px solid ${COLORS.border}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>{title}</div>
          <span style={{
            fontSize: 10, fontWeight: 700, background: '#dbeafe', color: '#1e40af',
            padding: '2px 7px', borderRadius: 8,
          }}>
            GCP
          </span>
        </div>
        <div style={{ fontWeight: 700, fontSize: 13, color: statusInfo.color }}>
          {statusInfo.label}
        </div>
      </div>

      <div style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 13, color: COLORS.text, marginBottom: 12, lineHeight: 1.5 }}>
          {result.description}
        </div>

        {/* Dry run steps */}
        {result.dry_run_preview?.length > 0 && (
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.muted, marginBottom: 6 }}>
              GCP API Calls
            </div>
            <div style={{
              background: '#f0f7ff', borderRadius: 4, padding: '8px 12px',
              fontFamily: 'Consolas, monospace', fontSize: 11.5,
              border: '1px solid #bfdbfe',
            }}>
              {result.dry_run_preview.map((step, i) => (
                <div key={i} style={{
                  padding: '1px 0',
                  color: step.startsWith('⚠') ? '#dc2626' : '#1e3a5f',
                }}>
                  {step || '\u00A0'}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Confirmed flag */}
        {result.mode === 'VALIDATE' && (
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 10px', borderRadius: 14, fontSize: 12, fontWeight: 600,
            background: result.confirmed ? '#dcfce7' : '#fef2f2',
            color: result.confirmed ? '#15803d' : '#dc2626',
            marginBottom: 10,
          }}>
            {result.confirmed ? '✓ Execution confirmed' : '✗ Execution not confirmed'}
          </div>
        )}

        {/* Evidence */}
        {result.evidence?.length > 0 && (
          <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.muted, marginBottom: 4 }}>
              Evidence ({result.evidence.length} item{result.evidence.length !== 1 ? 's' : ''})
            </div>
            {result.evidence.map((ev, i) => (
              <div key={i} style={{
                fontFamily: 'monospace', fontSize: 11, background: '#f0f0f0',
                padding: '4px 8px', borderRadius: 4, marginBottom: 4,
              }}>
                {JSON.stringify(ev)}
              </div>
            ))}
          </div>
        )}

        {/* Cleanup status */}
        <div style={{ fontSize: 12, color: COLORS.muted }}>
          {result.cleanup_status && result.cleanup_status !== 'N/A' && (
            <>
              Cleanup:{' '}
              {result.cleanup_status === 'COMPLETED' && (
                <span style={{ color: '#16a34a' }}>COMPLETED</span>
              )}
              {result.cleanup_status === 'PENDING' && (
                <span style={{ color: '#ca8a04' }}>PENDING — use "Clean Up Test Object" button</span>
              )}
              {result.cleanup_status === 'FAILED' && (
                <span style={{ color: '#dc2626' }}>FAILED — check audit log</span>
              )}
              {result.cleanup_status === 'PARTIAL' && (
                <span style={{ color: '#ea580c' }}>PARTIAL — verify VM state manually in GCP Console</span>
              )}
              {!['COMPLETED', 'PENDING', 'FAILED', 'PARTIAL'].includes(result.cleanup_status) && (
                <span>{result.cleanup_status}</span>
              )}
            </>
          )}
          {result.run_id && (
            <span style={{ marginLeft: 12 }}>
              Run ID: <code style={{ fontSize: 11 }}>{result.run_id}</code>
            </span>
          )}
        </div>

        {/* Error */}
        {result.error && (
          <div style={{
            marginTop: 8, padding: '6px 10px', background: '#fef2f2',
            borderRadius: 4, fontSize: 12, color: '#dc2626',
            fontFamily: 'monospace',
          }}>
            {result.error}
          </div>
        )}
      </div>
    </div>
  );
};


// ---------------------------------------------------------------------------
// GCPCleanupCard
// ---------------------------------------------------------------------------

interface GCPCleanupCardProps {
  result: CleanupResult;
}

const GCPCleanupCard: React.FC<GCPCleanupCardProps> = ({ result }) => {
  const isSuccess = result.status === 'success' || result.status === 'already_done';
  const isAlreadyDone = result.status === 'already_done';

  return (
    <div style={{
      border: `1px solid ${isSuccess ? '#86efac' : '#fca5a5'}`,
      borderRadius: 8, marginBottom: 16, overflow: 'hidden',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 16px',
        background: isSuccess ? '#f0fdf4' : '#fef2f2',
        borderBottom: `1px solid ${isSuccess ? '#86efac' : '#fca5a5'}`,
      }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>
          {isAlreadyDone ? 'GCS Cleanup (Already Done)' : 'GCS Cleanup Result'}
        </div>
        <div style={{
          fontWeight: 700, fontSize: 13,
          color: isSuccess ? '#15803d' : '#dc2626',
        }}>
          {isSuccess ? '✓ CLEANUP COMPLETED' : '✗ CLEANUP FAILED'}
        </div>
      </div>

      <div style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 13, color: COLORS.text, marginBottom: 10, lineHeight: 1.5 }}>
          {result.description}
        </div>
        {result.object_key && (
          <div style={{
            fontFamily: 'monospace', fontSize: 12, background: '#f0f0f0',
            padding: '6px 10px', borderRadius: 4, marginBottom: 8,
          }}>
            gs://{result.bucket}/{result.object_key}
          </div>
        )}
        {result.deletion_verified !== undefined && (
          <div style={{ fontSize: 12, color: COLORS.muted }}>
            Deletion verified:{' '}
            {result.deletion_verified
              ? <span style={{ color: '#16a34a' }}>Yes — object no longer exists</span>
              : <span style={{ color: '#ca8a04' }}>Not immediately confirmed (GCS eventual consistency)</span>
            }
          </div>
        )}
        {result.error && (
          <div style={{
            marginTop: 8, padding: '6px 10px', background: '#fef2f2',
            borderRadius: 4, fontSize: 12, color: '#dc2626', fontFamily: 'monospace',
          }}>
            {result.error}
          </div>
        )}
      </div>
    </div>
  );
};
