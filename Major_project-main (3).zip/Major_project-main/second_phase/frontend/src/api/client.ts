import axios from 'axios';

const BASE = 'http://localhost:8000';

const api = axios.create({ baseURL: BASE });

// ── Graph ────────────────────────────────────────────────
export const fetchGraph = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/attack-graph', { params: { provider } });

export const fetchNodeDetail = (id: string, provider: 'aws' | 'gcp' = 'aws') =>
  api.get(`/api/attack-graph/node/${encodeURIComponent(id)}`, { params: { provider } });

// ── Scan ─────────────────────────────────────────────────
export const triggerScan      = (payload: ScanRequest) => api.post('/api/scan', payload);
export const fetchScanStatus  = () => api.get('/api/scan/status');

// ── RL ───────────────────────────────────────────────────
export const fetchRLStatus    = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/rl/status', { params: { provider } });
export const fetchRLEpisodes  = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/rl/episodes', { params: { provider } });
export const fetchRLHistory   = (ep?: number, provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/rl/history', {
    params: { ...(ep !== undefined ? { episode: ep } : {}), provider },
  });
export const fetchRLAttackPath = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/rl/attack-path', { params: { provider } });
export const startRLTraining   = (payload: { provider: string; timesteps?: number }) =>
  api.post('/api/rl/train', payload);
export const fetchRLTrainStatus = () => api.get('/api/rl/train/status');
export const runRLInference    = (payload: { provider: string; n_episodes?: number }) =>
  api.post('/api/rl/inference', payload);

// ── Report ───────────────────────────────────────────────
export const generateReport = (provider: 'aws' | 'gcp' = 'aws') =>
  api.post('/api/report/generate', null, { params: { provider } });

export const fetchReport = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/report', { params: { provider } });

/**
 * Download the PDF as a binary Blob.
 * IMPORTANT: responseType must be 'arraybuffer' so Axios never interprets the
 * binary PDF bytes as a UTF-8 string (which would corrupt the file).
 */
export const downloadReportPdf = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/report/pdf', {
    params: { provider },
    responseType: 'arraybuffer',
  });

export const fetchReportHtmlUrl = (provider: 'aws' | 'gcp' = 'aws') =>
  `${BASE}/api/report/html?provider=${provider}`;

// ── Anomaly ──────────────────────────────────────────────
export const fetchAnomalies = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/anomaly', { params: { provider } });

// ── Validate ─────────────────────────────────────────────
export const fetchTechniques = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/validate/techniques', { params: { provider } });
export const validateFinding        = (payload: ValidateRequest) => api.post('/api/validate', payload);
export const cleanupWriteValidation = (payload: CleanupRequest)  => api.post('/api/validate/cleanup', payload);
/** @deprecated Use cleanupWriteValidation — kept for backwards compatibility */
export const cleanupS3Write         = (payload: CleanupRequest)  => cleanupWriteValidation(payload);
export const fetchValidationHistory = (provider?: 'aws' | 'gcp') =>
  api.get('/api/validate/history', { params: provider ? { provider } : {} });
export const fetchAttackPaths       = () => api.get('/api/attack-graph/paths');
export const fetchGraphExportUrl    = (format: 'graphml' | 'json') =>
  `${BASE}/api/attack-graph/export/${format}`;

// ── Health ───────────────────────────────────────────────
export const fetchHealth      = () => api.get('/api/health');

export interface ScanRequest {
  provider?: 'aws' | 'gcp';
  profile?: string;
  region?: string;
  regions?: string;
  skip_privesc?: boolean;
  skip_s3_iam_xref?: boolean;
  gcp_project_id?: string;
}

/** AWS validation technique identifiers */
export type AWSTechnique = 's3_write' | 's3_read' | 'iam_pass_role' | 'ec2_access' | 'ec2_control';

/** GCP validation technique identifiers */
export type GCPTechnique =
  | 'gcs_write'
  | 'gcs_read'
  | 'iam_sa_impersonation'
  | 'compute_access'
  | 'compute_control';

export interface ValidateRequest {
  finding_id: string;
  technique: AWSTechnique | GCPTechnique | string;
  mode: 'READ_ONLY' | 'DRY_RUN' | 'VALIDATE';
  confirmed: boolean;
  provider?: 'aws' | 'gcp';
  run_id?: string;

  // AWS credentials
  profile?: string;
  region?: string;

  // Shared / AWS technique params
  bucket_name?: string;
  object_key?: string;
  role_arn?: string;
  target_service?: string;
  instance_id?: string;

  // GCP technique params
  gcp_project_id?: string;
  service_account_email?: string;
  instance_name?: string;
  zone?: string;
}

export interface CleanupRequest {
  run_id: string;
  provider?: 'aws' | 'gcp';
  // AWS
  profile?: string;
  region?: string;
  // GCP
  gcp_project_id?: string;
}
