"""
Tests for the GCP attack graph pipeline.

Covers:
  - _build_gcp_graph_from_report: resource-to-node conversion
  - Correct node types (ServiceAccount, FirewallRule, Capability, IAMUser)
  - Evidence-backed edge generation from privilege_escalation_paths
  - Node IDs match the format used by get_node_detail
  - Empty / missing-resource graphs
  - get_attack_graph response shape (nodes, edges, meta)
  - get_node_detail success and genuine not-found responses
  - Zero-edge behaviour when no privesc paths exist
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any
from unittest.mock import patch, MagicMock

import pytest

# Ensure backend root is on sys.path
_BACKEND = Path(__file__).parent.parent.parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from api.services.graph_service import (
    _build_gcp_graph_from_report,
    _load_real_graph,
    get_attack_graph,
    get_node_detail,
)


# ---------------------------------------------------------------------------
# Shared report fixtures
# ---------------------------------------------------------------------------

def _minimal_report(
    service_accounts: list[dict] | None = None,
    storage_buckets: list[dict] | None = None,
    compute_instances: list[dict] | None = None,
    compute_findings: list[dict] | None = None,
    privesc_paths: list[dict] | None = None,
    project_id: str = "test-project",
) -> dict[str, Any]:
    return {
        "provider": "gcp",
        "project_id": project_id,
        "resources": {
            "service_accounts": service_accounts or [],
            "storage_buckets": storage_buckets or [],
            "compute_instances": compute_instances or [],
        },
        "findings": {
            "storage": [],
            "compute": compute_findings or [],
        },
        "privilege_escalation_paths": privesc_paths or [],
    }


def _sa(email: str, display_name: str | None = None) -> dict:
    return {"email": email, "display_name": display_name or email.split("@")[0]}


def _firewall_finding(rule_name: str) -> dict:
    return {
        "finding_id": "fw-001",
        "instance_name": f"firewall/{rule_name}",
        "zone": "global",
        "title": f"Firewall rule {rule_name} open",
        "severity": "HIGH",
        "recommendation": "Restrict access.",
        "evidence": {},
    }


def _privesc_sa(email: str, project_id: str = "test-project") -> dict:
    return {
        "source_member": f"serviceAccount:{email}",
        "technique": "ProjectOwnerOrEditor",
        "description": "Has roles/editor",
        "chain": [f"serviceAccount:{email}", "<ProjectOwnerOrEditor>", "roles/editor"],
        "required_permissions": [],
        "severity": "CRITICAL",
        "evidence": [
            {"type": "iam_binding", "role": "roles/editor",
             "member": f"serviceAccount:{email}",
             "resource": f"projects/{project_id}"}
        ],
        "confirmed": True,
    }


def _privesc_user(email: str, project_id: str = "test-project") -> dict:
    return {
        "source_member": f"user:{email}",
        "technique": "ProjectOwnerOrEditor",
        "description": "Has roles/owner",
        "chain": [f"user:{email}", "<ProjectOwnerOrEditor>", "roles/owner"],
        "required_permissions": [],
        "severity": "CRITICAL",
        "evidence": [
            {"type": "iam_binding", "role": "roles/owner",
             "member": f"user:{email}", "resource": f"projects/{project_id}"}
        ],
        "confirmed": True,
    }


# ---------------------------------------------------------------------------
# Node conversion tests
# ---------------------------------------------------------------------------

class TestServiceAccountNodes:
    def test_sa_node_created(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        g = _build_gcp_graph_from_report(report)
        assert "serviceAccount:sa@test-project.iam.gserviceaccount.com" in g.nodes

    def test_sa_node_type(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        g = _build_gcp_graph_from_report(report)
        node = g.nodes["serviceAccount:sa@test-project.iam.gserviceaccount.com"]
        assert node["node_type"] == "ServiceAccount"

    def test_sa_display_name_uses_display_name_field(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com", "My SA")]
        )
        g = _build_gcp_graph_from_report(report)
        node = g.nodes["serviceAccount:sa@test-project.iam.gserviceaccount.com"]
        assert node["display_name"] == "My SA"

    def test_sa_display_name_falls_back_to_email_prefix(self):
        report = _minimal_report(
            service_accounts=[{"email": "sa@test-project.iam.gserviceaccount.com", "display_name": None}]
        )
        g = _build_gcp_graph_from_report(report)
        node = g.nodes["serviceAccount:sa@test-project.iam.gserviceaccount.com"]
        assert node["display_name"] == "sa"

    def test_multiple_sa_nodes(self):
        report = _minimal_report(
            service_accounts=[
                _sa("a@p.iam.gserviceaccount.com"),
                _sa("b@p.iam.gserviceaccount.com"),
            ]
        )
        g = _build_gcp_graph_from_report(report)
        assert "serviceAccount:a@p.iam.gserviceaccount.com" in g.nodes
        assert "serviceAccount:b@p.iam.gserviceaccount.com" in g.nodes

    def test_empty_email_sa_skipped(self):
        report = _minimal_report(
            service_accounts=[{"email": "", "display_name": ""}]
        )
        g = _build_gcp_graph_from_report(report)
        # No real SA node should be added; might have fallback node
        assert "serviceAccount:" not in str(list(g.nodes))


class TestFirewallNodes:
    def test_firewall_node_created_from_finding(self):
        report = _minimal_report(
            compute_findings=[_firewall_finding("default-allow-ssh")]
        )
        g = _build_gcp_graph_from_report(report)
        assert "firewall/default-allow-ssh" in g.nodes

    def test_firewall_node_type(self):
        report = _minimal_report(
            compute_findings=[_firewall_finding("default-allow-rdp")]
        )
        g = _build_gcp_graph_from_report(report)
        node = g.nodes["firewall/default-allow-rdp"]
        assert node["node_type"] == "FirewallRule"

    def test_firewall_display_name_is_rule_name(self):
        report = _minimal_report(
            compute_findings=[_firewall_finding("default-allow-rdp")]
        )
        g = _build_gcp_graph_from_report(report)
        node = g.nodes["firewall/default-allow-rdp"]
        assert node["display_name"] == "default-allow-rdp"

    def test_non_firewall_compute_finding_not_added(self):
        report = _minimal_report(
            compute_findings=[{
                "finding_id": "inst-001",
                "instance_name": "my-vm",  # No "firewall/" prefix
                "zone": "us-central1-a",
                "title": "Public IP",
                "severity": "MEDIUM",
                "recommendation": "",
                "evidence": {},
            }]
        )
        g = _build_gcp_graph_from_report(report)
        # "my-vm" should NOT be added as a node by the firewall logic
        # (compute instance nodes require presence in resources.compute_instances)
        assert "my-vm" not in g.nodes

    def test_two_firewall_findings_two_nodes(self):
        report = _minimal_report(
            compute_findings=[
                _firewall_finding("default-allow-ssh"),
                _firewall_finding("default-allow-rdp"),
            ]
        )
        g = _build_gcp_graph_from_report(report)
        assert "firewall/default-allow-ssh" in g.nodes
        assert "firewall/default-allow-rdp" in g.nodes


class TestStorageBucketNodes:
    def test_bucket_node_created(self):
        report = _minimal_report(storage_buckets=[{"name": "my-bucket"}])
        g = _build_gcp_graph_from_report(report)
        assert "//storage.googleapis.com/my-bucket" in g.nodes

    def test_bucket_node_type(self):
        report = _minimal_report(storage_buckets=[{"name": "my-bucket"}])
        g = _build_gcp_graph_from_report(report)
        node = g.nodes["//storage.googleapis.com/my-bucket"]
        assert node["node_type"] == "StorageBucket"


class TestComputeInstanceNodes:
    def test_instance_node_created(self):
        report = _minimal_report(
            compute_instances=[{"name": "my-vm", "zone": "us-central1-a"}]
        )
        g = _build_gcp_graph_from_report(report)
        assert "my-vm" in g.nodes

    def test_instance_node_type(self):
        report = _minimal_report(
            compute_instances=[{"name": "my-vm", "zone": "us-central1-a"}]
        )
        g = _build_gcp_graph_from_report(report)
        node = g.nodes["my-vm"]
        assert node["node_type"] == "ComputeInstance"


# ---------------------------------------------------------------------------
# Edge generation tests
# ---------------------------------------------------------------------------

class TestPrivEscEdges:
    def test_privesc_edge_created_for_sa(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        g = _build_gcp_graph_from_report(report)
        assert g.number_of_edges() >= 1

    def test_privesc_edge_source_is_sa_node(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        g = _build_gcp_graph_from_report(report)
        src = f"serviceAccount:{email}"
        assert any(u == src for u, _ in g.edges())

    def test_privesc_edge_target_is_capability_node(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        g = _build_gcp_graph_from_report(report)
        src = f"serviceAccount:{email}"
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        assert g.has_edge(src, tgt)

    def test_privesc_edge_relation_is_privesc_to(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        g = _build_gcp_graph_from_report(report)
        src = f"serviceAccount:{email}"
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        edge = g[src][tgt]
        assert edge["relation"] == "PRIVESC_TO"
        assert edge["confirmed"] is True

    def test_privesc_edge_for_user_member(self):
        user_email = "user@example.com"
        report = _minimal_report(
            privesc_paths=[_privesc_user(user_email)],
        )
        g = _build_gcp_graph_from_report(report)
        src = f"user:{user_email}"
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        assert g.has_edge(src, tgt)

    def test_user_member_node_type_is_iamuser(self):
        user_email = "user@example.com"
        report = _minimal_report(
            privesc_paths=[_privesc_user(user_email)],
        )
        g = _build_gcp_graph_from_report(report)
        node = g.nodes[f"user:{user_email}"]
        assert node["node_type"] == "IAMUser"

    def test_capability_target_node_type(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        g = _build_gcp_graph_from_report(report)
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        assert g.nodes[tgt]["node_type"] == "Capability"

    def test_two_privesc_paths_two_edges(self):
        sa_email = "sa@test-project.iam.gserviceaccount.com"
        user_email = "admin@example.com"
        report = _minimal_report(
            service_accounts=[_sa(sa_email)],
            privesc_paths=[
                _privesc_sa(sa_email),
                _privesc_user(user_email),
            ],
        )
        g = _build_gcp_graph_from_report(report)
        assert g.number_of_edges() == 2

    def test_empty_privesc_paths_zero_edges(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")],
            privesc_paths=[],
        )
        g = _build_gcp_graph_from_report(report)
        assert g.number_of_edges() == 0

    def test_privesc_path_missing_source_member_skipped(self):
        """A path dict with no source_member must not crash or add an edge."""
        report = _minimal_report(
            privesc_paths=[{
                "technique": "SomeTechnique",
                "description": "desc",
                "chain": [],
                "required_permissions": [],
                "evidence": [],
            }]
        )
        g = _build_gcp_graph_from_report(report)
        assert g.number_of_edges() == 0


# ---------------------------------------------------------------------------
# Empty / missing resource tests
# ---------------------------------------------------------------------------

class TestEmptyGraph:
    def test_empty_report_has_fallback_node(self):
        report = _minimal_report()
        g = _build_gcp_graph_from_report(report)
        # The fallback placeholder is added when no resources produce nodes
        assert g.number_of_nodes() == 1

    def test_fallback_node_type_is_capability(self):
        report = _minimal_report(project_id="my-project")
        g = _build_gcp_graph_from_report(report)
        # Only one node — should be Capability, not ServiceAccount
        nid, attrs = next(iter(g.nodes(data=True)))
        assert attrs["node_type"] == "Capability"

    def test_report_with_only_sa_has_no_fallback(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        g = _build_gcp_graph_from_report(report)
        # One real SA node, no fallback
        assert g.number_of_nodes() == 1
        nid = list(g.nodes)[0]
        assert nid == "serviceAccount:sa@test-project.iam.gserviceaccount.com"


# ---------------------------------------------------------------------------
# Full report fixture (mirrors last_report.json)
# ---------------------------------------------------------------------------

_REAL_REPORT: dict = {
    "provider": "gcp",
    "project_id": "cloud-pentest-lab-508412",
    "resources": {
        "service_accounts": [
            {"email": "pentest-scanner@cloud-pentest-lab-508412.iam.gserviceaccount.com",
             "display_name": "pentest-scanner", "disabled": False},
            {"email": "793182887921-compute@developer.gserviceaccount.com",
             "display_name": "Compute Engine default service account", "disabled": False},
            {"email": "lab-test-sa@cloud-pentest-lab-508412.iam.gserviceaccount.com",
             "display_name": "lab-test-sa", "disabled": False},
        ],
        "storage_buckets": [],
        "compute_instances": [],
    },
    "findings": {
        "storage": [],
        "compute": [
            {"finding_id": "fw-rdp", "instance_name": "firewall/default-allow-rdp",
             "zone": "global", "title": "RDP open", "severity": "HIGH",
             "recommendation": "", "evidence": {}},
            {"finding_id": "fw-ssh", "instance_name": "firewall/default-allow-ssh",
             "zone": "global", "title": "SSH open", "severity": "HIGH",
             "recommendation": "", "evidence": {}},
        ],
    },
    "privilege_escalation_paths": [
        {
            "source_member": "serviceAccount:lab-test-sa@cloud-pentest-lab-508412.iam.gserviceaccount.com",
            "technique": "ProjectOwnerOrEditor",
            "description": "Has roles/editor",
            "chain": ["serviceAccount:lab-test-sa@...", "<ProjectOwnerOrEditor>", "roles/editor"],
            "required_permissions": [],
            "severity": "CRITICAL",
            "evidence": [{"type": "iam_binding", "role": "roles/editor"}],
            "confirmed": True,
        },
        {
            "source_member": "user:melricelroy27@gmail.com",
            "technique": "ProjectOwnerOrEditor",
            "description": "Has roles/owner",
            "chain": ["user:melricelroy27@gmail.com", "<ProjectOwnerOrEditor>", "roles/owner"],
            "required_permissions": [],
            "severity": "CRITICAL",
            "evidence": [{"type": "iam_binding", "role": "roles/owner"}],
            "confirmed": True,
        },
    ],
}


class TestRealReportGraph:
    def test_node_count(self):
        g = _build_gcp_graph_from_report(_REAL_REPORT)
        # 3 service accounts + 2 firewall rules + 1 Capability target = 6 nodes
        # + 1 IAMUser node for user: member = 7 nodes
        assert g.number_of_nodes() == 7

    def test_edge_count(self):
        g = _build_gcp_graph_from_report(_REAL_REPORT)
        # 2 privesc paths → 2 edges
        assert g.number_of_edges() == 2

    def test_sa_node_ids_prefixed(self):
        g = _build_gcp_graph_from_report(_REAL_REPORT)
        assert "serviceAccount:pentest-scanner@cloud-pentest-lab-508412.iam.gserviceaccount.com" in g.nodes
        assert "serviceAccount:lab-test-sa@cloud-pentest-lab-508412.iam.gserviceaccount.com" in g.nodes

    def test_firewall_node_ids(self):
        g = _build_gcp_graph_from_report(_REAL_REPORT)
        assert "firewall/default-allow-rdp" in g.nodes
        assert "firewall/default-allow-ssh" in g.nodes

    def test_capability_node_exists(self):
        g = _build_gcp_graph_from_report(_REAL_REPORT)
        tgt = "//cloudresourcemanager.googleapis.com/projects/cloud-pentest-lab-508412:admin"
        assert tgt in g.nodes
        assert g.nodes[tgt]["node_type"] == "Capability"

    def test_user_node_exists(self):
        g = _build_gcp_graph_from_report(_REAL_REPORT)
        assert "user:melricelroy27@gmail.com" in g.nodes
        assert g.nodes["user:melricelroy27@gmail.com"]["node_type"] == "IAMUser"

    def test_privesc_edges_present(self):
        g = _build_gcp_graph_from_report(_REAL_REPORT)
        tgt = "//cloudresourcemanager.googleapis.com/projects/cloud-pentest-lab-508412:admin"
        sa_src = "serviceAccount:lab-test-sa@cloud-pentest-lab-508412.iam.gserviceaccount.com"
        user_src = "user:melricelroy27@gmail.com"
        assert g.has_edge(sa_src, tgt)
        assert g.has_edge(user_src, tgt)


# ---------------------------------------------------------------------------
# get_attack_graph API shape tests
# ---------------------------------------------------------------------------

class TestGetAttackGraphShape:
    def _patched_graph(self, report: dict):
        from unittest.mock import mock_open
        import json as _json
        with patch("api.services.graph_service._GCP_REPORT_JSON_PATH") as mp:
            mp.exists.return_value = True
            with patch("builtins.open", mock_open(read_data=_json.dumps(report))):
                return get_attack_graph(provider="gcp")

    def test_returns_nodes_key(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        result = self._patched_graph(report)
        assert "nodes" in result

    def test_returns_edges_key(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        result = self._patched_graph(report)
        assert "edges" in result

    def test_returns_meta_key(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        result = self._patched_graph(report)
        assert "meta" in result

    def test_meta_has_provider_gcp(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        result = self._patched_graph(report)
        assert result["meta"]["provider"] == "gcp"

    def test_meta_node_count_matches_nodes(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        result = self._patched_graph(report)
        assert result["meta"]["nodeCount"] == len(result["nodes"])

    def test_react_flow_node_has_required_fields(self):
        report = _minimal_report(
            service_accounts=[_sa("sa@test-project.iam.gserviceaccount.com")]
        )
        result = self._patched_graph(report)
        node = result["nodes"][0]
        assert "id" in node
        assert "type" in node
        assert "data" in node
        assert "nodeType" in node["data"]
        assert "label" in node["data"]

    def test_confirmed_edges_counted_correctly(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        result = self._patched_graph(report)
        assert result["meta"]["confirmedEdges"] == 1
        assert result["meta"]["unconfirmedEdges"] == 0


# ---------------------------------------------------------------------------
# get_node_detail tests
# ---------------------------------------------------------------------------

class TestGetNodeDetail:
    def _patch_and_get(self, report: dict, node_id: str):
        from unittest.mock import mock_open
        import json as _json
        with patch("api.services.graph_service._GCP_REPORT_JSON_PATH") as mp:
            mp.exists.return_value = True
            with patch("builtins.open", mock_open(read_data=_json.dumps(report))):
                return get_node_detail(node_id, provider="gcp")

    def test_existing_node_returns_detail(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(service_accounts=[_sa(email)])
        node_id = f"serviceAccount:{email}"
        detail = self._patch_and_get(report, node_id)
        assert detail is not None
        assert detail["id"] == node_id

    def test_existing_node_has_attributes(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(service_accounts=[_sa(email)])
        node_id = f"serviceAccount:{email}"
        detail = self._patch_and_get(report, node_id)
        assert "attributes" in detail
        assert detail["attributes"]["node_type"] == "ServiceAccount"

    def test_existing_node_has_risk_score(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(service_accounts=[_sa(email)])
        node_id = f"serviceAccount:{email}"
        detail = self._patch_and_get(report, node_id)
        assert "riskScore" in detail
        assert isinstance(detail["riskScore"], int)

    def test_node_with_outgoing_edge(self):
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        node_id = f"serviceAccount:{email}"
        detail = self._patch_and_get(report, node_id)
        assert len(detail["outEdges"]) == 1
        assert detail["outEdges"][0]["relation"] == "PRIVESC_TO"

    def test_missing_node_returns_none(self):
        report = _minimal_report(service_accounts=[_sa("sa@test.iam.gserviceaccount.com")])
        detail = self._patch_and_get(report, "serviceAccount:nonexistent@test.iam.gserviceaccount.com")
        assert detail is None

    def test_firewall_node_detail(self):
        report = _minimal_report(
            compute_findings=[_firewall_finding("default-allow-ssh")]
        )
        detail = self._patch_and_get(report, "firewall/default-allow-ssh")
        assert detail is not None
        assert detail["attributes"]["node_type"] == "FirewallRule"

    def test_aws_provider_does_not_return_gcp_node(self):
        """AWS graph lookup for a GCP-style node ID returns None."""
        email = "sa@test-project.iam.gserviceaccount.com"
        # Don't patch the GCP path; use a missing AWS graph
        with patch("api.services.graph_service._GRAPH_JSON_PATH") as awsp:
            awsp.exists.return_value = False
            detail = get_node_detail(f"serviceAccount:{email}", provider="aws")
        assert detail is None


# ---------------------------------------------------------------------------
# Task 1: GCPGraphBuilder node type compatibility
# ---------------------------------------------------------------------------

class TestGCPGraphBuilderCompatibility:
    """
    Verify GCPGraphBuilder produces the same node types as
    _build_gcp_graph_from_report so both graph-building paths are compatible.
    """

    def _make_builder(self):
        from gcp_pentest.graph.builder import GCPGraphBuilder
        return GCPGraphBuilder()

    def _make_sa(self, email: str):
        from gcp_pentest.models import GCPServiceAccount
        return GCPServiceAccount(
            name=f"projects/p/serviceAccounts/{email}",
            email=email,
            display_name=email.split("@")[0],
            project_id="test-project",
            disabled=False,
            keys=[],
        )

    def _make_bucket(self, name: str):
        from gcp_pentest.models import GCPStorageBucket
        return GCPStorageBucket(
            name=name,
            location="US",
            is_public_read=False,
            is_public_write=False,
            versioning_enabled=False,
            iam_bindings=[],
        )

    def _make_instance(self, name: str):
        from gcp_pentest.models import GCPInstance
        return GCPInstance(
            name=name,
            zone="us-central1-a",
            machine_type="n1-standard-1",
            status="RUNNING",
            project_id="test-project",
            has_public_ip=False,
            has_default_service_account=False,
            service_accounts=[],
            metadata={},
        )

    def test_sa_node_type_is_service_account(self):
        builder = self._make_builder()
        sa = self._make_sa("sa@test-project.iam.gserviceaccount.com")
        graph = builder.build("test-project", [sa], [], [], [])
        nx_g = graph.to_networkx()
        node = nx_g.nodes["serviceAccount:sa@test-project.iam.gserviceaccount.com"]
        assert node["node_type"] == "ServiceAccount", (
            "GCPGraphBuilder must emit 'ServiceAccount' — not 'GCPServiceAccount'"
        )

    def test_bucket_node_type_is_storage_bucket(self):
        builder = self._make_builder()
        bucket = self._make_bucket("my-bucket")
        graph = builder.build("test-project", [], [], [bucket], [])
        nx_g = graph.to_networkx()
        node = nx_g.nodes["//storage.googleapis.com/my-bucket"]
        assert node["node_type"] == "StorageBucket", (
            "GCPGraphBuilder must emit 'StorageBucket' — not 'GCPStorageBucket'"
        )

    def test_instance_node_type_is_compute_instance(self):
        builder = self._make_builder()
        inst = self._make_instance("my-vm")
        graph = builder.build("test-project", [], [], [], [inst])
        nx_g = graph.to_networkx()
        node = nx_g.nodes["my-vm"]
        assert node["node_type"] == "ComputeInstance", (
            "GCPGraphBuilder must emit 'ComputeInstance' — not 'GCPInstance'"
        )

    def test_instance_node_id_matches_graph_service_format(self):
        """Both GCPGraphBuilder and _build_gcp_graph_from_report use plain inst.name."""
        builder = self._make_builder()
        inst = self._make_instance("my-vm")
        graph = builder.build("test-project", [], [], [], [inst])
        nx_g = graph.to_networkx()
        # The node ID must be the plain instance name — matching graph_service behavior
        assert "my-vm" in nx_g.nodes
        # The full compute resource path must NOT be a node ID
        full_path = "//compute.googleapis.com/projects/test-project/zones/us-central1-a/instances/my-vm"
        assert full_path not in nx_g.nodes

    def test_sa_node_id_format_matches_graph_service(self):
        """Both paths use 'serviceAccount:<email>' as the node ID."""
        builder = self._make_builder()
        email = "sa@test-project.iam.gserviceaccount.com"
        sa = self._make_sa(email)
        graph = builder.build("test-project", [sa], [], [], [])
        nx_g = graph.to_networkx()
        assert f"serviceAccount:{email}" in nx_g.nodes

    def test_bucket_node_id_format_matches_graph_service(self):
        """Both paths use '//storage.googleapis.com/<name>' as the bucket node ID."""
        builder = self._make_builder()
        bucket = self._make_bucket("pentest-bucket")
        graph = builder.build("test-project", [], [], [bucket], [])
        nx_g = graph.to_networkx()
        assert "//storage.googleapis.com/pentest-bucket" in nx_g.nodes

    def test_node_types_are_subset_of_graph_service_types(self):
        """All node types from GCPGraphBuilder must be known to _TYPE_BASE_RISK."""
        from api.services.graph_service import _TYPE_BASE_RISK
        builder = self._make_builder()
        sa = self._make_sa("sa@test-project.iam.gserviceaccount.com")
        bucket = self._make_bucket("my-bucket")
        inst = self._make_instance("my-vm")
        graph = builder.build("test-project", [sa], [], [bucket], [inst])
        nx_g = graph.to_networkx()
        unknown = [
            attrs.get("node_type")
            for _, attrs in nx_g.nodes(data=True)
            if attrs.get("node_type") not in _TYPE_BASE_RISK
        ]
        assert unknown == [], f"Unknown node types from GCPGraphBuilder: {unknown}"


# ---------------------------------------------------------------------------
# Task 2: PrivEsc edge semantics — actions derived from evidence roles
# ---------------------------------------------------------------------------

class TestPrivEscEdgeSemantics:
    """
    Verify the edge's 'actions' field accurately reflects what the evidence shows,
    distinguishing observed-permission paths from confirmed exploitable paths.
    """

    def test_actions_populated_from_evidence_when_required_permissions_empty(self):
        """
        When required_permissions is [], actions are derived from evidence roles.
        This preserves the distinction: the path was OBSERVED via an existing binding,
        not exploited by performing a new action.
        """
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        g = _build_gcp_graph_from_report(report)
        src = f"serviceAccount:{email}"
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        edge = g[src][tgt]
        # required_permissions is [] in _privesc_sa, so actions come from evidence
        assert edge["actions"] == ["roles/editor"], (
            "Edge actions must reflect the granted role when required_permissions is empty"
        )

    def test_actions_use_required_permissions_when_present(self):
        """When required_permissions is non-empty, those are used as actions."""
        email = "sa@test-project.iam.gserviceaccount.com"
        privesc = {
            "source_member": f"serviceAccount:{email}",
            "technique": "CreateServiceAccountKey",
            "description": "Can create SA key",
            "chain": [f"serviceAccount:{email}", "<CreateServiceAccountKey>"],
            "required_permissions": ["iam.serviceAccountKeys.create"],
            "severity": "HIGH",
            "evidence": [{"type": "iam_binding", "role": "roles/iam.serviceAccountKeyAdmin"}],
            "confirmed": True,
        }
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[privesc],
        )
        g = _build_gcp_graph_from_report(report)
        src = f"serviceAccount:{email}"
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        edge = g[src][tgt]
        assert edge["actions"] == ["iam.serviceAccountKeys.create"], (
            "required_permissions must take precedence over evidence roles"
        )

    def test_capability_node_not_labeled_project_admin(self):
        """
        The capability node must not be labeled 'ProjectAdmin' —
        roles/editor is not an admin role.
        """
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],  # technique: ProjectOwnerOrEditor, role: roles/editor
        )
        g = _build_gcp_graph_from_report(report)
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        display = g.nodes[tgt]["display_name"]
        assert display != "ProjectAdmin", (
            "Capability node must not be labeled 'ProjectAdmin' when evidence only shows roles/editor"
        )

    def test_edge_carries_technique_attribute(self):
        """The edge preserves the technique name for audit purposes."""
        email = "sa@test-project.iam.gserviceaccount.com"
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[_privesc_sa(email)],
        )
        g = _build_gcp_graph_from_report(report)
        src = f"serviceAccount:{email}"
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        edge = g[src][tgt]
        assert "technique" in edge
        assert edge["technique"] == "ProjectOwnerOrEditor"

    def test_confirmed_flag_propagated_from_path(self):
        """The confirmed flag on the path is reflected on the edge."""
        email = "sa@test-project.iam.gserviceaccount.com"
        privesc = dict(_privesc_sa(email))
        privesc["confirmed"] = False
        report = _minimal_report(
            service_accounts=[_sa(email)],
            privesc_paths=[privesc],
        )
        g = _build_gcp_graph_from_report(report)
        src = f"serviceAccount:{email}"
        tgt = "//cloudresourcemanager.googleapis.com/projects/test-project:admin"
        assert g[src][tgt]["confirmed"] is False


# ---------------------------------------------------------------------------
# Task 3: Provider-specific graph export tests
# ---------------------------------------------------------------------------

class TestGraphExportProvider:
    """
    Tests for the /api/attack-graph/export/json endpoint ensuring
    provider routing works correctly without live cloud access.
    """

    def _make_gcp_rf(self):
        """Patch GCP path to return a minimal GCP graph dict."""
        from unittest.mock import mock_open
        return {
            "provider": "gcp",
            "project_id": "test-project",
            "resources": {"service_accounts": [{"email": "sa@test.iam.gserviceaccount.com", "display_name": "sa", "disabled": False}],
                          "storage_buckets": [], "compute_instances": []},
            "findings": {"storage": [], "compute": []},
            "privilege_escalation_paths": [],
        }

    def test_gcp_export_returns_gcp_nodes(self):
        """GCP export serialises GCP graph nodes, not AWS nodes."""
        from unittest.mock import mock_open
        import json as _json
        report = self._make_gcp_rf()
        with patch("api.services.graph_service._GCP_REPORT_JSON_PATH") as mp:
            mp.exists.return_value = True
            with patch("builtins.open", mock_open(read_data=_json.dumps(report))):
                nx_graph, source = _load_real_graph(provider="gcp")
        assert nx_graph.number_of_nodes() > 0
        assert source == "gcp_real"
        node_types = {attrs.get("node_type") for _, attrs in nx_graph.nodes(data=True)}
        assert "ServiceAccount" in node_types
        # No AWS types should appear
        assert "IAMUser" not in node_types
        assert "IAMRole" not in node_types
        assert "S3Bucket" not in node_types

    def test_aws_export_returns_aws_source(self):
        """AWS graph export source label is phase1_real or legacy_partial, never gcp_real."""
        with patch("api.services.graph_service._GCP_REPORT_JSON_PATH") as gp:
            gp.exists.return_value = False
            with patch("api.services.graph_service._GRAPH_JSON_PATH") as ap:
                ap.exists.return_value = False
                nx_graph, source = _load_real_graph(provider="aws")
        # With no files present and no CloudGraphBuilder: returns empty + "empty"
        assert source in ("empty", "legacy_partial", "phase1_real")
        assert source != "gcp_real"

    def test_gcp_export_unavailable_returns_empty_source(self):
        """When no GCP report exists, source is 'gcp_empty'."""
        with patch("api.services.graph_service._GCP_REPORT_JSON_PATH") as mp:
            mp.exists.return_value = False
            nx_graph, source = _load_real_graph(provider="gcp")
        assert nx_graph.number_of_nodes() == 0
        assert source == "gcp_empty"

    def test_gcp_export_node_ids_use_canonical_format(self):
        """GCP graph service accounts use 'serviceAccount:' prefix in node IDs."""
        from unittest.mock import mock_open
        import json as _json
        report = self._make_gcp_rf()
        with patch("api.services.graph_service._GCP_REPORT_JSON_PATH") as mp:
            mp.exists.return_value = True
            with patch("builtins.open", mock_open(read_data=_json.dumps(report))):
                nx_graph, _ = _load_real_graph(provider="gcp")
        node_ids = list(nx_graph.nodes)
        assert any(nid.startswith("serviceAccount:") for nid in node_ids)

    def test_aws_export_with_missing_file_fallback(self):
        """AWS export falls through to CloudGraphBuilder or empty — never crashes."""
        with patch("api.services.graph_service._GRAPH_JSON_PATH") as ap:
            ap.exists.return_value = False
            # Prevent CloudGraphBuilder from making real API calls
            with patch("api.services.graph_service.Path") as pp:
                # Just confirm it doesn't raise
                try:
                    nx_graph, source = _load_real_graph(provider="aws")
                    assert isinstance(source, str)
                except Exception as exc:
                    pytest.fail(f"_load_real_graph(aws) raised unexpectedly: {exc}")
