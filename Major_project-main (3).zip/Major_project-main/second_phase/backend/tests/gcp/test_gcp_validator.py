"""
Unit tests for GCPValidator — three controlled-validation techniques.

Tests are fully mocked — no live GCP API calls are made.

Coverage per technique:
  iam_sa_impersonation
    - READ_ONLY → not_performed (no API call)
    - DRY_RUN  → dry_run_preview (no API call, preview lists generateAccessToken endpoint)
    - VALIDATE without confirmed → not_performed
    - VALIDATE success → success, token discarded, caller identity in evidence
    - VALIDATE permission denied (403) → failure (not error)
    - VALIDATE not found (404) → error
    - VALIDATE API not enabled → error
    - Missing service_account_email → error
    - Wrong provider (aws technique) never invokes GCP logic

  compute_access
    - READ_ONLY → not_performed
    - DRY_RUN with instance+zone → dry_run_preview
    - DRY_RUN without instance → dry_run_preview (aggregatedList preview)
    - VALIDATE success with instance+zone
    - VALIDATE success without instance (aggregatedList)
    - VALIDATE permission denied (403) → failure
    - VALIDATE not found (404) → error
    - Missing project_id → error

  compute_control
    - READ_ONLY → not_performed
    - DRY_RUN → dry_run_preview, no stop/start
    - VALIDATE without confirmed → not_performed
    - VALIDATE non-RUNNING instance → failure (skipped)
    - VALIDATE success (stop + start) → success, cleanup_done=True
    - VALIDATE permission denied (403) on stop → failure with clear permission message
    - VALIDATE not found (404) → error
    - Missing instance_name or zone → error
    - Missing project_id → error
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

_BACKEND = Path(__file__).parent.parent.parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from gcp_pentest.validation.validator import GCPValidator, ValidationMode, ValidationResult


# ---------------------------------------------------------------------------
# Constants matching the live test environment
# ---------------------------------------------------------------------------

PROJECT_ID = "cloud-pentest-lab-508412"
SCANNER_SA = "pentest-scanner@cloud-pentest-lab-508412.iam.gserviceaccount.com"
TARGET_SA = "gcp-impersonation-test-sa@cloud-pentest-lab-508412.iam.gserviceaccount.com"
VM_ACCESS = "pentest-lab-vm"
VM_CONTROL = "gcp-validation-control-vm"
ZONE = "us-central1-a"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _validator(mode: ValidationMode = ValidationMode.READ_ONLY,
               project_id: str = PROJECT_ID) -> GCPValidator:
    """Build a GCPValidator with a mock credentials object — no live SDK calls."""
    mock_creds = MagicMock()
    mock_creds.service_account_email = SCANNER_SA
    return GCPValidator(credentials=mock_creds, project_id=project_id, mode=mode)


def _assert_no_token_in_result(result: ValidationResult) -> None:
    """Assert that no actual token value appears anywhere in the result."""
    result_str = result.model_dump_json()
    # Tokens are typically long opaque strings starting with "ya29."
    assert "ya29." not in result_str, "Raw access token must not appear in result"
    for ev in result.evidence:
        assert ev.get("token_value") in (None, "[REDACTED]", "[REDACTED — never stored or returned]"), (
            f"token_value must be redacted, got: {ev.get('token_value')!r}"
        )


# ===========================================================================
# IAM Service Account Impersonation
# ===========================================================================

class TestIAMImpersonationReadOnly:
    def test_returns_not_performed(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        assert r.status == "not_performed"
        assert r.confirmed is False

    def test_no_api_call_in_read_only(self):
        v = _validator(ValidationMode.READ_ONLY)
        with patch("google.auth.impersonated_credentials.Credentials") as mock_imp:
            v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        mock_imp.assert_not_called()

    def test_description_mentions_generate_access_token(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        assert "generateAccessToken" in r.description

    def test_missing_sa_email_returns_error(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-1", "iam_sa_impersonation")
        assert r.status == "error"
        assert "service_account_email" in r.error


class TestIAMImpersonationDryRun:
    def test_returns_dry_run_preview(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        assert r.status == "dry_run_preview"
        assert r.confirmed is False

    def test_no_api_call_in_dry_run(self):
        v = _validator(ValidationMode.DRY_RUN)
        with patch("google.auth.impersonated_credentials.Credentials") as mock_imp:
            v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        mock_imp.assert_not_called()

    def test_preview_lists_generate_access_token_endpoint(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        preview_text = "\n".join(r.dry_run_preview)
        assert "generateAccessToken" in preview_text

    def test_preview_lists_target_sa(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        preview_text = "\n".join(r.dry_run_preview)
        assert TARGET_SA in preview_text

    def test_preview_states_token_discarded(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        preview_text = "\n".join(r.dry_run_preview)
        assert "discard" in preview_text.lower() or "not generated" in preview_text.lower()

    def test_audit_log_has_dry_run_entry(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-1", "iam_sa_impersonation", service_account_email=TARGET_SA)
        assert any(e.outcome == "dry_run" for e in r.audit_log)


class TestIAMImpersonationValidate:
    def test_requires_confirmed(self):
        v = _validator(ValidationMode.VALIDATE)
        r = v.validate("f-1", "iam_sa_impersonation",
                       confirmed=False, service_account_email=TARGET_SA)
        assert r.status == "not_performed"
        assert r.confirmed is False

    def test_success_uses_impersonated_credentials(self):
        """VALIDATE success path calls generateAccessToken via impersonated_credentials."""
        mock_imp_creds = MagicMock()
        mock_imp_creds.token = "fake-token-value"

        mock_creds = MagicMock()
        mock_creds.service_account_email = SCANNER_SA

        v = GCPValidator(credentials=mock_creds, project_id=PROJECT_ID,
                         mode=ValidationMode.VALIDATE)

        with patch("google.auth.impersonated_credentials.Credentials",
                   return_value=mock_imp_creds) as mock_imp_cls, \
             patch("google.auth.transport.requests.Request"):
            r = v.validate("f-1", "iam_sa_impersonation",
                           confirmed=True, service_account_email=TARGET_SA)

        mock_imp_cls.assert_called_once()
        call_kwargs = mock_imp_cls.call_args[1]
        assert call_kwargs["target_principal"] == TARGET_SA
        assert r.status == "success"
        assert r.confirmed is True

    def test_success_token_never_returned(self):
        """The actual token must not appear in the result."""
        mock_imp_creds = MagicMock()
        mock_imp_creds.token = "ya29.secret-real-token"

        mock_creds = MagicMock()
        mock_creds.service_account_email = SCANNER_SA

        v = GCPValidator(credentials=mock_creds, project_id=PROJECT_ID,
                         mode=ValidationMode.VALIDATE)

        with patch("google.auth.impersonated_credentials.Credentials",
                   return_value=mock_imp_creds), \
             patch("google.auth.transport.requests.Request"):
            r = v.validate("f-1", "iam_sa_impersonation",
                           confirmed=True, service_account_email=TARGET_SA)

        _assert_no_token_in_result(r)

    def test_success_caller_identity_in_evidence(self):
        """Evidence must show the caller service account identity."""
        mock_imp_creds = MagicMock()
        mock_imp_creds.token = "fake-token"

        mock_creds = MagicMock()
        mock_creds.service_account_email = SCANNER_SA

        v = GCPValidator(credentials=mock_creds, project_id=PROJECT_ID,
                         mode=ValidationMode.VALIDATE)

        with patch("google.auth.impersonated_credentials.Credentials",
                   return_value=mock_imp_creds), \
             patch("google.auth.transport.requests.Request"):
            r = v.validate("f-1", "iam_sa_impersonation",
                           confirmed=True, service_account_email=TARGET_SA)

        evidence_sa = [e.get("caller_service_account") for e in r.evidence]
        assert any(SCANNER_SA in (ea or "") for ea in evidence_sa), (
            f"Caller SA '{SCANNER_SA}' not found in evidence: {evidence_sa}"
        )

    def test_permission_denied_returns_failure(self):
        """403 from generateAccessToken → status='failure', not 'error'."""
        mock_creds = MagicMock()
        mock_creds.service_account_email = SCANNER_SA

        v = GCPValidator(credentials=mock_creds, project_id=PROJECT_ID,
                         mode=ValidationMode.VALIDATE)

        err_403 = Exception("403 The caller does not have permission")

        with patch("google.auth.impersonated_credentials.Credentials") as mock_cls, \
             patch("google.auth.transport.requests.Request"):
            mock_instance = MagicMock()
            mock_instance.refresh.side_effect = err_403
            mock_cls.return_value = mock_instance
            r = v.validate("f-1", "iam_sa_impersonation",
                           confirmed=True, service_account_email=TARGET_SA)

        assert r.status == "failure"
        assert r.confirmed is False
        assert "DENIED" in r.description or "denied" in r.description.lower()

    def test_not_found_returns_error(self):
        """404 from generateAccessToken → status='error'."""
        mock_creds = MagicMock()
        mock_creds.service_account_email = SCANNER_SA

        v = GCPValidator(credentials=mock_creds, project_id=PROJECT_ID,
                         mode=ValidationMode.VALIDATE)

        err_404 = Exception("404 Service account not found")

        with patch("google.auth.impersonated_credentials.Credentials") as mock_cls, \
             patch("google.auth.transport.requests.Request"):
            mock_instance = MagicMock()
            mock_instance.refresh.side_effect = err_404
            mock_cls.return_value = mock_instance
            r = v.validate("f-1", "iam_sa_impersonation",
                           confirmed=True, service_account_email=TARGET_SA)

        assert r.status == "error"
        assert "not found" in r.description.lower() or "NOT FOUND" in r.description

    def test_api_not_enabled_returns_error(self):
        """API-not-enabled error → status='error' with API enable instruction."""
        mock_creds = MagicMock()
        v = GCPValidator(credentials=mock_creds, project_id=PROJECT_ID,
                         mode=ValidationMode.VALIDATE)

        err_api = Exception("iamcredentials API not enabled on project")

        with patch("google.auth.impersonated_credentials.Credentials") as mock_cls, \
             patch("google.auth.transport.requests.Request"):
            mock_instance = MagicMock()
            mock_instance.refresh.side_effect = err_api
            mock_cls.return_value = mock_instance
            r = v.validate("f-1", "iam_sa_impersonation",
                           confirmed=True, service_account_email=TARGET_SA)

        assert r.status == "error"
        assert "iamcredentials" in r.description.lower() or "API" in r.description


# ===========================================================================
# Compute Access
# ===========================================================================

class TestComputeAccessReadOnly:
    def test_returns_not_performed(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-2", "compute_access",
                       instance_name=VM_ACCESS, zone=ZONE)
        assert r.status == "not_performed"

    def test_missing_project_id_returns_error(self):
        v = _validator(ValidationMode.READ_ONLY, project_id=None)
        r = v.validate("f-2", "compute_access")
        assert r.status == "error"


class TestComputeAccessDryRun:
    def test_with_instance_shows_get_preview(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-2", "compute_access",
                       instance_name=VM_ACCESS, zone=ZONE)
        assert r.status == "dry_run_preview"
        preview = "\n".join(r.dry_run_preview)
        assert "compute.instances.get" in preview
        assert VM_ACCESS in preview

    def test_without_instance_shows_list_preview(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-2", "compute_access")
        assert r.status == "dry_run_preview"
        preview = "\n".join(r.dry_run_preview)
        assert "aggregatedList" in preview or "list" in preview.lower()

    def test_no_compute_api_call_in_dry_run(self):
        v = _validator(ValidationMode.DRY_RUN)
        with patch("google.cloud.compute_v1.InstancesClient") as mock_client:
            v.validate("f-2", "compute_access", instance_name=VM_ACCESS, zone=ZONE)
        mock_client.assert_not_called()


class TestComputeAccessValidate:
    def test_requires_confirmed(self):
        v = _validator(ValidationMode.VALIDATE)
        r = v.validate("f-2", "compute_access", confirmed=False,
                       instance_name=VM_ACCESS, zone=ZONE)
        assert r.status == "not_performed"

    def test_success_with_instance(self):
        mock_inst = MagicMock()
        mock_inst.name = VM_ACCESS
        mock_inst.status = "RUNNING"
        mock_inst.machine_type = f"zones/{ZONE}/machineTypes/n1-standard-1"

        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.return_value = mock_inst
            r = v.validate("f-2", "compute_access", confirmed=True,
                           instance_name=VM_ACCESS, zone=ZONE)

        assert r.status == "success"
        assert r.confirmed is True
        assert any(e.get("instance") == VM_ACCESS for e in r.evidence)

    def test_permission_denied_returns_failure(self):
        """403 on compute.instances.get → status='failure'."""
        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.side_effect = Exception(
                "403 The caller does not have permission to compute.instances.get"
            )
            r = v.validate("f-2", "compute_access", confirmed=True,
                           instance_name=VM_ACCESS, zone=ZONE)

        assert r.status == "failure"
        assert "DENIED" in r.description or "denied" in r.description.lower()

    def test_not_found_returns_error(self):
        """404 on compute.instances.get → status='error'."""
        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.side_effect = Exception(
                "404 Instance not found"
            )
            r = v.validate("f-2", "compute_access", confirmed=True,
                           instance_name=VM_ACCESS, zone=ZONE)

        assert r.status == "error"
        assert "NOT FOUND" in r.description or "not found" in r.description.lower()

    def test_success_with_aggregated_list(self):
        """compute_access without instance_name uses aggregatedList."""
        mock_inst = MagicMock()
        mock_inst.name = VM_ACCESS
        mock_inst.status = "RUNNING"

        mock_zone_result = MagicMock()
        mock_zone_result.instances = [mock_inst]

        v = _validator(ValidationMode.VALIDATE)
        with patch("google.cloud.compute_v1.InstancesClient") as mock_cls, \
             patch.object(v, "_get_compute_client"):
            mock_agg = MagicMock()
            mock_agg.aggregated_list.return_value = [
                (ZONE, mock_zone_result)
            ]
            mock_cls.return_value = mock_agg
            # Patch credentials to inject into new client constructor
            v._credentials = MagicMock()
            r = v.validate("f-2", "compute_access", confirmed=True)

        assert r.status == "success"


# ===========================================================================
# Compute Control
# ===========================================================================

class TestComputeControlReadOnly:
    def test_returns_not_performed(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-3", "compute_control",
                       instance_name=VM_CONTROL, zone=ZONE)
        assert r.status == "not_performed"
        assert r.confirmed is False

    def test_missing_instance_name_returns_error(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-3", "compute_control", zone=ZONE)
        assert r.status == "error"

    def test_missing_zone_returns_error(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-3", "compute_control", instance_name=VM_CONTROL)
        assert r.status == "error"

    def test_missing_project_id_returns_error(self):
        v = _validator(ValidationMode.READ_ONLY, project_id=None)
        r = v.validate("f-3", "compute_control",
                       instance_name=VM_CONTROL, zone=ZONE)
        assert r.status == "error"


class TestComputeControlDryRun:
    def test_returns_dry_run_preview(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-3", "compute_control",
                       instance_name=VM_CONTROL, zone=ZONE)
        assert r.status == "dry_run_preview"
        assert r.confirmed is False

    def test_no_stop_or_start_in_dry_run(self):
        """The dry-run must not call stop or start on any VM."""
        v = _validator(ValidationMode.DRY_RUN)
        with patch.object(v, "_get_compute_client") as mock_gc:
            v.validate("f-3", "compute_control",
                       instance_name=VM_CONTROL, zone=ZONE)
        mock_gc.assert_not_called()

    def test_preview_shows_stop_and_start(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-3", "compute_control",
                       instance_name=VM_CONTROL, zone=ZONE)
        preview = "\n".join(r.dry_run_preview)
        assert "stop" in preview.lower()
        assert "start" in preview.lower()

    def test_preview_shows_instance_name_and_zone(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-3", "compute_control",
                       instance_name=VM_CONTROL, zone=ZONE)
        preview = "\n".join(r.dry_run_preview)
        assert VM_CONTROL in preview
        assert ZONE in preview

    def test_audit_log_has_stop_and_start_dry_run(self):
        v = _validator(ValidationMode.DRY_RUN)
        r = v.validate("f-3", "compute_control",
                       instance_name=VM_CONTROL, zone=ZONE)
        actions = [e.action for e in r.audit_log]
        assert any("stop" in a for a in actions)
        assert any("start" in a for a in actions)


class TestComputeControlValidate:
    def test_requires_confirmed(self):
        v = _validator(ValidationMode.VALIDATE)
        r = v.validate("f-3", "compute_control",
                       confirmed=False, instance_name=VM_CONTROL, zone=ZONE)
        assert r.status == "not_performed"
        assert r.confirmed is False

    def test_non_running_instance_returns_failure(self):
        """A non-RUNNING instance must not be stopped."""
        mock_inst = MagicMock()
        mock_inst.status = "TERMINATED"

        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.return_value = mock_inst
            r = v.validate("f-3", "compute_control",
                           confirmed=True, instance_name=VM_CONTROL, zone=ZONE)

        assert r.status == "failure"
        assert "RUNNING" in r.description

    def test_non_running_instance_does_not_call_stop(self):
        mock_inst = MagicMock()
        mock_inst.status = "STOPPED"

        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.return_value = mock_inst
            r = v.validate("f-3", "compute_control",
                           confirmed=True, instance_name=VM_CONTROL, zone=ZONE)

        mock_gc.return_value.stop.assert_not_called()

    def test_success_stop_and_start(self):
        """Successful stop+start → status='success', confirmed=True, cleanup_done=True."""
        mock_inst = MagicMock()
        mock_inst.status = "RUNNING"

        mock_stop_op = MagicMock()
        mock_stop_op.name = "stop-op-1"
        mock_start_op = MagicMock()
        mock_start_op.name = "start-op-1"

        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.return_value = mock_inst
            mock_gc.return_value.stop.return_value = mock_stop_op
            mock_gc.return_value.start.return_value = mock_start_op
            r = v.validate("f-3", "compute_control",
                           confirmed=True, instance_name=VM_CONTROL, zone=ZONE)

        assert r.status == "success"
        assert r.confirmed is True
        assert r.cleanup_done is True
        assert r.cleanup_status == "COMPLETED"

    def test_success_both_operations_in_evidence(self):
        mock_inst = MagicMock()
        mock_inst.status = "RUNNING"
        mock_stop_op = MagicMock()
        mock_stop_op.name = "stop-op-1"
        mock_start_op = MagicMock()
        mock_start_op.name = "start-op-1"

        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.return_value = mock_inst
            mock_gc.return_value.stop.return_value = mock_stop_op
            mock_gc.return_value.start.return_value = mock_start_op
            r = v.validate("f-3", "compute_control",
                           confirmed=True, instance_name=VM_CONTROL, zone=ZONE)

        ops = [e.get("operation") for e in r.evidence]
        assert "compute.instances.stop" in ops
        assert "compute.instances.start" in ops

    def test_permission_denied_on_stop_returns_failure(self):
        """403 on stop → status='failure' with permission explanation."""
        mock_inst = MagicMock()
        mock_inst.status = "RUNNING"

        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.return_value = mock_inst
            mock_gc.return_value.stop.side_effect = Exception(
                "403 Required 'compute.instances.stop' permission"
            )
            r = v.validate("f-3", "compute_control",
                           confirmed=True, instance_name=VM_CONTROL, zone=ZONE)

        assert r.status == "failure"
        assert r.confirmed is False
        # The description must explain which permission is missing
        assert "permission" in r.description.lower() or "DENIED" in r.description

    def test_not_found_returns_error(self):
        """404 on get → status='error'."""
        v = _validator(ValidationMode.VALIDATE)
        with patch.object(v, "_get_compute_client") as mock_gc:
            mock_gc.return_value.get.side_effect = Exception(
                "404 Instance not found"
            )
            r = v.validate("f-3", "compute_control",
                           confirmed=True, instance_name=VM_CONTROL, zone=ZONE)

        assert r.status == "error"
        assert "NOT FOUND" in r.description or "not found" in r.description.lower()


# ===========================================================================
# Wrong-provider safety: GCP validator never invokes AWS logic
# ===========================================================================

class TestProviderIsolation:
    """Selecting gcp provider must never route to AWS validator code."""

    def test_unknown_technique_returns_error(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-x", "s3_write")  # AWS technique
        assert r.status == "error"
        assert "s3_write" in r.description or "Unsupported" in r.description

    def test_ec2_technique_returns_error(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-x", "ec2_control")
        assert r.status == "error"

    def test_iam_pass_role_returns_error(self):
        v = _validator(ValidationMode.READ_ONLY)
        r = v.validate("f-x", "iam_pass_role")
        assert r.status == "error"


# ===========================================================================
# ValidationResult model invariants
# ===========================================================================

class TestValidationResultModel:
    """GCPValidator always returns a valid ValidationResult regardless of mode/input."""

    @pytest.mark.parametrize("technique,kwargs", [
        ("gcs_write", {"bucket_name": "test-bucket"}),
        ("gcs_read",  {"bucket_name": "test-bucket"}),
        ("iam_sa_impersonation", {"service_account_email": TARGET_SA}),
        ("compute_access", {"instance_name": VM_ACCESS, "zone": ZONE}),
        ("compute_control", {"instance_name": VM_CONTROL, "zone": ZONE}),
    ])
    @pytest.mark.parametrize("mode", [
        ValidationMode.READ_ONLY,
        ValidationMode.DRY_RUN,
    ])
    def test_result_is_validation_result(self, technique, kwargs, mode):
        v = _validator(mode)
        r = v.validate("f-x", technique, **kwargs)
        assert isinstance(r, ValidationResult)
        assert r.provider == "gcp"
        assert r.technique == technique
        assert r.mode == mode

    def test_dry_run_never_confirmed(self):
        """DRY_RUN results are never confirmed=True."""
        v = _validator(ValidationMode.DRY_RUN)
        for technique, kwargs in [
            ("iam_sa_impersonation", {"service_account_email": TARGET_SA}),
            ("compute_access", {"instance_name": VM_ACCESS, "zone": ZONE}),
            ("compute_control", {"instance_name": VM_CONTROL, "zone": ZONE}),
        ]:
            r = v.validate("f-x", technique, **kwargs)
            assert r.confirmed is False, (
                f"DRY_RUN result for {technique} must have confirmed=False"
            )
    def test_read_only_never_confirmed_simple(self):
        v = _validator(ValidationMode.READ_ONLY)
        r1 = v.validate("f-x", "iam_sa_impersonation", service_account_email=TARGET_SA)
        r2 = v.validate("f-x", "compute_access")
        r3 = v.validate("f-x", "compute_control",
                        instance_name=VM_CONTROL, zone=ZONE)
        assert r1.confirmed is False
        assert r2.confirmed is False
        assert r3.confirmed is False
