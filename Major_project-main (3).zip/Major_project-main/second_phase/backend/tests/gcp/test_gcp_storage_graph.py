"""
Tests for GCP Storage discovery → graph pipeline.

Covers (per task requirements):
  1. A discovered bucket reaches the graph builder.
  2. Target bucket produces exactly one correctly typed node with consistent ID.
  3. Discovery failures are reported clearly rather than silently becoming empty lists.
  4. Resources / relationships required by the five validation tests are represented
     when corresponding fixture evidence exists.
  5. Missing evidence does not produce fabricated edges.
  6. Both GCP graph-building paths produce compatible bucket schemas.
  7. Regression: AWS graph tests and existing GCP graph tests still pass.

Validation test ↔ required graph resource matrix
─────────────────────────────────────────────────
  gcs_write           → StorageBucket node with name matching bucket_name
  gcs_read            → StorageBucket node with name matching bucket_name
  iam_sa_impersonation→ ServiceAccount node for service_account_email
  compute_access      → project_id present (no specific node; uses API directly)
  compute_control     → ComputeInstance node with name + zone
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch, mock_open

import pytest

_BACKEND = Path(__file__).parent.parent.parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from gcp_pentest.models import GCPBucketIAMBinding, GCPStorageBucket, GCPServiceAccount
from gcp_pentest.graph.builder import GCPGraphBuilder
from api.services.graph_service import _build_gcp_graph_from_report


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

TARGET_BUCKET = "melric-gcp-pentest-lab-508412"
PROJECT_ID = "cloud-pentest-lab-508412"
SA_EMAIL = "lab-test-sa@cloud-pentest-lab-508412.iam.gserviceaccount.com"
SCANNER_EMAIL = "pentest-scanner@cloud-pentest-lab-508412.iam.gserviceaccount.com"
COMPUTE_SA_EMAIL = "793182887921-compute@developer.gserviceaccount.com"


def _make_bucket(
    name: str = TARGET_BUCKET,
    location: str = "US",
    is_public_read: bool = False,
    is_public_write: bool = False,
    iam_bindings: list[GCPBucketIAMBinding] | None = None,
) -> GCPStorageBucket:
    return GCPStorageBucket(
        name=name,
        location=location,
        is_public_read=is_public_read,
        is_public_write=is_public_write,
        versioning_enabled=False,
        iam_bindings=iam_bindings or [],
    )


def _make_sa(email: str = SA_EMAIL) -> GCPServiceAccount:
    return GCPServiceAccount(
        name=f"projects/{PROJECT_ID}/serviceAccounts/{email}",
        email=email,
        display_name=email.split("@")[0],
        project_id=PROJECT_ID,
        disabled=False,
    )


def _report_with_bucket(
    name: str = TARGET_BUCKET,
    iam_bindings: list[dict] | None = None,
    service_accounts: list[dict] | None = None,
) -> dict[str, Any]:
    return {
        "provider": "gcp",
        "project_id": PROJECT_ID,
        "resources": {
            "service_accounts": service_accounts or [
                {"email": SA_EMAIL, "display_name": "lab-test-sa", "disabled": False},
            ],
            "storage_buckets": [
                {
                    "name": name,
                    "location": "US",
                    "is_public_read": False,
                    "is_public_write": False,
                    "versioning_enabled": False,
                    "uniform_bucket_level_access": False,
                    "public_access_prevention": "inherited",
                    "iam_bindings": iam_bindings or [],
                }
            ],
            "compute_instances": [],
        },
        "findings": {"storage": [], "compute": []},
        "privilege_escalation_paths": [],
    }


# ---------------------------------------------------------------------------
# 1. Discovered bucket reaches the graph builder
# ---------------------------------------------------------------------------

class TestBucketReachesGraphBuilder:
    """Verifies that a GCPStorageBucket object passed to GCPGraphBuilder.build()
    produces a corresponding node in the AssessmentGraph."""

    def test_bucket_produces_node_in_assessment_graph(self):
        builder = GCPGraphBuilder()
        bucket = _make_bucket()
        graph = builder.build(PROJECT_ID, [], [], [bucket], [])
        node_ids = [n.node_id for n in graph.nodes]
        assert f"//storage.googleapis.com/{TARGET_BUCKET}" in node_ids

    def test_bucket_node_type_is_storage_bucket(self):
        builder = GCPGraphBuilder()
        bucket = _make_bucket()
        graph = builder.build(PROJECT_ID, [], [], [bucket], [])
        node = next(
            n for n in graph.nodes
            if n.node_id == f"//storage.googleapis.com/{TARGET_BUCKET}"
        )
        assert node.node_type == "StorageBucket"

    def test_multiple_buckets_all_reach_graph(self):
        builder = GCPGraphBuilder()
        b1 = _make_bucket("bucket-alpha")
        b2 = _make_bucket("bucket-beta")
        graph = builder.build(PROJECT_ID, [], [], [b1, b2], [])
        ids = [n.node_id for n in graph.nodes]
        assert "//storage.googleapis.com/bucket-alpha" in ids
        assert "//storage.googleapis.com/bucket-beta" in ids


# ---------------------------------------------------------------------------
# 2. Target bucket → exactly one correctly typed node with consistent ID
# ---------------------------------------------------------------------------

class TestTargetBucketNode:
    """Both graph-building paths must produce exactly one node for the target bucket,
    with the canonical node ID and type."""

    def test_graph_builder_produces_exactly_one_bucket_node(self):
        builder = GCPGraphBuilder()
        bucket = _make_bucket()
        graph = builder.build(PROJECT_ID, [], [], [bucket], [])
        bucket_nodes = [
            n for n in graph.nodes
            if n.node_id == f"//storage.googleapis.com/{TARGET_BUCKET}"
        ]
        assert len(bucket_nodes) == 1

    def test_graph_service_produces_exactly_one_bucket_node(self):
        report = _report_with_bucket()
        g = _build_gcp_graph_from_report(report)
        node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        # Count occurrences (networkx nodes are unique by ID, so this verifies no duplicate)
        assert node_id in g.nodes
        assert g.nodes[node_id]["node_type"] == "StorageBucket"

    def test_node_id_convention_matches_between_both_paths(self):
        """GCPGraphBuilder and graph_service must use the same node ID for the same bucket."""
        builder = GCPGraphBuilder()
        bucket = _make_bucket()
        ag = builder.build(PROJECT_ID, [], [], [bucket], [])
        builder_ids = {n.node_id for n in ag.nodes}

        report = _report_with_bucket()
        g = _build_gcp_graph_from_report(report)
        service_ids = set(g.nodes)

        expected = f"//storage.googleapis.com/{TARGET_BUCKET}"
        assert expected in builder_ids, "GCPGraphBuilder must use canonical bucket node ID"
        assert expected in service_ids, "graph_service must use canonical bucket node ID"

    def test_bucket_display_name_is_bucket_name(self):
        builder = GCPGraphBuilder()
        bucket = _make_bucket()
        graph = builder.build(PROJECT_ID, [], [], [bucket], [])
        node = next(
            n for n in graph.nodes
            if n.node_id == f"//storage.googleapis.com/{TARGET_BUCKET}"
        )
        assert node.display_name == TARGET_BUCKET

    def test_bucket_node_reachable_from_report_dict(self):
        """A report dict containing the target bucket produces the expected graph node.
        Uses a fixture report rather than the live last_report.json, so this test
        is not coupled to what the most-recent scan found."""
        report = _report_with_bucket(TARGET_BUCKET)
        g = _build_gcp_graph_from_report(report)
        node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        assert node_id in g.nodes
        assert g.nodes[node_id]["node_type"] == "StorageBucket"


# ---------------------------------------------------------------------------
# 3. Discovery failures reported clearly, not silently empty
# ---------------------------------------------------------------------------

class TestStorageDiscoveryErrors:
    """GCPStorageAnalyser.enumerate_buckets_with_errors() must distinguish
    an API failure from a genuinely empty project."""

    def test_success_returns_empty_errors(self):
        from gcp_pentest.storage.analyser import GCPStorageAnalyser
        analyser = GCPStorageAnalyser.__new__(GCPStorageAnalyser)
        analyser._project_id = PROJECT_ID
        analyser._credentials = None

        mock_client = MagicMock()
        mock_client.list_buckets.return_value = []
        analyser._client = mock_client

        buckets, errors = analyser.enumerate_buckets_with_errors()
        assert buckets == []
        assert errors == [], "No errors expected when list_buckets succeeds"

    def test_api_failure_returns_non_empty_errors(self):
        from gcp_pentest.storage.analyser import GCPStorageAnalyser
        analyser = GCPStorageAnalyser.__new__(GCPStorageAnalyser)
        analyser._project_id = PROJECT_ID
        analyser._credentials = None

        mock_client = MagicMock()
        mock_client.list_buckets.side_effect = PermissionError("storage.buckets.list denied")
        analyser._client = mock_client

        buckets, errors = analyser.enumerate_buckets_with_errors()
        assert buckets == []
        assert len(errors) == 1
        assert "list_buckets failed" in errors[0]

    def test_partial_failure_includes_error_and_successful_buckets(self):
        """If one bucket fails to analyse, others are still returned."""
        from gcp_pentest.storage.analyser import GCPStorageAnalyser
        analyser = GCPStorageAnalyser.__new__(GCPStorageAnalyser)
        analyser._project_id = PROJECT_ID
        analyser._credentials = None

        good_raw = MagicMock()
        good_raw.name = "good-bucket"
        bad_raw = MagicMock()
        bad_raw.name = "bad-bucket"

        mock_client = MagicMock()
        mock_client.list_buckets.return_value = [good_raw, bad_raw]

        def build_bucket_side_effect(client, raw):
            if raw.name == "bad-bucket":
                raise RuntimeError("Reload failed")
            return _make_bucket(name=raw.name)

        analyser._build_bucket = build_bucket_side_effect
        analyser._client = mock_client

        buckets, errors = analyser.enumerate_buckets_with_errors()
        assert len(buckets) == 1
        assert buckets[0].name == "good-bucket"
        assert len(errors) == 1
        assert "bad-bucket" in errors[0]

    def test_enumerate_buckets_backwards_compatible(self):
        """enumerate_buckets() still returns a plain list (no errors)."""
        from gcp_pentest.storage.analyser import GCPStorageAnalyser
        analyser = GCPStorageAnalyser.__new__(GCPStorageAnalyser)
        analyser._project_id = PROJECT_ID
        analyser._credentials = None

        mock_client = MagicMock()
        mock_client.list_buckets.return_value = []
        analyser._client = mock_client

        result = analyser.enumerate_buckets()
        assert isinstance(result, list)
        assert result == []


# ---------------------------------------------------------------------------
# 4. Validation test prerequisites in the graph
# ---------------------------------------------------------------------------

class TestValidationTestPrerequisites:
    """
    Coverage matrix: verify each of the five validation tests has its required
    graph nodes when fixture evidence exists.

    Technique      Required node        Fixture provides
    ─────────────────────────────────────────────────────
    gcs_write      StorageBucket        report with bucket
    gcs_read       StorageBucket        report with bucket
    iam_sa_impers  ServiceAccount       report with SA
    compute_access project_id only      (no node needed by API)
    compute_control ComputeInstance     report with instance
    """

    def test_gcs_write_bucket_node_present(self):
        """gcs_write requires StorageBucket node for the target bucket_name."""
        report = _report_with_bucket(TARGET_BUCKET)
        g = _build_gcp_graph_from_report(report)
        bucket_node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        assert bucket_node_id in g.nodes
        assert g.nodes[bucket_node_id]["node_type"] == "StorageBucket"

    def test_gcs_read_bucket_node_present(self):
        """gcs_read requires StorageBucket node for the target bucket_name."""
        report = _report_with_bucket(TARGET_BUCKET)
        g = _build_gcp_graph_from_report(report)
        bucket_node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        assert bucket_node_id in g.nodes

    def test_iam_sa_impersonation_sa_node_present(self):
        """iam_sa_impersonation requires ServiceAccount node for service_account_email."""
        report = _report_with_bucket(
            service_accounts=[{"email": SA_EMAIL, "display_name": "lab-test-sa", "disabled": False}]
        )
        g = _build_gcp_graph_from_report(report)
        sa_node_id = f"serviceAccount:{SA_EMAIL}"
        assert sa_node_id in g.nodes
        assert g.nodes[sa_node_id]["node_type"] == "ServiceAccount"

    def test_compute_access_does_not_require_instance_node(self):
        """compute_access uses compute.instances.list on project — no instance node needed."""
        # The validator only needs project_id (not a graph node). Verify graph is
        # still valid (has nodes) without requiring a ComputeInstance node.
        report = _report_with_bucket()
        g = _build_gcp_graph_from_report(report)
        assert g.number_of_nodes() >= 1
        # compute_access uses project_id from validator state, not the graph
        # — nothing to assert on the graph for this technique.

    def test_compute_control_instance_node_present(self):
        """compute_control requires ComputeInstance node for instance_name + zone."""
        report = {
            "provider": "gcp",
            "project_id": PROJECT_ID,
            "resources": {
                "service_accounts": [],
                "storage_buckets": [],
                "compute_instances": [
                    {"name": "pentest-vm", "zone": "us-central1-a", "status": "RUNNING",
                     "has_public_ip": False}
                ],
            },
            "findings": {"storage": [], "compute": []},
            "privilege_escalation_paths": [],
        }
        g = _build_gcp_graph_from_report(report)
        assert "pentest-vm" in g.nodes
        assert g.nodes["pentest-vm"]["node_type"] == "ComputeInstance"

    def test_all_five_test_resource_nodes_in_single_graph(self):
        """When all resources are present the graph contains all required node types."""
        report = {
            "provider": "gcp",
            "project_id": PROJECT_ID,
            "resources": {
                "service_accounts": [
                    {"email": SA_EMAIL, "display_name": "lab-test-sa", "disabled": False}
                ],
                "storage_buckets": [
                    {
                        "name": TARGET_BUCKET,
                        "location": "US",
                        "is_public_read": False,
                        "is_public_write": False,
                        "versioning_enabled": False,
                        "uniform_bucket_level_access": False,
                        "public_access_prevention": "inherited",
                        "iam_bindings": [],
                    }
                ],
                "compute_instances": [
                    {"name": "pentest-vm", "zone": "us-central1-a",
                     "status": "RUNNING", "has_public_ip": False}
                ],
            },
            "findings": {"storage": [], "compute": []},
            "privilege_escalation_paths": [],
        }
        g = _build_gcp_graph_from_report(report)
        node_types = {attrs["node_type"] for _, attrs in g.nodes(data=True)}
        assert "StorageBucket" in node_types, "gcs_write + gcs_read prerequisite"
        assert "ServiceAccount" in node_types, "iam_sa_impersonation prerequisite"
        assert "ComputeInstance" in node_types, "compute_control prerequisite"


# ---------------------------------------------------------------------------
# 5. Missing evidence does not produce fabricated edges
# ---------------------------------------------------------------------------

class TestNoFabricatedEdges:
    """Without IAM binding evidence, no SA→bucket edges should be created."""

    def test_bucket_with_no_iam_bindings_has_no_edges(self):
        report = _report_with_bucket(iam_bindings=[])
        g = _build_gcp_graph_from_report(report)
        bucket_node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        # No edges touching the bucket
        assert g.in_degree(bucket_node_id) == 0
        assert g.out_degree(bucket_node_id) == 0

    def test_bucket_with_non_sa_binding_produces_no_edge(self):
        """A binding for user: is not emitted as an edge (only SA and public members)."""
        report = _report_with_bucket(
            iam_bindings=[{"role": "roles/storage.objectViewer",
                           "members": ["user:someone@example.com"]}]
        )
        g = _build_gcp_graph_from_report(report)
        bucket_node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        assert g.in_degree(bucket_node_id) == 0

    def test_bucket_with_sa_binding_produces_edge(self):
        """A binding for a known serviceAccount: IS emitted as a CAN_READ_BUCKET edge."""
        report = _report_with_bucket(
            iam_bindings=[
                {"role": "roles/storage.objectViewer",
                 "members": [f"serviceAccount:{SA_EMAIL}"]}
            ],
            service_accounts=[
                {"email": SA_EMAIL, "display_name": "lab-test-sa", "disabled": False}
            ],
        )
        g = _build_gcp_graph_from_report(report)
        bucket_node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        sa_node_id = f"serviceAccount:{SA_EMAIL}"
        assert g.has_edge(sa_node_id, bucket_node_id)
        assert g[sa_node_id][bucket_node_id]["relation"] == "CAN_READ_BUCKET"

    def test_bucket_with_write_binding_produces_can_write_edge(self):
        report = _report_with_bucket(
            iam_bindings=[
                {"role": "roles/storage.objectCreator",
                 "members": [f"serviceAccount:{SA_EMAIL}"]}
            ],
            service_accounts=[
                {"email": SA_EMAIL, "display_name": "lab-test-sa", "disabled": False}
            ],
        )
        g = _build_gcp_graph_from_report(report)
        bucket_node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        sa_node_id = f"serviceAccount:{SA_EMAIL}"
        assert g.has_edge(sa_node_id, bucket_node_id)
        assert g[sa_node_id][bucket_node_id]["relation"] == "CAN_WRITE_BUCKET"

    def test_privesc_path_without_evidence_produces_no_extra_nodes(self):
        """A privesc path with empty evidence should still create edges but not hallucinate targets."""
        report = {
            "provider": "gcp",
            "project_id": PROJECT_ID,
            "resources": {
                "service_accounts": [
                    {"email": SA_EMAIL, "display_name": "lab-test-sa", "disabled": False}
                ],
                "storage_buckets": [],
                "compute_instances": [],
            },
            "findings": {"storage": [], "compute": []},
            "privilege_escalation_paths": [
                {
                    "source_member": f"serviceAccount:{SA_EMAIL}",
                    "technique": "ProjectOwnerOrEditor",
                    "description": "desc",
                    "chain": [],
                    "required_permissions": [],
                    "severity": "CRITICAL",
                    "evidence": [],          # empty evidence
                    "confirmed": True,
                }
            ],
        }
        g = _build_gcp_graph_from_report(report)
        tgt = f"//cloudresourcemanager.googleapis.com/projects/{PROJECT_ID}:admin"
        src = f"serviceAccount:{SA_EMAIL}"
        # Edge still created (we have a path), but actions list is empty (no evidence roles)
        assert g.has_edge(src, tgt)
        assert g[src][tgt]["actions"] == []  # no fabricated actions

    def test_graph_builder_no_edges_without_bindings(self):
        """GCPGraphBuilder produces no SA→bucket edges when no bindings are provided."""
        builder = GCPGraphBuilder()
        sa = _make_sa()
        bucket = _make_bucket()
        graph = builder.build(PROJECT_ID, [sa], [], [bucket], [])
        nx_g = graph.to_networkx()
        bucket_node_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        in_edges = list(nx_g.in_edges(bucket_node_id))
        assert in_edges == []


# ---------------------------------------------------------------------------
# 6. Both GCP graph-building paths produce compatible schemas
# ---------------------------------------------------------------------------

class TestBothPathsCompatible:
    """GCPGraphBuilder (used at scan time) and _build_gcp_graph_from_report
    (used by the API) must agree on node types, node IDs, and edge types."""

    def test_bucket_node_type_consistent(self):
        builder = GCPGraphBuilder()
        bucket = _make_bucket()
        ag = builder.build(PROJECT_ID, [], [], [bucket], [])

        report = _report_with_bucket()
        g = _build_gcp_graph_from_report(report)

        # Both produce "StorageBucket"
        builder_type = next(
            n.node_type for n in ag.nodes
            if n.node_id == f"//storage.googleapis.com/{TARGET_BUCKET}"
        )
        service_type = g.nodes[f"//storage.googleapis.com/{TARGET_BUCKET}"]["node_type"]
        assert builder_type == service_type == "StorageBucket"

    def test_sa_node_type_consistent(self):
        builder = GCPGraphBuilder()
        sa = _make_sa()
        ag = builder.build(PROJECT_ID, [sa], [], [], [])

        report = _report_with_bucket(service_accounts=[
            {"email": SA_EMAIL, "display_name": "lab-test-sa", "disabled": False}
        ])
        g = _build_gcp_graph_from_report(report)

        sa_id = f"serviceAccount:{SA_EMAIL}"
        builder_type = next(n.node_type for n in ag.nodes if n.node_id == sa_id)
        service_type = g.nodes[sa_id]["node_type"]
        assert builder_type == service_type == "ServiceAccount"

    def test_capability_node_display_name_consistent(self):
        """Both paths use 'ProjectPrivileged' — not 'ProjectAdmin'."""
        from gcp_pentest.models import GCPPrivEscPath, Severity
        builder = GCPGraphBuilder()
        path = GCPPrivEscPath(
            source_member=f"serviceAccount:{SA_EMAIL}",
            technique="ProjectOwnerOrEditor",
            description="Has roles/editor",
            chain=[],
            required_permissions=[],
            severity=Severity.CRITICAL,
            evidence=[{"type": "iam_binding", "role": "roles/editor"}],
            confirmed=True,
        )
        ag = builder.build(PROJECT_ID, [], [], [], [], privesc_paths=[path])
        cap_id = f"//cloudresourcemanager.googleapis.com/projects/{PROJECT_ID}:admin"
        builder_display = next(n.display_name for n in ag.nodes if n.node_id == cap_id)
        assert builder_display == "ProjectPrivileged"

        report = {
            "provider": "gcp",
            "project_id": PROJECT_ID,
            "resources": {"service_accounts": [], "storage_buckets": [], "compute_instances": []},
            "findings": {"storage": [], "compute": []},
            "privilege_escalation_paths": [
                {
                    "source_member": f"serviceAccount:{SA_EMAIL}",
                    "technique": "ProjectOwnerOrEditor",
                    "description": "Has roles/editor",
                    "chain": [],
                    "required_permissions": [],
                    "severity": "CRITICAL",
                    "evidence": [{"type": "iam_binding", "role": "roles/editor"}],
                    "confirmed": True,
                }
            ],
        }
        g = _build_gcp_graph_from_report(report)
        service_display = g.nodes[cap_id]["display_name"]
        assert service_display == "ProjectPrivileged"

    def test_bucket_edge_type_consistent(self):
        """Both paths use CAN_READ_BUCKET for objectViewer role."""
        # GCPGraphBuilder path
        binding = GCPBucketIAMBinding(
            role="roles/storage.objectViewer",
            members=[f"serviceAccount:{SA_EMAIL}"],
        )
        builder = GCPGraphBuilder()
        sa = _make_sa()
        bucket = _make_bucket(iam_bindings=[binding])
        ag = builder.build(PROJECT_ID, [sa], [], [bucket], [])
        sa_id = f"serviceAccount:{SA_EMAIL}"
        bucket_id = f"//storage.googleapis.com/{TARGET_BUCKET}"
        nx_ag = ag.to_networkx()
        assert nx_ag.has_edge(sa_id, bucket_id)
        builder_relation = nx_ag[sa_id][bucket_id]["relation"]

        # graph_service path
        report = _report_with_bucket(
            iam_bindings=[
                {"role": "roles/storage.objectViewer", "members": [f"serviceAccount:{SA_EMAIL}"]}
            ],
            service_accounts=[
                {"email": SA_EMAIL, "display_name": "lab-test-sa", "disabled": False}
            ],
        )
        g = _build_gcp_graph_from_report(report)
        assert g.has_edge(sa_id, bucket_id)
        service_relation = g[sa_id][bucket_id]["relation"]

        assert builder_relation == service_relation == "CAN_READ_BUCKET"



# ---------------------------------------------------------------------------
# GCPProvider.discover_resources() — uses enumerate_buckets_with_errors()
# ---------------------------------------------------------------------------

class TestGCPProviderDiscoverResources:
    """
    Verifies that GCPProvider.discover_resources() uses enumerate_buckets_with_errors()
    so that Storage API errors are surfaced (not silently swallowed) and discovered
    buckets flow into the resources dict returned to run_full_scan().
    """

    def _make_provider(self):
        from providers.gcp_provider import GCPProvider
        provider = GCPProvider.__new__(GCPProvider)
        provider._project_id = PROJECT_ID
        provider._credentials = None
        provider._authenticated = True
        return provider

    def test_discovered_bucket_appears_in_resources(self):
        """A bucket returned by enumerate_buckets_with_errors() appears in resources."""
        from unittest.mock import patch, MagicMock
        from gcp_pentest.storage.analyser import GCPStorageAnalyser

        test_bucket = _make_bucket()
        provider = self._make_provider()

        with patch.object(GCPStorageAnalyser, "enumerate_buckets_with_errors",
                          return_value=([test_bucket], [])) as mock_enum, \
             patch("gcp_pentest.iam.enumerator.GCPIAMEnumerator") as mock_iam, \
             patch("gcp_pentest.iam.privesc.GCPPrivEscDetector") as mock_pe, \
             patch("gcp_pentest.compute.analyser.GCPComputeAnalyser") as mock_comp:
            mock_iam.return_value.enumerate_all.return_value = ([], [], [])
            mock_pe.return_value.detect_all.return_value = []
            mock_comp.return_value.enumerate_instances.return_value = []
            mock_comp.return_value.enumerate_firewall_rules.return_value = []
            mock_comp.return_value.check_findings.return_value = []

            resources = provider.discover_resources()

        assert mock_enum.called, (
            "discover_resources() must call enumerate_buckets_with_errors(), not enumerate_buckets()"
        )
        assert len(resources["resources"]["storage_buckets"]) == 1
        assert resources["resources"]["storage_buckets"][0].name == TARGET_BUCKET

    def test_storage_api_error_surfaced_in_scan_errors(self):
        """When enumerate_buckets_with_errors() returns errors, they appear in scan_errors."""
        from unittest.mock import patch
        from gcp_pentest.storage.analyser import GCPStorageAnalyser

        error_msg = "list_buckets failed: 403 storage.buckets.list denied"
        provider = self._make_provider()

        with patch.object(GCPStorageAnalyser, "enumerate_buckets_with_errors",
                          return_value=([], [error_msg])), \
             patch("gcp_pentest.iam.enumerator.GCPIAMEnumerator") as mock_iam, \
             patch("gcp_pentest.iam.privesc.GCPPrivEscDetector") as mock_pe, \
             patch("gcp_pentest.compute.analyser.GCPComputeAnalyser") as mock_comp:
            mock_iam.return_value.enumerate_all.return_value = ([], [], [])
            mock_pe.return_value.detect_all.return_value = []
            mock_comp.return_value.enumerate_instances.return_value = []
            mock_comp.return_value.enumerate_firewall_rules.return_value = []
            mock_comp.return_value.check_findings.return_value = []

            resources = provider.discover_resources()

        assert resources["scan_errors"]["storage"] == [error_msg], (
            "scan_errors.storage must contain the error message when the Storage API fails"
        )
        assert resources["resources"]["storage_buckets"] == []

    def test_empty_bucket_list_with_no_errors_is_genuine_empty(self):
        """Empty bucket list + empty errors = project has no buckets (not a permission failure)."""
        from unittest.mock import patch
        from gcp_pentest.storage.analyser import GCPStorageAnalyser

        provider = self._make_provider()

        with patch.object(GCPStorageAnalyser, "enumerate_buckets_with_errors",
                          return_value=([], [])), \
             patch("gcp_pentest.iam.enumerator.GCPIAMEnumerator") as mock_iam, \
             patch("gcp_pentest.iam.privesc.GCPPrivEscDetector") as mock_pe, \
             patch("gcp_pentest.compute.analyser.GCPComputeAnalyser") as mock_comp:
            mock_iam.return_value.enumerate_all.return_value = ([], [], [])
            mock_pe.return_value.detect_all.return_value = []
            mock_comp.return_value.enumerate_instances.return_value = []
            mock_comp.return_value.enumerate_firewall_rules.return_value = []
            mock_comp.return_value.check_findings.return_value = []

            resources = provider.discover_resources()

        assert resources["resources"]["storage_buckets"] == []
        assert resources["scan_errors"]["storage"] == []

    def test_multiple_buckets_all_reach_resources(self):
        """All buckets returned by enumerate_buckets_with_errors() are in resources."""
        from unittest.mock import patch
        from gcp_pentest.storage.analyser import GCPStorageAnalyser

        b1 = _make_bucket("bucket-one")
        b2 = _make_bucket("bucket-two")
        provider = self._make_provider()

        with patch.object(GCPStorageAnalyser, "enumerate_buckets_with_errors",
                          return_value=([b1, b2], [])), \
             patch("gcp_pentest.iam.enumerator.GCPIAMEnumerator") as mock_iam, \
             patch("gcp_pentest.iam.privesc.GCPPrivEscDetector") as mock_pe, \
             patch("gcp_pentest.compute.analyser.GCPComputeAnalyser") as mock_comp:
            mock_iam.return_value.enumerate_all.return_value = ([], [], [])
            mock_pe.return_value.detect_all.return_value = []
            mock_comp.return_value.enumerate_instances.return_value = []
            mock_comp.return_value.enumerate_firewall_rules.return_value = []
            mock_comp.return_value.check_findings.return_value = []

            resources = provider.discover_resources()

        names = [b.name for b in resources["resources"]["storage_buckets"]]
        assert "bucket-one" in names
        assert "bucket-two" in names


# ---------------------------------------------------------------------------
# scan_errors field in report — distinguishing empty vs failed
# ---------------------------------------------------------------------------

class TestScanErrorsField:
    """The scan_errors.storage field in the report distinguishes a failed
    enumeration from a genuinely empty project.

    These tests use self-contained fixture dicts — they do not read the live
    last_report.json, which changes with every fresh scan run.
    """

    def test_run_full_scan_report_includes_scan_errors_key(self):
        """GCPProvider.run_full_scan() serializes scan_errors so callers can
        distinguish a permission failure from a genuinely empty project.
        This is verified by inspecting the report dict produced by run_full_scan,
        mocked to avoid live API calls."""
        from unittest.mock import MagicMock, patch
        from providers.gcp_provider import GCPProvider

        provider = GCPProvider.__new__(GCPProvider)
        provider._project_id = PROJECT_ID
        provider._credentials = None
        provider._authenticated = True

        mock_resources = {
            "provider": "gcp",
            "project_id": PROJECT_ID,
            "resources": {
                "service_accounts": [],
                "iam_roles": [],
                "iam_bindings": [],
                "storage_buckets": [],
                "compute_instances": [],
                "firewall_rules": [],
            },
            "findings": {"storage": [], "compute": []},
            "privesc_paths": [],
            "scan_errors": {"storage": []},
        }

        with patch.object(provider, "authenticate", return_value=True), \
             patch.object(provider, "discover_resources", return_value=mock_resources), \
             patch.object(provider, "get_attack_graph") as mock_graph:
            from aws_pentest.models.graph_models import AssessmentGraph
            mock_graph.return_value = AssessmentGraph()
            report = provider.run_full_scan(project_id=PROJECT_ID)

        assert "scan_errors" in report, (
            "run_full_scan report must include scan_errors so callers can detect partial failures"
        )
        assert "storage" in report["scan_errors"]

    def test_scan_errors_non_empty_when_storage_api_fails(self):
        """If the Storage API raises, scan_errors.storage is non-empty in the report."""
        from providers.gcp_provider import GCPProvider

        provider = GCPProvider.__new__(GCPProvider)
        provider._project_id = PROJECT_ID
        provider._credentials = None
        provider._authenticated = True

        mock_resources = {
            "provider": "gcp",
            "project_id": PROJECT_ID,
            "resources": {
                "service_accounts": [],
                "iam_roles": [],
                "iam_bindings": [],
                "storage_buckets": [],
                "compute_instances": [],
                "firewall_rules": [],
            },
            "findings": {"storage": [], "compute": []},
            "privesc_paths": [],
            "scan_errors": {"storage": ["list_buckets failed: 403 storage.buckets.list denied"]},
        }

        with patch.object(provider, "authenticate", return_value=True), \
             patch.object(provider, "discover_resources", return_value=mock_resources), \
             patch.object(provider, "get_attack_graph") as mock_graph:
            from aws_pentest.models.graph_models import AssessmentGraph
            mock_graph.return_value = AssessmentGraph()
            report = provider.run_full_scan(project_id=PROJECT_ID)

        assert report["scan_errors"]["storage"] != [], (
            "scan_errors.storage must be non-empty when the Storage API fails"
        )

    def test_bucket_serialisation_includes_iam_bindings_key(self):
        """Buckets produced by GCPProvider.run_full_scan() include the iam_bindings field."""
        from providers.gcp_provider import GCPProvider
        from gcp_pentest.models import GCPStorageBucket

        provider = GCPProvider.__new__(GCPProvider)
        provider._project_id = PROJECT_ID
        provider._credentials = None
        provider._authenticated = True

        test_bucket = GCPStorageBucket(
            name=TARGET_BUCKET,
            location="US",
            is_public_read=False,
            is_public_write=False,
            versioning_enabled=False,
            iam_bindings=[],
        )
        mock_resources = {
            "provider": "gcp",
            "project_id": PROJECT_ID,
            "resources": {
                "service_accounts": [],
                "iam_roles": [],
                "iam_bindings": [],
                "storage_buckets": [test_bucket],
                "compute_instances": [],
                "firewall_rules": [],
            },
            "findings": {"storage": [], "compute": []},
            "privesc_paths": [],
            "scan_errors": {"storage": []},
        }

        with patch.object(provider, "authenticate", return_value=True), \
             patch.object(provider, "discover_resources", return_value=mock_resources), \
             patch.object(provider, "get_attack_graph") as mock_graph:
            from aws_pentest.models.graph_models import AssessmentGraph
            mock_graph.return_value = AssessmentGraph()
            report = provider.run_full_scan(project_id=PROJECT_ID)

        buckets = report["resources"]["storage_buckets"]
        assert len(buckets) == 1
        assert buckets[0]["name"] == TARGET_BUCKET
        assert "iam_bindings" in buckets[0], "Bucket serialisation must include iam_bindings"

    def test_bucket_serialisation_full_fields(self):
        """GCPProvider.run_full_scan() serializes all required bucket fields."""
        from providers.gcp_provider import GCPProvider
        from gcp_pentest.models import GCPStorageBucket, GCPBucketIAMBinding

        provider = GCPProvider.__new__(GCPProvider)
        provider._project_id = PROJECT_ID
        provider._credentials = None
        provider._authenticated = True

        test_bucket = GCPStorageBucket(
            name=TARGET_BUCKET,
            location="US-EAST1",
            is_public_read=False,
            is_public_write=False,
            versioning_enabled=True,
            uniform_bucket_level_access=True,
            public_access_prevention="enforced",
            iam_bindings=[
                GCPBucketIAMBinding(
                    role="roles/storage.objectViewer",
                    members=[f"serviceAccount:{SA_EMAIL}"],
                )
            ],
        )
        mock_resources = {
            "provider": "gcp",
            "project_id": PROJECT_ID,
            "resources": {
                "service_accounts": [],
                "iam_roles": [],
                "iam_bindings": [],
                "storage_buckets": [test_bucket],
                "compute_instances": [],
                "firewall_rules": [],
            },
            "findings": {"storage": [], "compute": []},
            "privesc_paths": [],
            "scan_errors": {"storage": []},
        }

        with patch.object(provider, "authenticate", return_value=True), \
             patch.object(provider, "discover_resources", return_value=mock_resources), \
             patch.object(provider, "get_attack_graph") as mock_graph:
            from aws_pentest.models.graph_models import AssessmentGraph
            mock_graph.return_value = AssessmentGraph()
            report = provider.run_full_scan(project_id=PROJECT_ID)

        b = report["resources"]["storage_buckets"][0]
        assert b["name"] == TARGET_BUCKET
        assert b["location"] == "US-EAST1"
        assert b["versioning_enabled"] is True
        assert b["uniform_bucket_level_access"] is True
        assert b["public_access_prevention"] == "enforced"
        assert len(b["iam_bindings"]) == 1
        assert b["iam_bindings"][0]["role"] == "roles/storage.objectViewer"
