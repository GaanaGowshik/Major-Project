"""
GCP test suite — pytest conftest.

Provides two fixtures that stub out missing native dependencies so tests run
in environments where Google Cloud SDK and/or AWS SDK packages are not
installed.  Both fixtures use setup/teardown (yield) so they restore
``sys.modules`` to its original state after every test — no stubs leak into
unrelated test files.

Scoping rules
-------------
Both fixtures live in ``tests/gcp/conftest.py``.  pytest auto-use fixtures
in a sub-directory conftest only apply to tests collected from *that*
directory and its children — never to tests in sibling or parent directories
(e.g., ``tests/aws/``).  AWS tests therefore never see these stubs.

google_sdk_stubs  (session-scoped, autouse)
-------------------------------------------
Why needed:
  ``unittest.mock.patch("google.auth.impersonated_credentials.Credentials")``
  resolves the dotted path by *attribute traversal* starting from
  ``sys.modules["google"]``.  If google-auth is not installed, ``google.auth``
  is not a navigable attribute and the patch raises AttributeError.

  The GCP validator also does lazy ``import google.auth.impersonated_credentials``
  inside function bodies, then accesses ``google.auth.impersonated_credentials.Credentials``
  as an attribute chain.  Both paths require the same module objects to be
  reachable both via ``sys.modules`` keys and via attribute traversal.

Fix:
  A session-scoped fixture installs ``_AutoAttrModule`` stubs for every
  ``google.*`` sub-module used by the validator/provider.  It saves the
  original ``sys.modules`` entries (if any) and restores them on teardown,
  so the stubs are never visible outside this pytest session's GCP test
  collection.

  Session scope is intentional: installing and tearing down per-function
  would be unnecessarily expensive and the stubs are stateless.  The
  teardown at session end ensures nothing leaks into a subsequent pytest
  invocation (which starts a new process anyway).

boto3_stubs  (function-scoped, autouse)
---------------------------------------
Why needed:
  ``providers/__init__.py`` eagerly imports ``AWSProvider``, which imports
  boto3 at *module level*.  Several GCP tests do
  ``from providers.gcp_provider import GCPProvider`` inside their method
  bodies; this triggers the package ``__init__`` and crashes with
  ``ModuleNotFoundError: No module named 'boto3'``.

Important: this fixture runs at *test-execution* time, not at collection
  time.  It therefore cannot prevent a collection-time crash caused by a
  module-level ``from providers import ...`` in a test file.  Any test module
  that needs ``providers.*`` symbols must import them lazily (inside a
  fixture or test body) so that those imports only execute after this
  fixture has populated ``sys.modules``.  See ``test_gcp_provider.py`` for
  the pattern.

Fix:
  A function-scoped fixture stubs ``boto3`` and ``botocore.*`` for the
  duration of each GCP test, then restores the originals.  Function scope
  is required here because some AWS tests in a combined run legitimately
  need the *real* boto3/botocore to be absent (their ModuleNotFoundError is
  expected behaviour — the four tests that import ClientError inside the
  test body will still fail with ModuleNotFoundError when run standalone,
  which is the correct reported behaviour for a missing dependency).

  The fixture avoids installing stubs if the real packages are already
  installed in the test environment — in that case providers/__init__.py
  will import successfully on its own.
"""

from __future__ import annotations

import sys
import types
from typing import Iterator
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

class _AutoAttrModule(types.ModuleType):
    """A ``types.ModuleType`` sub-class whose *attribute access* always returns
    a ``MagicMock`` for unknown names.

    Using ``__getattr__`` (not ``__getattribute__``) means explicitly
    ``setattr``-ed attributes are returned as-is — only *missing* attributes
    fall through to the auto-mock path.  This is required for ``patch()`` to
    work: ``patch()`` sets the target attribute via ``setattr``, and subsequent
    reads of that attribute return the mock rather than a new auto-generated
    value.
    """

    def __getattr__(self, name: str):
        mock = MagicMock(name=f"{self.__name__}.{name}")
        object.__setattr__(self, name, mock)
        return mock


def _build_google_stubs() -> dict[str, _AutoAttrModule]:
    """Create a complete set of google.* stub modules wired as an attribute tree.

    Returns a mapping of module-name → stub module.  The caller is responsible
    for inserting them into ``sys.modules`` and removing them on teardown.
    """
    _NAMES = [
        # Parents before children — _install relies on this order.
        "google",
        "google.auth",
        "google.auth.credentials",
        "google.auth.exceptions",
        "google.auth.impersonated_credentials",
        "google.auth.transport",
        "google.auth.transport.requests",
        "google.cloud",
        "google.cloud.storage",
        "google.cloud.compute_v1",
        "google.oauth2",
        "google.oauth2.credentials",
        "google.oauth2.service_account",
    ]

    stubs: dict[str, _AutoAttrModule] = {}

    for name in _NAMES:
        parts = name.split(".")
        mod = _AutoAttrModule(name)
        mod.__package__ = ".".join(parts[:-1]) if len(parts) > 1 else name
        mod.__path__ = []  # marks it as a package
        stubs[name] = mod

        # Wire child onto its parent stub (always overwrite — the parent's
        # __getattr__ may have already cached a plain MagicMock for this
        # child name before we created the real child module, so we must
        # force-replace it to keep attribute-chain traversal consistent with
        # sys.modules lookups).
        if len(parts) > 1:
            parent_name = ".".join(parts[:-1])
            if parent_name in stubs:
                setattr(stubs[parent_name], parts[-1], mod)

    # Seed well-known attributes so patch() can locate and replace them.
    imp = stubs["google.auth.impersonated_credentials"]
    imp.Credentials = MagicMock(name="google.auth.impersonated_credentials.Credentials")

    req = stubs["google.auth.transport.requests"]
    req.Request = MagicMock(name="google.auth.transport.requests.Request")

    compute = stubs["google.cloud.compute_v1"]
    compute.InstancesClient = MagicMock(name="google.cloud.compute_v1.InstancesClient")

    auth = stubs["google.auth"]
    auth.default = MagicMock(
        name="google.auth.default",
        return_value=(MagicMock(name="credentials"), "test-project"),
    )

    # google.auth.exceptions: provide a concrete exception class so that
    # ``from google.auth.exceptions import DefaultCredentialsError`` inside
    # providers/gcp_provider.py does not crash when the real google-auth
    # package is not installed.
    exc_mod = stubs["google.auth.exceptions"]
    exc_mod.DefaultCredentialsError = type(
        "DefaultCredentialsError", (Exception,), {}
    )

    return stubs


def _build_boto3_stubs() -> dict[str, _AutoAttrModule]:
    """Create minimal boto3/botocore stub modules.

    Only needed to satisfy the ``import boto3`` at the top of
    ``providers/aws_provider.py`` when tests import ``GCPProvider`` via the
    providers package ``__init__``.  The stubs are intentionally thin — they
    are never called by GCP tests.

    Returns a mapping of module-name → stub module.
    """
    _NAMES = [
        "boto3",
        "botocore",
        "botocore.exceptions",
        "botocore.session",
        "botocore.config",
    ]
    stubs: dict[str, _AutoAttrModule] = {}
    for name in _NAMES:
        parts = name.split(".")
        mod = _AutoAttrModule(name)
        mod.__package__ = ".".join(parts[:-1]) if len(parts) > 1 else name
        mod.__path__ = []
        stubs[name] = mod
        if len(parts) > 1:
            parent_name = ".".join(parts[:-1])
            if parent_name in stubs:
                setattr(stubs[parent_name], parts[-1], mod)

    # botocore.exceptions: provide concrete exception types so that
    # ``from botocore.exceptions import ClientError`` in production code and
    # isinstance checks don't crash.  The stubs are bare Exception subclasses
    # — they are not intended to replace the real botocore API for AWS tests.
    exc_mod = stubs["botocore.exceptions"]
    exc_mod.ClientError = type("ClientError", (Exception,), {})
    exc_mod.NoCredentialsError = type("NoCredentialsError", (Exception,), {})
    exc_mod.ProfileNotFound = type("ProfileNotFound", (Exception,), {})

    return stubs


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def google_sdk_stubs() -> Iterator[None]:
    """Session-scoped fixture: install google.* stubs for the GCP test session.

    Saves any pre-existing ``sys.modules`` entries for google.* names and
    restores them on teardown so the stubs are never visible to test runs
    outside this session's GCP collection.

    Session scope is intentional: the stubs are stateless, and re-installing
    them per test would be wasteful.
    """
    # Only stub packages that are genuinely absent.  If the real SDK is
    # installed, leave it alone — the tests will use the real package.
    stubs = _build_google_stubs()
    saved: dict[str, object] = {}

    for name, stub in stubs.items():
        saved[name] = sys.modules.get(name)          # None if absent
        if not isinstance(sys.modules.get(name), _AutoAttrModule):
            # Real package absent or a non-stub object: replace with stub.
            sys.modules[name] = stub
        # else: already a stub from a previous fixture cycle — leave it.

    yield

    # Teardown: restore originals.
    for name, original in saved.items():
        if original is None:
            sys.modules.pop(name, None)
        else:
            sys.modules[name] = original  # type: ignore[assignment]


@pytest.fixture(autouse=True)
def boto3_stubs(request) -> Iterator[None]:
    """Function-scoped fixture: stub boto3/botocore for the duration of each
    GCP test, then restore the originals.

    Why function scope (not session):
      Some tests in a combined run (AWS tests in tests/aws/) legitimately
      expect boto3/botocore to be *absent* and will receive
      ModuleNotFoundError for 'botocore'.  Installing boto3 stubs at session
      scope would mask those failures when GCP tests run first.  Function
      scope with teardown ensures the stubs are confined to GCP tests.

    Skip stubbing if the real boto3 is already installed — in that case the
    providers package imports successfully without any help.
    """
    if "boto3" in sys.modules and not isinstance(sys.modules["boto3"], _AutoAttrModule):
        # Real boto3 is installed — nothing to stub.
        yield
        return

    stubs = _build_boto3_stubs()
    saved: dict[str, object] = {}

    for name, stub in stubs.items():
        saved[name] = sys.modules.get(name)
        if sys.modules.get(name) is None:
            sys.modules[name] = stub

    # providers/__init__ may have already been imported and cached.  If
    # aws_provider failed to import previously, its entry in sys.modules may
    # be a partially-constructed module or None.  We leave cached modules
    # alone here — the stubs only need to satisfy *new* import attempts
    # triggered by tests that have not yet imported providers.

    yield

    # Teardown: remove the stubs we inserted.
    for name, original in saved.items():
        if original is None:
            sys.modules.pop(name, None)
        else:
            sys.modules[name] = original  # type: ignore[assignment]
