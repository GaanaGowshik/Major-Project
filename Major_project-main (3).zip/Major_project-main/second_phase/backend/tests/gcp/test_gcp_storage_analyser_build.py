"""
Regression tests for GCPStorageAnalyser._build_bucket().

Root cause confirmed: before the fix (source modified 2026-10-24 19:32),
_build_bucket accessed `raw.logging` (an attribute that does not exist on
google-cloud-storage >= 2.x).  The correct call is `raw.get_logging()`.

The scan at 13:52 ran against the old .pyc (compiled 18:40 from a prior
source version with `raw.logging`).  After the source was fixed at 19:32
Python regenerated the .pyc at 19:52 from the corrected source.

These tests verify that the current source:
  1. Successfully builds a bucket with full metadata.
  2. Handles a bucket without logging config (no exception; logging_enabled=False).
  3. Passes all three reported bucket names through _build_bucket without the
     'Bucket' object has no attribute 'logging' AttributeError.
  4. Does NOT drop a bucket from the result when get_logging() raises
     (logs at DEBUG, returns logging_enabled=False).
  5. Real permission errors from reload() are still raised and appear in
     scan_errors.storage (not silently swallowed).
  6. Real permission errors from get_iam_policy() are caught per-policy,
     not per-bucket (the bucket is still returned).

No live GCP API calls are made — all Bucket SDK objects are MagicMock.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

import sys
from pathlib import Path

_BACKEND = Path(__file__).parent.parent.parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from gcp_pentest.storage.analyser import GCPStorageAnalyser
from gcp_pentest.models import GCPStorageBucket


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# The three exact bucket names that produced the error in production
_REPORTED_BUCKETS = [
    "cloud-pentest-private-melric-2026",
    "melric-gcp-pentest-lab-508412",
    "melric-graph-test-20261024185001",
]


def _make_analyser() -> GCPStorageAnalyser:
    analyser = GCPStorageAnalyser.__new__(GCPStorageAnalyser)
    analyser._project_id = "cloud-pentest-lab-508412"
    analyser._credentials = None
    analyser._client = MagicMock()
    return analyser


def _make_raw_bucket(
    name: str = "test-bucket",
    location: str = "US",
    storage_class: str = "STANDARD",
    versioning_enabled: bool = False,
    get_logging_return: dict | None = None,
    get_logging_raises: Exception | None = None,
    ubla: bool = True,
    pap: str = "enforced",
    default_kms: str | None = None,
    project_number: int = 123456789,
    iam_policy_bindings: list[dict] | None = None,
    iam_policy_raises: Exception | None = None,
) -> MagicMock:
    """Build a MagicMock that mimics the google-cloud-storage Bucket object."""
    raw = MagicMock()
    raw.name = name
    raw.location = location
    raw.storage_class = storage_class
    raw.versioning_enabled = versioning_enabled
    raw.project_number = project_number
    raw.default_kms_key_name = default_kms
    raw.labels = {}

    # get_logging() — the corrected method (replaces the broken .logging attribute)
    if get_logging_raises is not None:
        raw.get_logging.side_effect = get_logging_raises
    else:
        raw.get_logging.return_value = get_logging_return

    # iam_configuration
    raw.iam_configuration.uniform_bucket_level_access_enabled = ubla
    raw.iam_configuration.public_access_prevention = pap

    # get_iam_policy()
    if iam_policy_raises is not None:
        raw.get_iam_policy.side_effect = iam_policy_raises
    else:
        mock_policy = MagicMock()
        mock_policy.bindings = iam_policy_bindings or []
        raw.get_iam_policy.return_value = mock_policy

    return raw


# ---------------------------------------------------------------------------
# 1. Successfully built bucket with full metadata
# ---------------------------------------------------------------------------

class TestBuildBucketFullMetadata:
    """_build_bucket returns a complete GCPStorageBucket when all SDK calls succeed."""

    def test_returns_gcp_storage_bucket_instance(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(
            get_logging_return={"logBucket": "my-log-bucket", "logObjectPrefix": "access_log"},
        )
        bucket = analyser._build_bucket(analyser._client, raw)
        assert isinstance(bucket, GCPStorageBucket)

    def test_bucket_name_preserved(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(name="full-metadata-bucket")
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.name == "full-metadata-bucket"

    def test_logging_enabled_when_log_bucket_present(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(
            get_logging_return={"logBucket": "my-log-bucket", "logObjectPrefix": ""},
        )
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.logging_enabled is True
        assert bucket.logging_bucket == "my-log-bucket"

    def test_versioning_propagated(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(versioning_enabled=True)
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.versioning_enabled is True

    def test_ubla_propagated(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(ubla=True)
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.uniform_bucket_level_access is True

    def test_public_access_prevention_propagated(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(pap="enforced")
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.public_access_prevention == "enforced"

    def test_uses_get_logging_not_logging_attribute(self):
        """Confirm get_logging() was called — verifies the SDK call, not a .logging attribute."""
        analyser = _make_analyser()
        raw = _make_raw_bucket()
        analyser._build_bucket(analyser._client, raw)
        raw.get_logging.assert_called_once()

    def test_logging_attribute_never_accessed(self):
        """
        The .logging attribute must not be accessed — accessing it on a real
        Bucket object raises AttributeError in google-cloud-storage >= 2.x.
        We verify this by ensuring the mock's .logging attribute is NOT
        accessed during _build_bucket().
        """
        analyser = _make_analyser()
        raw = _make_raw_bucket()
        # Delete the .logging attribute from the mock so any access would raise AttributeError
        # (MagicMock auto-creates attributes; we remove it to make it fail like the real SDK)
        del raw.logging
        # Should not raise
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket is not None


# ---------------------------------------------------------------------------
# 2. Bucket without logging config — still returned, logging_enabled=False
# ---------------------------------------------------------------------------

class TestBucketWithoutLogging:
    """A bucket with no logging configured is still included in results."""

    def test_logging_disabled_when_get_logging_returns_none(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(get_logging_return=None)
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.logging_enabled is False
        assert bucket.logging_bucket is None

    def test_logging_disabled_when_get_logging_returns_empty_dict(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(get_logging_return={})
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.logging_enabled is False

    def test_logging_disabled_when_get_logging_returns_no_log_bucket_key(self):
        analyser = _make_analyser()
        raw = _make_raw_bucket(get_logging_return={"logObjectPrefix": ""})
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.logging_enabled is False

    def test_bucket_is_still_returned_without_logging(self):
        """The absence of logging config must not prevent the bucket from being returned."""
        analyser = _make_analyser()
        raw = _make_raw_bucket(name="no-logging-bucket", get_logging_return=None)
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.name == "no-logging-bucket"

    def test_get_logging_exception_does_not_drop_bucket(self):
        """If get_logging() raises (e.g. permission denied), the bucket is still returned
        with logging_enabled=False — the exception is not re-raised."""
        analyser = _make_analyser()
        raw = _make_raw_bucket(
            name="get-logging-error-bucket",
            get_logging_raises=PermissionError("storage.buckets.getIamPolicy denied"),
        )
        # Must not raise
        bucket = analyser._build_bucket(analyser._client, raw)
        assert bucket.name == "get-logging-error-bucket"
        assert bucket.logging_enabled is False


# ---------------------------------------------------------------------------
# 3. The three reported bucket names pass through without AttributeError
# ---------------------------------------------------------------------------

class TestReportedBucketNames:
    """
    Regression: the three buckets that triggered 'Bucket' object has no
    attribute 'logging' must now pass through _build_bucket without any
    AttributeError.

    Before the fix:  raw.logging  → AttributeError → bucket dropped → storage_buckets: []
    After the fix:   raw.get_logging() → returns None/dict → logging_enabled set correctly
    """

    @pytest.mark.parametrize("bucket_name", _REPORTED_BUCKETS)
    def test_reported_bucket_does_not_raise(self, bucket_name: str):
        analyser = _make_analyser()
        raw = _make_raw_bucket(name=bucket_name, get_logging_return=None)
        # Before fix: raises AttributeError('Bucket' object has no attribute 'logging')
        # After fix:  returns a GCPStorageBucket
        bucket = analyser._build_bucket(analyser._client, raw)
        assert isinstance(bucket, GCPStorageBucket)
        assert bucket.name == bucket_name

    @pytest.mark.parametrize("bucket_name", _REPORTED_BUCKETS)
    def test_reported_bucket_name_in_enumeration_result(self, bucket_name: str):
        """End-to-end: reported bucket names appear in enumerate_buckets_with_errors()."""
        analyser = _make_analyser()
        raw = _make_raw_bucket(name=bucket_name, get_logging_return=None)
        analyser._client.list_buckets.return_value = [raw]

        buckets, errors = analyser.enumerate_buckets_with_errors()
        assert errors == [], f"Unexpected errors for bucket {bucket_name}: {errors}"
        assert len(buckets) == 1
        assert buckets[0].name == bucket_name

    def test_all_three_reported_buckets_in_single_scan(self):
        """All three reported buckets are present when enumerated together."""
        analyser = _make_analyser()
        raws = [_make_raw_bucket(name=name, get_logging_return=None) for name in _REPORTED_BUCKETS]
        analyser._client.list_buckets.return_value = raws

        buckets, errors = analyser.enumerate_buckets_with_errors()
        assert errors == []
        result_names = {b.name for b in buckets}
        assert result_names == set(_REPORTED_BUCKETS)


# ---------------------------------------------------------------------------
# 4. Real API/permission failures remain visible in scan_errors.storage
# ---------------------------------------------------------------------------

class TestRealPermissionErrorsAreReported:
    """Genuine API failures are surfaced in errors, not silently swallowed."""

    def test_reload_permission_error_captured_in_errors(self):
        """If raw.reload() raises (permission denied), the bucket is skipped and
        the error message appears in scan_errors — not silently dropped."""
        analyser = _make_analyser()
        raw = MagicMock()
        raw.name = "permission-denied-bucket"
        raw.reload.side_effect = PermissionError("storage.buckets.get denied")
        analyser._client.list_buckets.return_value = [raw]

        buckets, errors = analyser.enumerate_buckets_with_errors()
        assert buckets == []
        assert len(errors) == 1
        assert "permission-denied-bucket" in errors[0]
        assert "storage.buckets.get denied" in errors[0]

    def test_list_buckets_permission_error_captured(self):
        """If list_buckets() raises (project-level permission denied), errors is non-empty."""
        analyser = _make_analyser()
        analyser._client.list_buckets.side_effect = PermissionError(
            "storage.buckets.list denied on project"
        )

        buckets, errors = analyser.enumerate_buckets_with_errors()
        assert buckets == []
        assert len(errors) == 1
        assert "list_buckets failed" in errors[0]

    def test_iam_policy_error_does_not_drop_bucket(self):
        """A permission error on get_iam_policy() is caught at policy-read level,
        not at bucket level — the bucket is still returned (with empty bindings)."""
        analyser = _make_analyser()
        raw = _make_raw_bucket(
            name="iam-error-bucket",
            iam_policy_raises=PermissionError("storage.buckets.getIamPolicy denied"),
        )
        analyser._client.list_buckets.return_value = [raw]

        buckets, errors = analyser.enumerate_buckets_with_errors()
        # Bucket is returned (IAM policy error is caught inside _build_bucket)
        assert len(buckets) == 1
        assert buckets[0].name == "iam-error-bucket"
        assert buckets[0].iam_bindings == []
        # No error in scan_errors — the IAM failure is per-policy (logged at DEBUG)
        assert errors == []

    def test_error_message_format_includes_bucket_name(self):
        """Error messages include the bucket name so operators can identify which bucket failed."""
        analyser = _make_analyser()
        raw = MagicMock()
        raw.name = "melric-gcp-pentest-lab-508412"
        raw.reload.side_effect = RuntimeError("timeout")
        analyser._client.list_buckets.return_value = [raw]

        _, errors = analyser.enumerate_buckets_with_errors()
        assert any("melric-gcp-pentest-lab-508412" in e for e in errors)
