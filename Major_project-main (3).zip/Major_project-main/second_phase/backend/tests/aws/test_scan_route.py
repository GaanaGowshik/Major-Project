"""
Tests for api/routes/scan.py — scan-path graph-file write behaviour.

Scope (P1 verification):
  - AWS scans use _run_scan_legacy, which passes output_graph_json to
    aws_pentest.run.run().  This test verifies that the graph file IS written
    after a successful AWS scan and is NOT overwritten after a failed scan.

No live AWS API calls are made.  All external calls are mocked.

Mocking strategy
----------------
_run_scan_legacy does ``from aws_pentest.run import run as pentest_run`` inside
its function body.  Since boto3 is not installed in this test environment,
aws_pentest.run cannot be imported at module level.  We therefore inject a fake
``aws_pentest.run`` module into sys.modules before the function executes so
the local import resolves to our mock without touching boto3.
"""

from __future__ import annotations

import json
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_scan_req(**kwargs):
    """Return a minimal ScanRequest-like namespace."""
    from api.routes.scan import ScanRequest
    defaults = {
        "provider": "aws",
        "profile": None,
        "region": None,
        "regions": None,
        "skip_privesc": False,
        "skip_s3_iam_xref": False,
        "gcp_project_id": None,
    }
    defaults.update(kwargs)
    return ScanRequest(**defaults)


def _minimal_report() -> dict:
    return {
        "summary": {
            "iam_users": 1,
            "iam_roles": 2,
            "s3_buckets": 1,
            "ec2_instances": 0,
            "total_findings": 3,
        }
    }


def _minimal_graph() -> dict:
    return {"nodes": [], "edges": []}


def _inject_fake_run(fake_run_fn):
    """
    Context manager: inject a fake ``aws_pentest.run`` module whose ``run``
    attribute is ``fake_run_fn``.  Restores sys.modules on exit.
    """
    import contextlib

    @contextlib.contextmanager
    def _ctx():
        fake_module = types.ModuleType("aws_pentest.run")
        fake_module.run = fake_run_fn
        orig = sys.modules.get("aws_pentest.run")
        sys.modules["aws_pentest.run"] = fake_module
        try:
            yield fake_module
        finally:
            if orig is None:
                sys.modules.pop("aws_pentest.run", None)
            else:
                sys.modules["aws_pentest.run"] = orig

    return _ctx()


# ---------------------------------------------------------------------------
# P1 — _run_scan_legacy writes graph JSON on success
# ---------------------------------------------------------------------------

def test_legacy_scan_writes_graph_json():
    """
    _run_scan_legacy passes output_graph_json to aws_pentest.run.run().
    We verify the correct path is forwarded by having the mock capture kwargs
    and write the file as the real run() would.
    """
    from api.routes.scan import _run_scan_legacy, _GRAPH_OUT

    captured = {}

    def fake_pentest_run(**kwargs):
        captured.update(kwargs)
        out = kwargs.get("output_graph_json")
        assert out is not None, "output_graph_json must be passed to pentest_run"
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        Path(out).write_text(json.dumps(_minimal_graph()), encoding="utf-8")
        return _minimal_report()

    req = _make_scan_req()
    with _inject_fake_run(fake_pentest_run):
        _run_scan_legacy(req)

    assert "output_graph_json" in captured, "run() was not called with output_graph_json"
    assert captured["output_graph_json"] == str(_GRAPH_OUT), (
        f"output_graph_json must equal str(_GRAPH_OUT)={_GRAPH_OUT!s}, "
        f"got {captured['output_graph_json']!r}"
    )


def test_legacy_scan_graph_json_path_matches_graph_service_path():
    """
    The _GRAPH_OUT constant in scan.py must match the path graph_service reads.
    A mismatch means a fresh scan never updates the graph served by the API.
    """
    from api.routes.scan import _GRAPH_OUT as scan_graph_out
    from api.services.graph_service import _GRAPH_JSON_PATH as service_graph_path

    assert scan_graph_out.resolve() == service_graph_path.resolve(), (
        f"Scan writes to {scan_graph_out} but graph service reads from {service_graph_path}. "
        "These must be the same file."
    )


def test_legacy_scan_failed_scan_does_not_overwrite_existing_graph():
    """
    When run() raises an exception the graph file that existed before the scan
    must NOT be replaced with empty/partial data.
    """
    import api.routes.scan as scan_module

    original_graph = {"nodes": [{"node_id": "existing"}], "edges": []}
    graph_path = scan_module._GRAPH_OUT
    graph_path.parent.mkdir(parents=True, exist_ok=True)
    original_content = json.dumps(original_graph)
    graph_path.write_text(original_content, encoding="utf-8")

    req = _make_scan_req()

    def failing_run(**kwargs):
        raise RuntimeError("Simulated AWS API failure")

    with _inject_fake_run(failing_run):
        scan_module._run_scan_legacy(req)

    assert scan_module._scan_state["status"] == "error"

    after_content = graph_path.read_text(encoding="utf-8")
    assert after_content == original_content, (
        "A failed scan must not overwrite the existing valid graph file"
    )


def test_legacy_scan_sets_complete_status_on_success():
    """After a successful scan, _scan_state.status must be 'complete'."""
    import api.routes.scan as scan_module

    req = _make_scan_req()

    def good_run(**kwargs):
        out = kwargs.get("output_graph_json")
        if out:
            Path(out).parent.mkdir(parents=True, exist_ok=True)
            Path(out).write_text(json.dumps(_minimal_graph()), encoding="utf-8")
        return _minimal_report()

    with _inject_fake_run(good_run):
        scan_module._run_scan_legacy(req)

    assert scan_module._scan_state["status"] == "complete"


def test_legacy_scan_sets_error_status_on_failure():
    """After a failed scan, _scan_state.status must be 'error'."""
    import api.routes.scan as scan_module

    req = _make_scan_req()

    def boom(**kwargs):
        raise RuntimeError("boom")

    with _inject_fake_run(boom):
        scan_module._run_scan_legacy(req)

    assert scan_module._scan_state["status"] == "error"
    assert "boom" in scan_module._scan_state["message"]


# ---------------------------------------------------------------------------
# P1 — trigger_scan routes AWS to legacy path
# ---------------------------------------------------------------------------

def test_trigger_scan_aws_uses_legacy_path():
    """
    trigger_scan for provider=aws must schedule _run_scan_legacy, not _run_scan.
    This is the routing decision that determines whether last_graph.json is written.
    """
    from api.routes.scan import trigger_scan, _run_scan_legacy, _run_scan

    bg = MagicMock()
    req = _make_scan_req(provider="aws")

    import api.routes.scan as scan_module
    scan_module._scan_state = {"status": "idle"}

    trigger_scan(req, background_tasks=bg)

    assert bg.add_task.called
    call_args = bg.add_task.call_args
    assert call_args[0][0] is _run_scan_legacy, (
        "AWS scans must use _run_scan_legacy (which writes last_graph.json)"
    )


def test_trigger_scan_gcp_uses_provider_path():
    """GCP scans use _run_scan (the provider path), not _run_scan_legacy."""
    from api.routes.scan import trigger_scan, _run_scan_legacy, _run_scan

    bg = MagicMock()
    req = _make_scan_req(provider="gcp", gcp_project_id="my-project")

    import api.routes.scan as scan_module
    scan_module._scan_state = {"status": "idle"}

    trigger_scan(req, background_tasks=bg)

    assert bg.add_task.called
    call_args = bg.add_task.call_args
    assert call_args[0][0] is _run_scan, (
        "GCP scans must use _run_scan (the provider path)"
    )
    assert call_args[0][0] is not _run_scan_legacy
