"""
Tests for aws_pentest.graph.builder — verifies that:
  1. No cross-product edges are emitted (only trust-policy-backed CAN_ASSUME edges)
  2. S3 edges only appear when confirmed_access is populated
  3. PrivEsc edges only appear when privesc_paths are provided
  4. HAS_INSTANCE_PROFILE edges follow real instance profile data
"""

import json

import pytest
import networkx as nx

from aws_pentest.graph.builder import GraphBuilder
from aws_pentest.models.iam_models import (
    IAMUser, IAMRole, IAMGroup, IAMPolicy, TrustRelationship, PrivEscPath, Severity,
    PolicyEffect,
)
from aws_pentest.models.s3_models import S3Bucket
from aws_pentest.models.ec2_models import EC2Instance, InstanceProfile


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _user(username: str, arn: str) -> IAMUser:
    return IAMUser(
        user_id=f"uid-{username}",
        username=username,
        arn=arn,
    )


def _role(role_name: str, arn: str, trusting_principals: list[str] = None) -> IAMRole:
    trusts = []
    for p in (trusting_principals or []):
        trusts.append(TrustRelationship(
            principal_arn=p,
            principal_type="AWS",
            actions=["sts:AssumeRole"],
            effect=PolicyEffect.ALLOW,
            source_statement={"Principal": {"AWS": p}, "Action": "sts:AssumeRole"},
        ))
    return IAMRole(
        role_id=f"rid-{role_name}",
        role_name=role_name,
        arn=arn,
        trust_relationships=trusts,
    )


def _bucket(name: str, confirmed_access: dict = None) -> S3Bucket:
    return S3Bucket(
        name=name,
        arn=f"arn:aws:s3:::{name}",
        confirmed_access=confirmed_access or {},
    )


def _instance(instance_id: str, region: str = "us-east-1", role_arns: list[str] = None) -> EC2Instance:
    profile = None
    if role_arns:
        profile = InstanceProfile(
            profile_id=f"ip-{instance_id}",
            profile_name=f"profile-{instance_id}",
            arn=f"arn:aws:iam::123456789:instance-profile/profile-{instance_id}",
            role_arns=role_arns,
        )
    return EC2Instance(
        instance_id=instance_id,
        state="running",
        region=region,
        instance_profile=profile,
    )


# ---------------------------------------------------------------------------
# No-cross-product: trust edges
# ---------------------------------------------------------------------------

def test_no_edges_without_trust():
    """Two users and a role with no trust — no CAN_ASSUME edges."""
    users = [_user("alice", "arn:aws:iam::123:user/alice")]
    roles = [_role("MyRole", "arn:aws:iam::123:role/MyRole", trusting_principals=[])]

    graph = GraphBuilder().build(users=users, roles=roles, buckets=[], instances=[])
    nx_g = graph.to_networkx()

    assume_edges = [
        (u, v) for u, v, d in nx_g.edges(data=True) if d.get("relation") == "CAN_ASSUME"
    ]
    assert assume_edges == [], "No CAN_ASSUME edge without a trust relationship"


def test_can_assume_edge_when_trust_exists():
    """User ARN in trust policy → CAN_ASSUME edge created."""
    user_arn = "arn:aws:iam::123:user/alice"
    role_arn = "arn:aws:iam::123:role/AdminRole"
    users = [_user("alice", user_arn)]
    roles = [_role("AdminRole", role_arn, trusting_principals=[user_arn])]

    graph = GraphBuilder().build(users=users, roles=roles, buckets=[], instances=[])
    nx_g = graph.to_networkx()

    assert nx_g.has_edge(user_arn, role_arn), "CAN_ASSUME edge expected"
    edge_data = nx_g[user_arn][role_arn]
    assert edge_data["relation"] == "CAN_ASSUME"


def test_can_assume_edge_not_created_for_unknown_principal():
    """External account ARN in trust → edge skipped (unknown principal)."""
    user_arn = "arn:aws:iam::123:user/alice"
    external_arn = "arn:aws:iam::999:user/external"
    role_arn = "arn:aws:iam::123:role/CrossAccountRole"
    users = [_user("alice", user_arn)]
    # Trust allows only the external (unknown) principal
    roles = [_role("CrossAccountRole", role_arn, trusting_principals=[external_arn])]

    graph = GraphBuilder().build(users=users, roles=roles, buckets=[], instances=[])
    nx_g = graph.to_networkx()

    assert not nx_g.has_edge(external_arn, role_arn), (
        "Edge to unknown external principal should be skipped"
    )
    assert not nx_g.has_edge(user_arn, role_arn), (
        "Alice is not in trust policy — no edge for her"
    )


def test_service_principal_trust_creates_edge():
    """EC2 service principal trust → CAN_ASSUME edge kept (AWS service)."""
    role_arn = "arn:aws:iam::123:role/EC2Role"
    roles = [_role("EC2Role", role_arn, trusting_principals=["ec2.amazonaws.com"])]

    graph = GraphBuilder().build(users=[], roles=roles, buckets=[], instances=[])
    nx_g = graph.to_networkx()

    assert nx_g.has_edge("ec2.amazonaws.com", role_arn)


# ---------------------------------------------------------------------------
# S3 edges only from confirmed_access
# ---------------------------------------------------------------------------

def test_no_s3_edges_without_confirmed_access():
    user_arn = "arn:aws:iam::123:user/alice"
    users = [_user("alice", user_arn)]
    buckets = [_bucket("my-bucket", confirmed_access={})]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])
    nx_g = graph.to_networkx()

    s3_edges = [
        (u, v) for u, v, d in nx_g.edges(data=True)
        if "BUCKET" in d.get("relation", "")
    ]
    assert s3_edges == [], "No S3 edges without simulator confirmation"


def test_s3_read_edge_from_confirmed_access():
    user_arn = "arn:aws:iam::123:user/alice"
    bucket_arn = "arn:aws:s3:::my-bucket"
    users = [_user("alice", user_arn)]
    buckets = [_bucket("my-bucket", confirmed_access={user_arn: ["s3:GetObject"]})]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])
    nx_g = graph.to_networkx()

    assert nx_g.has_edge(user_arn, bucket_arn)
    edge = nx_g[user_arn][bucket_arn]
    assert edge["relation"] == "CAN_READ_BUCKET"
    assert "s3:GetObject" in edge["actions"]


def test_s3_write_edge_from_confirmed_access():
    user_arn = "arn:aws:iam::123:user/alice"
    bucket_arn = "arn:aws:s3:::my-bucket"
    users = [_user("alice", user_arn)]
    buckets = [_bucket("my-bucket", confirmed_access={user_arn: ["s3:PutObject"]})]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])
    nx_g = graph.to_networkx()

    assert nx_g.has_edge(user_arn, bucket_arn)
    assert nx_g[user_arn][bucket_arn]["relation"] == "CAN_WRITE_BUCKET"


# ---------------------------------------------------------------------------
# Instance profile edges
# ---------------------------------------------------------------------------

def test_has_instance_profile_edge():
    role_arn = "arn:aws:iam::123:role/EC2Role"
    roles = [_role("EC2Role", role_arn)]
    instance = _instance("i-123", role_arns=[role_arn])

    graph = GraphBuilder().build(users=[], roles=roles, buckets=[], instances=[instance])
    nx_g = graph.to_networkx()

    inst_arn = "arn:aws:ec2:us-east-1::instance/i-123"
    assert nx_g.has_edge(inst_arn, role_arn)
    edge = nx_g[inst_arn][role_arn]
    assert edge["relation"] == "HAS_INSTANCE_PROFILE"


def test_no_instance_profile_edge_without_profile():
    instance = _instance("i-999", role_arns=None)
    graph = GraphBuilder().build(users=[], roles=[], buckets=[], instances=[instance])
    nx_g = graph.to_networkx()

    profile_edges = [
        (u, v) for u, v, d in nx_g.edges(data=True)
        if d.get("relation") == "HAS_INSTANCE_PROFILE"
    ]
    assert profile_edges == []


# ---------------------------------------------------------------------------
# PrivEsc edges
# ---------------------------------------------------------------------------

def test_privesc_edge_added():
    """Default (no account_id) falls back to UNKNOWN — edge still added."""
    user_arn = "arn:aws:iam::123:user/bob"
    users = [_user("bob", user_arn)]
    path = PrivEscPath(
        source_arn=user_arn,
        technique="AttachUserPolicy",
        description="Can attach admin policy",
        chain=[user_arn, "<AttachUserPolicy>", "AdministratorAccess"],
        required_actions=["iam:AttachUserPolicy"],
        simulator_confirmed=True,
        severity=Severity.CRITICAL,
        evidence=[{"EvalDecision": "allowed"}],
    )

    graph = GraphBuilder().build(
        users=users, roles=[], buckets=[], instances=[], privesc_paths=[path]
    )
    nx_g = graph.to_networkx()

    # Default account_id="UNKNOWN" — no real account_id supplied
    admin_node = "arn:aws:iam::UNKNOWN:policy/AdministratorAccess"
    assert nx_g.has_edge(user_arn, admin_node)
    edge = nx_g[user_arn][admin_node]
    assert edge["relation"] == "PRIVESC_TO"


def test_no_privesc_edge_without_paths():
    user_arn = "arn:aws:iam::123:user/bob"
    users = [_user("bob", user_arn)]
    graph = GraphBuilder().build(users=users, roles=[], buckets=[], instances=[], privesc_paths=[])
    nx_g = graph.to_networkx()

    privesc_edges = [
        (u, v) for u, v, d in nx_g.edges(data=True)
        if d.get("relation") == "PRIVESC_TO"
    ]
    assert privesc_edges == []


# ---------------------------------------------------------------------------
# Node counts
# ---------------------------------------------------------------------------

def test_node_types_in_graph():
    user_arn = "arn:aws:iam::123:user/alice"
    role_arn = "arn:aws:iam::123:role/MyRole"
    users = [_user("alice", user_arn)]
    roles = [_role("MyRole", role_arn)]
    buckets = [_bucket("my-bucket")]
    instances = [_instance("i-001")]

    graph = GraphBuilder().build(
        users=users, roles=roles, buckets=buckets, instances=instances
    )
    nx_g = graph.to_networkx()

    node_types = {d.get("node_type") for _, d in nx_g.nodes(data=True)}
    assert "IAMUser" in node_types
    assert "IAMRole" in node_types
    assert "S3Bucket" in node_types
    assert "EC2Instance" in node_types


# ---------------------------------------------------------------------------
# P2 — PrivEsc admin-node uses real account ID
# ---------------------------------------------------------------------------

def _privesc_path(source_arn: str) -> PrivEscPath:
    return PrivEscPath(
        source_arn=source_arn,
        technique="AttachUserPolicy",
        description="test",
        chain=[source_arn, "<AttachUserPolicy>", "AdministratorAccess"],
        required_actions=["iam:AttachUserPolicy"],
        simulator_confirmed=True,
        severity=Severity.CRITICAL,
        evidence=[{"EvalDecision": "allowed"}],
    )


def test_privesc_admin_node_uses_real_account_id():
    """When account_id is supplied, the admin node ARN must embed it — no literal 'ACCOUNT'."""
    user_arn = "arn:aws:iam::608841097745:user/pentest"
    users = [_user("pentest", user_arn)]

    graph = GraphBuilder().build(
        users=users, roles=[], buckets=[], instances=[],
        privesc_paths=[_privesc_path(user_arn)],
        account_id="608841097745",
    )
    nx_g = graph.to_networkx()

    expected_node = "arn:aws:iam::608841097745:policy/AdministratorAccess"
    assert nx_g.has_node(expected_node), "Admin capability node must use the real account ID"
    assert nx_g.has_edge(user_arn, expected_node), "PrivEsc edge must point to real-account-ID node"
    assert nx_g[user_arn][expected_node]["relation"] == "PRIVESC_TO"


def test_privesc_admin_node_no_account_placeholder_when_id_known():
    """The literal string 'ACCOUNT' must not appear in any node ID when account_id is supplied."""
    user_arn = "arn:aws:iam::123456789012:user/alice"
    users = [_user("alice", user_arn)]

    graph = GraphBuilder().build(
        users=users, roles=[], buckets=[], instances=[],
        privesc_paths=[_privesc_path(user_arn)],
        account_id="123456789012",
    )
    nx_g = graph.to_networkx()

    for node_id in nx_g.nodes():
        assert "ACCOUNT" not in node_id, (
            f"Node '{node_id}' contains the literal placeholder 'ACCOUNT'"
        )


def test_privesc_admin_node_unknown_fallback_does_not_crash():
    """Callers that omit account_id still get a valid (UNKNOWN) edge — no exception."""
    user_arn = "arn:aws:iam::123:user/bob"
    users = [_user("bob", user_arn)]

    graph = GraphBuilder().build(
        users=users, roles=[], buckets=[], instances=[],
        privesc_paths=[_privesc_path(user_arn)],
        # account_id omitted → defaults to "UNKNOWN"
    )
    nx_g = graph.to_networkx()

    admin_node = "arn:aws:iam::UNKNOWN:policy/AdministratorAccess"
    assert nx_g.has_node(admin_node)
    assert nx_g.has_edge(user_arn, admin_node)


# ---------------------------------------------------------------------------
# P4 — Multiple S3 actions on the same (principal, bucket) pair
# ---------------------------------------------------------------------------

def test_multiple_s3_actions_produce_single_edge():
    """Read + Write access to one bucket → exactly one edge carrying both actions."""
    user_arn = "arn:aws:iam::123:user/alice"
    bucket_arn = "arn:aws:s3:::my-bucket"
    users = [_user("alice", user_arn)]
    buckets = [_bucket("my-bucket", confirmed_access={
        user_arn: ["s3:GetObject", "s3:PutObject"],
    })]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])
    nx_g = graph.to_networkx()

    # Exactly one edge between this pair
    assert nx_g.has_edge(user_arn, bucket_arn)
    assert nx_g.number_of_edges(user_arn, bucket_arn) == 1, (
        "Multiple confirmed actions on the same bucket must produce exactly one edge"
    )

    edge = nx_g[user_arn][bucket_arn]
    # Both actions preserved
    assert "s3:GetObject" in edge["actions"], "s3:GetObject must be in merged actions"
    assert "s3:PutObject" in edge["actions"], "s3:PutObject must be in merged actions"


def test_multiple_s3_actions_highest_precedence_relation():
    """When both read and write are confirmed, the edge relation must be CAN_WRITE_BUCKET."""
    user_arn = "arn:aws:iam::123:user/alice"
    bucket_arn = "arn:aws:s3:::my-bucket"
    users = [_user("alice", user_arn)]
    buckets = [_bucket("my-bucket", confirmed_access={
        user_arn: ["s3:GetObject", "s3:PutObject"],
    })]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])
    nx_g = graph.to_networkx()

    edge = nx_g[user_arn][bucket_arn]
    assert edge["relation"] == "CAN_WRITE_BUCKET", (
        "Write access outranks read access — relation must be CAN_WRITE_BUCKET"
    )


def test_all_four_s3_actions_merged():
    """All four S3 actions for one principal → one edge, CAN_WRITE_BUCKET relation."""
    user_arn = "arn:aws:iam::123:user/poweruser"
    bucket_arn = "arn:aws:s3:::big-bucket"
    users = [_user("poweruser", user_arn)]
    buckets = [_bucket("big-bucket", confirmed_access={
        user_arn: ["s3:GetObject", "s3:PutObject", "s3:ListBucket", "s3:DeleteObject"],
    })]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])
    nx_g = graph.to_networkx()

    assert nx_g.has_edge(user_arn, bucket_arn)
    edge = nx_g[user_arn][bucket_arn]
    assert set(edge["actions"]) == {
        "s3:GetObject", "s3:PutObject", "s3:ListBucket", "s3:DeleteObject"
    }, "All four actions must be preserved"
    # CAN_WRITE_BUCKET (rank 4) > CAN_DELETE_BUCKET (rank 3) — write wins
    assert edge["relation"] == "CAN_WRITE_BUCKET"


def test_multiple_s3_actions_evidence_contains_all_actions():
    """The merged edge evidence must contain one entry per confirmed action."""
    user_arn = "arn:aws:iam::123:user/alice"
    bucket_arn = "arn:aws:s3:::my-bucket"
    users = [_user("alice", user_arn)]
    buckets = [_bucket("my-bucket", confirmed_access={
        user_arn: ["s3:GetObject", "s3:PutObject"],
    })]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])
    nx_g = graph.to_networkx()

    edge = nx_g[user_arn][bucket_arn]
    evidence_actions = {e["action"] for e in edge["evidence"]}
    assert "s3:GetObject" in evidence_actions
    assert "s3:PutObject" in evidence_actions


def test_s3_two_principals_same_bucket_each_get_own_edge():
    """Two different principals with access to the same bucket get independent edges."""
    alice_arn = "arn:aws:iam::123:user/alice"
    bob_arn = "arn:aws:iam::123:user/bob"
    bucket_arn = "arn:aws:s3:::shared-bucket"
    users = [_user("alice", alice_arn), _user("bob", bob_arn)]
    buckets = [_bucket("shared-bucket", confirmed_access={
        alice_arn: ["s3:GetObject"],
        bob_arn: ["s3:PutObject"],
    })]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])
    nx_g = graph.to_networkx()

    assert nx_g.has_edge(alice_arn, bucket_arn)
    assert nx_g.has_edge(bob_arn, bucket_arn)
    assert nx_g[alice_arn][bucket_arn]["relation"] == "CAN_READ_BUCKET"
    assert nx_g[bob_arn][bucket_arn]["relation"] == "CAN_WRITE_BUCKET"


def test_graph_assessment_edges_count_one_per_principal_bucket():
    """AssessmentGraph.edges must contain exactly one entry per (principal, bucket) pair."""
    user_arn = "arn:aws:iam::123:user/alice"
    users = [_user("alice", user_arn)]
    buckets = [_bucket("my-bucket", confirmed_access={
        user_arn: ["s3:GetObject", "s3:PutObject", "s3:ListBucket"],
    })]

    graph = GraphBuilder().build(users=users, roles=[], buckets=buckets, instances=[])

    s3_edges = [
        e for e in graph.edges
        if e.source_id == user_arn and e.target_id == "arn:aws:s3:::my-bucket"
    ]
    assert len(s3_edges) == 1, (
        f"Expected 1 S3 edge in AssessmentGraph.edges, got {len(s3_edges)}"
    )
