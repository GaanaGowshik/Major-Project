"""
Graph service — converts the aws_pentest AssessmentGraph (or the GCP graph,
or the legacy CloudGraphBuilder graph) into the React Flow wire format expected
by the frontend.

Every edge carries a `confirmed` boolean:
  True  → backed by IAM Policy Simulator or parsed trust policy
  False → derived from a static heuristic or a deprecated cross-product

The caller must pass the confirmed flag through; this layer never invents data.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Literal, Optional

import networkx as nx

logger = logging.getLogger(__name__)

# Where the latest Phase 1 graph JSON is written by aws_pentest.run
_GRAPH_JSON_PATH = Path(__file__).parent.parent.parent / "aws_pentest" / "last_graph.json"
# GCP report JSON path (the GCP provider does not write a separate graph file yet;
# the graph is built on-the-fly from the report findings)
_GCP_REPORT_JSON_PATH = Path(__file__).parent.parent.parent / "gcp_pentest" / "last_report.json"


# ---------------------------------------------------------------------------
# Node risk scoring
# ---------------------------------------------------------------------------

_TYPE_BASE_RISK: dict[str, int] = {
    "IAMUser": 60,
    "IAMRole": 70,
    "S3Bucket": 50,
    "EC2Instance": 55,
    "Capability": 100,
    "user": 60,
    "role": 70,
    "bucket": 50,
    # GCP types
    "ServiceAccount": 70,
    "StorageBucket": 50,
    "ComputeInstance": 55,
    "FirewallRule": 40,
}

_RELATION_RISK_BOOST: dict[str, int] = {
    "CAN_ASSUME": 20,
    "CAN_READ_BUCKET": 10,
    "CAN_WRITE_BUCKET": 25,
    "CAN_LIST_BUCKET": 10,
    "CAN_DELETE_BUCKET": 20,
    "HAS_INSTANCE_PROFILE": 15,
    "PRIVESC_TO": 50,
    "CAN_ACCESS": 20,
    "CAN_IMPERSONATE": 40,
}


def _node_risk(node_id: str, nx_graph: nx.DiGraph) -> int:
    base = _TYPE_BASE_RISK.get(
        nx_graph.nodes[node_id].get("node_type")
        or nx_graph.nodes[node_id].get("type", ""),
        40,
    )
    boost = sum(
        _RELATION_RISK_BOOST.get(nx_graph[u][v].get("relation", ""), 0)
        for u, v in nx_graph.out_edges(node_id)
    )
    return min(base + boost, 100)


# ---------------------------------------------------------------------------
# React Flow conversion
# ---------------------------------------------------------------------------

def nx_to_react_flow(nx_graph: nx.DiGraph) -> dict[str, Any]:
    """
    Convert a networkx DiGraph to React Flow nodes + edges JSON.

    Nodes carry:
      id, type(=nodeType), data{label, nodeType, arn, attributes, riskScore,
      reachableCount, confirmed}

    Edges carry:
      id, source, target, data{relation, actions, confirmed, label}
    """
    rf_nodes: list[dict] = []
    rf_edges: list[dict] = []

    # ---- nodes ----
    for node_id, attrs in nx_graph.nodes(data=True):
        node_type = attrs.get("node_type") or attrs.get("type", "unknown")
        confirmed = attrs.get("confirmed", True)
        risk = _node_risk(node_id, nx_graph)
        reachable = len(list(nx.descendants(nx_graph, node_id)))

        rf_nodes.append(
            {
                "id": str(node_id),
                "type": "cloudNode",
                "position": {"x": 0, "y": 0},  # frontend auto-layouts
                "data": {
                    "label": attrs.get("display_name") or node_id.split("/")[-1],
                    "nodeType": node_type,
                    "arn": attrs.get("arn") or node_id,
                    "attributes": {
                        k: v
                        for k, v in attrs.items()
                        if k not in ("node_type", "type", "display_name", "arn", "confirmed")
                    },
                    "riskScore": risk,
                    "reachableCount": reachable,
                    "confirmed": confirmed,
                },
            }
        )

    # ---- edges ----
    for u, v, eattrs in nx_graph.edges(data=True):
        relation = eattrs.get("relation", "CONNECTED")
        actions = eattrs.get("actions", [])
        confirmed = eattrs.get("confirmed", True)

        # Edges from the legacy CloudGraphBuilder may carry confirmed=False
        rf_edges.append(
            {
                "id": f"{u}--{relation}--{v}",
                "source": str(u),
                "target": str(v),
                "data": {
                    "relation": relation,
                    "actions": actions if isinstance(actions, list) else [actions],
                    "confirmed": confirmed,
                    "label": relation,
                    "evidenceCount": len(eattrs.get("evidence", [])),
                    "policySources": eattrs.get("policy_sources", []),
                },
            }
        )

    return {"nodes": rf_nodes, "edges": rf_edges}


# ---------------------------------------------------------------------------
# GCP graph builder — constructs a DiGraph from the GCP report findings
# ---------------------------------------------------------------------------

def _build_gcp_graph_from_report(report: dict) -> nx.DiGraph:
    """
    Build a networkx DiGraph from the GCP last_report.json.

    Nodes: service accounts, storage buckets, compute instances, firewall rules
    Edges: privilege escalation paths, IAM bindings, firewall relationships
    """
    g = nx.DiGraph()

    resources = report.get("resources", {})
    privesc_paths = report.get("privilege_escalation_paths", [])
    findings = report.get("findings", {})

    # Add service accounts as nodes
    for sa in resources.get("service_accounts", []):
        email = sa.get("email", "")
        if not email:
            continue
        node_id = f"serviceAccount:{email}"
        g.add_node(node_id, node_type="ServiceAccount",
                   display_name=sa.get("display_name") or email.split("@")[0],
                   arn=node_id,
                   confirmed=True)

    # Add storage bucket nodes
    sa_node_ids = {
        f"serviceAccount:{sa.get('email', '')}"
        for sa in resources.get("service_accounts", [])
        if sa.get("email")
    }
    _storage_read_roles = {
        "roles/storage.objectViewer", "roles/storage.objectAdmin",
        "roles/storage.admin", "roles/viewer", "roles/editor", "roles/owner",
    }
    _storage_write_roles = {
        "roles/storage.objectCreator", "roles/storage.objectAdmin",
        "roles/storage.admin", "roles/editor", "roles/owner",
    }
    _public_members = {"allUsers", "allAuthenticatedUsers"}

    for b in resources.get("storage_buckets", []):
        name = b.get("name", "")
        if not name:
            continue
        bucket_node_id = f"//storage.googleapis.com/{name}"
        g.add_node(bucket_node_id, node_type="StorageBucket",
                   display_name=name,
                   arn=bucket_node_id,
                   confirmed=True,
                   is_public_read=b.get("is_public_read", False),
                   is_public_write=b.get("is_public_write", False))

        # Bucket-level IAM binding edges (serialized by run.py into the report)
        for bnd in b.get("iam_bindings", []):
            role = bnd.get("role", "")
            for member in bnd.get("members", []):
                is_sa = member.startswith("serviceAccount:") and member in sa_node_ids
                is_public = member in _public_members
                if not (is_sa or is_public):
                    continue
                if role in _storage_write_roles:
                    relation = "CAN_WRITE_BUCKET"
                elif role in _storage_read_roles:
                    relation = "CAN_READ_BUCKET"
                else:
                    relation = "CAN_ACCESS_BUCKET"
                # Ensure source node exists before adding edge
                if member not in g:
                    g.add_node(member, node_type="ServiceAccount",
                               display_name=member.split(":")[-1].split("@")[0],
                               arn=member, confirmed=True)
                g.add_edge(member, bucket_node_id,
                           relation=relation,
                           actions=[role],
                           confirmed=True,
                           evidence=[{"type": "bucket_iam_binding", "role": role, "member": member}])

    # Add compute instance nodes
    for inst in resources.get("compute_instances", []):
        inst_name = inst.get("name", inst.get("id", ""))
        if not inst_name:
            continue
        g.add_node(inst_name, node_type="ComputeInstance",
                   display_name=inst_name,
                   arn=inst_name,
                   confirmed=True)

    # Add firewall rule nodes from compute findings.
    # Findings for firewall rules use instance_name = "firewall/<rule-name>".
    for f in findings.get("compute", []):
        raw_name = f.get("instance_name", "")
        if raw_name and raw_name.startswith("firewall/"):
            rule_name = raw_name[len("firewall/"):]
            node_id = f"firewall/{rule_name}"
            if node_id not in g:
                g.add_node(node_id, node_type="FirewallRule",
                           display_name=rule_name,
                           arn=node_id,
                           confirmed=True)

    # Add privilege escalation edges.
    # The report stores paths with key "source_member".
    # The target is a Capability node representing elevated project-level access.
    # Label is "ProjectPrivileged" — not "ProjectAdmin" — because the evidence may
    # show roles/editor (not roles/owner), and conflating the two is misleading.
    project_id = report.get("project_id", "gcp-project")
    for path in privesc_paths:
        src = path.get("source_member", "")
        technique = path.get("technique", "PRIVESC_TO")
        if not src:
            continue
        # Build a deterministic target node for this project
        tgt = f"//cloudresourcemanager.googleapis.com/projects/{project_id}:admin"
        # Ensure source node exists (may be a user: member, not a service account)
        if src not in g:
            if src.startswith("serviceAccount:"):
                g.add_node(src, node_type="ServiceAccount",
                           display_name=src.split(":")[-1].split("@")[0],
                           arn=src, confirmed=True)
            else:
                # user: or group: member — represent as generic identity
                g.add_node(src, node_type="IAMUser",
                           display_name=src.split(":")[-1],
                           arn=src, confirmed=True)
        # Ensure target capability node exists.
        # Display name is "ProjectPrivileged" rather than "ProjectAdmin" to avoid
        # implying roles/owner when the evidence may only show roles/editor.
        if tgt not in g:
            g.add_node(tgt, node_type="Capability",
                       display_name="ProjectPrivileged",
                       arn=tgt, confirmed=True)
        # Derive the granted roles from evidence when required_permissions is empty.
        # This preserves the distinction between observed permissions and required actions.
        actions = path.get("required_permissions") or [
            ev["role"] for ev in path.get("evidence", []) if isinstance(ev, dict) and "role" in ev
        ]
        confirmed = bool(path.get("confirmed", True))
        g.add_edge(src, tgt, relation="PRIVESC_TO",
                   actions=actions,
                   confirmed=confirmed,
                   technique=technique,
                   evidence=path.get("evidence", [technique]))

    if g.number_of_nodes() == 0:
        # Fall back: add a placeholder Capability node so the graph is not empty
        g.add_node(project_id, node_type="Capability",
                   display_name=project_id, arn=project_id, confirmed=True)

    return g


# ---------------------------------------------------------------------------
# Graph loader — tries Phase 1 JSON (AWS), GCP report, falls back to live builder
# ---------------------------------------------------------------------------

def _load_real_graph(provider: Literal["aws", "gcp"] = "aws") -> tuple[nx.DiGraph, str]:
    """
    Return (nx_graph, source_label).

    For AWS:
      Priority:
      1. last_graph.json produced by aws_pentest.run (real, confirmed)
      2. Live CloudGraphBuilder call (partial — CAN_ASSUME only, no bucket edges)

    For GCP:
      1. gcp_pentest/last_report.json → build graph on-the-fly
      2. Return empty graph if no GCP scan has been run
    """
    if provider == "gcp":
        if _GCP_REPORT_JSON_PATH.exists():
            try:
                with open(_GCP_REPORT_JSON_PATH, encoding="utf-8") as f:
                    raw = json.load(f)
                nx_graph = _build_gcp_graph_from_report(raw)
                logger.info("Built GCP graph: %d nodes, %d edges",
                            nx_graph.number_of_nodes(), nx_graph.number_of_edges())
                return nx_graph, "gcp_real"
            except Exception as exc:
                logger.warning("Could not build GCP graph: %s", exc)
        return nx.DiGraph(), "gcp_empty"

    # AWS path
    if _GRAPH_JSON_PATH.exists():
        try:
            from aws_pentest.models.graph_models import AssessmentGraph
            with open(_GRAPH_JSON_PATH, encoding="utf-8") as f:
                raw = json.load(f)
            ag = AssessmentGraph.model_validate(raw)
            nx_graph = ag.to_networkx()
            # All edges from Phase 1 are confirmed
            for _, _, d in nx_graph.edges(data=True):
                d.setdefault("confirmed", True)
            for _, d in nx_graph.nodes(data=True):
                d.setdefault("confirmed", True)
            logger.info("Loaded Phase 1 graph: %d nodes, %d edges",
                        nx_graph.number_of_nodes(), nx_graph.number_of_edges())
            return nx_graph, "phase1_real"
        except Exception as exc:
            logger.warning("Could not load Phase 1 graph JSON: %s", exc)

    # Fallback: legacy CloudGraphBuilder
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))
        from graph.builder import CloudGraphBuilder
        builder = CloudGraphBuilder()
        nx_graph = builder.build_graph()
        # Mark CAN_ASSUME edges as confirmed (trust-policy backed)
        # Mark CAN_ACCESS edges as unconfirmed (they're empty in current code anyway)
        for u, v, d in nx_graph.edges(data=True):
            relation = d.get("relation", "")
            d["confirmed"] = relation == "CAN_ASSUME"
        for _, d in nx_graph.nodes(data=True):
            d["confirmed"] = True
            d["node_type"] = d.pop("type", "unknown")
        logger.info("Loaded legacy CloudGraphBuilder graph: %d nodes, %d edges",
                    nx_graph.number_of_nodes(), nx_graph.number_of_edges())
        return nx_graph, "legacy_partial"
    except Exception as exc:
        logger.warning("CloudGraphBuilder failed: %s", exc)
        return nx.DiGraph(), "empty"


def get_attack_graph(provider: Literal["aws", "gcp"] = "aws") -> dict[str, Any]:
    nx_graph, source = _load_real_graph(provider=provider)
    rf = nx_to_react_flow(nx_graph)
    rf["meta"] = {
        "source": source,
        "provider": provider,
        "nodeCount": nx_graph.number_of_nodes(),
        "edgeCount": nx_graph.number_of_edges(),
        "confirmedEdges": sum(
            1 for _, _, d in nx_graph.edges(data=True) if d.get("confirmed", False)
        ),
        "unconfirmedEdges": sum(
            1 for _, _, d in nx_graph.edges(data=True) if not d.get("confirmed", False)
        ),
    }
    return rf


def get_node_detail(node_id: str, provider: Literal["aws", "gcp"] = "aws") -> Optional[dict[str, Any]]:
    nx_graph, _ = _load_real_graph(provider=provider)
    if node_id not in nx_graph:
        return None
    attrs = dict(nx_graph.nodes[node_id])
    out_edges = [
        {
            "target": v,
            "relation": d.get("relation"),
            "actions": d.get("actions", []),
            "confirmed": d.get("confirmed", True),
        }
        for _, v, d in nx_graph.out_edges(node_id, data=True)
    ]
    in_edges = [
        {
            "source": u,
            "relation": d.get("relation"),
            "actions": d.get("actions", []),
            "confirmed": d.get("confirmed", True),
        }
        for u, _, d in nx_graph.in_edges(node_id, data=True)
    ]
    reachable = list(nx.descendants(nx_graph, node_id))
    return {
        "id": node_id,
        "attributes": attrs,
        "outEdges": out_edges,
        "inEdges": in_edges,
        "reachableNodes": reachable,
        "riskScore": _node_risk(node_id, nx_graph),
    }
