"""
Validation API routes — Controlled Finding Validation (Phase 6).

Safety model:
  READ_ONLY  — describe only, no cloud calls
  DRY_RUN    — describe exact cloud API calls, no execution
  VALIDATE   — execute controlled test (requires confirmed=True)

Endpoints
---------
POST /api/validate
    Execute or preview a validation technique.
    Dispatches to AWSValidator (provider="aws") or GCPValidator (provider="gcp").

GET  /api/validate/techniques
    List available techniques for the requested provider.

POST /api/validate/cleanup
    Explicitly delete the test object created by a previous write VALIDATE run.
    For AWS: deletes the S3 object.
    For GCP: deletes the GCS object.

GET  /api/validate/history
    Return the persisted validation log.
"""

from __future__ import annotations

import logging
from typing import Any, Literal, Optional

from fastapi import APIRouter
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/validate", tags=["validate"])


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class ValidateRequest(BaseModel):
    """
    Request body for a validation action.

    Fields
    ------
    finding_id:
        ID of the finding to validate (from scan output).
    technique:
        Validation technique to execute.
        AWS:  "s3_write" | "s3_read" | "iam_pass_role" | "ec2_access" | "ec2_control"
        GCP:  "gcs_write" | "gcs_read" | "iam_sa_impersonation" | "compute_access" | "compute_control"
    mode:
        Safety level.
        "READ_ONLY" — describe only (default)
        "DRY_RUN"   — describe exact cloud API calls, no execution
        "VALIDATE"  — execute controlled test (requires confirmed=True)
    confirmed:
        Must be True for mode="VALIDATE" to proceed.
    provider:
        Cloud provider: "aws" (default) or "gcp".
    profile:
        AWS profile name (optional — falls back to standard credential chain).
    region:
        AWS region for the session.
    run_id:
        Optional run identifier. Auto-generated if not provided.

    AWS-specific parameters
    -----------------------
    bucket_name:    Required for s3_write and s3_read techniques.
    object_key:     Optional for s3_read — specific object key to GetObject.
    role_arn:       Required for iam_pass_role technique.
    target_service: Optional for iam_pass_role — AWS service principal to target.
    instance_id:    Required for ec2_access and ec2_control techniques.

    GCP-specific parameters
    -----------------------
    gcp_project_id:         GCP project ID (required for compute_access, compute_control,
                            iam_sa_impersonation).
    bucket_name:            GCS bucket name for gcs_write and gcs_read techniques.
    object_key:             Optional for gcs_read — specific GCS object key.
    service_account_email:  Required for iam_sa_impersonation technique.
    instance_name:          GCP VM instance name for compute_access / compute_control.
    zone:                   GCP zone for compute_access / compute_control.
    """
    finding_id: str
    technique: str
    mode: Literal["READ_ONLY", "DRY_RUN", "VALIDATE"] = "READ_ONLY"
    confirmed: bool = False
    provider: Literal["aws", "gcp"] = "aws"

    # AWS credentials
    profile: Optional[str] = None
    # If omitted, boto3 will use the region defined in the AWS profile.
    region: Optional[str] = None
    run_id: Optional[str] = None

    # Shared / AWS parameters
    bucket_name: Optional[str] = None
    object_key: Optional[str] = None         # s3_read / gcs_read: specific object
    role_arn: Optional[str] = None           # iam_pass_role
    target_service: Optional[str] = None     # iam_pass_role: target service principal
    instance_id: Optional[str] = None        # ec2_access, ec2_control

    # GCP parameters
    gcp_project_id: Optional[str] = None
    service_account_email: Optional[str] = None   # iam_sa_impersonation
    instance_name: Optional[str] = None           # compute_access, compute_control
    zone: Optional[str] = None                    # compute_access, compute_control


class CleanupRequest(BaseModel):
    """
    Request body for explicit write-validation cleanup.

    For AWS (s3_write): deletes the S3 object created by the validation run.
    For GCP (gcs_write): deletes the GCS object created by the validation run.

    The run_id is used to look up the exact bucket/key from the validation log.
    The frontend MUST NOT submit arbitrary bucket/key — the backend resolves
    the target from the persisted run record.
    """
    run_id: str
    provider: Literal["aws", "gcp"] = "aws"
    # AWS
    profile: Optional[str] = None
    region: Optional[str] = None
    # GCP
    gcp_project_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Helper: build boto3 session (AWS)
# ---------------------------------------------------------------------------

def _build_aws_session(profile: Optional[str], region: Optional[str]) -> Any:
    """Build and verify a boto3 session."""
    import boto3
    from botocore.exceptions import NoCredentialsError, ProfileNotFound, ClientError

    session_kwargs: dict[str, Any] = {}
    if profile:
        session_kwargs["profile_name"] = profile
    if region:
        session_kwargs["region_name"] = region
    session = boto3.Session(**session_kwargs)

    try:
        session.client("sts").get_caller_identity()
    except (NoCredentialsError, ProfileNotFound, ClientError):
        raise

    return session


def _aws_credential_error_response(finding_id: str, technique: str, mode: str, exc: Exception) -> dict:
    return {
        "provider": "aws",
        "finding_id": finding_id,
        "technique": technique,
        "mode": mode,
        "status": "error",
        "confirmed": False,
        "description": f"AWS credential error: {exc}. Cannot validate.",
        "error": str(exc),
        "dry_run_preview": [],
        "evidence": [],
        "cleanup_done": False,
        "cleanup_status": "N/A",
        "audit_log": [],
    }


# ---------------------------------------------------------------------------
# Helper: build GCP credentials
# ---------------------------------------------------------------------------

def _build_gcp_credentials(gcp_project_id: Optional[str]) -> tuple[Any, Optional[str]]:
    """
    Resolve GCP credentials via Application Default Credentials.

    Returns (credentials, project_id).
    project_id may come from ADC if gcp_project_id is None.
    """
    import google.auth

    try:
        creds, detected_project = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
    except Exception as exc:
        raise RuntimeError(
            f"GCP credentials unavailable. Set GOOGLE_APPLICATION_CREDENTIALS or "
            f"run 'gcloud auth application-default login'. Error: {exc}"
        ) from exc

    project = gcp_project_id or detected_project
    return creds, project


def _gcp_credential_error_response(finding_id: str, technique: str, mode: str, exc: Exception) -> dict:
    return {
        "provider": "gcp",
        "finding_id": finding_id,
        "technique": technique,
        "mode": mode,
        "status": "error",
        "confirmed": False,
        "description": (
            f"GCP credential error: {exc}. "
            f"Ensure GOOGLE_APPLICATION_CREDENTIALS is set or "
            f"'gcloud auth application-default login' has been run."
        ),
        "error": str(exc),
        "dry_run_preview": [],
        "evidence": [],
        "cleanup_done": False,
        "cleanup_status": "N/A",
        "audit_log": [],
    }


# ---------------------------------------------------------------------------
# POST /api/validate — main validation endpoint
# ---------------------------------------------------------------------------

@router.post("")
def validate_finding(req: ValidateRequest) -> dict[str, Any]:
    """
    Validate a security finding using a controlled technique.

    Dispatches to the appropriate provider-specific validator based on
    req.provider ("aws" or "gcp").

    Returns a ValidationResult dict. The response always includes:
      - provider: the cloud provider used
      - mode: the safety level used
      - status: "not_performed" | "dry_run_preview" | "success" | "failure" | "error"
      - confirmed: True ONLY when mode=VALIDATE and execution succeeded
      - dry_run_preview: list of API calls that would/did execute
      - evidence: list of execution evidence dicts (empty unless VALIDATE ran)
      - cleanup_done / cleanup_status: cleanup state
      - audit_log: list of audit entries for every API call made
      - run_id: unique run identifier
      - [AWS] s3_bucket / s3_object_key: populated for s3_write VALIDATE runs
      - [GCP] gcs_bucket / gcs_object_key: populated for gcs_write VALIDATE runs
    """
    if req.provider == "gcp":
        return _validate_gcp(req)
    else:
        return _validate_aws(req)


def _validate_aws(req: ValidateRequest) -> dict[str, Any]:
    """Handle AWS validation requests."""
    from botocore.exceptions import NoCredentialsError, ProfileNotFound, ClientError
    from aws_pentest.validation.validator import AWSValidator, ValidationMode

    try:
        session = _build_aws_session(req.profile, req.region)
    except (NoCredentialsError, ProfileNotFound, ClientError) as exc:
        return _aws_credential_error_response(req.finding_id, req.technique, req.mode, exc)

    mode = ValidationMode(req.mode)
    validator = AWSValidator(session=session, mode=mode, run_id=req.run_id)

    kwargs: dict[str, Any] = {}
    if req.bucket_name:
        kwargs["bucket_name"] = req.bucket_name
    if req.object_key:
        kwargs["object_key"] = req.object_key
    if req.role_arn:
        kwargs["role_arn"] = req.role_arn
    if req.target_service:
        kwargs["target_service"] = req.target_service
    if req.instance_id:
        kwargs["instance_id"] = req.instance_id
    if req.region:
        kwargs["region"] = req.region

    result = validator.validate(
        finding_id=req.finding_id,
        technique=req.technique,
        confirmed=req.confirmed,
        **kwargs,
    )

    result_dict = result.model_dump()
    result_dict["provider"] = "aws"

    if req.mode == "VALIDATE":
        try:
            from api.services.report_service import record_validation_result
            record_validation_result(result_dict)
        except Exception as exc:
            logger.warning("Could not record AWS validation result: %s", exc)

    return result_dict


def _validate_gcp(req: ValidateRequest) -> dict[str, Any]:
    """Handle GCP validation requests."""
    from gcp_pentest.validation.validator import GCPValidator, ValidationMode
    mode = ValidationMode(req.mode)
    # Determine project_id safely. For preview modes we avoid credential calls.
    if req.gcp_project_id:
        project_id = req.gcp_project_id
    else:
        try:
            import google.auth
            _, detected_project = google.auth.default()
            project_id = detected_project
        except Exception:
            project_id = None

    if mode == ValidationMode.VALIDATE:
        try:
            credentials, _ = _build_gcp_credentials(req.gcp_project_id)
        except Exception as exc:
            return _gcp_credential_error_response(req.finding_id, req.technique, req.mode, exc)
    else:
        # No credentials needed for preview-only modes
        credentials = None

    validator = GCPValidator(
        credentials=credentials,
        project_id=project_id,
        mode=mode,
        run_id=req.run_id,
    )

    kwargs: dict[str, Any] = {}
    if req.bucket_name:
        kwargs["bucket_name"] = req.bucket_name
    if req.object_key:
        kwargs["object_key"] = req.object_key
    if req.service_account_email:
        kwargs["service_account_email"] = req.service_account_email
    if req.instance_name:
        kwargs["instance_name"] = req.instance_name
    if req.zone:
        kwargs["zone"] = req.zone

    result = validator.validate(
        finding_id=req.finding_id,
        technique=req.technique,
        confirmed=req.confirmed,
        **kwargs,
    )

    result_dict = result.model_dump()

    if req.mode == "VALIDATE":
        try:
            from api.services.report_service import record_validation_result
            record_validation_result(result_dict)
        except Exception as exc:
            logger.warning("Could not record GCP validation result: %s", exc)

    return result_dict


# ---------------------------------------------------------------------------
# POST /api/validate/cleanup — explicit write-validation cleanup
# ---------------------------------------------------------------------------

@router.post("/cleanup")
def cleanup_write_validation(req: CleanupRequest) -> dict[str, Any]:
    """
    Explicitly delete the test object created by a previous write VALIDATE run.

    Dispatches to AWS S3 cleanup or GCP GCS cleanup based on req.provider.

    Safety:
      - Only operates on objects recorded in the validation log for this run_id.
      - Does NOT accept arbitrary bucket/key from the frontend.
      - Verifies deletion after DeleteObject / blob.delete().
      - cleanup_status is set to "COMPLETED" ONLY if deletion actually succeeded.
    """
    if req.provider == "gcp":
        return _cleanup_gcp(req)
    else:
        return _cleanup_aws(req)


def _cleanup_aws(req: CleanupRequest) -> dict[str, Any]:
    """Delete the S3 object created by an s3_write VALIDATE run."""
    from botocore.exceptions import NoCredentialsError, ProfileNotFound, ClientError
    from api.services.report_service import _load_validation_log, record_validation_result
    from datetime import datetime, timezone

    log = _load_validation_log()
    run_record: Optional[dict[str, Any]] = None
    for entry in log:
        if entry.get("run_id") == req.run_id and entry.get("technique") == "s3_write":
            run_record = entry

    if run_record is None:
        return {
            "provider": "aws",
            "run_id": req.run_id,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": (
                f"No s3_write validation record found for run_id '{req.run_id}'. "
                f"Cannot perform cleanup."
            ),
        }

    bucket = run_record.get("s3_bucket")
    key = run_record.get("s3_object_key")

    if not bucket or not key:
        return {
            "provider": "aws",
            "run_id": req.run_id,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": (
                f"Validation record for run_id '{req.run_id}' does not contain "
                f"bucket/object_key. bucket={bucket!r}, object_key={key!r}."
            ),
        }

    if run_record.get("cleanup_status") == "COMPLETED":
        return {
            "provider": "aws",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "already_done",
            "cleanup_status": "COMPLETED",
            "description": (
                f"Cleanup for run_id '{req.run_id}' was already completed. "
                f"Object s3://{bucket}/{key} was previously deleted."
            ),
        }

    try:
        session = _build_aws_session(req.profile, req.region)
    except (NoCredentialsError, ProfileNotFound, ClientError) as exc:
        return {
            "provider": "aws",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": f"AWS credential error: {exc}. Cannot perform cleanup.",
            "error": str(exc),
        }

    s3 = session.client("s3")
    timestamp = datetime.now(timezone.utc).isoformat()

    try:
        s3.delete_object(Bucket=bucket, Key=key)

        deletion_verified = False
        try:
            s3.head_object(Bucket=bucket, Key=key)
            deletion_verified = False
        except ClientError as head_exc:
            error_code = head_exc.response.get("Error", {}).get("Code", "")
            if error_code in ("404", "NoSuchKey"):
                deletion_verified = True
            else:
                logger.warning("head_object after delete: %s", head_exc)

        cleanup_status = "COMPLETED" if deletion_verified else "COMPLETED_UNVERIFIED"
        description = (
            f"CLEANUP COMPLETED: Test object s3://{bucket}/{key} was deleted. "
        )
        if deletion_verified:
            description += "Deletion verified — object is no longer accessible."
        else:
            description += "Note: could not immediately verify deletion (may be eventual consistency)."

        _patch_validation_log(req.run_id, "s3_write", {
            "cleanup_done": True,
            "cleanup_status": "COMPLETED",
        })

        return {
            "provider": "aws",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "success",
            "cleanup_status": cleanup_status,
            "cleanup_done": True,
            "deletion_verified": deletion_verified,
            "description": description,
            "timestamp": timestamp,
        }

    except ClientError as exc:
        error_code = exc.response.get("Error", {}).get("Code", "Unknown")
        logger.error("AWS cleanup DeleteObject failed for run %s: %s", req.run_id, exc)
        return {
            "provider": "aws",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "failure",
            "cleanup_status": "FAILED",
            "cleanup_done": False,
            "description": (
                f"CLEANUP FAILED: s3://{bucket}/{key} could not be deleted. "
                f"AWS error: {error_code}. Reason: {exc}"
            ),
            "error": str(exc),
            "timestamp": timestamp,
        }
    except Exception as exc:
        logger.error("AWS cleanup failed unexpectedly for run %s: %s", req.run_id, exc)
        return {
            "provider": "aws",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "error",
            "cleanup_status": "FAILED",
            "cleanup_done": False,
            "description": f"Cleanup failed unexpectedly: {exc}",
            "error": str(exc),
            "timestamp": timestamp,
        }


def _cleanup_gcp(req: CleanupRequest) -> dict[str, Any]:
    """Delete the GCS object created by a gcs_write VALIDATE run."""
    from api.services.report_service import _load_validation_log
    from datetime import datetime, timezone

    log = _load_validation_log()
    run_record: Optional[dict[str, Any]] = None
    for entry in log:
        if entry.get("run_id") == req.run_id and entry.get("technique") == "gcs_write":
            run_record = entry

    if run_record is None:
        return {
            "provider": "gcp",
            "run_id": req.run_id,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": (
                f"No gcs_write validation record found for run_id '{req.run_id}'. "
                f"Cannot perform cleanup."
            ),
        }

    bucket = run_record.get("gcs_bucket")
    key = run_record.get("gcs_object_key")

    if not bucket or not key:
        return {
            "provider": "gcp",
            "run_id": req.run_id,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": (
                f"Validation record for run_id '{req.run_id}' does not contain "
                f"gcs_bucket/gcs_object_key. bucket={bucket!r}, key={key!r}."
            ),
        }

    if run_record.get("cleanup_status") == "COMPLETED":
        return {
            "provider": "gcp",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "already_done",
            "cleanup_status": "COMPLETED",
            "description": (
                f"Cleanup for run_id '{req.run_id}' was already completed. "
                f"Object gs://{bucket}/{key} was previously deleted."
            ),
        }

    timestamp = datetime.now(timezone.utc).isoformat()

    try:
        credentials, _ = _build_gcp_credentials(req.gcp_project_id)
    except Exception as exc:
        return {
            "provider": "gcp",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": f"GCP credential error: {exc}. Cannot perform cleanup.",
            "error": str(exc),
        }

    try:
        from google.cloud import storage as gcs

        client = gcs.Client(credentials=credentials)
        bucket_obj = client.bucket(bucket)
        blob = bucket_obj.blob(key)
        blob.delete()

        # Verify deletion
        deletion_verified = not blob.exists()
        cleanup_status = "COMPLETED" if deletion_verified else "COMPLETED_UNVERIFIED"
        description = (
            f"CLEANUP COMPLETED: GCS object gs://{bucket}/{key} was deleted. "
        )
        if deletion_verified:
            description += "Deletion verified — object no longer exists."
        else:
            description += "Note: could not immediately verify deletion (may be eventual consistency)."

        _patch_validation_log(req.run_id, "gcs_write", {
            "cleanup_done": True,
            "cleanup_status": "COMPLETED",
        })

        return {
            "provider": "gcp",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "success",
            "cleanup_status": cleanup_status,
            "cleanup_done": True,
            "deletion_verified": deletion_verified,
            "description": description,
            "timestamp": timestamp,
        }

    except Exception as exc:
        logger.error("GCP cleanup failed for run %s: %s", req.run_id, exc)
        return {
            "provider": "gcp",
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "error",
            "cleanup_status": "FAILED",
            "cleanup_done": False,
            "description": f"GCP cleanup failed: {exc}",
            "error": str(exc),
            "timestamp": timestamp,
        }


# ---------------------------------------------------------------------------
# Shared helper: patch validation log
# ---------------------------------------------------------------------------

def _patch_validation_log(run_id: str, technique: str, updates: dict[str, Any]) -> None:
    """Update fields on the most recent validation log entry matching run_id + technique."""
    try:
        from api.services.report_service import _load_validation_log, _VALIDATION_LOG_PATH
        import json

        log = _load_validation_log()
        last_idx = None
        for i, entry in enumerate(log):
            if entry.get("run_id") == run_id and entry.get("technique") == technique:
                last_idx = i
        if last_idx is not None:
            log[last_idx].update(updates)
            _VALIDATION_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
            with open(_VALIDATION_LOG_PATH, "w", encoding="utf-8") as f:
                json.dump(log, f, indent=2, default=str)
    except Exception as exc:
        logger.warning("_patch_validation_log failed: %s", exc)


# ---------------------------------------------------------------------------
# GET /api/validate/techniques — list available techniques
# ---------------------------------------------------------------------------

@router.get("/techniques")
def list_techniques(provider: str = "aws"):
    """Return the list of available validation techniques for the requested provider."""
    if provider == "gcp":
        return {
            "provider": "gcp",
            "techniques": [
                {
                    "id": "gcs_write",
                    "name": "Cloud Storage Write Validation",
                    "description": (
                        "Tests whether the current principal can write to the specified GCS bucket "
                        "by uploading a sequential test object (controlled_validN.txt) and verifying "
                        "it with storage.objects.get. The object is NOT auto-deleted — the user must "
                        "explicitly press 'Clean Up Test Object' after inspecting the resource."
                    ),
                    "required_params": ["bucket_name"],
                    "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                    "creates_resources": True,
                    "cleanup": "MANUAL — user must explicitly trigger cleanup via POST /api/validate/cleanup.",
                },
                {
                    "id": "gcs_read",
                    "name": "Cloud Storage Read Validation",
                    "description": (
                        "Tests whether the current principal can read from the specified GCS bucket. "
                        "If object_key is provided, calls storage.objects.get on that specific object. "
                        "Otherwise calls storage.objects.list on the validation prefix."
                    ),
                    "required_params": ["bucket_name"],
                    "optional_params": ["object_key"],
                    "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                    "creates_resources": False,
                    "cleanup": "No resources created — read-only operation.",
                },
                {
                    "id": "iam_sa_impersonation",
                    "name": "IAM Service Account Impersonation Validation",
                    "description": (
                        "Uses iam.serviceAccounts.testIamPermissions (non-mutating) to verify "
                        "whether the current principal has iam.serviceAccounts.getAccessToken "
                        "on the specified service account. No token is generated."
                    ),
                    "required_params": ["service_account_email"],
                    "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                    "creates_resources": False,
                    "cleanup": "No resources created — IAM testIamPermissions is read-only.",
                },
                {
                    "id": "compute_access",
                    "name": "Compute Access Validation",
                    "description": (
                        "Tests whether the current principal can call compute.instances.list "
                        "(or compute.instances.get if instance_name+zone provided). "
                        "Read-only — no VM state is changed."
                    ),
                    "required_params": ["gcp_project_id"],
                    "optional_params": ["instance_name", "zone"],
                    "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                    "creates_resources": False,
                    "cleanup": "No resources created — read-only operation.",
                },
                {
                    "id": "compute_control",
                    "name": "Compute Control Validation",
                    "description": (
                        "Tests whether the current principal can stop and start a designated "
                        "test VM instance (compute.instances.stop / compute.instances.start). "
                        "Requires explicit instance_name and zone. Only operates on RUNNING "
                        "instances. The original RUNNING state is always restored."
                    ),
                    "required_params": ["gcp_project_id", "instance_name", "zone"],
                    "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                    "creates_resources": False,
                    "cleanup": "State restoration is part of the validation sequence.",
                    "warning": (
                        "This will temporarily stop the designated test instance. "
                        "Only use against a specifically designated test instance."
                    ),
                },
            ],
        }

    # Default: AWS
    return {
        "provider": "aws",
        "techniques": [
            {
                "id": "s3_write",
                "name": "S3 Write Validation",
                "description": (
                    "Tests whether the current principal can write to the specified S3 bucket "
                    "by creating a sequential test object (controlled_validN.txt) and verifying "
                    "it exists via GetObject. The object is NOT auto-deleted — the user must "
                    "explicitly press 'Clean Up Test Object' after demonstrating the object."
                ),
                "required_params": ["bucket_name"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": True,
                "cleanup": "MANUAL — user must explicitly trigger cleanup via POST /api/validate/cleanup.",
            },
            {
                "id": "s3_read",
                "name": "S3 Read Validation",
                "description": (
                    "Tests whether the current principal can read from the specified S3 bucket. "
                    "If object_key is provided, calls s3:GetObject on that specific object. "
                    "Otherwise calls s3:ListObjectsV2 on the validation prefix."
                ),
                "required_params": ["bucket_name"],
                "optional_params": ["object_key"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": "No resources created — read-only operation.",
            },
            {
                "id": "iam_pass_role",
                "name": "IAM PassRole Validation",
                "description": (
                    "Uses the IAM Policy Simulator (non-mutating) to verify whether the current "
                    "principal has iam:PassRole permission on the specified role ARN. "
                    "No IAM resources are created, modified, or deleted."
                ),
                "required_params": ["role_arn"],
                "optional_params": ["target_service"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": "No resources created — IAM simulator is read-only.",
            },
            {
                "id": "ec2_access",
                "name": "EC2 Access Validation",
                "description": (
                    "Tests whether the current principal can call ec2:DescribeInstances. "
                    "If instance_id is provided, restricts the query to that specific instance. "
                    "This is a READ-ONLY validation — no instance state is changed."
                ),
                "required_params": [],
                "optional_params": ["instance_id"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": "No resources created — read-only operation.",
            },
            {
                "id": "ec2_control",
                "name": "EC2 Control Validation",
                "description": (
                    "Tests whether the current principal can stop and start a designated EC2 "
                    "test instance. Requires explicit instance_id. Requires confirmed=True. "
                    "The original running state is always restored. "
                    "Only operates on running instances."
                ),
                "required_params": ["instance_id"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": (
                    "State restoration is part of the validation sequence. "
                    "Original state (running) is restored after stop/start."
                ),
                "warning": (
                    "This will temporarily stop the designated test instance. "
                    "Only use against a specifically designated test instance."
                ),
            },
        ],
    }


# ---------------------------------------------------------------------------
# GET /api/validate/history — return persisted validation log
# ---------------------------------------------------------------------------

@router.get("/history")
def get_validation_history(provider: Optional[str] = None) -> dict[str, Any]:
    """Return persisted validation results from the validation log."""
    try:
        from api.services.report_service import _load_validation_log
        log = _load_validation_log()
        if provider:
            log = [e for e in log if e.get("provider", "aws") == provider]
        return {"results": log, "count": len(log)}
    except Exception as exc:
        logger.warning("Could not load validation history: %s", exc)
        return {"results": [], "count": 0, "error": str(exc)}
