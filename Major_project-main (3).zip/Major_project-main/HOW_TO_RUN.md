# How to Run — Multi-Cloud Pentest RL Platform

> **Phases 1–12 are fully implemented and tested (123 tests, 0 failures).**  
> This guide walks you through every step: environment setup, running scans, starting the UI, training the RL agent, and demo walkthrough.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Repository Layout](#2-repository-layout)
3. [Backend Setup](#3-backend-setup)
4. [Frontend Setup](#4-frontend-setup)
5. [Running the Application](#5-running-the-application)
6. [AWS Scan — Step by Step](#6-aws-scan--step-by-step)
7. [GCP Scan — Step by Step](#7-gcp-scan--step-by-step)
8. [RL Training and Evaluation](#8-rl-training-and-evaluation)
9. [Controlled Validation](#9-controlled-validation)
   - [9a. AWS Controlled Validation](#9a-aws-controlled-validation)
   - [9b. GCP Controlled Validation](#9b-gcp-controlled-validation)
   - [9c. Required GCP Permissions for Validation](#9c-required-gcp-permissions-for-validation)
   - [9d. Dry-Run / Execute / Cleanup flow](#9d-dry-run--execute--cleanup-flow)
   - [9e. Via the API](#9e-via-the-api)
10. [Running the Test Suite](#10-running-the-test-suite)
11. [PDF Report Generation](#11-pdf-report-generation)
12. [CLI — Standalone AWS Scan](#12-cli--standalone-aws-scan)
13. [Environment Variables](#13-environment-variables)
14. [Common Issues](#14-common-issues)

---

## 1. Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Python | 3.11+ | 3.12 confirmed working |
| Node.js | 18+ | For the React frontend |
| npm | 9+ | Bundled with Node.js |
| AWS credentials | — | Named profile or `AWS_*` env vars |
| GCP credentials | — | ADC (`gcloud auth`) or service account JSON |

**Optional (for real PDF output on Windows):**  
Install the [GTK3 Windows Runtime](https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer).  
Without GTK3, the PDF endpoint falls back to returning the HTML document (which you can print to PDF from your browser).

---

## 2. Repository Layout

```
Major_project/
├── HOW_TO_RUN.md           ← This file
├── IMPLEMENTATION_PLAN.md  ← Architecture reference
├── docker-compose.yml      ← LocalStack (dev/test only)
├── first_phase/            ← Prototype — NOT used
└── second_phase/           ← ACTIVE project
    ├── requirements.txt    ← Python dependencies for pip install
    ├── backend/            ← Python backend (FastAPI + scanners + RL)
    │   ├── .venv/          ← Virtual environment (already created)
    │   ├── api/            ← FastAPI routes and services
    │   ├── aws_pentest/    ← Real AWS scanner (IAM / S3 / EC2)
    │   ├── gcp_pentest/    ← GCP scanner (IAM / Storage / Compute)
    │   ├── providers/      ← AWSProvider + GCPProvider + BaseCloudProvider
    │   ├── models/         ← Shared Pydantic v2 models
    │   ├── env/            ← Gymnasium environment (backed by real graph)
    │   ├── rl/             ← PPO training and evaluation scripts
    │   └── tests/          ← 123 pytest tests (AWS + GCP)
    └── frontend/           ← React + TypeScript + Vite
        └── src/            ← All components and API client
```

---

## 3. Backend Setup

The virtual environment already exists at `second_phase/backend/.venv`.

### 3a. Install / verify Python dependencies

```powershell
cd second_phase/backend
.\.venv\Scripts\pip.exe install -r ..\requirements.txt
```

> The `.venv` already has all packages installed. Run the above only on a fresh clone or if packages are missing.

### 3b. Install GCP packages (if not yet installed)

```powershell
cd second_phase/backend
.\.venv\Scripts\pip.exe install `
  google-cloud-iam `
  google-cloud-storage `
  google-cloud-compute `
  google-auth `
  google-cloud-resource-manager
```

### 3c. Verify the backend imports

```powershell
cd second_phase/backend
.\.venv\Scripts\python.exe -c "from api.main import app; print('Backend OK')"
```

Expected output: `Backend OK`

---

## 4. Frontend Setup

Node modules are already installed. On a fresh clone:

```powershell
cd second_phase/frontend
npm install
```

---

## 5. Running the Application

Open **two terminals** simultaneously.

### Terminal 1 — Backend (FastAPI)

```powershell
cd second_phase/backend
.\.venv\Scripts\uvicorn.exe api.main:app --reload --port 8000
```

The backend will be available at `http://localhost:8000`.  
API docs (Swagger UI): `http://localhost:8000/docs`

### Terminal 2 — Frontend (Vite dev server)

```powershell
cd second_phase/frontend
npm run dev
```

The frontend will be available at `http://localhost:5173`.

### First Launch

On first load the browser shows a **cloud provider selection** modal:
- Choose **AWS** for an AWS scan
- Choose **GCP** for a GCP scan

Your selection is remembered in `localStorage`. Click **Switch** in the top bar to change providers.

---

## 6. AWS Scan — Step by Step

### 6a. Set up AWS credentials

Option A — Named profile in `~/.aws/credentials`:
```ini
[aws-pentest]
aws_access_key_id     = AKIA...
aws_secret_access_key = ...
region                = us-east-1
```

Option B — Environment variables:
```powershell
$env:AWS_ACCESS_KEY_ID     = "AKIA..."
$env:AWS_SECRET_ACCESS_KEY = "..."
$env:AWS_DEFAULT_REGION    = "us-east-1"
```

The account needs read-only IAM/S3/EC2/STS permissions. The included policy file documents the minimum required:
```
second_phase/backend/aws_pentest/aws_pentest_readonly_policy.json
```

### 6b. Scan via the UI

1. Open `http://localhost:5173`
2. Select **AWS** on the provider screen
3. Click the **🔍 Scan** tab
4. Enter your AWS profile name (leave blank to use the default credential chain)
5. Set the primary region (default: `us-east-1`)
6. Click **▶ Start AWS Scan**
7. The scan runs in the background; status updates every 3 seconds
8. When complete, the status shows summary stats (users, roles, buckets, findings)

### 6c. Scan via CLI (optional)

```powershell
cd second_phase/backend
.\.venv\Scripts\python.exe -m aws_pentest.run `
  --profile aws-pentest `
  --region us-east-1 `
  --output aws_pentest/last_report.json `
  --graph-json aws_pentest/last_graph.json
```

Flags:
- `--skip-privesc` — skip IAM Policy Simulator checks (faster)
- `--skip-s3-iam-xref` — skip per-bucket × per-principal IAM xref (faster)
- `--regions us-east-1,eu-west-1` — scan EC2 in multiple regions

---

## 7. GCP Scan — Step by Step

### 7a. Set up GCP credentials

Option A — Application Default Credentials (recommended):
```bash
gcloud auth application-default login
```

Option B — Service account JSON key file:
```powershell
$env:GOOGLE_APPLICATION_CREDENTIALS = "C:\path\to\service-account.json"
```

The service account needs at least these roles on the project:
- `roles/iam.securityReviewer`
- `roles/storage.objectViewer`
- `roles/compute.viewer`

### 7b. Scan via the UI

1. Open `http://localhost:5173`
2. Select **GCP** on the provider screen (or click **Switch** to change)
3. Click the **🔍 Scan** tab
4. Enter your **GCP Project ID** (required — e.g. `my-project-123456`)
5. Click **▶ Start GCP Scan**
6. Scan runs in background; status updates every 3 seconds

GCP scan output is saved to `second_phase/backend/gcp_pentest/last_report.json`.

---

## 8. RL Training and Evaluation

The RL agent trains against the real Phase 1 attack graph (written by the AWS scan).

### 8a. Run the AWS scan first

The RL environment loads `aws_pentest/last_graph.json`. Run the scan first (§6).

### 8b. Train the PPO agent

```powershell
cd second_phase/backend
.\.venv\Scripts\python.exe rl/train_with_logging.py
```

- Trains for 5000 timesteps using PPO
- Saves model to `ppo_cloud_agent.zip`
- Writes per-episode log to `rl/training_log.json`
- The RL tab in the frontend will show live reward curves after training

### 8c. Evaluate against baselines

```powershell
cd second_phase/backend
.\.venv\Scripts\python.exe rl/evaluate.py --episodes 200
```

Compares the PPO agent against:
- **Random policy** — uniform random edge selection
- **Shortest path** — always take action 0
- **Heuristic** — prefer PRIVESC_TO > CAN_ASSUME > CAN_WRITE_BUCKET > others

Output saved to `rl/evaluation_results.json`. Console summary printed at the end.

### 8d. View RL results in the UI

1. Open the **🤖 RL Agent** tab
2. Reward curve, success/fail bar chart, and step trace are shown

---

## 9. Controlled Validation

The validation system supports **both AWS and GCP** through the same three-level safety model:

```
READ_ONLY  — (default) describe what would be tested, no API call made
DRY_RUN    — show exact cloud API calls that WOULD be made, no execution
VALIDATE   — execute with explicit confirmation only
```

The correct panel is shown automatically based on the selected provider.
Switch providers using the **Switch** button in the top bar — the Validate tab updates immediately.

---

### 9a. AWS Controlled Validation

| Technique | Required fields | Creates resources? | Cleanup |
|---|---|---|---|
| **S3 Write Validation** | Bucket name | Yes — test object `controlled_validN.txt` | Manual — "Clean Up Test Object" button |
| **S3 Read Validation** | Bucket name | No | N/A |
| **IAM PassRole Validation** | Role ARN | No (IAM simulator only) | N/A |
| **EC2 Access Validation** | — (instance ID optional) | No | N/A |
| **EC2 Control Validation** | Instance ID | No — stops/starts only | Auto-restored (stop → start sequence) |

**Steps (UI):**

1. Select **AWS** as provider
2. Open the **🛡 Validate** tab — the AWS validation panel appears
3. Choose a technique from the dropdown
4. Fill in required fields
5. Click **🔍 Dry Run Preview** — shows exact AWS API calls, nothing executed
6. Click **⚡ Execute Validation** (appears after dry-run)
7. Confirm the dialog
8. Result shows `✓ VALIDATED` or `✗ DENIED` with full evidence and audit log
9. For S3 Write: the test object remains in S3. Click **🗑 Clean Up Test Object** when done.

---

### 9b. GCP Controlled Validation

| Technique | Required fields | Creates resources? | Cleanup |
|---|---|---|---|
| **Cloud Storage Write Validation** | GCS bucket name | Yes — test object `controlled_validN.txt` | Manual — "Clean Up Test Object" button |
| **Cloud Storage Read Validation** | GCS bucket name | No | N/A |
| **IAM Service Account Impersonation Validation** | Service account email, Project ID | No (`testIamPermissions` only) | N/A |
| **Compute Access Validation** | Project ID | No (read-only `instances.list`) | N/A |
| **Compute Control Validation** | Project ID, Instance name, Zone | No — stops/starts only | Auto-restored (stop → start sequence) |

**Steps (UI):**

1. Select **GCP** as provider (provider badge turns blue in the top bar)
2. Open the **🛡 Validate** tab — the **GCP** validation panel now appears (blue header, GCP labels)
3. Choose a technique from the dropdown
4. Fill in required fields (GCP Project ID is shown for relevant techniques)
5. Click **🔍 Dry Run Preview** — shows exact GCP API calls, nothing executed
6. Click **⚡ Execute Validation** (appears after dry-run)
7. Confirm the dialog (badge shows ☁ Google Cloud Platform)
8. Result shows `✓ VALIDATED` or `✗ DENIED` with full evidence and audit log
9. For Cloud Storage Write: the test object remains in GCS. Click **🗑 Clean Up Test Object** when done.

> **No GCP credentials needed for Dry Run** — READ_ONLY and DRY_RUN modes produce previews without making any real GCP API calls. Only VALIDATE mode requires valid credentials.

---

### 9c. Required GCP Permissions for Validation

The service account or ADC identity used for GCP validation needs only the permissions required by the specific technique being tested:

| Technique | Required GCP Permission |
|---|---|
| Cloud Storage Write | `storage.objects.create`, `storage.objects.get` on the target bucket |
| Cloud Storage Read | `storage.objects.list` or `storage.objects.get` on the target bucket |
| IAM SA Impersonation | `iam.serviceAccounts.testIamPermissions` on the target service account |
| Compute Access | `compute.instances.list` or `compute.instances.get` on the project |
| Compute Control | `compute.instances.stop`, `compute.instances.start` on the target instance |

For cleanup of a GCS Write validation, the identity also needs `storage.objects.delete`.

---

### 9d. Dry-Run / Execute / Cleanup flow

```
┌─────────────────────────────────────────────────────────────┐
│  Step 1 — DRY RUN                                           │
│  Click "🔍 Dry Run Preview"                                  │
│  • No API call is made to AWS or GCP                        │
│  • Preview shows exactly which API calls WOULD execute      │
│  • Shows target resource, operation, and cleanup behavior   │
└────────────────────────┬────────────────────────────────────┘
                         │ review preview
┌────────────────────────▼────────────────────────────────────┐
│  Step 2 — EXECUTE                                           │
│  Click "⚡ Execute Validation" → confirm dialog              │
│  • Controlled operation is performed on the target resource │
│  • Evidence is collected (bytes written, permissions found) │
│  • Result: VALIDATED / DENIED / ERROR                       │
└────────────────────────┬────────────────────────────────────┘
                         │ for write validations only
┌────────────────────────▼────────────────────────────────────┐
│  Step 3 — INSPECT (write validations only)                  │
│  Test object remains in S3 / GCS for inspection             │
│  • AWS: verify in S3 Console → s3://bucket/cloud-pentest-   │
│          validation/controlled_validN.txt                   │
│  • GCP: verify in GCS Console → gs://bucket/cloud-pentest- │
│          validation/controlled_validN.txt                   │
└────────────────────────┬────────────────────────────────────┘
                         │ when ready
┌────────────────────────▼────────────────────────────────────┐
│  Step 4 — CLEANUP (write validations only)                  │
│  Click "🗑 Clean Up Test Object"                              │
│  • Deletes only the specific controlled test object         │
│  • Verifies deletion                                        │
│  • Cannot accidentally delete existing user resources       │
└─────────────────────────────────────────────────────────────┘
```

Validation results are persisted to `aws_pentest/validation_log.json` and tagged with `"provider": "aws"` or `"provider": "gcp"`.

---

### 9e. Via the API

**AWS — Dry run:**
```bash
curl -X POST http://localhost:8000/api/validate \
  -H "Content-Type: application/json" \
  -d '{
    "finding_id": "test-001",
    "technique":  "s3_write",
    "mode":       "DRY_RUN",
    "confirmed":  false,
    "provider":   "aws",
    "bucket_name":"my-bucket",
    "region":     "us-east-1"
  }'
```

**GCP — Dry run (no credentials needed):**
```bash
curl -X POST http://localhost:8000/api/validate \
  -H "Content-Type: application/json" \
  -d '{
    "finding_id":    "test-002",
    "technique":     "gcs_write",
    "mode":          "DRY_RUN",
    "confirmed":     false,
    "provider":      "gcp",
    "bucket_name":   "my-gcs-bucket",
    "gcp_project_id":"my-project-123"
  }'
```

**GCP — Execute (requires credentials + confirmed=true):**
```bash
curl -X POST http://localhost:8000/api/validate \
  -H "Content-Type: application/json" \
  -d '{
    "finding_id":    "test-002",
    "technique":     "gcs_write",
    "mode":          "VALIDATE",
    "confirmed":     true,
    "provider":      "gcp",
    "bucket_name":   "my-gcs-bucket",
    "gcp_project_id":"my-project-123"
  }'
```

**GCP — Cleanup after a write validation:**
```bash
curl -X POST http://localhost:8000/api/validate/cleanup \
  -H "Content-Type: application/json" \
  -d '{
    "run_id":   "abc12345",
    "provider": "gcp",
    "gcp_project_id": "my-project-123"
  }'
```

**List techniques for a provider:**
```bash
curl http://localhost:8000/api/validate/techniques?provider=gcp
curl http://localhost:8000/api/validate/techniques?provider=aws
```

**View validation history (filter by provider):**
```bash
curl http://localhost:8000/api/validate/history?provider=gcp
curl http://localhost:8000/api/validate/history?provider=aws
```

Validated results are written to `aws_pentest/validation_log.json` and appear in the next report.

---

## 10. Running the Test Suite

```powershell
cd second_phase/backend
.\.venv\Scripts\python.exe -m pytest tests/ -v
```

Expected: **123 passed, 0 failed** (confirmed working).

Run specific test files:
```powershell
# AWS tests only
.\.venv\Scripts\python.exe -m pytest tests/aws/ -v

# GCP tests only
.\.venv\Scripts\python.exe -m pytest tests/gcp/ -v

# Specific test class
.\.venv\Scripts\python.exe -m pytest tests/aws/test_validation.py -v
```

---

## 11. PDF Report Generation

### Via the UI

1. Click the **📋 Report** tab
2. Click **Generate Report** — builds the full report from scan data
3. Click **Download PDF** — downloads the report

> **Windows Note:** WeasyPrint requires the GTK3 runtime to generate real PDFs.  
> Without GTK3 installed, the PDF endpoint returns the HTML report instead (which you can print to PDF from Chrome: Ctrl+P → Save as PDF).  
> GTK3 installer: https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer  
> On Linux/macOS, install `pango` / `libpango` and WeasyPrint will generate real PDFs.

### Via the API

```bash
# Generate and fetch JSON report
curl http://localhost:8000/api/report

# Download HTML report
curl http://localhost:8000/api/report/html > report.html

# Download PDF (or HTML fallback on Windows)
curl http://localhost:8000/api/report/pdf -o report.pdf
```

---

## 12. CLI — Standalone AWS Scan

Run the full scan without starting the API server:

```powershell
cd second_phase/backend
.\.venv\Scripts\python.exe -m aws_pentest.run \
  --profile YOUR_PROFILE \
  --region us-east-1 \
  --output aws_pentest/last_report.json \
  --graph-json aws_pentest/last_graph.json \
  --graphml aws_pentest/last_graph.graphml
```

The GraphML file can be opened in **Gephi**, **yEd**, or **Cytoscape** for interactive graph exploration.

---

## 13. Environment Variables

| Variable | Required | Description |
|---|---|---|
| `AWS_PROFILE` | No | AWS named credential profile |
| `AWS_ACCESS_KEY_ID` | No | AWS access key (alternative to profile) |
| `AWS_SECRET_ACCESS_KEY` | No | AWS secret key |
| `AWS_DEFAULT_REGION` | No | Default AWS region |
| `GOOGLE_APPLICATION_CREDENTIALS` | No | Path to GCP service account JSON key |
| `GOOGLE_CLOUD_PROJECT` | No | GCP project ID (used if not passed explicitly) |

No credentials are hardcoded in any source file. All credentials flow through the standard SDK credential chains.

---

## 14. Common Issues

### "No module named 'google.cloud.resourcemanager_v3'"

```powershell
cd second_phase/backend
.\.venv\Scripts\pip.exe install google-cloud-resource-manager
```

### "Cannot load library 'libgobject-2.0-0'" (WeasyPrint)

This is the GTK3 dependency on Windows. Options:
1. Install [GTK3 Windows Runtime](https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer)
2. Use the HTML report endpoint instead (`/api/report/html`)
3. On Linux: `sudo apt-get install libpango-1.0-0 libharfbuzz0b libpangoft2-1.0-0`

### "No credentials found" for AWS

```powershell
aws sts get-caller-identity --profile YOUR_PROFILE
```
Ensure the profile exists in `~/.aws/credentials` or set `AWS_*` environment variables.

### "GCP authentication error" / "No project ID"

1. Run `gcloud auth application-default login`
2. Or set `$env:GOOGLE_APPLICATION_CREDENTIALS = "path/to/key.json"` plus `$env:GOOGLE_CLOUD_PROJECT = "your-project-id"`

### "Backend offline" indicator in the UI

Start the backend:
```powershell
cd second_phase/backend
.\.venv\Scripts\uvicorn.exe api.main:app --reload --port 8000
```

### Scan hangs or takes very long

The IAM Policy Simulator (`iam:SimulatePrincipalPolicy`) rate-limits at ~100 calls/batch. Use:
- `--skip-privesc` to skip the slow simulator phase
- `--skip-s3-iam-xref` to skip per-bucket × per-principal IAM checks

These are also checkboxes in the Scan UI.

### "ppo_cloud_agent.zip not found" in evaluate.py

Train the agent first:
```powershell
cd second_phase/backend
.\.venv\Scripts\python.exe rl/train_with_logging.py
```

### "Graph is empty / no nodes" in Attack Graph tab

Run a scan first. The graph requires `aws_pentest/last_graph.json` to exist.

### "GCP credential error" during GCP VALIDATE

DRY_RUN and READ_ONLY do **not** need credentials — only `VALIDATE` does.
For `VALIDATE`, ensure credentials are configured:
```powershell
# Option A — Application Default Credentials
gcloud auth application-default login

# Option B — Service account key file
$env:GOOGLE_APPLICATION_CREDENTIALS = "C:\path\to\key.json"
```
Then retry — `DRY_RUN` and `READ_ONLY` always work without credentials.

### "Validate tab shows AWS UI when GCP is selected"

1. Click **Switch** in the top bar
2. Re-select **GCP** — the badge turns blue and the Validate tab immediately shows the GCP panel
3. Selection is saved in `localStorage`; it persists across page refreshes

---

## Quick Start Summary

```powershell
# Terminal 1 — Backend
cd second_phase/backend
.\.venv\Scripts\uvicorn.exe api.main:app --reload --port 8000

# Terminal 2 — Frontend
cd second_phase/frontend
npm run dev
```

Then open `http://localhost:5173` in your browser.

**Demo flow:**
1. Select **AWS** → fill in profile/region → click **▶ Start AWS Scan**
2. Go to **🗺 Attack Graph** → view confirmed edges and node details
3. Go to **🛡 Validate** → choose a technique → Dry Run → review → Execute
4. Go to **📋 Report** → Generate Report → Download PDF
5. Train RL: `python rl/train_with_logging.py` then view in **🤖 RL Agent** tab
