import React, { useState, useEffect } from 'react';
import { AppProvider, useAppContext } from './AppContext';
import { AttackGraph }      from './components/AttackGraph';
import { RLVisualization }  from './components/RLVisualization';
import { PentestReport }    from './components/PentestReport';
import { ScanPanel }        from './components/ScanPanel';
import { ValidatePanel }    from './components/ValidatePanel';
import { CloudSelect }      from './components/CloudSelect';
import type { CloudProvider } from './components/CloudSelect';
import { fetchHealth }      from './api/client';
import { COLORS }           from './constants';

const TABS = [
  { id: 'graph',    label: '🗺 Attack Graph'   },
  { id: 'rl',       label: '🤖 RL Agent'       },
  { id: 'report',   label: '📋 Report'         },
  { id: 'validate', label: '🛡 Validate'        },
  { id: 'scan',     label: '🔍 Scan'           },
];

const PROVIDER_LABELS: Record<CloudProvider, string> = {
  aws: 'AWS',
  gcp: 'GCP',
};

const PROVIDER_COLORS: Record<CloudProvider, string> = {
  aws: '#ea580c',
  gcp: '#2563eb',
};

/** Inner shell — consumes AppContext, renders tabs + provider switcher. */
const AppShell: React.FC = () => {
  const { provider, setProvider } = useAppContext();
  const [activeTab, setActiveTab]           = useState<string>('graph');
  const [backendOk, setBackendOk]           = useState<boolean | null>(null);
  const [showProviderSelect, setShowProviderSelect] = useState<boolean>(!provider);

  // Sync modal visibility when provider changes externally (e.g. first load with no saved value)
  useEffect(() => {
    if (!provider) setShowProviderSelect(true);
  }, [provider]);

  // Health check: poll with retries so a slow backend startup doesn't
  // permanently show "Backend offline".  Retries up to 5 times (10 s total)
  // then settles.  Once online, a periodic re-check every 30 s keeps the
  // indicator live without flooding the server.
  useEffect(() => {
    let cancelled = false;
    let retryCount = 0;
    const MAX_RETRIES = 5;
    const RETRY_DELAY_MS = 2000;   // 2 s between retries on startup
    const POLL_INTERVAL_MS = 30000; // 30 s steady-state polling
    let pollTimer: ReturnType<typeof setTimeout> | null = null;

    const check = async () => {
      try {
        await fetchHealth();
        if (!cancelled) {
          // Reset retry window so a future outage gets the full grace period again.
          retryCount = 0;
          setBackendOk(true);
          // Steady-state: recheck every 30 s so the indicator stays current
          pollTimer = setTimeout(check, POLL_INTERVAL_MS);
        }
      } catch (err: unknown) {
        if (cancelled) return;

        // Distinguish a real connection failure from an HTTP-level error.
        // axios throws AxiosError; if the response field is set the server
        // responded (reachable) — only treat connection-refused / network
        // errors (no response) as "offline".
        const hasResponse = (err as { response?: unknown }).response !== undefined;
        if (hasResponse) {
          // Server responded with a non-2xx status on /api/health — still reachable.
          // Treat as online so a momentary 5xx doesn't flip the indicator off.
          retryCount = 0;
          setBackendOk(true);
          pollTimer = setTimeout(check, POLL_INTERVAL_MS);
          return;
        }

        retryCount += 1;
        if (retryCount <= MAX_RETRIES) {
          // Still in startup / transient-error window — retry quickly
          pollTimer = setTimeout(check, RETRY_DELAY_MS);
        } else {
          // Exhausted retries — mark offline but keep retrying slowly
          setBackendOk(false);
          pollTimer = setTimeout(check, POLL_INTERVAL_MS);
        }
      }
    };

    check();

    return () => {
      cancelled = true;
      if (pollTimer !== null) clearTimeout(pollTimer);
    };
  }, []);

  const handleProviderSelect = (p: CloudProvider) => {
    setProvider(p);
    setShowProviderSelect(false);
  };

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', height: '100vh',
      fontFamily: '-apple-system,"Segoe UI",system-ui,sans-serif',
      fontSize: 14, color: COLORS.text, background: '#fff',
    }}>

      {/* Cloud provider selection modal */}
      {showProviderSelect && <CloudSelect onSelect={handleProviderSelect} />}

      {/* Top bar */}
      <div style={{
        display: 'flex', alignItems: 'center', padding: '0 20px', height: 52,
        borderBottom: `1px solid ${COLORS.border}`, background: '#fff',
        flexShrink: 0, gap: 24,
      }}>
        <div style={{ fontWeight: 800, fontSize: 15, letterSpacing: -0.5 }}>
          ☁ Cloud Pentest RL
        </div>

        {/* Tabs */}
        <nav style={{ display: 'flex', gap: 2, flex: 1 }}>
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                padding: '6px 16px', border: 'none', cursor: 'pointer',
                borderRadius: 6, fontSize: 13, fontWeight: 600,
                background: activeTab === tab.id ? COLORS.accent : 'transparent',
                color: activeTab === tab.id ? '#fff' : COLORS.muted,
                transition: 'background 0.15s',
              }}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {/* Provider badge + switch button */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {provider && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{
                fontSize: 11, fontWeight: 700,
                background: PROVIDER_COLORS[provider],
                color: '#fff', padding: '2px 8px', borderRadius: 10,
              }}>
                {PROVIDER_LABELS[provider]}
              </span>
              <button
                onClick={() => setShowProviderSelect(true)}
                style={{
                  fontSize: 11, color: COLORS.muted, background: 'none',
                  border: `1px solid ${COLORS.border}`, borderRadius: 4,
                  padding: '2px 7px', cursor: 'pointer',
                }}
              >
                Switch
              </button>
            </div>
          )}

          {/* Backend status */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: COLORS.muted }}>
            <span style={{
              width: 8, height: 8, borderRadius: '50%', display: 'inline-block',
              background: backendOk === null ? COLORS.muted : backendOk ? COLORS.success : COLORS.danger,
            }} />
            {backendOk === null ? 'Connecting…' : backendOk ? 'Backend connected' : 'Backend offline'}
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        <div style={{ height: '100%', display: activeTab === 'graph'    ? 'flex' : 'none', flexDirection: 'column' }}>
          <AttackGraph />
        </div>
        <div style={{ height: '100%', display: activeTab === 'rl'       ? 'block' : 'none', overflowY: 'auto' }}>
          <RLVisualization />
        </div>
        <div style={{ height: '100%', display: activeTab === 'report'   ? 'block' : 'none', overflowY: 'auto' }}>
          <PentestReport />
        </div>
        <div style={{ height: '100%', display: activeTab === 'validate' ? 'block' : 'none', overflowY: 'auto' }}>
          <ValidatePanel />
        </div>
        <div style={{ height: '100%', display: activeTab === 'scan'     ? 'block' : 'none', overflowY: 'auto' }}>
          <ScanPanel />
        </div>
      </div>
    </div>
  );
};

/** Root — wraps everything in the context provider. */
export const App: React.FC = () => (
  <AppProvider>
    <AppShell />
  </AppProvider>
);
