import React, { useEffect, useState, useCallback } from 'react';
import {
  LineChart, Line, XAxis, YAxis, Tooltip,
  CartesianGrid, ResponsiveContainer, ReferenceLine,
} from 'recharts';
import {
  fetchRLStatus, fetchRLEpisodes, fetchRLHistory,
  fetchRLAttackPath, startRLTraining, fetchRLTrainStatus,
  runRLInference,
} from '../api/client';
import { COLORS } from '../constants';
import { Spinner, ErrorBox, Card, StatCard } from './common/Widgets';
import { useAppContext } from '../AppContext';

// ── Attack Path Visualization ─────────────────────────────────────────────

const AttackPathViz: React.FC<{ data: any }> = ({ data }) => {
  if (!data || !data.path || data.path.length === 0) {
    const msg = data?.message || 'No attack path available. Train the RL model first.';
    return (
      <Card style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>RL Attack Path</div>
        <div style={{ color: COLORS.muted, fontSize: 13 }}>{msg}</div>
        {data?.status === 'no_model' && (
          <div style={{ marginTop: 8, fontSize: 12, color: COLORS.muted }}>
            Click <strong>Train Model</strong> above to train the RL agent on the scanned graph.
          </div>
        )}
      </Card>
    );
  }

  const path: any[] = data.path;

  return (
    <Card style={{ marginBottom: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <div style={{ fontSize: 13, fontWeight: 700 }}>RL Attack Path Analysis</div>
        <div style={{ display: 'flex', gap: 8, fontSize: 12 }}>
          <span style={{ color: COLORS.muted }}>
            Length: <strong>{data.path_length ?? path.length}</strong>
          </span>
          <span style={{ color: COLORS.muted }}>
            Reward: <strong style={{ color: COLORS.accent }}>{(data.total_reward ?? 0).toFixed(2)}</strong>
          </span>
          {data.success && (
            <span style={{ color: COLORS.success, fontWeight: 700 }}>✓ Goal reached</span>
          )}
        </div>
      </div>

      {/* Path visual */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 4, marginBottom: 12 }}>
        {path.map((step: any, i: number) => {
          const label = (step.display_name || step.node_id || '?').split('/').pop() || '?';
          return (
            <React.Fragment key={i}>
              <div style={{
                background: step.node_type === 'Capability' ? '#fef2f2' : '#e0f2fe',
                border: `1px solid ${step.node_type === 'Capability' ? '#fca5a5' : '#7dd3fc'}`,
                borderRadius: 6, padding: '4px 10px', fontSize: 12,
              }}>
                <div style={{ fontWeight: 700, color: step.node_type === 'Capability' ? COLORS.danger : '#0369a1' }}>
                  {label.length > 25 ? label.slice(0, 22) + '…' : label}
                </div>
                <div style={{ fontSize: 10, color: COLORS.muted }}>{step.node_type}</div>
              </div>
              {i < path.length - 1 && (
                <span style={{ color: COLORS.muted, fontSize: 11, margin: '0 2px' }}>
                  → {step.action || ''}
                </span>
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Data source notice */}
      <div style={{ fontSize: 11, color: COLORS.muted, borderTop: `1px solid ${COLORS.border}`, paddingTop: 6 }}>
        Source: scanner graph ({data.graph_source || 'unknown'}) · Provider: {(data.provider || 'aws').toUpperCase()}
        · Path derived from real RL inference on actual scan data
      </div>
    </Card>
  );
};

// ── Training Controls ─────────────────────────────────────────────────────

const TrainingControls: React.FC<{
  provider: string;
  onTrainComplete: () => void;
}> = ({ provider, onTrainComplete }) => {
  const [trainStatus, setTrainStatus] = useState<any>(null);
  const [polling, setPolling] = useState(false);

  const startTraining = async () => {
    try {
      await startRLTraining({ provider, timesteps: 20000 });
      setPolling(true);
    } catch (e: any) {
      setTrainStatus({ status: 'error', message: e.message });
    }
  };

  const runInference = async () => {
    try {
      const r = await runRLInference({ provider });
      setTrainStatus({ status: 'inference_complete', message: 'Inference complete.', ...r.data });
      onTrainComplete();
    } catch (e: any) {
      setTrainStatus({ status: 'error', message: e.message });
    }
  };

  useEffect(() => {
    if (!polling) return;
    const iv = setInterval(async () => {
      try {
        const r = await fetchRLTrainStatus();
        setTrainStatus(r.data);
        if (r.data.status === 'complete' || r.data.status === 'error') {
          setPolling(false);
          if (r.data.status === 'complete') onTrainComplete();
        }
      } catch (_) {}
    }, 3000);
    return () => clearInterval(iv);
  }, [polling, onTrainComplete]);

  const isRunning = trainStatus?.status === 'running' || polling;

  return (
    <Card style={{ marginBottom: 20 }}>
      <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>RL Training Controls</div>
      <div style={{ fontSize: 12, color: COLORS.muted, marginBottom: 12 }}>
        The RL agent trains on the actual scanner-generated graph for the selected provider.
        Training discovers attack paths through real IAM / permission relationships.
      </div>

      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
        <button
          onClick={startTraining}
          disabled={isRunning}
          style={{
            padding: '7px 18px', borderRadius: 6, border: 'none',
            background: isRunning ? COLORS.border : COLORS.accent,
            color: isRunning ? COLORS.muted : '#fff',
            cursor: isRunning ? 'not-allowed' : 'pointer', fontSize: 13, fontWeight: 600,
          }}
        >
          {isRunning ? '⏳ Training…' : '▶ Train Model'}
        </button>
        <button
          onClick={runInference}
          disabled={isRunning}
          style={{
            padding: '7px 18px', borderRadius: 6,
            border: `1px solid ${COLORS.accent}`,
            background: 'transparent',
            color: isRunning ? COLORS.muted : COLORS.accent,
            cursor: isRunning ? 'not-allowed' : 'pointer', fontSize: 13,
          }}
        >
          Run Inference
        </button>
      </div>

      {trainStatus && (
        <div style={{
          padding: '8px 12px', borderRadius: 6, fontSize: 12,
          background: trainStatus.status === 'error' ? '#fef2f2' :
                      trainStatus.status === 'complete' ? '#f0fdf4' : COLORS.surface,
          border: `1px solid ${trainStatus.status === 'error' ? '#fca5a5' :
                               trainStatus.status === 'complete' ? '#86efac' : COLORS.border}`,
        }}>
          <strong>{trainStatus.status?.toUpperCase()}</strong>{' '}
          {trainStatus.message}
          {trainStatus.metrics && (
            <span style={{ color: COLORS.muted, marginLeft: 8 }}>
              · Episodes: {trainStatus.metrics.total_episodes}
              · Avg reward: {(trainStatus.metrics.avg_reward ?? 0).toFixed(2)}
              · Success rate: {((trainStatus.metrics.success_rate ?? 0) * 100).toFixed(0)}%
            </span>
          )}
        </div>
      )}
    </Card>
  );
};

// ── Step history ─────────────────────────────────────────────────────────

const StepRow: React.FC<{ step: any; index: number }> = ({ step, index }) => (
  <div style={{
    display: 'flex', gap: 12, padding: '8px 12px',
    background: index % 2 === 0 ? '#fff' : COLORS.surface,
    borderBottom: `1px solid ${COLORS.border}`,
    alignItems: 'flex-start',
  }}>
    <div style={{ minWidth: 28, color: COLORS.muted, fontSize: 12, paddingTop: 2 }}>
      {step.step ?? index}
    </div>
    <div style={{ flex: 1 }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 3 }}>
        <span style={{ fontSize: 12, fontWeight: 700 }}>
          {step.relation || `Action ${step.action}`}
        </span>
        {step.is_goal && (
          <span style={{ fontSize: 10, background: '#f0fdf4', color: '#16a34a', padding: '1px 6px', borderRadius: 6, border: '1px solid #86efac' }}>
            GOAL
          </span>
        )}
        <span style={{
          fontSize: 11, fontWeight: 700,
          color: step.reward >= 0 ? COLORS.success : COLORS.danger,
        }}>
          {step.reward >= 0 ? '+' : ''}{typeof step.reward === 'number' ? step.reward.toFixed(1) : step.reward}
        </span>
      </div>
      {step.node && (
        <div style={{ fontSize: 11, color: COLORS.muted }}>
          Node: <code style={{ fontSize: 11 }}>{String(step.node).split('/').pop()}</code>
        </div>
      )}
    </div>
  </div>
);

// ── Main component ────────────────────────────────────────────────────────

export const RLVisualization: React.FC = () => {
  const { provider } = useAppContext();
  const prov = provider ?? 'aws';

  const [status, setStatus]         = useState<any>(null);
  const [episodes, setEpisodes]     = useState<any[]>([]);
  const [history, setHistory]       = useState<any[]>([]);
  const [attackPath, setAttackPath] = useState<any>(null);
  const [selectedEp, setSelectedEp] = useState<number | null>(null);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [sRes, eRes, apRes] = await Promise.all([
        fetchRLStatus(prov),
        fetchRLEpisodes(prov),
        fetchRLAttackPath(prov),
      ]);
      setStatus(sRes.data);
      setEpisodes(eRes.data ?? []);
      setAttackPath(apRes.data);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [prov]);

  useEffect(() => { load(); }, [load]);

  const loadHistory = useCallback(async (ep?: number) => {
    try {
      const r = await fetchRLHistory(ep, prov);
      setHistory(r.data ?? []);
    } catch (_) {}
  }, [prov]);

  useEffect(() => {
    if (episodes.length) {
      const ep = selectedEp ?? episodes[episodes.length - 1]?.episode;
      loadHistory(ep);
    }
  }, [episodes, selectedEp, loadHistory]);

  const rewardData = episodes.map((ep) => ({
    episode: ep.episode,
    reward: parseFloat((ep.totalReward ?? 0).toFixed(1)),
    avg: parseFloat((ep.avgReward ?? 0).toFixed(1)),
  }));

  if (loading) return <Spinner />;
  if (error)   return <div style={{ padding: 20 }}><ErrorBox message={error} /></div>;

  const noData = !status?.is_trained && episodes.length === 0;

  return (
    <div style={{ padding: '20px 24px', overflowY: 'auto', height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <strong style={{ fontSize: 17 }}>
          RL Agent — {prov.toUpperCase()} Attack Path Analysis
        </strong>
        <button onClick={load} style={{
          padding: '5px 14px', borderRadius: 6,
          border: `1px solid ${COLORS.border}`,
          background: COLORS.accent, color: '#fff', cursor: 'pointer', fontSize: 13,
        }}>
          ↺ Refresh
        </button>
      </div>

      {/* Training controls */}
      <TrainingControls provider={prov} onTrainComplete={load} />

      {/* Attack Path */}
      <AttackPathViz data={attackPath} />

      {noData ? (
        <Card>
          <div style={{ color: COLORS.muted, fontSize: 14, textAlign: 'center', padding: 32 }}>
            No training data found. Click <strong>Train Model</strong> to train on the{' '}
            {prov.toUpperCase()} scan graph.
          </div>
        </Card>
      ) : (
        <>
          {/* Status summary */}
          {status && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
              <StatCard label="Episodes" value={episodes.length} />
              <StatCard label="Total Timesteps" value={status.total_timesteps ?? 0} />
              <StatCard label="Last Reward" value={(status.reward ?? 0).toFixed(1)} accent={COLORS.accent} />
              <StatCard label="Cumulative Reward" value={(status.cumulative_reward ?? 0).toFixed(1)} accent={COLORS.success} />
            </div>
          )}

          {/* Reward chart */}
          {rewardData.length > 0 && (
            <Card style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Reward per Episode</div>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={rewardData} margin={{ top: 4, right: 16, bottom: 32, left: 48 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
                  <XAxis
                    dataKey="episode"
                    tick={{ fontSize: 11 }}
                    label={{
                      value: 'Training Episode',
                      position: 'insideBottom',
                      offset: -18,
                      fontSize: 12,
                      fill: COLORS.muted,
                    }}
                  />
                  <YAxis
                    tick={{ fontSize: 11 }}
                    label={{
                      value: 'Episode Reward',
                      angle: -90,
                      position: 'insideLeft',
                      offset: 12,
                      fontSize: 12,
                      fill: COLORS.muted,
                    }}
                  />
                  <Tooltip
                    formatter={(value: unknown, name: unknown) => [
                      typeof value === 'number' ? value.toFixed(2) : String(value),
                      name === 'reward' ? 'Total Reward' : 'Avg Reward/Step',
                    ]}
                    labelFormatter={(label: unknown) => `Episode ${label}`}
                  />
                  <ReferenceLine y={0} stroke={COLORS.muted} strokeDasharray="4 2" />
                  <Line type="monotone" dataKey="reward" stroke={COLORS.accent} dot={false} strokeWidth={2} name="Total Reward" />
                  <Line type="monotone" dataKey="avg" stroke={COLORS.success} dot={false} strokeWidth={1.5} strokeDasharray="4 2" name="Avg Reward/Step" />
                </LineChart>
              </ResponsiveContainer>
              <div style={{ display: 'flex', gap: 16, justifyContent: 'center', fontSize: 11, color: COLORS.muted, marginTop: 4 }}>
                <span><span style={{ color: COLORS.accent, fontWeight: 700 }}>—</span> Total episode reward (sum of all step rewards)</span>
                <span><span style={{ color: COLORS.success, fontWeight: 700 }}>- -</span> Avg reward per step</span>
              </div>
            </Card>
          )}

          {/* Episode history */}
          {episodes.length > 0 && (
            <Card style={{ marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>Step Trace</div>
                <select
                  value={selectedEp ?? ''}
                  onChange={(e) => {
                    const v = parseInt(e.target.value);
                    setSelectedEp(isNaN(v) ? null : v);
                    loadHistory(isNaN(v) ? undefined : v);
                  }}
                  style={{ padding: '4px 8px', borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 12 }}
                >
                  {episodes.map((ep) => (
                    <option key={ep.episode} value={ep.episode}>
                      Episode {ep.episode} (reward {(ep.totalReward ?? 0).toFixed(1)}{ep.success ? ' ✓' : ''})
                    </option>
                  ))}
                </select>
              </div>
              <div style={{ maxHeight: 360, overflowY: 'auto', border: `1px solid ${COLORS.border}`, borderRadius: 6 }}>
                <div style={{
                  background: COLORS.surface, borderBottom: `1px solid ${COLORS.border}`,
                  padding: '6px 12px', display: 'grid', gridTemplateColumns: '28px 1fr',
                  gap: 12, fontSize: 11, fontWeight: 700, color: COLORS.muted,
                }}>
                  <span>#</span><span>Action / Result</span>
                </div>
                {history.map((step, i) => <StepRow key={i} step={step} index={i} />)}
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  );
};
