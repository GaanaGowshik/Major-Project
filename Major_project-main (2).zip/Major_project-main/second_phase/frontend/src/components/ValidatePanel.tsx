/**
 * ValidatePanel — Controlled Finding Validation UI.
 *
 * Implements the three-level safety model:
 *   READ_ONLY  — describe what would be tested (default)
 *   DRY_RUN    — show exact AWS calls, no execution
 *   VALIDATE   — execute with user confirmation after dry-run preview
 *
 * Safety UX invariants:
 *   1. Technique + params are filled in first.
 *   2. Always start with DRY_RUN to show preview.
 *   3. VALIDATE button only appears after dry-run completes.
 *   4. A confirmation dialog appears before VALIDATE executes.
 *   5. result.confirmed is true ONLY when execution succeeded.
 *   6. S3 Write: object is NOT auto-deleted — user must press "Clean Up Test Object".
 *   7. EC2 Control: requires explicit confirmation warning before execution.
 *   8. "NOT PERFORMED" is shown for unexecuted actions.
 */

import React, { useState } from 'react';
import { COLORS } from '../constants';
import { validateFinding, cleanupS3Write, fetchGraphExportUrl } from '../api/client';
import type { ValidateRequest, CleanupRequest } from '../api/client';

type Technique = 's3_write' | 's3_read' | 'iam_pass_role' | 'ec2_access' | 'ec2_control';
type Mode = 'READ_ONLY' | 'DRY_RUN' | 'VALIDATE';

interface ValidationResult {
  finding_id: string;
  technique: string;
  mode: string;
  status: string;
  confirmed: boolean;
  description: string;
  dry_run_preview: string[];
  evidence: Record<string, unknown>[];
  cleanup_done: boolean;
  cleanup_status: string;
  audit_log: Record<string, unknown>[];
  run_id?: string;
  s3_bucket?: string;
  s3_object_key?: string;
  error?: string;
}

interface CleanupResult {
  run_id: string;
  bucket?: string;
  object_key?: string;
  status: string;
  cleanup_status: string;
  cleanup_done?: boolean;
  deletion_verified?: boolean;
  description: string;
  error?: string;
}

const TECHNIQUE_LABELS: Record<Technique, string> = {
  s3_write:     'S3 Write Validation',
  s3_read:      'S3 Read Validation',
  iam_pass_role: 'IAM PassRole Validation',
  ec2_access:   'EC2 Access Validation',
  ec2_control:  'EC2 Control Validation',
};

const STATUS_STYLES: Record<string, { color: string; label: string }> = {
  success:          { color: '#16a34a', label: '✓ VALIDATED' },
  failure:          { color: '#ea580c', label: '✗ DENIED (access blocked)' },
  dry_run_preview:  { color: '#2563eb', label: 'DRY RUN PREVIEW' },
  not_performed:    { color: '#ca8a04', label: 'NOT PERFORMED' },
  error:            { color: '#dc2626', label: 'ERROR' },
};

const inputStyle: React.CSSProperties = {
  width: '100%', padding: '7px 10px',
  border: `1px solid ${COLORS.border}`,
  borderRadius: 6, fontSize: 13, boxSizing: 'border-box',
};

export const ValidatePanel: React.FC = () => {
  const [technique, setTechnique]         = useState<Technique>('s3_write');
  const [findingId, setFindingId]         = useState('');
  const [bucketName, setBucketName]       = useState('');
  const [objectKey, setObjectKey]         = useState('');
  const [roleArn, setRoleArn]             = useState('');
  const [targetService, setTargetService] = useState('');
  const [instanceId, setInstanceId]       = useState('');
  const [profile, setProfile]             = useState('');
  const [region, setRegion]               = useState('us-east-1');
  const [ec2Confirmed, setEc2Confirmed]   = useState(false);

  const [loading, setLoading]                   = useState(false);
  const [cleanupLoading, setCleanupLoading]     = useState(false);
  const [dryRunResult, setDryRunResult]         = useState<ValidationResult | null>(null);
  const [validateResult, setValidateResult]     = useState<ValidationResult | null>(null);
  const [cleanupResult, setCleanupResult]       = useState<CleanupResult | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [error, setError]   = useState<string | null>(null);

  // Reset per-technique state when technique changes
  const handleTechniqueChange = (t: Technique) => {
    setTechnique(t);
    setDryRunResult(null);
    setValidateResult(null);
    setCleanupResult(null);
    setError(null);
    setEc2Confirmed(false);
  };

  const buildRequest = (mode: Mode, confirmed = false): ValidateRequest => {
    const req: ValidateRequest = {
      finding_id: findingId || `manual-${technique}`,
      technique,
      mode,
      confirmed,
      profile: profile || undefined,
      region: region || 'us-east-1',
    };
    if (technique === 's3_write' || technique === 's3_read') {
      req.bucket_name = bucketName || undefined;
    }
    if (technique === 's3_read' && objectKey) {
      req.object_key = objectKey;
    }
    if (technique === 'iam_pass_role') {
      req.role_arn = roleArn || undefined;
      if (targetService) req.target_service = targetService;
    }
    if (technique === 'ec2_access' || technique === 'ec2_control') {
      req.instance_id = instanceId || undefined;
    }
    return req;
  };

  const handleDryRun = async () => {
    setLoading(true);
    setError(null);
    setDryRunResult(null);
    setValidateResult(null);
    setCleanupResult(null);
    try {
      const resp = await validateFinding(buildRequest('DRY_RUN'));
      setDryRunResult(resp.data as ValidationResult);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  const handleValidate = () => setShowConfirmDialog(true);

  const handleConfirmedValidate = async () => {
    setShowConfirmDialog(false);
    setLoading(true);
    setError(null);
    try {
      const resp = await validateFinding(buildRequest('VALIDATE', true));
      setValidateResult(resp.data as ValidationResult);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  const handleCleanup = async () => {
    if (!validateResult?.run_id) return;
    setCleanupLoading(true);
    setError(null);
    try {
      const req: CleanupRequest = {
        run_id: validateResult.run_id,
        profile: profile || undefined,
        region: region || 'us-east-1',
      };
      const resp = await cleanupS3Write(req);
      setCleanupResult(resp.data as CleanupResult);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setCleanupLoading(false);
    }
  };

  return (
    <div style={{ padding: 24, maxWidth: 820, margin: '0 auto' }}>

      {/* Title */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>
          🛡 Controlled Validation
        </div>
        <div style={{ fontSize: 13, color: COLORS.muted, lineHeight: 1.5 }}>
          Test specific attack paths with explicit confirmation.
          Default mode is <strong>DRY Run</strong> — no resources are created until you confirm.
        </div>
      </div>

      {/* Safety banner */}
      <div style={{
        background: '#fff8ed', border: '1px solid #e6a817', borderRadius: 6,
        padding: '10px 14px', marginBottom: 20, fontSize: 12,
      }}>
        <strong>Safety Model:</strong> READ_ONLY → DRY_RUN (preview) → VALIDATE (execute with explicit confirmation).
        No AWS resource is created or modified without explicit confirmation.
        For S3 Write, the test object remains in S3 after execution and must be cleaned up manually.
      </div>

      {/* Form */}
      <div style={{
        background: COLORS.surface, border: `1px solid ${COLORS.border}`,
        borderRadius: 8, padding: 20, marginBottom: 20,
      }}>
        <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>
          Validation Parameters
        </div>

        {/* Technique selector */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
            Technique
          </label>
          <select
            value={technique}
            onChange={e => handleTechniqueChange(e.target.value as Technique)}
            style={{ ...inputStyle, background: '#fff' }}
          >
            {(Object.entries(TECHNIQUE_LABELS) as [Technique, string][]).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </select>
        </div>

        {/* EC2 Control warning */}
        {technique === 'ec2_control' && (
          <div style={{
            background: '#fff5f5', border: '1px solid #fca5a5', borderRadius: 6,
            padding: '10px 14px', marginBottom: 14, fontSize: 12,
          }}>
            <strong>⚠ Warning:</strong> EC2 Control Validation will temporarily <strong>stop and start</strong> the
            designated test instance. Only proceed against a specifically designated test instance.
            The original running state will be restored automatically.
          </div>
        )}

        {/* Finding ID */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
            Finding ID (optional — for tracking in report)
          </label>
          <input type="text" value={findingId} onChange={e => setFindingId(e.target.value)}
            placeholder="e.g. finding-001" style={inputStyle} />
        </div>

        {/* S3 bucket name — s3_write, s3_read */}
        {(technique === 's3_write' || technique === 's3_read') && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              S3 Bucket Name <span style={{ color: COLORS.danger }}>*</span>
            </label>
            <input type="text" value={bucketName} onChange={e => setBucketName(e.target.value)}
              placeholder="e.g. my-test-bucket" style={inputStyle} />
          </div>
        )}

        {/* S3 object key — s3_read only */}
        {technique === 's3_read' && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              Object Key (optional — specific object to GetObject, e.g.{' '}
              <code>cloud-pentest-validation/controlled_valid1.txt</code>)
            </label>
            <input type="text" value={objectKey} onChange={e => setObjectKey(e.target.value)}
              placeholder="cloud-pentest-validation/controlled_valid1.txt (leave blank for ListObjectsV2)"
              style={inputStyle} />
          </div>
        )}

        {/* Role ARN — iam_pass_role */}
        {technique === 'iam_pass_role' && (
          <>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
                Role ARN <span style={{ color: COLORS.danger }}>*</span>
              </label>
              <input type="text" value={roleArn} onChange={e => setRoleArn(e.target.value)}
                placeholder="arn:aws:iam::ACCOUNT:role/ROLE-NAME" style={inputStyle} />
            </div>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
                Target Service (optional — e.g. ec2.amazonaws.com)
              </label>
              <input type="text" value={targetService} onChange={e => setTargetService(e.target.value)}
                placeholder="ec2.amazonaws.com" style={inputStyle} />
            </div>
          </>
        )}

        {/* Instance ID — ec2_access, ec2_control */}
        {(technique === 'ec2_access' || technique === 'ec2_control') && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              Instance ID{technique === 'ec2_control' ? <span style={{ color: COLORS.danger }}> *</span> : ' (optional)'}
            </label>
            <input type="text" value={instanceId} onChange={e => setInstanceId(e.target.value)}
              placeholder="i-0123456789abcdef0" style={inputStyle} />
          </div>
        )}

        {/* EC2 Control explicit confirmation checkbox */}
        {technique === 'ec2_control' && (
          <div style={{
            marginBottom: 14, padding: '10px 12px',
            background: '#fef9ec', border: '1px solid #fcd34d', borderRadius: 6,
          }}>
            <label style={{ fontSize: 13, display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
              <input type="checkbox" checked={ec2Confirmed} onChange={e => setEc2Confirmed(e.target.checked)} />
              I confirm this is a <strong>designated test instance</strong> and I accept that it will be
              temporarily stopped and restarted.
            </label>
          </div>
        )}

        {/* AWS profile + region */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
          <div>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              AWS Profile (optional)
            </label>
            <input type="text" value={profile} onChange={e => setProfile(e.target.value)}
              placeholder="default" style={inputStyle} />
          </div>
          <div>
            <label style={{ fontSize: 12, color: COLORS.muted, display: 'block', marginBottom: 4 }}>
              AWS Region
            </label>
            <input type="text" value={region} onChange={e => setRegion(e.target.value)}
              placeholder="us-east-1" style={inputStyle} />
          </div>
        </div>

        {/* Action buttons */}
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          {/* DRY RUN */}
          <button
            onClick={handleDryRun}
            disabled={loading}
            style={{
              padding: '8px 20px', background: COLORS.accent, color: '#fff',
              border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
              cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? 'Running…' : '🔍 Dry Run Preview'}
          </button>

          {/* EXECUTE VALIDATION — only shown after dry run, before execution */}
          {dryRunResult && !validateResult && (
            <button
              onClick={handleValidate}
              disabled={loading || (technique === 'ec2_control' && !ec2Confirmed)}
              title={technique === 'ec2_control' && !ec2Confirmed
                ? 'Check the confirmation box above before executing'
                : undefined}
              style={{
                padding: '8px 20px', background: '#dc2626', color: '#fff',
                border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
                cursor: (loading || (technique === 'ec2_control' && !ec2Confirmed))
                  ? 'not-allowed' : 'pointer',
                opacity: (loading || (technique === 'ec2_control' && !ec2Confirmed)) ? 0.5 : 1,
              }}
            >
              ⚡ Execute Validation
            </button>
          )}
        </div>
      </div>

      {/* Error */}
      {error && (
        <div style={{
          background: '#fef2f2', border: '1px solid #fca5a5', borderRadius: 6,
          padding: '10px 14px', marginBottom: 16, fontSize: 13, color: '#dc2626',
        }}>
          Error: {error}
        </div>
      )}

      {/* Dry run result */}
      {dryRunResult && (
        <ResultCard result={dryRunResult} title="Dry Run Preview" />
      )}

      {/* Validate result */}
      {validateResult && (
        <>
          <ResultCard result={validateResult} title="Validation Result" />

          {/* S3 Write — object left in bucket info box */}
          {technique === 's3_write' && validateResult.status === 'success' && (
            <div style={{
              background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 8,
              padding: '14px 16px', marginBottom: 16,
            }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#15803d', marginBottom: 8 }}>
                ✓ VALIDATION SUCCESSFUL — Test object created
              </div>
              <div style={{ fontSize: 12, color: '#166534', lineHeight: 1.6, marginBottom: 8 }}>
                <strong>s3:PutObject → SUCCESS</strong><br />
                <strong>s3:GetObject → SUCCESS</strong>
              </div>
              <div style={{
                fontFamily: 'monospace', fontSize: 12, background: '#dcfce7',
                padding: '8px 10px', borderRadius: 4, marginBottom: 10,
              }}>
                s3://{validateResult.s3_bucket || '(bucket)'}/<br />
                &nbsp;&nbsp;{validateResult.s3_object_key || '(object key)'}
              </div>
              <div style={{ fontSize: 12, color: '#166534', marginBottom: 10 }}>
                The test object has <strong>NOT</strong> been deleted.
                You can now open the AWS Console and navigate to the S3 bucket to verify the object exists.
                When you are ready, press the cleanup button below.
              </div>
              {cleanupResult === null && (
                <button
                  onClick={handleCleanup}
                  disabled={cleanupLoading}
                  style={{
                    padding: '8px 18px', background: '#ca8a04', color: '#fff',
                    border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 600,
                    cursor: cleanupLoading ? 'not-allowed' : 'pointer',
                    opacity: cleanupLoading ? 0.7 : 1,
                  }}
                >
                  {cleanupLoading ? 'Cleaning up…' : '🗑 Clean Up Test Object'}
                </button>
              )}
            </div>
          )}

          {/* Cleanup result */}
          {cleanupResult && (
            <CleanupCard result={cleanupResult} />
          )}
        </>
      )}

      {/* Graph export links */}
      <div style={{
        marginTop: 28, paddingTop: 16, borderTop: `1px solid ${COLORS.border}`,
        display: 'flex', gap: 12, alignItems: 'center',
      }}>
        <span style={{ fontSize: 12, color: COLORS.muted }}>Export graph:</span>
        <a href={fetchGraphExportUrl('graphml')} download="attack_graph.graphml"
          style={{ fontSize: 12, color: COLORS.accent }}>
          GraphML (Gephi/yEd)
        </a>
        <a href={fetchGraphExportUrl('json')} download="attack_graph.json"
          style={{ fontSize: 12, color: COLORS.accent }}>
          JSON
        </a>
        <a href="http://localhost:8000/api/report/pdf" download="pentest_report.pdf"
          style={{ fontSize: 12, color: COLORS.accent }}>
          PDF Report
        </a>
      </div>

      {/* Confirmation dialog */}
      {showConfirmDialog && dryRunResult && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2000,
        }}>
          <div style={{
            background: '#fff', borderRadius: 10, padding: 28, width: 500,
            boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
          }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 12, color: '#dc2626' }}>
              ⚠ Confirm Controlled Validation
            </div>
            <div style={{ fontSize: 13, marginBottom: 12, color: COLORS.text, lineHeight: 1.5 }}>
              This will execute the following AWS API calls against real cloud resources.
              {technique === 'ec2_control' && (
                <span style={{ color: '#dc2626', fontWeight: 600 }}>
                  {' '}This will temporarily stop the designated test instance.
                </span>
              )}
              {technique === 's3_write' && (
                <span>
                  {' '}The test object will be created and will remain in S3 until
                  you explicitly press "Clean Up Test Object".
                </span>
              )}
            </div>
            <div style={{
              background: COLORS.surface, borderRadius: 6, padding: 12, marginBottom: 16,
              maxHeight: 240, overflowY: 'auto',
            }}>
              {dryRunResult.dry_run_preview.map((step, i) => (
                <div key={i} style={{
                  fontFamily: 'monospace', fontSize: 11.5, padding: '1px 0',
                  color: step.startsWith('⚠') ? '#dc2626' : '#374151',
                }}>
                  {step}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button
                onClick={() => setShowConfirmDialog(false)}
                style={{
                  padding: '7px 18px', border: `1px solid ${COLORS.border}`,
                  borderRadius: 6, background: '#fff', cursor: 'pointer', fontSize: 13,
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmedValidate}
                style={{
                  padding: '7px 18px', background: '#dc2626', color: '#fff',
                  border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13,
                  fontWeight: 600,
                }}
              >
                Confirm — Execute
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


// ---------------------------------------------------------------------------
// ResultCard component
// ---------------------------------------------------------------------------

interface ResultCardProps {
  result: ValidationResult;
  title: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, title }) => {
  const statusInfo = STATUS_STYLES[result.status] ?? { color: COLORS.muted, label: result.status };

  return (
    <div style={{
      border: `1px solid ${COLORS.border}`, borderRadius: 8,
      marginBottom: 16, overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 16px', background: COLORS.surface,
        borderBottom: `1px solid ${COLORS.border}`,
      }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>{title}</div>
        <div style={{ fontWeight: 700, fontSize: 13, color: statusInfo.color }}>
          {statusInfo.label}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 13, color: COLORS.text, marginBottom: 12, lineHeight: 1.5 }}>
          {result.description}
        </div>

        {/* Dry run steps */}
        {result.dry_run_preview?.length > 0 && (
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.muted, marginBottom: 6 }}>
              AWS API Calls
            </div>
            <div style={{
              background: '#f8f9fa', borderRadius: 4, padding: '8px 12px',
              fontFamily: 'Consolas, monospace', fontSize: 11.5,
            }}>
              {result.dry_run_preview.map((step, i) => (
                <div key={i} style={{
                  padding: '1px 0',
                  color: step.startsWith('⚠') ? '#dc2626' : '#374151',
                }}>
                  {step || '\u00A0'}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Confirmed flag */}
        {result.mode === 'VALIDATE' && (
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 10px', borderRadius: 14, fontSize: 12, fontWeight: 600,
            background: result.confirmed ? '#dcfce7' : '#fef2f2',
            color: result.confirmed ? '#15803d' : '#dc2626',
            marginBottom: 10,
          }}>
            {result.confirmed ? '✓ Execution confirmed' : '✗ Execution not confirmed'}
          </div>
        )}

        {/* Evidence */}
        {result.evidence?.length > 0 && (
          <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.muted, marginBottom: 4 }}>
              Evidence ({result.evidence.length} item{result.evidence.length !== 1 ? 's' : ''})
            </div>
            {result.evidence.map((ev, i) => (
              <div key={i} style={{
                fontFamily: 'monospace', fontSize: 11, background: '#f0f0f0',
                padding: '4px 8px', borderRadius: 4, marginBottom: 4,
              }}>
                {JSON.stringify(ev)}
              </div>
            ))}
          </div>
        )}

        {/* Cleanup status */}
        <div style={{ fontSize: 12, color: COLORS.muted }}>
          {result.cleanup_status && result.cleanup_status !== 'N/A' && (
            <>
              Cleanup: {' '}
              {result.cleanup_status === 'COMPLETED' && (
                <span style={{ color: '#16a34a' }}>COMPLETED</span>
              )}
              {result.cleanup_status === 'PENDING' && (
                <span style={{ color: '#ca8a04' }}>PENDING — use "Clean Up Test Object" button</span>
              )}
              {result.cleanup_status === 'FAILED' && (
                <span style={{ color: '#dc2626' }}>FAILED — check audit log</span>
              )}
              {result.cleanup_status === 'PARTIAL' && (
                <span style={{ color: '#ea580c' }}>PARTIAL — verify instance state manually</span>
              )}
              {!['COMPLETED', 'PENDING', 'FAILED', 'PARTIAL'].includes(result.cleanup_status) && (
                <span>{result.cleanup_status}</span>
              )}
            </>
          )}
          {result.run_id && (
            <span style={{ marginLeft: 12 }}>
              Run ID: <code style={{ fontSize: 11 }}>{result.run_id}</code>
            </span>
          )}
        </div>

        {/* Error */}
        {result.error && (
          <div style={{
            marginTop: 8, padding: '6px 10px', background: '#fef2f2',
            borderRadius: 4, fontSize: 12, color: '#dc2626',
            fontFamily: 'monospace',
          }}>
            {result.error}
          </div>
        )}
      </div>
    </div>
  );
};


// ---------------------------------------------------------------------------
// CleanupCard component
// ---------------------------------------------------------------------------

interface CleanupCardProps {
  result: CleanupResult;
}

const CleanupCard: React.FC<CleanupCardProps> = ({ result }) => {
  const isSuccess = result.status === 'success' || result.status === 'already_done';
  const isAlreadyDone = result.status === 'already_done';

  return (
    <div style={{
      border: `1px solid ${isSuccess ? '#86efac' : '#fca5a5'}`,
      borderRadius: 8, marginBottom: 16, overflow: 'hidden',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 16px',
        background: isSuccess ? '#f0fdf4' : '#fef2f2',
        borderBottom: `1px solid ${isSuccess ? '#86efac' : '#fca5a5'}`,
      }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>
          {isAlreadyDone ? 'Cleanup (Already Done)' : 'Cleanup Result'}
        </div>
        <div style={{
          fontWeight: 700, fontSize: 13,
          color: isSuccess ? '#15803d' : '#dc2626',
        }}>
          {isSuccess ? '✓ CLEANUP COMPLETED' : '✗ CLEANUP FAILED'}
        </div>
      </div>

      <div style={{ padding: '14px 16px' }}>
        <div style={{ fontSize: 13, color: COLORS.text, marginBottom: 10, lineHeight: 1.5 }}>
          {result.description}
        </div>
        {result.object_key && (
          <div style={{
            fontFamily: 'monospace', fontSize: 12, background: '#f0f0f0',
            padding: '6px 10px', borderRadius: 4, marginBottom: 8,
          }}>
            s3://{result.bucket}/{result.object_key}
          </div>
        )}
        {result.deletion_verified !== undefined && (
          <div style={{ fontSize: 12, color: COLORS.muted }}>
            Deletion verified: {result.deletion_verified
              ? <span style={{ color: '#16a34a' }}>Yes — object is no longer accessible</span>
              : <span style={{ color: '#ca8a04' }}>Not immediately confirmed (S3 eventual consistency)</span>
            }
          </div>
        )}
        {result.error && (
          <div style={{
            marginTop: 8, padding: '6px 10px', background: '#fef2f2',
            borderRadius: 4, fontSize: 12, color: '#dc2626',
            fontFamily: 'monospace',
          }}>
            {result.error}
          </div>
        )}
      </div>
    </div>
  );
};
