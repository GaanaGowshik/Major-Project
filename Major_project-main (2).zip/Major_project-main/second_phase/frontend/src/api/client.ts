import axios from 'axios';

const BASE = 'http://localhost:8000';

const api = axios.create({ baseURL: BASE });

// ── Graph ────────────────────────────────────────────────
export const fetchGraph = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/attack-graph', { params: { provider } });

export const fetchNodeDetail = (id: string) =>
  api.get(`/api/attack-graph/node/${encodeURIComponent(id)}`);

// ── Scan ─────────────────────────────────────────────────
export const triggerScan      = (payload: ScanRequest) => api.post('/api/scan', payload);
export const fetchScanStatus  = () => api.get('/api/scan/status');

// ── RL ───────────────────────────────────────────────────
export const fetchRLStatus    = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/rl/status', { params: { provider } });
export const fetchRLEpisodes  = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/rl/episodes', { params: { provider } });
export const fetchRLHistory   = (ep?: number, provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/rl/history', {
    params: { ...(ep !== undefined ? { episode: ep } : {}), provider },
  });
export const fetchRLAttackPath = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/rl/attack-path', { params: { provider } });
export const startRLTraining   = (payload: { provider: string; timesteps?: number }) =>
  api.post('/api/rl/train', payload);
export const fetchRLTrainStatus = () => api.get('/api/rl/train/status');
export const runRLInference    = (payload: { provider: string; n_episodes?: number }) =>
  api.post('/api/rl/inference', payload);

// ── Report ───────────────────────────────────────────────
export const generateReport = (provider: 'aws' | 'gcp' = 'aws') =>
  api.post('/api/report/generate', null, { params: { provider } });

export const fetchReport = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/report', { params: { provider } });

/**
 * Download the PDF as a binary Blob.
 * IMPORTANT: responseType must be 'arraybuffer' so Axios never interprets the
 * binary PDF bytes as a UTF-8 string (which would corrupt the file).
 */
export const downloadReportPdf = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/report/pdf', {
    params: { provider },
    responseType: 'arraybuffer',
  });

export const fetchReportHtmlUrl = (provider: 'aws' | 'gcp' = 'aws') =>
  `${BASE}/api/report/html?provider=${provider}`;

// ── Anomaly ──────────────────────────────────────────────
export const fetchAnomalies = (provider: 'aws' | 'gcp' = 'aws') =>
  api.get('/api/anomaly', { params: { provider } });

// ── Validate ─────────────────────────────────────────────
export const fetchTechniques        = () => api.get('/api/validate/techniques');
export const validateFinding        = (payload: ValidateRequest) => api.post('/api/validate', payload);
export const cleanupS3Write         = (payload: CleanupRequest) => api.post('/api/validate/cleanup', payload);
export const fetchValidationHistory = () => api.get('/api/validate/history');
export const fetchAttackPaths       = () => api.get('/api/attack-graph/paths');
export const fetchGraphExportUrl    = (format: 'graphml' | 'json') =>
  `${BASE}/api/attack-graph/export/${format}`;

// ── Health ───────────────────────────────────────────────
export const fetchHealth      = () => api.get('/api/health');

export interface ScanRequest {
  provider?: 'aws' | 'gcp';
  profile?: string;
  region?: string;
  regions?: string;
  skip_privesc?: boolean;
  skip_s3_iam_xref?: boolean;
  gcp_project_id?: string;
}

export interface ValidateRequest {
  finding_id: string;
  technique: 's3_write' | 's3_read' | 'iam_pass_role' | 'ec2_access' | 'ec2_control';
  mode: 'READ_ONLY' | 'DRY_RUN' | 'VALIDATE';
  confirmed: boolean;
  provider?: 'aws';
  profile?: string;
  region?: string;
  run_id?: string;
  // s3_write / s3_read
  bucket_name?: string;
  object_key?: string;
  // iam_pass_role
  role_arn?: string;
  target_service?: string;
  // ec2_access / ec2_control
  instance_id?: string;
}

export interface CleanupRequest {
  run_id: string;
  profile?: string;
  region?: string;
}
