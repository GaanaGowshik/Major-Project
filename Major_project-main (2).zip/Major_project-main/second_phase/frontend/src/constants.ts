// Centralised design tokens — no external CSS framework needed

export const COLORS = {
  bg:          '#ffffff',
  surface:     '#f7f8fa',
  border:      '#e5e7eb',
  text:        '#1f2328',
  muted:       '#57606a',
  accent:      '#3b82d4',
  success:     '#16a34a',
  warning:     '#ca8a04',
  danger:      '#dc2626',
  orange:      '#ea580c',

  CRITICAL:    '#dc2626',
  HIGH:        '#ea580c',
  MEDIUM:      '#ca8a04',
  LOW:         '#16a34a',
  INFO:        '#2563eb',

  nodeUser:    '#3b82d4',
  nodeRole:    '#7c3aed',
  nodeBucket:  '#0891b2',
  nodeEC2:     '#0d9488',
  nodeCap:     '#dc2626',
};

export const NODE_TYPE_LABEL: Record<string, string> = {
  IAMUser:           'IAM User',
  user:              'IAM User',
  IAMRole:           'IAM Role',
  role:              'IAM Role',
  S3Bucket:          'S3 Bucket',
  bucket:            'S3 Bucket',
  EC2Instance:       'EC2 Instance',
  Capability:        'Capability (Admin)',
  GCPServiceAccount: 'Service Account',
  ServiceAccount:    'Service Account',
  GCPStorageBucket:  'Storage Bucket',
  StorageBucket:     'Storage Bucket',
  GCPInstance:       'Compute Instance',
  ComputeInstance:   'Compute Instance',
};

export const RL_RELATION_LABELS: Record<string, string> = {
  CAN_ASSUME:           'Assume Role',
  CAN_IMPERSONATE:      'Impersonate',
  PRIVESC_TO:           'Privilege Escalation',
  HAS_INSTANCE_PROFILE: 'Instance Profile',
  HAS_SERVICE_ACCOUNT:  'Service Account',
  CAN_WRITE_BUCKET:     'Write Bucket',
  CAN_READ_BUCKET:      'Read Bucket',
  CAN_LIST_BUCKET:      'List Bucket',
};
