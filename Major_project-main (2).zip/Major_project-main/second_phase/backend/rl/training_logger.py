"""
rl/training_logger.py — SB3 callback that writes structured training logs.

Writes one record per completed episode to:
  - rl/training_log.json         (full step history, all providers)
  - rl/training_log_{provider}.json (provider-specific)

Log schema per episode::
    {
      "episode": 1,
      "provider": "aws",
      "total_reward": 42.0,
      "steps_count": 15,
      "success": true,
      "steps": [
        {
          "step": 0,
          "node": "arn:aws:iam::123:user/alice",
          "action": 0,
          "relation": "CAN_ASSUME",
          "reward": 12.5,
          "success": true,
          "is_goal": false
        },
        ...
      ]
    }

Also pushes live status to rl_service._LIVE_STATUS so the
GET /api/rl/status endpoint reflects training progress in real-time.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from stable_baselines3.common.callbacks import BaseCallback

logger = logging.getLogger(__name__)

_LOG_PATH = Path(__file__).parent / "training_log.json"


class TrainingLogger(BaseCallback):
    """
    SB3 callback: records structured episode data during training.

    Key terminology:
      - Episode:   one full run from reset() to terminated/truncated
      - Step:      one environment step within an episode
      - Epoch:     one PPO update (multiple episodes worth of steps)
      - Timestep:  total environment steps across all episodes

    This callback operates at the step level (one call per env.step()).
    Episode boundaries are detected via the 'dones' flag.
    """

    def __init__(self, verbose: int = 0, provider: str = "aws") -> None:
        super().__init__(verbose)
        self._provider = provider
        self._episodes: list[dict[str, Any]] = []
        self._current_steps: list[dict[str, Any]] = []
        self._episode_num: int = 0
        self._step_num: int = 0
        self._cumulative_reward: float = 0.0
        self._success_count: int = 0

    # ── SB3 callback interface ─────────────────────────────────────────────

    def _on_step(self) -> bool:
        """Called after every environment step during training."""
        infos   = self.locals.get("infos", [{}])
        rewards = self.locals.get("rewards", [0.0])
        actions = self.locals.get("actions", [None])
        dones   = self.locals.get("dones", [False])

        reward  = float(rewards[0]) if rewards else 0.0
        action  = int(actions[0]) if actions is not None and len(actions) > 0 else None
        info    = infos[0] if infos else {}
        done    = bool(dones[0]) if dones else False

        # Get current node name from env
        node_name = None
        relation  = None
        is_goal   = False
        try:
            env = self.training_env.envs[0]
            node_name = getattr(env, "_current_node", None)
            relation  = info.get("relation")
            is_goal   = info.get("is_goal", False)
        except Exception:
            pass

        step_record: dict[str, Any] = {
            "step":     self._step_num,
            "node":     node_name,
            "action":   action,
            "relation": relation,
            "reward":   reward,
            "success":  info.get("success", reward >= 0),
            "is_goal":  is_goal,
        }
        self._current_steps.append(step_record)
        self._cumulative_reward += reward
        self._step_num += 1

        # Push live status so the API returns real-time training progress
        try:
            from api.services.rl_service import set_live_status
            set_live_status({
                "episode":          self._episode_num,
                "step":             self._step_num,
                "current_node":     node_name,
                "last_action":      action,
                "last_relation":    relation,
                "reward":           reward,
                "cumulative_reward": self._cumulative_reward,
                "is_trained":       False,
                "provider":         self._provider,
            })
        except Exception:
            pass

        if done:
            self._flush_episode(info)

        return True

    def _on_training_end(self) -> None:
        """Flush any remaining steps at training end."""
        if self._current_steps:
            self._flush_episode({})

    # ── Internal helpers ────────────────────────────────────────────────────

    def _flush_episode(self, last_info: dict) -> None:
        """Write completed episode to training log."""
        self._episode_num += 1
        success = last_info.get("reached_goal", False) or last_info.get("is_goal", False)
        if success:
            self._success_count += 1

        episode_record: dict[str, Any] = {
            "episode":      self._episode_num,
            "provider":     self._provider,
            "total_reward": self._cumulative_reward,
            "steps_count":  len(self._current_steps),
            "success":      success,
            "steps":        list(self._current_steps),
        }
        self._episodes.append(episode_record)

        # Persist to JSON
        try:
            with open(_LOG_PATH, "w", encoding="utf-8") as f:
                json.dump(self._episodes, f, indent=2, default=str)
        except Exception as exc:
            logger.warning("Could not write training log: %s", exc)

        # Also write provider-specific log
        try:
            provider_path = Path(__file__).parent / f"training_log_{self._provider}.json"
            with open(provider_path, "w", encoding="utf-8") as f:
                json.dump(self._episodes, f, indent=2, default=str)
        except Exception:
            pass

        self._current_steps = []
        self._cumulative_reward = 0.0

    def get_summary(self) -> dict[str, Any]:
        """Return aggregate training metrics."""
        if not self._episodes:
            return {
                "total_episodes":  0,
                "total_timesteps": self._step_num,
                "avg_reward":      0.0,
                "max_reward":      0.0,
                "min_reward":      0.0,
                "success_rate":    0.0,
                "avg_steps":       0.0,
            }

        rewards = [ep["total_reward"] for ep in self._episodes]
        steps   = [ep["steps_count"]  for ep in self._episodes]

        return {
            "total_episodes":  len(self._episodes),
            "total_timesteps": self._step_num,
            "avg_reward":      sum(rewards) / len(rewards),
            "max_reward":      max(rewards),
            "min_reward":      min(rewards),
            "success_rate":    self._success_count / max(len(self._episodes), 1),
            "avg_steps":       sum(steps) / len(steps),
        }
