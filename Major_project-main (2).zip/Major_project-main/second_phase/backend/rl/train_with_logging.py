"""
rl/train_with_logging.py — Convenience wrapper for training with structured logging.

Usage:
    cd second_phase/backend
    .venv/Scripts/python rl/train_with_logging.py [--provider aws|gcp] [--timesteps 20000]

This is a thin CLI wrapper over rl/train.train().
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import argparse
import logging

from rl.train import train


def main() -> None:
    parser = argparse.ArgumentParser(description="Train RL agent with structured logging")
    parser.add_argument("--provider", default="aws", choices=["aws", "gcp"])
    parser.add_argument("--timesteps", type=int, default=20_000)
    parser.add_argument("--model", default="ppo_cloud_agent")
    parser.add_argument("--graph", default=None)
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    print(f"Training started (provider={args.provider}, timesteps={args.timesteps})...")

    result = train(
        provider=args.provider,
        graph_json_path=args.graph,
        model_save_path=args.model,
        total_timesteps=args.timesteps,
        verbose=1,
    )

    if result.get("status") == "complete":
        m = result.get("metrics", {})
        print(f"\nTraining complete!")
        print(f"  Episodes:     {m.get('total_episodes', 0)}")
        print(f"  Avg Reward:   {m.get('avg_reward', 0.0):.2f}")
        print(f"  Max Reward:   {m.get('max_reward', 0.0):.2f}")
        print(f"  Success Rate: {m.get('success_rate', 0.0):.2%}")
        print(f"  Model Path:   {result.get('model_path', '')}")
        print(f"  Log:          rl/training_log.json")
        print(f"  Attack Path:  rl/attack_path_result.json")
    else:
        print(f"\nTraining failed: {result.get('message', 'unknown error')}")


if __name__ == "__main__":
    main()
