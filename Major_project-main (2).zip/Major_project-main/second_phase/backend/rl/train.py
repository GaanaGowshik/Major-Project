"""
rl/train.py — RL training pipeline for cloud attack-path exploration.

This module implements the full training loop:
  1. Load scanner-generated graph (AWS or GCP)
  2. Validate the graph
  3. Create the RL environment (CloudPentestEnv)
  4. Initialise the PPO agent
  5. Run training episodes
  6. Track metrics per episode (reward, path length, success rate)
  7. Save the trained model
  8. Run inference to generate an attack path
  9. Save structured attack-path output to JSON

Algorithm: PPO (stable_baselines3)
Why PPO:
  - Discrete action space bounded by MAX_EDGES cap
  - Variable number of valid actions per node → handled by invalid-action masking
  - MlpPolicy maps the fixed OBS_DIM observation vector to a policy
  - PPO is sample-efficient and stable for sparse-reward graph navigation
  - Well-tested SB3 implementation avoids manual RL bugs

Usage
-----
    cd second_phase/backend
    .venv/Scripts/python rl/train.py [--provider aws|gcp] [--timesteps 20000]

or import and call:
    from rl.train import train, run_inference

Training vs Inference
---------------------
Training:   Creates or updates the model from the current scan graph.
Inference:  Loads a saved model and runs one evaluation episode.
            Does NOT retrain — fast for UI/API use.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any, Optional

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

logger = logging.getLogger(__name__)

# Default model save path (relative to backend directory)
_DEFAULT_MODEL_PATH = "ppo_cloud_agent"
# Structured inference result path
_RESULT_PATH = Path(__file__).parent / "attack_path_result.json"
# Training metrics path
_METRICS_PATH = Path(__file__).parent / "training_metrics.json"


# ──────────────────────────────────────────────────────────────────────────────
# Training
# ──────────────────────────────────────────────────────────────────────────────

def train(
    provider: str = "aws",
    graph_json_path: Optional[str] = None,
    model_save_path: str = _DEFAULT_MODEL_PATH,
    total_timesteps: int = 20_000,
    verbose: int = 1,
) -> dict[str, Any]:
    """
    Train a PPO agent on the scanner-generated cloud attack graph.

    Parameters
    ----------
    provider:
        "aws" or "gcp" — determines which last scan is loaded.
    graph_json_path:
        Override path to a specific graph JSON (AssessmentGraph format).
        If None, uses the most recent scan for the given provider.
    model_save_path:
        Filename (without .zip) to save the trained model.
    total_timesteps:
        Total environment steps to train for.
        20,000 is sufficient for small–medium graphs (< 50 nodes).
        Use 50,000+ for larger or more complex graphs.
    verbose:
        SB3 verbosity level (0=silent, 1=progress, 2=debug).

    Returns
    -------
    dict with training summary including metrics, model path, attack path.
    """
    from stable_baselines3 import PPO
    from stable_baselines3.common.monitor import Monitor

    from env.gym_env import CloudPentestEnv
    from rl.training_logger import TrainingLogger

    # ── 1. Create environment ───────────────────────────────────────────────
    logger.info("Creating CloudPentestEnv (provider=%s)…", provider)
    raw_env = CloudPentestEnv(
        graph_json_path=graph_json_path,
        provider=provider,
    )
    env = Monitor(raw_env)

    node_count = len(raw_env.nodes)
    edge_count = raw_env._nx_graph.number_of_edges()
    graph_source = raw_env.graph_source

    logger.info(
        "Graph loaded: source=%s nodes=%d edges=%d",
        graph_source, node_count, edge_count,
    )

    if node_count == 0:
        return {
            "status": "error",
            "message": "Graph has no nodes. Run a cloud scan first.",
        }

    if node_count == 1:
        logger.warning(
            "Graph has only 1 node — training will be trivial. "
            "Run a real cloud scan for meaningful results."
        )

    # ── 2. Initialise PPO agent ─────────────────────────────────────────────
    logger.info("Initialising PPO agent…")
    model = PPO(
        "MlpPolicy",
        env,
        verbose=verbose,
        learning_rate=3e-4,
        n_steps=512,
        batch_size=64,
        n_epochs=10,
        gamma=0.99,
        gae_lambda=0.95,
        clip_range=0.2,
        ent_coef=0.01,        # encourage exploration
    )

    # ── 3. Train ────────────────────────────────────────────────────────────
    logger.info("Training started: total_timesteps=%d…", total_timesteps)
    training_logger = TrainingLogger(verbose=verbose, provider=provider)

    try:
        model.learn(
            total_timesteps=total_timesteps,
            callback=training_logger,
            progress_bar=False,
        )
    except Exception as exc:
        logger.error("Training failed: %s", exc, exc_info=True)
        return {"status": "error", "message": f"Training failed: {exc}"}

    # ── 4. Save model ───────────────────────────────────────────────────────
    try:
        model.save(model_save_path)
        logger.info("Model saved to %s.zip", model_save_path)
    except Exception as exc:
        logger.warning("Could not save model: %s", exc)

    # ── 5. Run inference on best episode path ───────────────────────────────
    attack_path = run_inference(
        provider=provider,
        graph_json_path=graph_json_path,
        model_path=model_save_path,
    )

    # ── 6. Save training metrics ────────────────────────────────────────────
    metrics = training_logger.get_summary()
    metrics.update({
        "provider":     provider,
        "graph_source": graph_source,
        "node_count":   node_count,
        "edge_count":   edge_count,
        "model_path":   model_save_path + ".zip",
    })
    try:
        with open(_METRICS_PATH, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2, default=str)
    except Exception as exc:
        logger.warning("Could not write metrics: %s", exc)

    logger.info(
        "Training complete. episodes=%d avg_reward=%.2f",
        metrics.get("total_episodes", 0),
        metrics.get("avg_reward", 0.0),
    )

    return {
        "status":       "complete",
        "model_path":   model_save_path + ".zip",
        "metrics":      metrics,
        "attack_path":  attack_path,
    }


# ──────────────────────────────────────────────────────────────────────────────
# Inference
# ──────────────────────────────────────────────────────────────────────────────

def run_inference(
    provider: str = "aws",
    graph_json_path: Optional[str] = None,
    model_path: str = _DEFAULT_MODEL_PATH,
    n_episodes: int = 5,
) -> dict[str, Any]:
    """
    Load a trained model and run it on the current graph to generate an attack path.

    Does NOT retrain the model — for fast UI/API use.

    Parameters
    ----------
    provider:
        "aws" or "gcp"
    graph_json_path:
        Path to a specific AssessmentGraph JSON.  None = most recent scan.
    model_path:
        Path to the saved model (without .zip extension).
    n_episodes:
        Number of evaluation episodes to run.  Best path is returned.

    Returns
    -------
    dict matching the structured attack-path output schema:
      { path, total_reward, path_length, target, target_type,
        success, graph_source, provider }

    Returns an empty/failed result if no model exists or graph is empty.
    """
    from stable_baselines3 import PPO
    from env.gym_env import CloudPentestEnv

    model_file = Path(model_path + ".zip")
    if not model_file.exists():
        logger.info("No trained model found at %s — skipping inference.", model_file)
        return {
            "status": "no_model",
            "message": (
                f"No trained model found at {model_file}. "
                "Run training first (POST /api/rl/train)."
            ),
            "path": [],
            "total_reward": 0.0,
            "path_length": 0,
            "provider": provider,
        }

    # Load environment
    env = CloudPentestEnv(graph_json_path=graph_json_path, provider=provider)
    if len(env.nodes) == 0:
        return {
            "status": "no_graph",
            "message": "No graph available. Run a cloud scan first.",
            "path": [],
            "total_reward": 0.0,
            "path_length": 0,
            "provider": provider,
        }

    # Load model
    try:
        model = PPO.load(model_path)
    except Exception as exc:
        logger.error("Could not load model %s: %s", model_path, exc)
        return {
            "status":  "model_load_error",
            "message": f"Could not load model: {exc}",
            "path": [],
            "total_reward": 0.0,
            "path_length": 0,
            "provider": provider,
        }

    # Run n evaluation episodes and keep the best
    best_result: dict[str, Any] = {}
    best_reward = float("-inf")

    for ep in range(n_episodes):
        obs, _ = env.reset()
        ep_reward = 0.0
        terminated = truncated = False

        for _ in range(50):
            action, _ = model.predict(obs, deterministic=(ep == 0))
            obs, reward, terminated, truncated, info = env.step(int(action))
            ep_reward += float(reward)
            if terminated or truncated:
                break

        result = env.get_attack_path_result()
        result["total_reward"] = ep_reward
        result["provider"] = provider

        if ep_reward > best_reward:
            best_reward = ep_reward
            best_result = result

    # Persist best result
    try:
        _RESULT_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(_RESULT_PATH, "w", encoding="utf-8") as f:
            json.dump(best_result, f, indent=2, default=str)
    except Exception as exc:
        logger.warning("Could not write attack path result: %s", exc)

    best_result["status"] = "complete"
    return best_result


def load_latest_attack_path(provider: str = "aws") -> dict[str, Any]:
    """
    Load the most recently saved inference result for the given provider.
    Returns an empty result if none exists.
    """
    # Try provider-specific result first
    provider_path = Path(__file__).parent / f"attack_path_result_{provider}.json"
    fallback_path = _RESULT_PATH

    for path in [provider_path, fallback_path]:
        if path.exists():
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                if data.get("provider") == provider or provider_path == path:
                    return data
            except Exception:
                pass

    return {
        "status": "no_result",
        "message": "No inference result available. Train the model first.",
        "path": [],
        "total_reward": 0.0,
        "path_length": 0,
        "provider": provider,
    }


# ──────────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Train or run RL attack-path agent")
    parser.add_argument("--provider", default="aws", choices=["aws", "gcp"])
    parser.add_argument("--timesteps", type=int, default=20_000)
    parser.add_argument("--model", default=_DEFAULT_MODEL_PATH)
    parser.add_argument("--graph", default=None, help="Path to graph JSON (overrides default)")
    parser.add_argument("--inference-only", action="store_true",
                        help="Skip training — only run inference on existing model")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    if args.inference_only:
        result = run_inference(
            provider=args.provider,
            graph_json_path=args.graph,
            model_path=args.model,
        )
        print("\n=== INFERENCE RESULT ===")
        print(json.dumps(result, indent=2, default=str))
    else:
        result = train(
            provider=args.provider,
            graph_json_path=args.graph,
            model_save_path=args.model,
            total_timesteps=args.timesteps,
        )
        print("\n=== TRAINING COMPLETE ===")
        print(f"Status: {result.get('status')}")
        metrics = result.get("metrics", {})
        print(f"Episodes:     {metrics.get('total_episodes', 0)}")
        print(f"Avg Reward:   {metrics.get('avg_reward', 0.0):.2f}")
        print(f"Max Reward:   {metrics.get('max_reward', 0.0):.2f}")
        print(f"Success Rate: {metrics.get('success_rate', 0.0):.2%}")
        print(f"Model Path:   {result.get('model_path', '')}")

        ap = result.get("attack_path", {})
        if ap.get("path"):
            print("\n=== BEST ATTACK PATH ===")
            for step in ap["path"]:
                print(f"  [{step['node_type']}] {step['node_id'][:60]}  ({step['action']})")
            print(f"  Total reward: {ap.get('total_reward', 0):.2f}")
            print(f"  Path length:  {ap.get('path_length', 0)}")


if __name__ == "__main__":
    main()
