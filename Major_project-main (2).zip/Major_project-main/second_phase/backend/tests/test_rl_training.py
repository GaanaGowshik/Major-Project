"""
tests/test_rl_training.py — Tests for RL training and inference pipeline.

These tests use synthetic graphs so no actual cloud scan is required.
Training is run for a very small number of timesteps to keep tests fast.
"""

import json
import sys
from pathlib import Path

import networkx as nx
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))


# ──────────────────────────────────────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────────────────────────────────────

def _make_test_graph() -> nx.DiGraph:
    """Minimal graph: user → role → capability."""
    g = nx.DiGraph()
    g.add_node("arn:aws:iam::123:user/tester", node_type="IAMUser", display_name="tester")
    g.add_node("arn:aws:iam::123:role/test-role", node_type="IAMRole", display_name="test-role")
    g.add_node("arn:aws:iam::ACCOUNT:policy/Admin", node_type="Capability", display_name="Admin")
    g.add_edge("arn:aws:iam::123:user/tester", "arn:aws:iam::123:role/test-role",
               relation="CAN_ASSUME", actions=["sts:AssumeRole"], confirmed=True)
    g.add_edge("arn:aws:iam::123:role/test-role", "arn:aws:iam::ACCOUNT:policy/Admin",
               relation="PRIVESC_TO", actions=["iam:AttachUserPolicy"], confirmed=True)
    return g


def _save_graph(g: nx.DiGraph, tmp_path: Path) -> str:
    """Save graph as AssessmentGraph JSON to tmp_path."""
    from aws_pentest.models.graph_models import AssessmentGraph, GraphNode, GraphEdge
    ag = AssessmentGraph(
        nodes=[
            GraphNode(
                node_id=node_id,
                node_type=data.get("node_type", "IAMUser"),
                display_name=data.get("display_name", node_id.split("/")[-1]),
                arn=node_id,
            )
            for node_id, data in g.nodes(data=True)
        ],
        edges=[
            GraphEdge(
                source_id=u, target_id=v,
                relation=d.get("relation", "CONNECTED"),
                actions=d.get("actions", []),
                evidence=d.get("evidence", []),
            )
            for u, v, d in g.edges(data=True)
        ],
    )
    graph_file = tmp_path / "test_graph.json"
    graph_file.write_text(json.dumps(ag.to_dict(), default=str), encoding="utf-8")
    return str(graph_file)


# ──────────────────────────────────────────────────────────────────────────────
# Training pipeline tests
# ──────────────────────────────────────────────────────────────────────────────

class TestTrainingPipeline:
    def test_train_starts_and_completes(self, tmp_path):
        """Training should complete without error on a synthetic graph."""
        from rl.train import train

        graph_path = _save_graph(_make_test_graph(), tmp_path)
        model_path = str(tmp_path / "test_model")

        result = train(
            provider="aws",
            graph_json_path=graph_path,
            model_save_path=model_path,
            total_timesteps=500,   # tiny — just validates pipeline works
            verbose=0,
        )

        assert result["status"] == "complete", f"Training failed: {result.get('message')}"

    def test_model_is_saved(self, tmp_path):
        """Training should save a .zip model file."""
        from rl.train import train

        graph_path = _save_graph(_make_test_graph(), tmp_path)
        model_path = str(tmp_path / "test_model")

        train(
            provider="aws",
            graph_json_path=graph_path,
            model_save_path=model_path,
            total_timesteps=300,
            verbose=0,
        )

        assert (tmp_path / "test_model.zip").exists(), "Model .zip file not saved"

    def test_training_metrics_returned(self, tmp_path):
        """Training should return metrics dict with expected keys."""
        from rl.train import train

        graph_path = _save_graph(_make_test_graph(), tmp_path)
        model_path = str(tmp_path / "test_model")

        result = train(
            provider="aws",
            graph_json_path=graph_path,
            model_save_path=model_path,
            total_timesteps=300,
            verbose=0,
        )

        metrics = result.get("metrics", {})
        assert "total_episodes" in metrics
        assert "avg_reward" in metrics
        assert "success_rate" in metrics
        assert metrics["total_episodes"] >= 0


# ──────────────────────────────────────────────────────────────────────────────
# Inference tests
# ──────────────────────────────────────────────────────────────────────────────

class TestInferencePipeline:
    def test_inference_no_model_returns_graceful(self, tmp_path):
        """If no model exists, inference should return a meaningful message."""
        from rl.train import run_inference

        graph_path = _save_graph(_make_test_graph(), tmp_path)
        model_path = str(tmp_path / "nonexistent_model")

        result = run_inference(
            provider="aws",
            graph_json_path=graph_path,
            model_path=model_path,
        )

        assert result["status"] == "no_model"
        assert "path" in result
        assert isinstance(result["path"], list)
        assert "message" in result

    def test_inference_after_training(self, tmp_path):
        """After training, inference should return a path with only valid graph nodes."""
        from rl.train import train, run_inference

        g = _make_test_graph()
        graph_path = _save_graph(g, tmp_path)
        model_path = str(tmp_path / "infer_model")

        train(
            provider="aws",
            graph_json_path=graph_path,
            model_save_path=model_path,
            total_timesteps=500,
            verbose=0,
        )

        result = run_inference(
            provider="aws",
            graph_json_path=graph_path,
            model_path=model_path,
            n_episodes=3,
        )

        assert result["status"] == "complete", f"Inference failed: {result.get('message')}"
        assert "path" in result

        # Every node in the path must be a real graph node
        real_nodes = set(g.nodes())
        for step in result["path"]:
            assert step["node_id"] in real_nodes, (
                f"Inference path node '{step['node_id']}' not in graph nodes"
            )

    def test_inference_path_has_valid_structure(self, tmp_path):
        """Each path step must have required fields."""
        from rl.train import train, run_inference

        graph_path = _save_graph(_make_test_graph(), tmp_path)
        model_path = str(tmp_path / "struct_model")

        train(
            provider="aws",
            graph_json_path=graph_path,
            model_save_path=model_path,
            total_timesteps=500,
            verbose=0,
        )

        result = run_inference(
            provider="aws",
            graph_json_path=graph_path,
            model_path=model_path,
        )

        for step in result.get("path", []):
            assert "node_id" in step, "Path step missing node_id"
            assert "node_type" in step, "Path step missing node_type"
            assert "action" in step, "Path step missing action"


# ──────────────────────────────────────────────────────────────────────────────
# Provider separation tests
# ──────────────────────────────────────────────────────────────────────────────

class TestProviderSeparation:
    def test_aws_and_gcp_models_are_independent(self, tmp_path):
        """Training for AWS should not affect GCP model path."""
        from rl.train import train

        g = _make_test_graph()
        graph_path = _save_graph(g, tmp_path)
        aws_model = str(tmp_path / "aws_model")
        gcp_model = str(tmp_path / "gcp_model")

        # Train AWS model
        train(
            provider="aws",
            graph_json_path=graph_path,
            model_save_path=aws_model,
            total_timesteps=300,
            verbose=0,
        )

        assert (tmp_path / "aws_model.zip").exists()
        assert not (tmp_path / "gcp_model.zip").exists()

    def test_inference_uses_correct_provider_graph(self, tmp_path):
        """Inference result should carry the correct provider label."""
        from rl.train import train, run_inference

        graph_path = _save_graph(_make_test_graph(), tmp_path)
        model_path = str(tmp_path / "prov_model")

        train(
            provider="aws",
            graph_json_path=graph_path,
            model_save_path=model_path,
            total_timesteps=300,
            verbose=0,
        )

        result = run_inference(
            provider="aws",
            graph_json_path=graph_path,
            model_path=model_path,
        )

        assert result.get("provider") == "aws"
