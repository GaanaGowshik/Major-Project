"""
tests/test_rl_env.py — Comprehensive tests for the new CloudPentestEnv,
GraphPreprocessor, and RewardSystem.

Uses synthetic in-memory graphs — no AWS/GCP calls required.
"""

import sys
from pathlib import Path

import networkx as nx
import pytest
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from env.graph_preprocessor import GraphPreprocessor, MAX_EDGES, NODE_FEATURE_DIM
from env.gym_env import CloudPentestEnv, _MAX_STEPS, _OBS_DIM
from env.rewards import RewardSystem


# ──────────────────────────────────────────────────────────────────────────────
# Synthetic graph fixtures
# ──────────────────────────────────────────────────────────────────────────────

def _make_aws_graph() -> nx.DiGraph:
    """Small AWS-like attack graph:
      alice (IAMUser) --CAN_ASSUME--> dev-role (IAMRole)
      dev-role        --PRIVESC_TO--> AdministratorAccess (Capability)
    """
    g = nx.DiGraph()
    g.add_node(
        "arn:aws:iam::123:user/alice",
        node_type="IAMUser", display_name="alice",
    )
    g.add_node(
        "arn:aws:iam::123:role/dev-role",
        node_type="IAMRole", display_name="dev-role",
    )
    g.add_node(
        "arn:aws:iam::ACCOUNT:policy/AdministratorAccess",
        node_type="Capability", display_name="AdministratorAccess",
    )
    g.add_edge(
        "arn:aws:iam::123:user/alice",
        "arn:aws:iam::123:role/dev-role",
        relation="CAN_ASSUME", actions=["sts:AssumeRole"],
        evidence=[{"EvalDecision": "allowed"}], confirmed=True,
    )
    g.add_edge(
        "arn:aws:iam::123:role/dev-role",
        "arn:aws:iam::ACCOUNT:policy/AdministratorAccess",
        relation="PRIVESC_TO", actions=["iam:AttachUserPolicy"],
        evidence=[{"EvalDecision": "allowed"}], confirmed=True,
    )
    return g


def _make_gcp_graph() -> nx.DiGraph:
    """Small GCP-like graph:
      sa-1 (GCPServiceAccount) --CAN_IMPERSONATE--> sa-admin (GCPServiceAccount)
      sa-admin --PRIVESC_TO--> project:admin (Capability)
    """
    g = nx.DiGraph()
    g.add_node("serviceAccount:sa-1@proj.iam", node_type="GCPServiceAccount", display_name="sa-1")
    g.add_node("serviceAccount:sa-admin@proj.iam", node_type="GCPServiceAccount", display_name="sa-admin")
    g.add_node("//cloudresourcemanager/projects/proj:admin", node_type="Capability", display_name="ProjectAdmin")
    g.add_edge("serviceAccount:sa-1@proj.iam", "serviceAccount:sa-admin@proj.iam",
               relation="CAN_IMPERSONATE", actions=["iam.serviceAccounts.getAccessToken"], confirmed=True)
    g.add_edge("serviceAccount:sa-admin@proj.iam", "//cloudresourcemanager/projects/proj:admin",
               relation="PRIVESC_TO", actions=["resourcemanager.projects.setIamPolicy"], confirmed=True)
    return g


def _make_empty_graph() -> nx.DiGraph:
    return nx.DiGraph()


def _make_single_node_graph() -> nx.DiGraph:
    g = nx.DiGraph()
    g.add_node("arn:aws:iam::123:user/only", node_type="IAMUser", display_name="only")
    return g


@pytest.fixture
def aws_env():
    env = CloudPentestEnv(nx_graph=_make_aws_graph())
    yield env
    env.close()


@pytest.fixture
def gcp_env():
    env = CloudPentestEnv(nx_graph=_make_gcp_graph())
    yield env
    env.close()


# ──────────────────────────────────────────────────────────────────────────────
# GraphPreprocessor tests
# ──────────────────────────────────────────────────────────────────────────────

class TestGraphPreprocessor:
    def test_valid_graph_loads(self):
        g = _make_aws_graph()
        pp = GraphPreprocessor(g)
        assert len(pp.nodes) == 3

    def test_feature_matrix_shape(self):
        g = _make_aws_graph()
        pp = GraphPreprocessor(g)
        assert pp.node_features.shape == (3, NODE_FEATURE_DIM)

    def test_capability_is_goal(self):
        g = _make_aws_graph()
        pp = GraphPreprocessor(g)
        # The Capability node should be in goal_nodes
        cap_id = "arn:aws:iam::ACCOUNT:policy/AdministratorAccess"
        cap_idx = pp.node_index[cap_id]
        assert cap_idx in pp.goal_nodes

    def test_iam_user_is_start(self):
        g = _make_aws_graph()
        pp = GraphPreprocessor(g)
        user_id = "arn:aws:iam::123:user/alice"
        user_idx = pp.node_index[user_id]
        assert user_idx in pp.start_nodes

    def test_empty_graph_raises(self):
        with pytest.raises(ValueError, match="empty graph"):
            GraphPreprocessor(_make_empty_graph())

    def test_out_edges_returns_correct_structure(self):
        g = _make_aws_graph()
        pp = GraphPreprocessor(g)
        user_id = "arn:aws:iam::123:user/alice"
        edges = pp.get_out_edges(user_id)
        assert len(edges) == 1
        assert edges[0]["relation"] == "CAN_ASSUME"
        assert edges[0]["target_id"] == "arn:aws:iam::123:role/dev-role"

    def test_gcp_graph_loads(self):
        g = _make_gcp_graph()
        pp = GraphPreprocessor(g)
        assert len(pp.nodes) == 3
        assert len(pp.goal_nodes) >= 1

    def test_missing_attributes_tolerated(self):
        """Graph nodes without node_type should not crash."""
        g = nx.DiGraph()
        g.add_node("node-a")  # no attributes
        g.add_node("node-b", node_type="IAMUser", display_name="b")
        g.add_edge("node-a", "node-b", relation="CAN_ASSUME")
        pp = GraphPreprocessor(g)
        assert len(pp.nodes) == 2


# ──────────────────────────────────────────────────────────────────────────────
# CloudPentestEnv tests
# ──────────────────────────────────────────────────────────────────────────────

class TestCloudPentestEnv:
    # ── Initialisation ───────────────────────────────────────────────────────

    def test_env_node_count(self, aws_env):
        assert len(aws_env.nodes) == 3

    def test_action_space_capped(self, aws_env):
        assert aws_env.action_space.n == MAX_EDGES

    def test_observation_space_shape(self, aws_env):
        assert aws_env.observation_space.shape == (_OBS_DIM,)

    def test_graph_source_injected(self, aws_env):
        assert aws_env.graph_source == "injected"

    def test_gcp_env_loads(self, gcp_env):
        assert len(gcp_env.nodes) == 3

    # ── reset() ──────────────────────────────────────────────────────────────

    def test_reset_returns_obs_and_info(self, aws_env):
        obs, info = aws_env.reset()
        assert obs.shape == (_OBS_DIM,)
        assert "node_id" in info
        assert "node_count" in info
        assert "edge_count" in info
        assert "graph_source" in info

    def test_reset_zeros_step_count(self, aws_env):
        aws_env.reset()
        aws_env.step(0)
        aws_env.step(0)
        aws_env.reset()
        assert aws_env._step_count == 0

    def test_reset_starts_on_valid_node(self, aws_env):
        obs, info = aws_env.reset()
        assert aws_env._current_node in aws_env.nodes

    # ── step() — valid action ─────────────────────────────────────────────

    def test_valid_action_changes_node(self, aws_env):
        """After a valid edge traversal, the current node should change."""
        aws_env.reset()
        # Force start to alice (has CAN_ASSUME edge)
        alice = "arn:aws:iam::123:user/alice"
        aws_env.current_node = aws_env.nodes.index(alice)
        aws_env._current_node = alice

        obs, reward, terminated, truncated, info = aws_env.step(0)
        # Should have moved to dev-role
        assert aws_env._current_node != alice
        assert info["success"] is True

    def test_valid_action_reward_positive(self, aws_env):
        """Traversing a valid edge should generally yield positive reward."""
        aws_env.reset()
        alice = "arn:aws:iam::123:user/alice"
        aws_env.current_node = aws_env.nodes.index(alice)
        aws_env._current_node = alice

        _, reward, _, _, _ = aws_env.step(0)
        # First traversal of CAN_ASSUME edge should yield positive reward
        # (novelty + privilege gain)
        assert reward > 0

    # ── step() — invalid action ──────────────────────────────────────────

    def test_invalid_action_negative_reward(self, aws_env):
        """Action index beyond real edge count → penalty."""
        aws_env.reset()
        # Force to Capability node which has no outgoing edges
        cap = "arn:aws:iam::ACCOUNT:policy/AdministratorAccess"
        aws_env.current_node = aws_env.nodes.index(cap)
        aws_env._current_node = cap

        _, reward, _, _, info = aws_env.step(0)
        assert reward < 0
        assert info["success"] is False

    def test_invalid_action_stays_in_place(self, aws_env):
        aws_env.reset()
        cap = "arn:aws:iam::ACCOUNT:policy/AdministratorAccess"
        aws_env.current_node = aws_env.nodes.index(cap)
        aws_env._current_node = cap

        aws_env.step(0)
        assert aws_env._current_node == cap  # should not move

    # ── Termination ──────────────────────────────────────────────────────

    def test_episode_terminates_at_goal(self, aws_env):
        """Navigate to the Capability node and verify terminated=True."""
        aws_env.reset()
        dev_role = "arn:aws:iam::123:role/dev-role"
        aws_env.current_node = aws_env.nodes.index(dev_role)
        aws_env._current_node = dev_role

        # dev-role has PRIVESC_TO → AdministratorAccess
        _, reward, terminated, _, info = aws_env.step(0)
        if info.get("relation") == "PRIVESC_TO":
            assert terminated is True
            assert reward > 0

    def test_episode_truncates_at_max_steps(self, aws_env):
        aws_env.reset()
        # Force to Capability (no outgoing edges → each step is invalid)
        cap = "arn:aws:iam::ACCOUNT:policy/AdministratorAccess"
        aws_env.current_node = aws_env.nodes.index(cap)
        aws_env._current_node = cap

        truncated = False
        for _ in range(_MAX_STEPS + 5):
            _, _, terminated, truncated, _ = aws_env.step(0)
            if terminated or truncated:
                break

        assert truncated or aws_env._step_count >= _MAX_STEPS

    # ── Observation ──────────────────────────────────────────────────────

    def test_observation_contains_action_mask(self, aws_env):
        """Valid action slots should have 1.0, invalid slots 0.0."""
        obs, _ = aws_env.reset()
        alice = "arn:aws:iam::123:user/alice"
        aws_env.current_node = aws_env.nodes.index(alice)
        aws_env._current_node = alice

        obs = aws_env._build_obs()
        # alice has 1 outgoing edge → action[0]=1.0, action[1..]=0.0
        mask_start = NODE_FEATURE_DIM + 2
        assert obs[mask_start] == 1.0
        assert obs[mask_start + 1] == 0.0

    # ── Empty / edge case graphs ─────────────────────────────────────────

    def test_empty_graph_creates_placeholder(self):
        """Empty graph should not crash — a placeholder node is added."""
        env = CloudPentestEnv(nx_graph=_make_empty_graph())
        obs, info = env.reset()
        assert obs.shape == (_OBS_DIM,)
        env.close()

    def test_single_node_graph(self):
        """Graph with one node and no edges — all actions should be invalid."""
        env = CloudPentestEnv(nx_graph=_make_single_node_graph())
        env.reset()
        _, reward, _, _, info = env.step(0)
        assert reward < 0
        env.close()

    # ── Attack path result ───────────────────────────────────────────────

    def test_get_attack_path_result_structure(self, aws_env):
        aws_env.reset()
        result = aws_env.get_attack_path_result()
        assert "path" in result
        assert "total_reward" in result
        assert "path_length" in result
        assert "success" in result
        assert "graph_source" in result

    def test_get_attack_path_result_nodes_are_real(self, aws_env):
        """Attack path should only contain nodes from the actual graph."""
        aws_env.reset()
        alice = "arn:aws:iam::123:user/alice"
        aws_env.current_node = aws_env.nodes.index(alice)
        aws_env._current_node = alice
        aws_env.step(0)  # move to dev-role

        result = aws_env.get_attack_path_result()
        for step in result["path"]:
            assert step["node_id"] in aws_env.nodes, (
                f"Path node {step['node_id']} not in graph nodes"
            )


# ──────────────────────────────────────────────────────────────────────────────
# RewardSystem tests
# ──────────────────────────────────────────────────────────────────────────────

class TestRewardSystem:
    def test_invalid_action_penalty(self):
        rs = RewardSystem()
        result = {"success": False, "action_type": "invalid"}
        assert rs.calculate_reward_for_traversal(result) == rs.INVALID_ACTION_PENALTY

    def test_novelty_bonus_first_visit(self):
        rs = RewardSystem()
        result = {
            "success": True, "action_type": "traverse_edge",
            "relation": "CAN_ASSUME", "source": "a", "target": "b",
            "target_node_type": "IAMRole", "is_privesc": False,
            "confirmed": True, "actions": [], "privilege_gain": 60,
            "is_goal": False, "is_sensitive": False, "is_public": False,
        }
        r1 = rs.calculate_reward_for_traversal(result)
        r2 = rs.calculate_reward_for_traversal(result)  # revisit
        assert r1 > r2, "First visit should yield higher reward than revisit"

    def test_privesc_bonus(self):
        rs = RewardSystem()
        result = {
            "success": True, "action_type": "traverse_edge",
            "relation": "PRIVESC_TO", "source": "src", "target": "admin",
            "target_node_type": "Capability", "is_privesc": True,
            "confirmed": True, "actions": [], "privilege_gain": 150,
            "is_goal": True, "is_sensitive": True, "is_public": False,
        }
        reward = rs.calculate_reward_for_traversal(result)
        assert reward > 50, "PrivEsc to Capability should give large reward"

    def test_revisit_penalty(self):
        rs = RewardSystem()
        result = {
            "success": True, "action_type": "traverse_edge",
            "relation": "CAN_ASSUME", "source": "a", "target": "b",
            "target_node_type": "IAMRole", "is_privesc": False,
            "confirmed": True, "actions": [], "privilege_gain": 0,
            "is_goal": False, "is_sensitive": False, "is_public": False,
        }
        rs.calculate_reward_for_traversal(result)   # first visit
        r2 = rs.calculate_reward_for_traversal(result)  # revisit
        assert r2 < 0 or r2 < 10, "Revisit should not give novelty bonus"

    def test_reset_clears_visited(self):
        rs = RewardSystem()
        result = {
            "success": True, "action_type": "traverse_edge",
            "relation": "CAN_ASSUME", "source": "a", "target": "b",
            "target_node_type": "IAMRole", "is_privesc": False,
            "confirmed": True, "actions": [], "privilege_gain": 40,
            "is_goal": False, "is_sensitive": False, "is_public": False,
        }
        r1 = rs.calculate_reward_for_traversal(result)
        rs.reset()
        r2 = rs.calculate_reward_for_traversal(result)  # should get novelty again
        assert abs(r1 - r2) < 1e-6, "After reset, same traversal should give same reward"


# ──────────────────────────────────────────────────────────────────────────────
# Backward compatibility: tests/aws/test_gym_env.py compatibility
# ──────────────────────────────────────────────────────────────────────────────

def test_env_has_nodes():
    env = CloudPentestEnv(nx_graph=_make_aws_graph())
    assert len(env.nodes) == 3
    env.close()


def test_env_observation_space_size():
    env = CloudPentestEnv(nx_graph=_make_aws_graph())
    # observation_space.n is the node count (backward compat attribute)
    assert env.observation_space.n == 3
    env.close()


def test_env_action_space_is_capped():
    env = CloudPentestEnv(nx_graph=_make_aws_graph())
    assert env.action_space.n == env._MAX_EDGES
    env.close()


def test_env_graph_source_injected():
    env = CloudPentestEnv(nx_graph=_make_aws_graph())
    assert env.graph_source == "injected"
    env.close()


def test_reset_returns_zero_step_count():
    env = CloudPentestEnv(nx_graph=_make_aws_graph())
    env.reset()
    assert env._step_count == 0
    env.close()


def test_reward_system_created_on_reset():
    env = CloudPentestEnv(nx_graph=_make_aws_graph())
    env.reset()
    assert isinstance(env.reward_system, RewardSystem)
    env.close()
