"""
tests/aws/test_gym_env.py — Legacy env test compatibility shim.

The real tests are now in tests/test_rl_env.py.
This file is kept for backward compatibility and re-exports the test functions
from the new location, ensuring the legacy test path still passes.
"""

import sys
from pathlib import Path

import networkx as nx
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from env.gym_env import CloudPentestEnv, _MAX_STEPS
from env.graph_preprocessor import MAX_EDGES
from env.rewards import RewardSystem


# ──────────────────────────────────────────────────────────────────────────────
# Synthetic graph fixture (same structure as before)
# ──────────────────────────────────────────────────────────────────────────────

def _make_synthetic_graph() -> nx.DiGraph:
    """
    Build a tiny synthetic attack graph for testing:

      alice (IAMUser) --CAN_ASSUME--> dev-role (IAMRole)
      dev-role        --PRIVESC_TO--> AdministratorAccess (Capability)
    """
    g = nx.DiGraph()
    g.add_node(
        "arn:aws:iam::123:user/alice",
        node_type="IAMUser", display_name="alice",
    )
    g.add_node(
        "arn:aws:iam::123:role/dev-role",
        node_type="IAMRole", display_name="dev-role",
    )
    g.add_node(
        "arn:aws:iam::ACCOUNT:policy/AdministratorAccess",
        node_type="Capability", display_name="AdministratorAccess",
    )
    g.add_edge(
        "arn:aws:iam::123:user/alice",
        "arn:aws:iam::123:role/dev-role",
        relation="CAN_ASSUME", actions=["sts:AssumeRole"],
        evidence=[{"EvalDecision": "allowed"}], confirmed=True,
    )
    g.add_edge(
        "arn:aws:iam::123:role/dev-role",
        "arn:aws:iam::ACCOUNT:policy/AdministratorAccess",
        relation="PRIVESC_TO", actions=["iam:AttachUserPolicy"],
        evidence=[{"EvalDecision": "allowed"}], confirmed=True,
    )
    return g


@pytest.fixture
def env_with_synthetic_graph(tmp_path, monkeypatch):
    """Create a CloudPentestEnv pre-loaded with the synthetic graph."""
    import json
    from aws_pentest.models.graph_models import AssessmentGraph, GraphNode, GraphEdge

    g = _make_synthetic_graph()

    # Serialise the graph into the Phase 1 JSON format
    ag = AssessmentGraph(
        nodes=[
            GraphNode(
                node_id=node_id,
                node_type=data["node_type"],
                display_name=data["display_name"],
                arn=node_id,
                attributes={},
            )
            for node_id, data in g.nodes(data=True)
        ],
        edges=[
            GraphEdge(
                source_id=u, target_id=v,
                relation=d["relation"],
                actions=d.get("actions", []),
                evidence=d.get("evidence", []),
                policy_sources=[],
            )
            for u, v, d in g.edges(data=True)
        ],
    )

    graph_file = tmp_path / "test_graph.json"
    graph_file.write_text(json.dumps(ag.to_dict()), encoding="utf-8")

    env = CloudPentestEnv(graph_json_path=str(graph_file))
    yield env
    env.close()


# ──────────────────────────────────────────────────────────────────────────────
# Tests — updated for the new env API
# ──────────────────────────────────────────────────────────────────────────────

def test_env_has_nodes(env_with_synthetic_graph):
    env = env_with_synthetic_graph
    assert len(env.nodes) == 3, "Synthetic graph has 3 nodes"


def test_env_observation_space_size(env_with_synthetic_graph):
    env = env_with_synthetic_graph
    # observation_space.n is the backward-compat node count attribute
    assert env.observation_space.n == 3


def test_env_action_space_is_capped(env_with_synthetic_graph):
    env = env_with_synthetic_graph
    assert env.action_space.n == env._MAX_EDGES


def test_env_graph_source_phase1(env_with_synthetic_graph):
    env = env_with_synthetic_graph
    assert env.graph_source == "phase1_real"


def test_reset_returns_info_dict(env_with_synthetic_graph):
    env = env_with_synthetic_graph
    _, info = env.reset()
    assert "node_count" in info
    assert "edge_count" in info
    assert "graph_source" in info


def test_reset_resets_step_count(env_with_synthetic_graph):
    env = env_with_synthetic_graph
    env.reset()
    env.step(0)
    env.step(0)
    env.reset()
    assert env._step_count == 0


def test_invalid_action_gives_negative_reward(env_with_synthetic_graph):
    """Action index beyond real edge count → penalty."""
    env = env_with_synthetic_graph
    env.reset()

    # Force to Capability node (no outgoing edges)
    cap = "arn:aws:iam::ACCOUNT:policy/AdministratorAccess"
    env.current_node = env.nodes.index(cap)
    env._current_node = cap

    _, reward, _, _, info = env.step(0)
    assert reward < 0


def test_episode_truncates_at_max_steps(env_with_synthetic_graph):
    """Episode must truncate after _MAX_STEPS steps."""
    env = env_with_synthetic_graph
    env.reset()

    # Force to Capability (no outgoing → all steps invalid → no termination)
    cap = "arn:aws:iam::ACCOUNT:policy/AdministratorAccess"
    env.current_node = env.nodes.index(cap)
    env._current_node = cap

    truncated = False
    for _ in range(_MAX_STEPS + 5):
        _, _, terminated, truncated, _ = env.step(0)
        if terminated or truncated:
            break

    assert truncated or env._step_count >= _MAX_STEPS, "Episode must end"


def test_episode_terminates_at_capability_node(env_with_synthetic_graph):
    """
    Navigate to the AdministratorAccess (Capability) node and verify
    terminated=True.
    """
    env = env_with_synthetic_graph
    env.reset()

    dev_role_arn = "arn:aws:iam::123:role/dev-role"
    if dev_role_arn in env.nodes:
        env.current_node = env.nodes.index(dev_role_arn)
        env._current_node = dev_role_arn
        out = env._out_edges()
        if out:
            _, reward, terminated, truncated, info = env.step(0)
            if info.get("relation") == "PRIVESC_TO":
                assert terminated is True, "PRIVESC_TO target should terminate episode"
                assert reward > 0, "Reaching goal should give positive reward"


def test_reward_system_created_on_reset(env_with_synthetic_graph):
    env = env_with_synthetic_graph
    env.reset()
    assert isinstance(env.reward_system, RewardSystem)


def test_novelty_bonus_on_first_visit(env_with_synthetic_graph):
    """First time visiting a node should give higher reward than revisiting."""
    env = env_with_synthetic_graph
    env.reset()

    result = {
        "success": True,
        "action_type": "traverse_edge",
        "relation": "CAN_ASSUME",
        "source": "arn:aws:iam::123:user/alice",
        "target": "arn:aws:iam::123:role/dev-role",
        "target_node_type": "IAMRole",
        "is_privesc": False,
        "confirmed": True,
        "actions": ["sts:AssumeRole"],
        "privilege_gain": 60,
        "is_goal": False,
        "is_sensitive": False,
        "is_public": False,
    }
    r1 = env.reward_system.calculate_reward_for_traversal(result)
    r2 = env.reward_system.calculate_reward_for_traversal(result)  # revisit

    assert r1 > r2, "First visit should yield higher reward than revisit"


def test_reward_system_failure_penalty():
    rs = RewardSystem()
    result = {"success": False, "action_type": "invalid"}
    assert rs.calculate_reward_for_traversal(result) == rs.INVALID_ACTION_PENALTY


def test_reward_system_privesc_bonus():
    rs = RewardSystem()
    result = {
        "success": True,
        "action_type": "traverse_edge",
        "relation": "PRIVESC_TO",
        "source": "src",
        "target": "admin",
        "target_node_type": "Capability",
        "is_privesc": True,
        "confirmed": True,
        "actions": [],
        "privilege_gain": 150,
        "is_goal": True,
        "is_sensitive": True,
        "is_public": False,
    }
    reward = rs.calculate_reward_for_traversal(result)
    assert reward > 50, "PrivEsc traversal should give large reward"


def test_reward_system_revisit_penalty():
    rs = RewardSystem()
    result = {
        "success": True,
        "action_type": "traverse_edge",
        "relation": "CAN_ASSUME",
        "source": "a",
        "target": "b",
        "target_node_type": "IAMRole",
        "is_privesc": False,
        "confirmed": True,
        "actions": [],
        "privilege_gain": 0,
        "is_goal": False,
        "is_sensitive": False,
        "is_public": False,
    }
    rs.calculate_reward_for_traversal(result)   # first visit: adds "b" to visited
    r2 = rs.calculate_reward_for_traversal(result)  # revisit
    assert r2 < 0 or r2 < 10, "Revisit should not give novelty bonus"
