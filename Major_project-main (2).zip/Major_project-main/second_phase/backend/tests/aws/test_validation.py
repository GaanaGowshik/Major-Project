"""
Phase 6 tests — Controlled AWS Validation (AWSValidator).

All AWS API calls are mocked via unittest.mock.patch.
No real AWS resources are created.

Tests verify:
  - READ_ONLY mode returns not_performed for all techniques
  - DRY_RUN mode returns dry_run_preview with correct steps
  - VALIDATE without confirmed=True returns not_performed
  - s3_write VALIDATE success creates the test object but does NOT delete it
  - s3_write uses sequential controlled_validN.txt naming
  - s3_write VALIDATE object key is returned in result for cleanup
  - s3_write cleanup is NOT automatic (object stays after Execute)
  - s3_write VALIDATE partial failure (PutObject ok, GetObject fails) still
    does not attempt DeleteObject automatically
  - s3_read VALIDATE success: GetObject when object_key provided
  - s3_read VALIDATE success: ListObjectsV2 when no object_key
  - iam_pass_role VALIDATE uses IAM simulator (non-mutating)
  - ec2_access VALIDATE success — DescribeInstances read-only
  - ec2_access DRY_RUN makes zero AWS calls
  - ec2_control DRY_RUN makes zero AWS calls
  - ec2_control VALIDATE success — stop/start/verify, state restored
  - ec2_control VALIDATE non-running instance — returns not_performed, no Stop
  - VALIDATION_PREFIX is used in all resource names
  - ValidationResult.confirmed is only True when execution succeeds
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch, call

import pytest

from aws_pentest.validation.validator import (
    AWSValidator,
    ValidationMode,
    ValidationResult,
    VALIDATION_PREFIX,
    WRITE_TEST_FILENAME_BASE,
)


# ---------------------------------------------------------------------------
# Fixture: validator instances for each mode
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_session():
    return MagicMock()


@pytest.fixture
def read_only_validator(mock_session):
    return AWSValidator(session=mock_session, mode=ValidationMode.READ_ONLY, run_id="test-run")


@pytest.fixture
def dry_run_validator(mock_session):
    return AWSValidator(session=mock_session, mode=ValidationMode.DRY_RUN, run_id="test-run")


@pytest.fixture
def validate_validator(mock_session):
    return AWSValidator(session=mock_session, mode=ValidationMode.VALIDATE, run_id="test-run")


# ---------------------------------------------------------------------------
# Tests: ValidationMode safety gate
# ---------------------------------------------------------------------------

class TestReadOnlyMode:
    def test_s3_write_read_only_not_performed(self, read_only_validator: AWSValidator):
        result = read_only_validator.validate(
            "find-001", "s3_write", confirmed=False, bucket_name="test-bucket"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False
        assert result.mode == ValidationMode.READ_ONLY

    def test_s3_read_read_only_not_performed(self, read_only_validator: AWSValidator):
        result = read_only_validator.validate(
            "find-002", "s3_read", confirmed=False, bucket_name="test-bucket"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False

    def test_iam_pass_role_read_only_not_performed(self, read_only_validator: AWSValidator):
        result = read_only_validator.validate(
            "find-003", "iam_pass_role", confirmed=False,
            role_arn="arn:aws:iam::123456789012:role/TestRole"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False

    def test_ec2_access_read_only_not_performed(self, read_only_validator: AWSValidator):
        result = read_only_validator.validate(
            "find-004", "ec2_access", confirmed=False, instance_id="i-abc123"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False

    def test_ec2_control_read_only_not_performed(self, read_only_validator: AWSValidator):
        result = read_only_validator.validate(
            "find-005", "ec2_control", confirmed=False, instance_id="i-abc123"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False

    def test_read_only_no_aws_calls(self, mock_session: MagicMock, read_only_validator: AWSValidator):
        read_only_validator.validate("f", "s3_write", bucket_name="b")
        mock_session.client.assert_not_called()


class TestDryRunMode:
    def test_s3_write_dry_run_preview(self, dry_run_validator: AWSValidator):
        result = dry_run_validator.validate(
            "find-001", "s3_write", confirmed=False, bucket_name="my-bucket"
        )
        assert result.status == "dry_run_preview"
        assert result.confirmed is False
        assert len(result.dry_run_preview) >= 2
        assert any("PutObject" in step for step in result.dry_run_preview)
        assert any("DeleteObject" in step for step in result.dry_run_preview)
        # DRY RUN must not reference auto-cleanup
        assert any("SEPARATE" in step or "user confirmation" in step.lower()
                   for step in result.dry_run_preview)

    def test_dry_run_no_aws_calls(self, mock_session: MagicMock, dry_run_validator: AWSValidator):
        dry_run_validator.validate("f", "s3_write", bucket_name="b")
        mock_session.client.assert_not_called()

    def test_iam_dry_run_preview(self, dry_run_validator: AWSValidator):
        result = dry_run_validator.validate(
            "find-003", "iam_pass_role", confirmed=False,
            role_arn="arn:aws:iam::123456789012:role/TestRole"
        )
        assert result.status == "dry_run_preview"
        assert any("SimulatePrincipalPolicy" in s for s in result.dry_run_preview)

    def test_ec2_access_dry_run_no_aws_calls(
        self, mock_session: MagicMock, dry_run_validator: AWSValidator
    ):
        result = dry_run_validator.validate(
            "find-004", "ec2_access", confirmed=False, instance_id="i-abc123"
        )
        assert result.status == "dry_run_preview"
        assert any("DescribeInstances" in s for s in result.dry_run_preview)
        mock_session.client.assert_not_called()

    def test_ec2_control_dry_run_no_aws_calls(
        self, mock_session: MagicMock, dry_run_validator: AWSValidator
    ):
        result = dry_run_validator.validate(
            "find-005", "ec2_control", confirmed=False, instance_id="i-abc123"
        )
        assert result.status == "dry_run_preview"
        assert any("StopInstances" in s for s in result.dry_run_preview)
        assert any("StartInstances" in s for s in result.dry_run_preview)
        # Critical: DRY RUN must make ZERO AWS calls
        mock_session.client.assert_not_called()


class TestValidateModeUnconfirmed:
    def test_validate_without_confirmed_not_performed(self, validate_validator: AWSValidator):
        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=False, bucket_name="test-bucket"
        )
        assert result.status == "not_performed"
        assert result.confirmed is False
        assert "confirmed=True" in result.description


# ---------------------------------------------------------------------------
# Tests: S3 Write Validation
# ---------------------------------------------------------------------------

class TestS3WriteValidation:
    def _make_s3_mock_with_paginator(self) -> MagicMock:
        """Create an S3 mock that also returns a working paginator (for _next_seq_object_key)."""
        s3 = MagicMock()
        # Mock paginator for list_objects_v2 (used by _next_seq_object_key)
        paginator = MagicMock()
        paginator.paginate.return_value = [{"Contents": []}]
        s3.get_paginator.return_value = paginator
        s3.put_object.return_value = {}
        s3.get_object.return_value = {
            "Body": MagicMock(read=MagicMock(return_value=b"test content"))
        }
        s3.delete_object.return_value = {}
        return s3

    def test_s3_write_success(self, mock_session: MagicMock, validate_validator: AWSValidator):
        s3 = self._make_s3_mock_with_paginator()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="pentest-test-bucket"
        )

        assert result.status == "success"
        assert result.confirmed is True
        assert result.mode == ValidationMode.VALIDATE
        # Verify PutObject was called
        s3.put_object.assert_called_once()
        call_kwargs = s3.put_object.call_args[1]
        assert call_kwargs["Bucket"] == "pentest-test-bucket"
        assert call_kwargs["Key"].startswith(VALIDATION_PREFIX)

    def test_s3_write_uses_sequential_naming(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """The object key must use controlled_validN.txt naming convention."""
        s3 = self._make_s3_mock_with_paginator()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        key = s3.put_object.call_args[1]["Key"]
        assert VALIDATION_PREFIX in key
        basename = key.split("/")[-1]
        assert basename.startswith(WRITE_TEST_FILENAME_BASE)
        assert basename.endswith(".txt")
        # e.g. controlled_valid1.txt — number must be parseable
        num_str = basename[len(WRITE_TEST_FILENAME_BASE):-4]
        assert num_str.isdigit()

    def test_s3_write_does_not_auto_delete(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """
        CRITICAL: s3:DeleteObject must NEVER be called automatically after
        a successful execution. The object must remain in S3 for demonstration.
        """
        s3 = self._make_s3_mock_with_paginator()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        assert result.status == "success"
        # DeleteObject must NOT be called — this is the critical safety requirement
        s3.delete_object.assert_not_called()

    def test_s3_write_cleanup_status_pending_after_success(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """After successful execution, cleanup_status must be PENDING."""
        s3 = self._make_s3_mock_with_paginator()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        assert result.cleanup_done is False
        assert result.cleanup_status == "PENDING"

    def test_s3_write_returns_bucket_and_key(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """The result must include s3_bucket and s3_object_key for the cleanup endpoint."""
        s3 = self._make_s3_mock_with_paginator()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="my-bucket"
        )

        assert result.s3_bucket == "my-bucket"
        assert result.s3_object_key is not None
        assert result.s3_object_key.startswith(VALIDATION_PREFIX)

    def test_s3_write_increments_sequence_number(
        self, mock_session: MagicMock
    ):
        """When controlled_valid1.txt exists, the next run must use controlled_valid2.txt."""
        s3 = MagicMock()
        paginator = MagicMock()
        # Simulate controlled_valid1.txt already in the bucket
        paginator.paginate.return_value = [{
            "Contents": [
                {"Key": f"{VALIDATION_PREFIX}/controlled_valid1.txt"}
            ]
        }]
        s3.get_paginator.return_value = paginator
        s3.put_object.return_value = {}
        s3.get_object.return_value = {
            "Body": MagicMock(read=MagicMock(return_value=b"x"))
        }
        mock_session.client.return_value = s3

        validator = AWSValidator(
            session=mock_session, mode=ValidationMode.VALIDATE, run_id="test-run"
        )
        result = validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        assert result.status == "success"
        key = s3.put_object.call_args[1]["Key"]
        basename = key.split("/")[-1]
        # Must NOT be controlled_valid1.txt since it already exists
        assert basename != "controlled_valid1.txt"
        assert basename == "controlled_valid2.txt"

    def test_s3_write_access_denied_no_cleanup(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """When PutObject is denied, no object is created and no cleanup is needed."""
        from botocore.exceptions import ClientError
        s3 = self._make_s3_mock_with_paginator()
        s3.put_object.side_effect = ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "Denied"}}, "PutObject"
        )
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        assert result.confirmed is False
        assert result.status in ("failure", "error")
        # No object was created, so no cleanup needed
        assert result.cleanup_status == "N/A"
        # DeleteObject should NOT be called
        s3.delete_object.assert_not_called()

    def test_s3_write_getobject_fails_object_pending_cleanup(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """When PutObject succeeds but GetObject fails, object exists and should be PENDING."""
        from botocore.exceptions import ClientError
        s3 = self._make_s3_mock_with_paginator()
        s3.get_object.side_effect = ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "Denied"}}, "GetObject"
        )
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        # Failure because GetObject failed
        assert result.status == "failure"
        assert result.confirmed is False
        # Object was created so cleanup is PENDING
        assert result.cleanup_status == "PENDING"
        assert result.s3_bucket == "test-bucket"
        assert result.s3_object_key is not None
        # Still no auto-delete
        s3.delete_object.assert_not_called()

    def test_s3_write_audit_log_populated(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        s3 = self._make_s3_mock_with_paginator()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="test-bucket"
        )

        assert len(result.audit_log) >= 2
        actions = [e.action for e in result.audit_log]
        assert "s3:PutObject" in actions
        assert "s3:GetObject" in actions
        # DeleteObject must NOT be in the audit log
        assert "s3:DeleteObject" not in actions


# ---------------------------------------------------------------------------
# Tests: S3 Read Validation
# ---------------------------------------------------------------------------

class TestS3ReadValidation:
    def test_s3_read_with_object_key_uses_getobject(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """When object_key is provided, GetObject must be called on that specific key."""
        s3 = MagicMock()
        s3.get_object.return_value = {"ContentLength": 42}
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-002", "s3_read", confirmed=True,
            bucket_name="test-bucket",
            object_key="cloud-pentest-validation/controlled_valid1.txt",
        )

        assert result.status == "success"
        assert result.confirmed is True
        s3.get_object.assert_called_once_with(
            Bucket="test-bucket",
            Key="cloud-pentest-validation/controlled_valid1.txt"
        )
        s3.list_objects_v2.assert_not_called()

    def test_s3_read_without_object_key_uses_list(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """When no object_key is provided, ListObjectsV2 must be called."""
        s3 = MagicMock()
        s3.list_objects_v2.return_value = {"KeyCount": 0, "Contents": []}
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-002", "s3_read", confirmed=True, bucket_name="test-bucket"
        )

        assert result.status == "success"
        assert result.confirmed is True
        s3.list_objects_v2.assert_called_once()
        s3.get_object.assert_not_called()

    def test_s3_read_list_prefix_restricted(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        s3 = MagicMock()
        s3.list_objects_v2.return_value = {"KeyCount": 0}
        mock_session.client.return_value = s3

        validate_validator.validate(
            "find-002", "s3_read", confirmed=True, bucket_name="test-bucket"
        )

        call_kwargs = s3.list_objects_v2.call_args[1]
        assert VALIDATION_PREFIX in call_kwargs["Prefix"]

    def test_s3_read_no_modification(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """S3 read must never call put_object or delete_object."""
        s3 = MagicMock()
        s3.get_object.return_value = {"ContentLength": 100}
        mock_session.client.return_value = s3

        validate_validator.validate(
            "find-002", "s3_read", confirmed=True,
            bucket_name="test-bucket",
            object_key="some/key.txt",
        )

        s3.put_object.assert_not_called()
        s3.delete_object.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: IAM PassRole Validation
# ---------------------------------------------------------------------------

class TestIAMPassRoleValidation:
    def test_iam_pass_role_allowed(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        sts = MagicMock()
        sts.get_caller_identity.return_value = {
            "Arn": "arn:aws:iam::123456789012:user/test-user",
            "Account": "123456789012",
        }
        iam = MagicMock()
        iam.simulate_principal_policy.return_value = {
            "EvaluationResults": [{"EvalDecision": "allowed", "EvalActionName": "iam:PassRole"}]
        }
        mock_session.client.side_effect = lambda svc, **kwargs: (sts if svc == "sts" else iam)

        result = validate_validator.validate(
            "find-003", "iam_pass_role", confirmed=True,
            role_arn="arn:aws:iam::123456789012:role/PrivilegedRole"
        )

        assert result.status == "success"
        assert result.confirmed is True
        # Description contains "VALIDATED" and "allowed" (case-insensitive)
        assert "VALIDATED" in result.description or "allowed" in result.description.lower()
        assert result.cleanup_done is True
        assert result.cleanup_status == "N/A"

    def test_iam_pass_role_denied(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        sts = MagicMock()
        sts.get_caller_identity.return_value = {
            "Arn": "arn:aws:iam::123456789012:user/limited-user",
            "Account": "123456789012",
        }
        iam = MagicMock()
        iam.simulate_principal_policy.return_value = {
            "EvaluationResults": [{"EvalDecision": "implicitDeny", "EvalActionName": "iam:PassRole"}]
        }
        mock_session.client.side_effect = lambda svc, **kwargs: (sts if svc == "sts" else iam)

        result = validate_validator.validate(
            "find-003", "iam_pass_role", confirmed=True,
            role_arn="arn:aws:iam::123456789012:role/PrivilegedRole"
        )

        assert result.status == "failure"
        assert result.confirmed is False
        assert "DENIED" in result.description

    def test_iam_pass_role_no_iam_resources_created(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """IAM simulator must never create, attach, or modify IAM resources."""
        sts = MagicMock()
        sts.get_caller_identity.return_value = {
            "Arn": "arn:aws:iam::123456789012:user/tester",
            "Account": "123456789012",
        }
        iam = MagicMock()
        iam.simulate_principal_policy.return_value = {"EvaluationResults": []}
        mock_session.client.side_effect = lambda svc, **kwargs: (sts if svc == "sts" else iam)

        validate_validator.validate(
            "find-003", "iam_pass_role", confirmed=True,
            role_arn="arn:aws:iam::123456789012:role/TestRole"
        )

        iam.create_role.assert_not_called()
        iam.attach_role_policy.assert_not_called()
        iam.put_role_policy.assert_not_called()
        iam.create_user.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: EC2 Access Validation
# ---------------------------------------------------------------------------

class TestEC2AccessValidation:
    def _make_ec2_mock(self, instance_id: str = "i-abc123") -> MagicMock:
        ec2 = MagicMock()
        ec2.describe_instances.return_value = {
            "Reservations": [{
                "Instances": [{
                    "InstanceId": instance_id,
                    "State": {"Name": "running"},
                    "InstanceType": "t3.micro",
                }]
            }]
        }
        return ec2

    def test_ec2_access_success_with_instance_id(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        ec2 = self._make_ec2_mock()
        mock_session.client.return_value = ec2

        result = validate_validator.validate(
            "find-004", "ec2_access", confirmed=True, instance_id="i-abc123"
        )

        assert result.status == "success"
        assert result.confirmed is True
        ec2.describe_instances.assert_called_once_with(InstanceIds=["i-abc123"])
        assert result.cleanup_status == "N/A"

    def test_ec2_access_success_without_instance_id(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        ec2 = self._make_ec2_mock()
        mock_session.client.return_value = ec2

        result = validate_validator.validate(
            "find-004", "ec2_access", confirmed=True
        )

        assert result.status == "success"
        assert result.confirmed is True
        # Without instance_id, DescribeInstances called without InstanceIds filter
        ec2.describe_instances.assert_called_once_with()

    def test_ec2_access_access_denied(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        from botocore.exceptions import ClientError
        ec2 = MagicMock()
        ec2.describe_instances.side_effect = ClientError(
            {"Error": {"Code": "UnauthorizedOperation", "Message": "Not authorized"}},
            "DescribeInstances"
        )
        mock_session.client.return_value = ec2

        result = validate_validator.validate(
            "find-004", "ec2_access", confirmed=True, instance_id="i-abc123"
        )

        assert result.status == "failure"
        assert result.confirmed is False

    def test_ec2_access_does_not_modify_instance(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        ec2 = self._make_ec2_mock()
        mock_session.client.return_value = ec2

        validate_validator.validate(
            "find-004", "ec2_access", confirmed=True, instance_id="i-abc123"
        )

        ec2.stop_instances.assert_not_called()
        ec2.start_instances.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: EC2 Control Validation
# ---------------------------------------------------------------------------

class TestEC2ControlValidation:
    def _make_ec2_mock_running(self, instance_id: str = "i-test123") -> MagicMock:
        """Create EC2 mock that returns running → stopping → stopped → running states."""
        ec2 = MagicMock()
        # Sequence of describe_instances calls:
        # 1. Initial state query → running
        # 2. After stop poll → stopped
        # 3. After start poll → running
        call_count = [0]

        def describe_side_effect(InstanceIds=None):
            call_count[0] += 1
            n = call_count[0]
            if n == 1:
                state = "running"
            elif n <= 3:
                state = "stopped"
            else:
                state = "running"
            return {
                "Reservations": [{
                    "Instances": [{
                        "InstanceId": instance_id,
                        "State": {"Name": state},
                    }]
                }]
            }

        ec2.describe_instances.side_effect = describe_side_effect
        ec2.stop_instances.return_value = {}
        ec2.start_instances.return_value = {}
        return ec2

    def test_ec2_control_dry_run_zero_aws_calls(
        self, mock_session: MagicMock, dry_run_validator: AWSValidator
    ):
        """DRY RUN must make zero AWS calls — Stop/Start must not execute."""
        result = dry_run_validator.validate(
            "find-005", "ec2_control", confirmed=False, instance_id="i-abc123"
        )
        assert result.status == "dry_run_preview"
        mock_session.client.assert_not_called()

    def test_ec2_control_non_running_instance_not_performed(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """If instance is not running, validation must not call Stop."""
        ec2 = MagicMock()
        ec2.describe_instances.return_value = {
            "Reservations": [{
                "Instances": [{
                    "InstanceId": "i-stopped",
                    "State": {"Name": "stopped"},
                }]
            }]
        }
        mock_session.client.return_value = ec2

        result = validate_validator.validate(
            "find-005", "ec2_control", confirmed=True, instance_id="i-stopped"
        )

        assert result.status == "not_performed"
        ec2.stop_instances.assert_not_called()
        ec2.start_instances.assert_not_called()

    def test_ec2_control_success_stop_start_restore(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """Successful validation: stop → verify → start → verify → result confirmed."""
        import unittest.mock

        ec2 = self._make_ec2_mock_running()
        mock_session.client.return_value = ec2

        # Patch time.sleep to avoid real delays
        with unittest.mock.patch("time.sleep"):
            result = validate_validator.validate(
                "find-005", "ec2_control", confirmed=True, instance_id="i-test123"
            )

        assert result.status == "success"
        assert result.confirmed is True
        ec2.stop_instances.assert_called_once_with(InstanceIds=["i-test123"])
        ec2.start_instances.assert_called_once_with(InstanceIds=["i-test123"])

    def test_ec2_control_audit_log_contains_stop_and_start(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        import unittest.mock

        ec2 = self._make_ec2_mock_running()
        mock_session.client.return_value = ec2

        with unittest.mock.patch("time.sleep"):
            result = validate_validator.validate(
                "find-005", "ec2_control", confirmed=True, instance_id="i-test123"
            )

        actions = [e.action for e in result.audit_log]
        assert "ec2:DescribeInstances" in actions
        assert "ec2:StopInstances" in actions
        assert "ec2:StartInstances" in actions

    def test_ec2_control_stop_failure_attempt_emergency_start(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """If Stop succeeds but Start fails, emergency restart is attempted."""
        import unittest.mock
        from botocore.exceptions import ClientError

        ec2 = MagicMock()
        # Initial describe → running
        ec2.describe_instances.return_value = {
            "Reservations": [{
                "Instances": [{"InstanceId": "i-test", "State": {"Name": "running"}}]
            }]
        }
        ec2.stop_instances.return_value = {}
        ec2.start_instances.side_effect = ClientError(
            {"Error": {"Code": "InvalidInstanceID.NotFound", "Message": "Not found"}},
            "StartInstances"
        )
        mock_session.client.return_value = ec2

        with unittest.mock.patch("time.sleep"):
            result = validate_validator.validate(
                "find-005", "ec2_control", confirmed=True, instance_id="i-test"
            )

        assert result.status == "failure"
        # Emergency start was attempted (start_instances called twice: once in main flow,
        # once in emergency handler)
        assert ec2.start_instances.call_count >= 1


# ---------------------------------------------------------------------------
# Tests: Unknown technique
# ---------------------------------------------------------------------------

class TestUnknownTechnique:
    def test_unknown_technique_returns_error(self, validate_validator: AWSValidator):
        result = validate_validator.validate(
            "find-999", "nonexistent_technique", confirmed=True
        )
        assert result.status == "error"
        assert result.confirmed is False
        assert "Unknown" in result.description


# ---------------------------------------------------------------------------
# Tests: Resource naming convention
# ---------------------------------------------------------------------------

class TestResourceNaming:
    def test_validation_prefix_constant(self):
        assert VALIDATION_PREFIX == "cloud-pentest-validation"

    def test_resource_prefix_includes_run_id(self):
        validator = AWSValidator(
            session=MagicMock(), mode=ValidationMode.READ_ONLY, run_id="abc12345"
        )
        assert "cloud-pentest-validation/abc12345" == validator.resource_prefix

    def test_sequential_key_starts_at_1_when_empty(self):
        """When no objects exist, _next_seq_object_key returns controlled_valid1.txt."""
        s3 = MagicMock()
        paginator = MagicMock()
        paginator.paginate.return_value = [{"Contents": []}]
        s3.get_paginator.return_value = paginator

        validator = AWSValidator(
            session=MagicMock(), mode=ValidationMode.READ_ONLY, run_id="r1"
        )
        n, key = validator._next_seq_object_key(s3, "test-bucket")
        assert n == 1
        assert key == f"{VALIDATION_PREFIX}/controlled_valid1.txt"

    def test_sequential_key_skips_existing(self):
        """When controlled_valid1.txt and controlled_valid2.txt exist, returns 3."""
        s3 = MagicMock()
        paginator = MagicMock()
        paginator.paginate.return_value = [{
            "Contents": [
                {"Key": f"{VALIDATION_PREFIX}/controlled_valid1.txt"},
                {"Key": f"{VALIDATION_PREFIX}/controlled_valid2.txt"},
            ]
        }]
        s3.get_paginator.return_value = paginator

        validator = AWSValidator(
            session=MagicMock(), mode=ValidationMode.READ_ONLY, run_id="r1"
        )
        n, key = validator._next_seq_object_key(s3, "test-bucket")
        assert n == 3
        assert key == f"{VALIDATION_PREFIX}/controlled_valid3.txt"


# ---------------------------------------------------------------------------
# Tests: S3 Write Execute and Cleanup are SEPARATE operations
# ---------------------------------------------------------------------------

class TestS3WriteExecuteCleanupSeparation:
    """Verify that Execute Validation and Cleanup are completely independent."""

    def _make_s3_mock(self):
        s3 = MagicMock()
        paginator = MagicMock()
        paginator.paginate.return_value = [{"Contents": []}]
        s3.get_paginator.return_value = paginator
        s3.put_object.return_value = {}
        s3.get_object.return_value = {
            "Body": MagicMock(read=MagicMock(return_value=b"test content"))
        }
        return s3

    def test_execute_does_not_call_delete(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        s3 = self._make_s3_mock()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="my-bucket"
        )

        assert result.status == "success"
        s3.delete_object.assert_not_called()
        assert result.cleanup_status == "PENDING"

    def test_result_contains_run_id_for_cleanup_endpoint(
        self, mock_session: MagicMock, validate_validator: AWSValidator
    ):
        """The run_id returned by execute must be usable for the cleanup endpoint."""
        s3 = self._make_s3_mock()
        mock_session.client.return_value = s3

        result = validate_validator.validate(
            "find-001", "s3_write", confirmed=True, bucket_name="my-bucket"
        )

        assert result.run_id is not None
        assert result.s3_bucket == "my-bucket"
        assert result.s3_object_key is not None
