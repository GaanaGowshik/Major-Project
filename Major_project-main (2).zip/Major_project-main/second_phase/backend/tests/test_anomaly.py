"""
tests/test_anomaly.py — Tests for the anomaly detection system.

Uses synthetic scan data — no cloud API calls required.
"""

import sys
from pathlib import Path

import networkx as nx
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from anomaly.detector import AnomalyDetector, Anomaly


# ──────────────────────────────────────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────────────────────────────────────

def _make_graph_with_privesc() -> nx.DiGraph:
    g = nx.DiGraph()
    g.add_node("arn:aws:iam::123:user/alice", node_type="IAMUser", display_name="alice")
    g.add_node("arn:aws:iam::123:role/admin-role", node_type="IAMRole", display_name="admin-role")
    g.add_node("arn:aws:iam::ACCOUNT:policy/AdministratorAccess",
               node_type="Capability", display_name="AdministratorAccess")
    g.add_edge("arn:aws:iam::123:user/alice", "arn:aws:iam::123:role/admin-role",
               relation="CAN_ASSUME", actions=["sts:AssumeRole"], confirmed=True)
    g.add_edge("arn:aws:iam::123:role/admin-role",
               "arn:aws:iam::ACCOUNT:policy/AdministratorAccess",
               relation="PRIVESC_TO", actions=["iam:AttachUserPolicy"],
               evidence=[{"type": "simulator_confirmed"}], confirmed=True)
    return g


def _make_graph_with_excessive_privilege() -> nx.DiGraph:
    """User node with many outgoing edges — above average."""
    g = nx.DiGraph()
    g.add_node("user1", node_type="IAMUser", display_name="user1")
    for i in range(8):
        g.add_node(f"bucket{i}", node_type="S3Bucket", display_name=f"bucket{i}")
        g.add_edge("user1", f"bucket{i}", relation="CAN_WRITE_BUCKET", confirmed=True)
    # Another user with 1 edge — so mean is low, user1 is anomalous
    g.add_node("user2", node_type="IAMUser", display_name="user2")
    g.add_node("bucket_user2", node_type="S3Bucket", display_name="bu2")
    g.add_edge("user2", "bucket_user2", relation="CAN_READ_BUCKET", confirmed=True)
    return g


def _make_graph_with_public_bucket() -> nx.DiGraph:
    g = nx.DiGraph()
    g.add_node("my-public-bucket", node_type="S3Bucket", display_name="my-public-bucket",
               is_public_read=True, is_public_write=False)
    return g


def _make_aws_report_with_public_bucket() -> dict:
    return {
        "provider": "aws",
        "resources": {
            "s3_buckets": [
                {"name": "my-public-bucket", "is_public_read": True, "is_public_write": False},
            ],
            "ec2_instances": [],
        },
        "findings": {"iam": [], "s3": [], "ec2": []},
        "privilege_escalation_paths": [],
        "summary": {},
    }


def _make_aws_report_with_firewall() -> dict:
    return {
        "provider": "aws",
        "resources": {"s3_buckets": [], "ec2_instances": []},
        "findings": {
            "iam": [],
            "s3": [],
            "ec2": [
                {
                    "title": "Unrestricted inbound SSH (0.0.0.0/0)",
                    "description": "Security group allows unrestricted inbound SSH",
                    "severity": "HIGH",
                    "instance_id": "i-12345",
                    "recommendation": "Restrict SSH access to known IP ranges.",
                }
            ],
        },
        "privilege_escalation_paths": [],
        "summary": {},
    }


def _make_baseline_report() -> dict:
    return {
        "provider": "aws",
        "resources": {
            "iam_users": [{"UserName": "alice"}],
            "iam_roles": [{"RoleName": "admin-role"}],
            "s3_buckets": [{"Name": "bucket-1"}],
        },
        "findings": {"iam": [], "s3": [], "ec2": []},
        "privilege_escalation_paths": [],
        "summary": {
            "total_findings": 1,
            "privesc_paths": 0,
        },
    }


def _make_current_report_with_drift() -> dict:
    return {
        "provider": "aws",
        "resources": {
            "iam_users": [{"UserName": "alice"}, {"UserName": "new-user"}],
            "iam_roles": [{"RoleName": "admin-role"}, {"RoleName": "new-role"}],
            "s3_buckets": [{"Name": "bucket-1"}],
        },
        "findings": {"iam": [{}] * 5, "s3": [], "ec2": []},
        "privilege_escalation_paths": [{"source_arn": "x", "technique": "PassRole"}],
        "summary": {
            "total_findings": 5,
            "privesc_paths": 1,
        },
    }


# ──────────────────────────────────────────────────────────────────────────────
# Tests
# ──────────────────────────────────────────────────────────────────────────────

class TestAnomalyDetector:
    detector = AnomalyDetector()

    def test_detect_privilege_escalation(self):
        """PRIVESC_TO edge must produce a PRIVILEGE_ESCALATION anomaly."""
        g = _make_graph_with_privesc()
        report = {"resources": {}, "findings": {}, "privilege_escalation_paths": [],
                  "summary": {}}
        anomalies = self.detector.detect(g, report, provider="aws")

        types = [a.type for a in anomalies]
        assert "PRIVILEGE_ESCALATION" in types, (
            f"Expected PRIVILEGE_ESCALATION in {types}"
        )

    def test_privilege_escalation_is_critical(self):
        g = _make_graph_with_privesc()
        report = {"resources": {}, "findings": {}, "summary": {}}
        anomalies = self.detector.detect(g, report, provider="aws")

        privesc = [a for a in anomalies if a.type == "PRIVILEGE_ESCALATION"]
        assert any(a.severity == "CRITICAL" for a in privesc), (
            "Direct PRIVESC_TO anomaly should be CRITICAL"
        )

    def test_privilege_escalation_has_evidence(self):
        g = _make_graph_with_privesc()
        report = {"resources": {}, "findings": {}, "summary": {}}
        anomalies = self.detector.detect(g, report, provider="aws")

        privesc = [a for a in anomalies if a.type == "PRIVILEGE_ESCALATION"]
        assert privesc, "Should have at least one privesc anomaly"
        assert len(privesc[0].evidence) > 0, "Evidence must not be empty"

    def test_detect_excessive_privilege(self):
        """Node with many edges should be flagged as EXCESSIVE_PRIVILEGE."""
        g = _make_graph_with_excessive_privilege()
        report = {"resources": {}, "findings": {}, "summary": {}}
        anomalies = self.detector.detect(g, report, provider="aws")

        types = [a.type for a in anomalies]
        assert "EXCESSIVE_PRIVILEGE" in types, (
            f"Expected EXCESSIVE_PRIVILEGE in {types}"
        )

    def test_detect_public_exposure_bucket(self):
        """Public S3 bucket should trigger PUBLIC_EXPOSURE anomaly."""
        g = _make_graph_with_public_bucket()
        report = _make_aws_report_with_public_bucket()
        anomalies = self.detector.detect(g, report, provider="aws")

        types = [a.type for a in anomalies]
        assert "PUBLIC_EXPOSURE" in types, (
            f"Expected PUBLIC_EXPOSURE in {types}"
        )

    def test_public_exposure_high_severity(self):
        g = _make_graph_with_public_bucket()
        report = _make_aws_report_with_public_bucket()
        anomalies = self.detector.detect(g, report, provider="aws")

        pub = [a for a in anomalies if a.type == "PUBLIC_EXPOSURE"]
        assert pub, "Should have public exposure anomaly"
        assert pub[0].severity in ("HIGH", "CRITICAL")

    def test_detect_firewall_anomaly(self):
        """EC2 security group findings should produce FIREWALL_ANOMALY."""
        report = _make_aws_report_with_firewall()
        anomalies = self.detector.detect(nx.DiGraph(), report, provider="aws")

        types = [a.type for a in anomalies]
        assert "FIREWALL_ANOMALY" in types, (
            f"Expected FIREWALL_ANOMALY in {types}"
        )

    def test_detect_configuration_drift(self):
        """New resources vs baseline should produce CONFIGURATION_DRIFT."""
        current  = _make_current_report_with_drift()
        baseline = _make_baseline_report()
        anomalies = self.detector.detect(nx.DiGraph(), current,
                                         baseline=baseline, provider="aws")

        types = [a.type for a in anomalies]
        assert "CONFIGURATION_DRIFT" in types or "UNEXPECTED_RESOURCE" in types, (
            f"Expected drift/unexpected anomaly in {types}"
        )

    def test_detect_unexpected_resources(self):
        """New IAM user vs baseline should produce UNEXPECTED_RESOURCE."""
        current  = _make_current_report_with_drift()
        baseline = _make_baseline_report()
        anomalies = self.detector.detect(nx.DiGraph(), current,
                                         baseline=baseline, provider="aws")

        types = [a.type for a in anomalies]
        assert "UNEXPECTED_RESOURCE" in types, (
            f"Expected UNEXPECTED_RESOURCE in {types}"
        )

    def test_empty_graph_no_crash(self):
        """Empty graph should not crash the detector."""
        report = {"resources": {}, "findings": {}, "summary": {}}
        anomalies = self.detector.detect(nx.DiGraph(), report, provider="aws")
        assert isinstance(anomalies, list)

    def test_empty_report_no_crash(self):
        """Empty report should not crash."""
        anomalies = self.detector.detect(nx.DiGraph(), {}, provider="aws")
        assert isinstance(anomalies, list)

    def test_anomaly_has_recommendation(self):
        """Every anomaly should include a recommendation string."""
        g = _make_graph_with_privesc()
        report = {"resources": {}, "findings": {}, "summary": {}}
        anomalies = self.detector.detect(g, report, provider="aws")
        for a in anomalies:
            assert a.recommendation, f"Anomaly {a.type} has empty recommendation"

    def test_severity_sorted(self):
        """Anomalies should be sorted by severity (CRITICAL first)."""
        g = _make_graph_with_privesc()
        report = _make_aws_report_with_public_bucket()
        anomalies = self.detector.detect(g, report, provider="aws")
        if len(anomalies) > 1:
            order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
            for i in range(len(anomalies) - 1):
                assert order.get(anomalies[i].severity, 99) <= order.get(anomalies[i+1].severity, 99)

    def test_to_dict_serializable(self):
        """Anomaly.to_dict() should produce a JSON-serializable dict."""
        import json
        a = Anomaly(
            type="TEST",
            severity="HIGH",
            resource="resource-1",
            description="Test anomaly",
            evidence=["evidence 1", "evidence 2"],
            recommendation="Fix it.",
        )
        d = a.to_dict()
        # Should not raise
        json.dumps(d)
        assert d["type"] == "TEST"
        assert d["severity"] == "HIGH"


# ──────────────────────────────────────────────────────────────────────────────
# Provider separation tests
# ──────────────────────────────────────────────────────────────────────────────

class TestProviderSeparation:
    """Verify AWS and GCP anomaly detection are independent."""

    def test_gcp_anomalies_use_gcp_resources(self):
        detector = AnomalyDetector()
        gcp_report = {
            "provider": "gcp",
            "resources": {
                "service_accounts": [{"email": "sa@proj.iam"}],
                "storage_buckets": [
                    {"name": "gcp-bucket", "is_public_read": True, "is_public_write": False}
                ],
                "compute_instances": [],
            },
            "findings": {"storage": [], "compute": []},
            "privilege_escalation_paths": [],
            "summary": {},
        }
        anomalies = detector.detect(nx.DiGraph(), gcp_report, provider="gcp")
        # Should detect public storage bucket
        types = [a.type for a in anomalies]
        assert "PUBLIC_EXPOSURE" in types

    def test_aws_report_not_used_for_gcp(self):
        """GCP detector should not find AWS-specific resource types."""
        detector = AnomalyDetector()
        # An AWS report passed as GCP — EC2 findings should not become GCP anomalies
        aws_report = {
            "provider": "aws",
            "resources": {"s3_buckets": [], "ec2_instances": []},
            "findings": {"iam": [], "s3": [], "ec2": []},
            "privilege_escalation_paths": [],
            "summary": {},
        }
        anomalies = detector.detect(nx.DiGraph(), aws_report, provider="gcp")
        # Should not produce FIREWALL_ANOMALY from AWS ec2 findings via GCP path
        types = [a.type for a in anomalies]
        assert "FIREWALL_ANOMALY" not in types  # AWS ec2 firewall check not run for gcp
