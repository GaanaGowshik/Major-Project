"""
Anomaly detection API routes.

GET  /api/anomaly          — run anomaly detection on latest scan graph
GET  /api/anomaly/summary  — brief anomaly summary (counts by severity)
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Query

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/anomaly", tags=["anomaly"])

_AWS_REPORT_PATH = Path(__file__).parent.parent.parent / "aws_pentest" / "last_report.json"
_GCP_REPORT_PATH = Path(__file__).parent.parent.parent / "gcp_pentest" / "last_report.json"
_AWS_GRAPH_PATH  = Path(__file__).parent.parent.parent / "aws_pentest" / "last_graph.json"


def _load_report(provider: str) -> dict:
    path = _AWS_REPORT_PATH if provider == "aws" else _GCP_REPORT_PATH
    if not path.exists():
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        logger.warning("Could not load %s report: %s", provider, exc)
        return {}


def _build_graph(provider: str):
    """Build nx.DiGraph from the most recent scan."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))
    import networkx as nx

    if provider == "aws" and _AWS_GRAPH_PATH.exists():
        try:
            with open(_AWS_GRAPH_PATH, encoding="utf-8") as f:
                raw = json.load(f)
            from aws_pentest.models.graph_models import AssessmentGraph
            ag = AssessmentGraph.model_validate(raw)
            return ag.to_networkx()
        except Exception as exc:
            logger.warning("Could not build AWS graph: %s", exc)

    if provider == "gcp":
        report = _load_report("gcp")
        if report:
            from api.services.graph_service import _build_gcp_graph_from_report
            return _build_gcp_graph_from_report(report)

    return nx.DiGraph()


@router.get("")
def get_anomalies(provider: Literal["aws", "gcp"] = Query("aws")):
    """
    Run anomaly detection on the latest scan for the given provider.

    Returns structured anomaly data with evidence.
    Every anomaly is derived from real scan data — none are fabricated.
    """
    report = _load_report(provider)
    if not report:
        return {
            "provider":  provider,
            "anomalies": [],
            "count":     0,
            "status":    "no_scan",
            "message":   f"No {provider.upper()} scan results found. Run a scan first.",
        }

    nx_graph = _build_graph(provider)

    from anomaly.detector import AnomalyDetector
    detector = AnomalyDetector()
    anomalies = detector.detect(
        nx_graph=nx_graph,
        report_data=report,
        baseline=None,
        provider=provider,
    )

    return {
        "provider":  provider,
        "anomalies": [a.to_dict() for a in anomalies],
        "count":     len(anomalies),
        "status":    "complete",
        "summary": {
            "CRITICAL": sum(1 for a in anomalies if a.severity == "CRITICAL"),
            "HIGH":     sum(1 for a in anomalies if a.severity == "HIGH"),
            "MEDIUM":   sum(1 for a in anomalies if a.severity == "MEDIUM"),
            "LOW":      sum(1 for a in anomalies if a.severity == "LOW"),
        },
    }


@router.get("/summary")
def get_anomaly_summary(provider: Literal["aws", "gcp"] = Query("aws")):
    """Return brief anomaly count by severity."""
    result = get_anomalies(provider=provider)
    return {
        "provider": provider,
        "count":    result["count"],
        "summary":  result.get("summary", {}),
        "status":   result["status"],
    }
