"""
RL API routes.

GET  /api/rl/status          — current/most-recent RL step status
GET  /api/rl/episodes        — per-episode summary list
GET  /api/rl/history         — full step trace for a given episode
GET  /api/rl/attack-path     — latest structured attack path result
POST /api/rl/train           — start RL training (background task)
GET  /api/rl/train/status    — training job status
POST /api/rl/inference       — run inference on saved model

All endpoints that depend on provider data accept a ?provider=aws|gcp query param.
"""

from __future__ import annotations

import logging
from typing import Literal, Optional

from fastapi import APIRouter, BackgroundTasks, Query
from pydantic import BaseModel

from api.services.rl_service import (
    get_rl_status, get_episodes, get_history,
    get_attack_path, get_training_status,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/rl", tags=["rl"])


# ── Status / history endpoints ─────────────────────────────────────────────

@router.get("/status")
def rl_status(provider: Literal["aws", "gcp"] = Query("aws")):
    return get_rl_status(provider=provider)


@router.get("/episodes")
def rl_episodes(provider: Literal["aws", "gcp"] = Query("aws")):
    return get_episodes(provider=provider)


@router.get("/history")
def rl_history(
    episode: Optional[int] = Query(default=None),
    provider: Literal["aws", "gcp"] = Query("aws"),
):
    return get_history(episode=episode, provider=provider)


@router.get("/attack-path")
def rl_attack_path(provider: Literal["aws", "gcp"] = Query("aws")):
    """
    Return the latest structured attack path produced by RL inference.

    Returns a path list (may be empty if training hasn't been run yet).
    The path nodes are from the actual scanner graph — no fabricated data.
    """
    return get_attack_path(provider=provider)


# ── Training endpoints ─────────────────────────────────────────────────────

class TrainRequest(BaseModel):
    provider:    Literal["aws", "gcp"] = "aws"
    timesteps:   int = 20_000
    model_path:  str = "ppo_cloud_agent"
    graph_path:  Optional[str] = None   # override graph JSON path


_training_state: dict = {"status": "idle", "provider": None}


def _run_training(req: TrainRequest) -> None:
    """Background training job."""
    global _training_state
    _training_state = {
        "status":   "running",
        "provider": req.provider,
        "message":  f"Training started ({req.provider.upper()}, {req.timesteps} steps)…",
    }
    try:
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))

        from rl.train import train as _train
        result = _train(
            provider=req.provider,
            graph_json_path=req.graph_path,
            model_save_path=req.model_path,
            total_timesteps=req.timesteps,
            verbose=0,
        )

        if result.get("status") == "complete":
            metrics = result.get("metrics", {})
            _training_state = {
                "status":       "complete",
                "provider":     req.provider,
                "message":      "Training complete.",
                "metrics":      metrics,
                "model_path":   result.get("model_path"),
                "attack_path":  result.get("attack_path"),
            }
        else:
            _training_state = {
                "status":   "error",
                "provider": req.provider,
                "message":  result.get("message", "Training failed"),
            }
    except Exception as exc:
        logger.error("RL training failed: %s", exc, exc_info=True)
        _training_state = {
            "status":   "error",
            "provider": req.provider,
            "message":  str(exc),
        }


@router.post("/train")
def start_training(req: TrainRequest, background_tasks: BackgroundTasks):
    """
    Start RL training in the background.

    Training:
      1. Loads the scanner graph for the specified provider
      2. Creates the CloudPentestEnv
      3. Trains a PPO agent for `timesteps` steps
      4. Saves the model
      5. Runs inference to generate the best attack path

    Poll /api/rl/train/status to check progress.
    """
    if _training_state.get("status") == "running":
        return {
            "status": "already_running",
            "message": "Training is already in progress.",
        }
    background_tasks.add_task(_run_training, req)
    return {
        "status":  "started",
        "message": f"RL training started ({req.provider.upper()}, {req.timesteps} steps).",
    }


@router.get("/train/status")
def training_status():
    """Return current training job status."""
    return _training_state


# ── Inference endpoint ─────────────────────────────────────────────────────

class InferenceRequest(BaseModel):
    provider:    Literal["aws", "gcp"] = "aws"
    model_path:  str = "ppo_cloud_agent"
    graph_path:  Optional[str] = None
    n_episodes:  int = 5


@router.post("/inference")
def run_inference(req: InferenceRequest):
    """
    Run RL inference using a saved model on the current graph.

    Does NOT retrain.  Loads the saved model and runs `n_episodes` episodes,
    returning the best attack path discovered.

    If no model exists, returns status="no_model" with instructions.
    """
    try:
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))

        from rl.train import run_inference as _inference
        result = _inference(
            provider=req.provider,
            graph_json_path=req.graph_path,
            model_path=req.model_path,
            n_episodes=req.n_episodes,
        )
        return result
    except Exception as exc:
        logger.error("RL inference failed: %s", exc, exc_info=True)
        return {
            "status":       "error",
            "message":      str(exc),
            "path":         [],
            "total_reward": 0.0,
            "provider":     req.provider,
        }
