"""
Validation API routes — Controlled Finding Validation (Phase 6).

Safety model:
  READ_ONLY  — describe only, no AWS calls
  DRY_RUN    — describe exact AWS calls, no execution
  VALIDATE   — execute controlled test (requires confirmed=True)

Endpoints
---------
POST /api/validate
    Execute or preview a validation technique.

GET  /api/validate/techniques
    List available techniques.

POST /api/validate/cleanup
    Explicitly delete the S3 object created by a previous s3_write VALIDATE run.
    This is intentionally a SEPARATE endpoint from /api/validate — the object
    must remain in S3 until the user explicitly requests cleanup.

GET  /api/validate/history
    Return the persisted validation log.
"""

from __future__ import annotations

import logging
from typing import Any, Literal, Optional

from fastapi import APIRouter
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/validate", tags=["validate"])


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class ValidateRequest(BaseModel):
    """
    Request body for a validation action.

    Fields
    ------
    finding_id:
        ID of the finding to validate (from scan output).
    technique:
        Validation technique to execute.
        Supported: "s3_write" | "s3_read" | "iam_pass_role" |
                   "ec2_access" | "ec2_control"
    mode:
        Safety level.
        "READ_ONLY" — describe only (default)
        "DRY_RUN"   — describe exact AWS calls, no execution
        "VALIDATE"  — execute controlled test (requires confirmed=True)
    confirmed:
        Must be True for mode="VALIDATE" to proceed.
    provider:
        Cloud provider. Only "aws" is supported.
    profile:
        AWS profile name (optional — falls back to standard credential chain).
    region:
        AWS region for the session.
    run_id:
        Optional run identifier. Auto-generated if not provided.
    bucket_name:
        Required for s3_write and s3_read techniques.
    object_key:
        Optional for s3_read — specific object key to GetObject.
        If omitted, falls back to ListObjectsV2 on the validation prefix.
    role_arn:
        Required for iam_pass_role technique.
    target_service:
        Optional for iam_pass_role — AWS service principal to target.
    instance_id:
        Required for ec2_access and ec2_control techniques.
    """
    finding_id: str
    technique: Literal["s3_write", "s3_read", "iam_pass_role", "ec2_access", "ec2_control"]
    mode: Literal["READ_ONLY", "DRY_RUN", "VALIDATE"] = "READ_ONLY"
    confirmed: bool = False
    provider: Literal["aws"] = "aws"
    profile: Optional[str] = None
    region: Optional[str] = "us-east-1"
    run_id: Optional[str] = None
    # Technique-specific parameters
    bucket_name: Optional[str] = None
    object_key: Optional[str] = None       # s3_read: specific object to GetObject
    role_arn: Optional[str] = None
    target_service: Optional[str] = None   # iam_pass_role: target service principal
    instance_id: Optional[str] = None      # ec2_access, ec2_control


class CleanupRequest(BaseModel):
    """
    Request body for explicit S3 Write cleanup.

    The run_id is used to look up the exact bucket and object key from the
    validation log.  The frontend MUST NOT submit an arbitrary bucket/key —
    the backend resolves the target from the persisted run record.
    """
    run_id: str
    profile: Optional[str] = None
    region: Optional[str] = "us-east-1"


# ---------------------------------------------------------------------------
# Helper: build boto3 session
# ---------------------------------------------------------------------------

def _build_session(profile: Optional[str], region: Optional[str]) -> Any:
    """Build and verify a boto3 session."""
    import boto3
    from botocore.exceptions import NoCredentialsError, ProfileNotFound, ClientError

    session_kwargs: dict[str, Any] = {}
    if profile:
        session_kwargs["profile_name"] = profile
    if region:
        session_kwargs["region_name"] = region
    session = boto3.Session(**session_kwargs)

    # Verify credentials are present
    try:
        session.client("sts").get_caller_identity()
    except (NoCredentialsError, ProfileNotFound, ClientError):
        raise

    return session


def _credential_error_response(finding_id: str, technique: str, mode: str, exc: Exception) -> dict:
    return {
        "finding_id": finding_id,
        "technique": technique,
        "mode": mode,
        "status": "error",
        "confirmed": False,
        "description": f"AWS credential error: {exc}. Cannot validate.",
        "error": str(exc),
        "dry_run_preview": [],
        "evidence": [],
        "cleanup_done": False,
        "cleanup_status": "N/A",
        "audit_log": [],
    }


# ---------------------------------------------------------------------------
# POST /api/validate — main validation endpoint
# ---------------------------------------------------------------------------

@router.post("")
def validate_finding(req: ValidateRequest) -> dict[str, Any]:
    """
    Validate a security finding using a controlled technique.

    Returns a ValidationResult dict. The response always includes:
      - mode: the safety level used
      - status: "not_performed" | "dry_run_preview" | "success" | "failure" | "error"
      - confirmed: True ONLY when mode=VALIDATE and execution succeeded
      - dry_run_preview: list of AWS calls that would/did execute
      - evidence: list of execution evidence dicts (empty unless VALIDATE ran)
      - cleanup_done / cleanup_status: cleanup state
      - audit_log: list of audit entries for every AWS API call made
      - s3_bucket / s3_object_key: populated for s3_write VALIDATE runs
      - run_id: unique run identifier
    """
    from botocore.exceptions import NoCredentialsError, ProfileNotFound, ClientError
    from aws_pentest.validation.validator import AWSValidator, ValidationMode

    try:
        session = _build_session(req.profile, req.region)
    except (NoCredentialsError, ProfileNotFound, ClientError) as exc:
        return _credential_error_response(req.finding_id, req.technique, req.mode, exc)

    mode = ValidationMode(req.mode)
    validator = AWSValidator(session=session, mode=mode, run_id=req.run_id)

    # Build technique-specific kwargs
    kwargs: dict[str, Any] = {}
    if req.bucket_name:
        kwargs["bucket_name"] = req.bucket_name
    if req.object_key:
        kwargs["object_key"] = req.object_key
    if req.role_arn:
        kwargs["role_arn"] = req.role_arn
    if req.target_service:
        kwargs["target_service"] = req.target_service
    if req.instance_id:
        kwargs["instance_id"] = req.instance_id
    if req.region:
        kwargs["region"] = req.region

    result = validator.validate(
        finding_id=req.finding_id,
        technique=req.technique,
        confirmed=req.confirmed,
        **kwargs,
    )

    result_dict = result.model_dump()

    # Persist VALIDATE mode results to the validation log
    # (DRY_RUN and READ_ONLY are not persisted — they're preview-only)
    if req.mode == "VALIDATE":
        try:
            from api.services.report_service import record_validation_result
            record_validation_result(result_dict)
        except Exception as exc:
            logger.warning("Could not record validation result: %s", exc)

    return result_dict


# ---------------------------------------------------------------------------
# POST /api/validate/cleanup — explicit S3 Write cleanup
# ---------------------------------------------------------------------------

@router.post("/cleanup")
def cleanup_s3_write(req: CleanupRequest) -> dict[str, Any]:
    """
    Explicitly delete the S3 object created by a previous s3_write VALIDATE run.

    Safety:
      - Only operates on objects recorded in the validation log for this run_id.
      - Does NOT accept arbitrary bucket/key from the frontend.
      - Verifies deletion by attempting a HeadObject after DeleteObject.
      - cleanup_status is set to "COMPLETED" ONLY if DeleteObject actually succeeded.
      - Never reports COMPLETED if deletion failed.
    """
    from botocore.exceptions import NoCredentialsError, ProfileNotFound, ClientError
    from api.services.report_service import _load_validation_log, record_validation_result
    from datetime import datetime, timezone

    # Find the run record in the validation log
    log = _load_validation_log()
    run_record: Optional[dict[str, Any]] = None
    for entry in log:
        if entry.get("run_id") == req.run_id and entry.get("technique") == "s3_write":
            run_record = entry
            # Use the most recent matching record
            # (don't break — take the last one in case of multiple)

    if run_record is None:
        return {
            "run_id": req.run_id,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": (
                f"No s3_write validation record found for run_id '{req.run_id}'. "
                f"Cannot perform cleanup."
            ),
        }

    bucket = run_record.get("s3_bucket")
    key = run_record.get("s3_object_key")

    if not bucket or not key:
        return {
            "run_id": req.run_id,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": (
                f"Validation record for run_id '{req.run_id}' does not contain "
                f"bucket/object_key information. "
                f"bucket={bucket!r}, object_key={key!r}. Cannot perform cleanup."
            ),
        }

    if run_record.get("cleanup_status") == "COMPLETED":
        return {
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "already_done",
            "cleanup_status": "COMPLETED",
            "description": (
                f"Cleanup for run_id '{req.run_id}' was already completed. "
                f"Object s3://{bucket}/{key} was previously deleted."
            ),
        }

    # Build session
    try:
        session = _build_session(req.profile, req.region)
    except (NoCredentialsError, ProfileNotFound, ClientError) as exc:
        return {
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "error",
            "cleanup_status": "FAILED",
            "description": f"AWS credential error: {exc}. Cannot perform cleanup.",
            "error": str(exc),
        }

    s3 = session.client("s3")
    timestamp = datetime.now(timezone.utc).isoformat()

    try:
        # Attempt DeleteObject
        s3.delete_object(Bucket=bucket, Key=key)

        # Verify deletion — try HeadObject; should raise NoSuchKey or 404
        deletion_verified = False
        try:
            s3.head_object(Bucket=bucket, Key=key)
            # Object still exists — deletion may not have propagated yet
            deletion_verified = False
        except ClientError as head_exc:
            error_code = head_exc.response.get("Error", {}).get("Code", "")
            if error_code in ("404", "NoSuchKey"):
                deletion_verified = True
            else:
                logger.warning("head_object after delete returned unexpected error: %s", head_exc)
                deletion_verified = False  # Conservative: cannot confirm

        cleanup_status = "COMPLETED" if deletion_verified else "COMPLETED_UNVERIFIED"
        description = (
            f"CLEANUP COMPLETED: Test object s3://{bucket}/{key} was deleted "
            f"(s3:DeleteObject → success). "
        )
        if deletion_verified:
            description += "Deletion verified — object is no longer accessible."
        else:
            description += "Note: object accessibility could not be immediately verified (may be eventual consistency)."

        # Update the run record in the log
        _patch_validation_log(req.run_id, {
            "cleanup_done": True,
            "cleanup_status": "COMPLETED",
        })

        return {
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "success",
            "cleanup_status": cleanup_status,
            "cleanup_done": True,
            "deletion_verified": deletion_verified,
            "description": description,
            "timestamp": timestamp,
        }

    except ClientError as exc:
        error_code = exc.response.get("Error", {}).get("Code", "Unknown")
        logger.error("Cleanup DeleteObject failed for run %s: %s", req.run_id, exc)
        return {
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "failure",
            "cleanup_status": "FAILED",
            "cleanup_done": False,
            "description": (
                f"CLEANUP FAILED: The validation object s3://{bucket}/{key} could not be deleted. "
                f"AWS error code: {error_code}. Reason: {exc}"
            ),
            "error": str(exc),
            "timestamp": timestamp,
        }
    except Exception as exc:
        logger.error("Cleanup failed unexpectedly for run %s: %s", req.run_id, exc)
        return {
            "run_id": req.run_id,
            "bucket": bucket,
            "object_key": key,
            "status": "error",
            "cleanup_status": "FAILED",
            "cleanup_done": False,
            "description": f"Cleanup failed unexpectedly: {exc}",
            "error": str(exc),
            "timestamp": timestamp,
        }


def _patch_validation_log(run_id: str, updates: dict[str, Any]) -> None:
    """Update fields on the most recent validation log entry matching run_id."""
    try:
        from api.services.report_service import _load_validation_log, _VALIDATION_LOG_PATH
        import json

        log = _load_validation_log()
        # Apply updates to the last matching record
        last_idx = None
        for i, entry in enumerate(log):
            if entry.get("run_id") == run_id and entry.get("technique") == "s3_write":
                last_idx = i
        if last_idx is not None:
            log[last_idx].update(updates)
            _VALIDATION_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
            with open(_VALIDATION_LOG_PATH, "w", encoding="utf-8") as f:
                json.dump(log, f, indent=2, default=str)
    except Exception as exc:
        logger.warning("_patch_validation_log failed: %s", exc)


# ---------------------------------------------------------------------------
# GET /api/validate/techniques — list available techniques
# ---------------------------------------------------------------------------

@router.get("/techniques")
def list_techniques():
    """Return the list of available validation techniques and their requirements."""
    return {
        "techniques": [
            {
                "id": "s3_write",
                "name": "S3 Write Validation",
                "description": (
                    "Tests whether the current principal can write to the specified S3 bucket "
                    "by creating a sequential test object (controlled_validN.txt) and verifying "
                    "it exists via GetObject. The object is NOT auto-deleted — the user must "
                    "explicitly press 'Clean Up Test Object' after demonstrating the object."
                ),
                "required_params": ["bucket_name"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": True,
                "cleanup": "MANUAL — user must explicitly trigger cleanup via POST /api/validate/cleanup.",
            },
            {
                "id": "s3_read",
                "name": "S3 Read Validation",
                "description": (
                    "Tests whether the current principal can read from the specified S3 bucket. "
                    "If object_key is provided, calls s3:GetObject on that specific object. "
                    "Otherwise calls s3:ListObjectsV2 on the validation prefix."
                ),
                "required_params": ["bucket_name"],
                "optional_params": ["object_key"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": "No resources created — read-only operation.",
            },
            {
                "id": "iam_pass_role",
                "name": "IAM PassRole Validation",
                "description": (
                    "Uses the IAM Policy Simulator (non-mutating) to verify whether the current "
                    "principal has iam:PassRole permission on the specified role ARN. "
                    "No IAM resources are created, modified, or deleted."
                ),
                "required_params": ["role_arn"],
                "optional_params": ["target_service"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": "No resources created — IAM simulator is read-only.",
            },
            {
                "id": "ec2_access",
                "name": "EC2 Access Validation",
                "description": (
                    "Tests whether the current principal can call ec2:DescribeInstances. "
                    "If instance_id is provided, restricts the query to that specific instance. "
                    "This is a READ-ONLY validation — no instance state is changed."
                ),
                "required_params": [],
                "optional_params": ["instance_id"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": "No resources created — read-only operation.",
            },
            {
                "id": "ec2_control",
                "name": "EC2 Control Validation",
                "description": (
                    "Tests whether the current principal can stop and start a designated EC2 "
                    "test instance. Requires explicit instance_id. Requires confirmed=True. "
                    "The original running state is always restored. "
                    "Only operates on running instances."
                ),
                "required_params": ["instance_id"],
                "modes": ["READ_ONLY", "DRY_RUN", "VALIDATE"],
                "creates_resources": False,
                "cleanup": (
                    "State restoration is part of the validation sequence. "
                    "Original state (running) is restored after stop/start."
                ),
                "warning": (
                    "This will temporarily stop the designated test instance. "
                    "Only use against a specifically designated test instance."
                ),
            },
        ]
    }


# ---------------------------------------------------------------------------
# GET /api/validate/history — return persisted validation log
# ---------------------------------------------------------------------------

@router.get("/history")
def get_validation_history() -> dict[str, Any]:
    """Return all persisted validation results from the validation log."""
    try:
        from api.services.report_service import _load_validation_log
        log = _load_validation_log()
        return {"results": log, "count": len(log)}
    except Exception as exc:
        logger.warning("Could not load validation history: %s", exc)
        return {"results": [], "count": 0, "error": str(exc)}
