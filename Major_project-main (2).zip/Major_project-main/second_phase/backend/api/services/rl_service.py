"""
RL service — reads the structured training log and attack path results
produced by rl/training_logger.py and rl/train.py.

Provides typed access for the API routes.
If no log file exists yet (training hasn't been run), every function
returns sensible empty/default values rather than crashing.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Literal, Optional

logger = logging.getLogger(__name__)

_LOG_PATH = Path(__file__).parent.parent.parent / "rl" / "training_log.json"
_ATTACK_PATH_RESULT = Path(__file__).parent.parent.parent / "rl" / "attack_path_result.json"
_TRAINING_METRICS   = Path(__file__).parent.parent.parent / "rl" / "training_metrics.json"

# In-memory cache of latest live status (written by the live training callback)
_LIVE_STATUS: dict[str, Any] = {}


def _load_log(provider: Optional[str] = None) -> list[dict[str, Any]]:
    """Load training log, optionally filtered by provider."""
    # Try provider-specific log first
    if provider:
        provider_path = Path(__file__).parent.parent.parent / "rl" / f"training_log_{provider}.json"
        if provider_path.exists():
            try:
                with open(provider_path, encoding="utf-8") as f:
                    data = json.load(f)
                return data if isinstance(data, list) else []
            except Exception:
                pass

    if not _LOG_PATH.exists():
        return []
    try:
        with open(_LOG_PATH, encoding="utf-8") as f:
            data = json.load(f)
        episodes = data if isinstance(data, list) else []
        if provider:
            episodes = [e for e in episodes if e.get("provider", provider) == provider]
        return episodes
    except Exception as exc:
        logger.warning("Could not load training log: %s", exc)
        return []


def get_rl_status(provider: str = "aws") -> dict[str, Any]:
    """Current / most-recent RL step status."""
    # Live status during training (set by TrainingLogger callback)
    if _LIVE_STATUS and _LIVE_STATUS.get("provider", provider) == provider:
        return _LIVE_STATUS

    episodes = _load_log(provider)
    if not episodes:
        return {
            "episode":           0,
            "step":              0,
            "current_node":      None,
            "last_action":       None,
            "last_relation":     None,
            "reward":            0.0,
            "cumulative_reward": 0.0,
            "is_trained":        False,
            "total_timesteps":   0,
            "provider":          provider,
            "message": (
                "No training log found. "
                "POST /api/rl/train to start training."
            ),
        }

    last_ep = episodes[-1]
    steps = last_ep.get("steps", [])
    last_step = steps[-1] if steps else {}

    return {
        "episode":           last_ep.get("episode", len(episodes)),
        "step":              last_step.get("step", 0),
        "current_node":      last_step.get("node"),
        "last_action":       last_step.get("action"),
        "last_relation":     last_step.get("relation"),
        "reward":            last_step.get("reward", 0.0),
        "cumulative_reward": last_ep.get("total_reward", 0.0),
        "is_trained":        True,
        "total_timesteps":   sum(ep.get("steps_count", 0) for ep in episodes),
        "provider":          provider,
    }


def get_episodes(provider: str = "aws") -> list[dict[str, Any]]:
    """Per-episode summary list."""
    episodes = _load_log(provider)
    summaries = []
    for ep in episodes:
        steps = ep.get("steps", [])
        rewards = [s.get("reward", 0) for s in steps]
        summaries.append({
            "episode":        ep.get("episode", 0),
            "provider":       ep.get("provider", provider),
            "totalReward":    ep.get("total_reward", sum(rewards)),
            "stepsCount":     ep.get("steps_count", len(steps)),
            "success":        ep.get("success", False),
            "maxReward":      max(rewards) if rewards else 0,
            "minReward":      min(rewards) if rewards else 0,
            "avgReward":      sum(rewards) / len(rewards) if rewards else 0,
            "path":           [s.get("node") for s in steps if s.get("node")],
        })
    return summaries


def get_history(
    episode: Optional[int] = None,
    provider: str = "aws",
) -> list[dict[str, Any]]:
    """Full step trace for a given episode (or most recent)."""
    episodes = _load_log(provider)
    if not episodes:
        return []

    if episode is not None:
        matches = [e for e in episodes if e.get("episode") == episode]
        ep = matches[-1] if matches else episodes[-1]
    else:
        ep = episodes[-1]

    steps = ep.get("steps", [])
    return [
        {
            "step":       s.get("step", i),
            "node":       s.get("node"),
            "action":     s.get("action"),
            "relation":   s.get("relation"),
            "reward":     s.get("reward", 0),
            "success":    s.get("success", False),
            "is_goal":    s.get("is_goal", False),
        }
        for i, s in enumerate(steps)
    ]


def get_attack_path(provider: str = "aws") -> dict[str, Any]:
    """
    Return the latest RL inference attack path result.

    Tries to load a provider-specific result file first,
    falls back to the shared result file.
    """
    # Try provider-specific result
    provider_path = (
        Path(__file__).parent.parent.parent / "rl" / f"attack_path_result_{provider}.json"
    )
    for path in [provider_path, _ATTACK_PATH_RESULT]:
        if path.exists():
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                # Verify it's for the right provider (if field present)
                if data.get("provider", provider) == provider or path == provider_path:
                    return data
            except Exception as exc:
                logger.warning("Could not load attack path from %s: %s", path, exc)

    return {
        "status":       "no_result",
        "message": (
            "No RL attack path result available. "
            "POST /api/rl/train to train the model first."
        ),
        "path":         [],
        "total_reward": 0.0,
        "path_length":  0,
        "provider":     provider,
    }


def get_training_status() -> dict[str, Any]:
    """Return the training metrics from the most recent training run."""
    if not _TRAINING_METRICS.exists():
        return {
            "status":  "no_training",
            "message": "No training metrics found. Run training first.",
        }
    try:
        with open(_TRAINING_METRICS, encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        logger.warning("Could not load training metrics: %s", exc)
        return {"status": "error", "message": str(exc)}


def set_live_status(status: dict[str, Any]) -> None:
    """Called by TrainingLogger to push live updates during training."""
    _LIVE_STATUS.update(status)
