"""
anomaly/detector.py — Cloud security anomaly detection.

Detects security anomalies from the scanner-produced graph and resource data
without fabricating evidence. Every anomaly includes specific evidence from
the actual scan.

Implemented anomaly types:
  1. EXCESSIVE_PRIVILEGE     — identity has unusually broad permissions
  2. PUBLIC_EXPOSURE         — resource unexpectedly publicly accessible
  3. FIREWALL_ANOMALY        — suspicious/broad firewall configuration
  4. PRIVILEGE_ESCALATION    — graph relationship enabling privilege escalation
  5. UNEXPECTED_RESOURCE     — resource not present in baseline (new resource)
  6. CONFIGURATION_DRIFT     — meaningful configuration change vs baseline
  7. HIGH_PRIVILEGE_IDENTITY — identity with admin/owner-equivalent role

Anomaly severity levels: CRITICAL, HIGH, MEDIUM, LOW

Design principles:
  - Every anomaly references specific evidence from the scan
  - No anomaly is fabricated — all are based on real graph/scan attributes
  - Baseline comparison requires a previous scan result (optional)
  - Each anomaly type can be independently enabled/disabled
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

import networkx as nx

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Data models
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class Anomaly:
    """
    A detected security anomaly with supporting evidence.

    Fields
    ------
    type       : Anomaly type key (e.g. "EXCESSIVE_PRIVILEGE")
    severity   : "CRITICAL" | "HIGH" | "MEDIUM" | "LOW"
    resource   : Affected resource identifier
    description: Human-readable explanation
    evidence   : List of specific evidence strings from the scan
    recommendation: Remediation advice
    """
    type:           str
    severity:       str
    resource:       str
    description:    str
    evidence:       list[str] = field(default_factory=list)
    recommendation: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ──────────────────────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────────────────────

# Roles / policies that indicate admin/owner-level privilege
_ADMIN_KEYWORDS = frozenset([
    "AdministratorAccess", "AdministratorAccess",
    "roles/owner", "roles/editor",
    "FullAccess", "PowerUser",
    "admin", "owner", "superuser", "root",
])

# Roles considered "normal" for most service accounts
_NORMAL_ROLES = frozenset([
    "roles/viewer", "roles/logging.logWriter", "roles/monitoring.metricWriter",
    "roles/storage.objectViewer",
    "ReadOnlyAccess", "ViewOnlyAccess",
])

# Firewall ports that indicate dangerous broad exposure
_SENSITIVE_PORTS = {22: "SSH", 3389: "RDP", 5432: "PostgreSQL", 3306: "MySQL",
                    6379: "Redis", 27017: "MongoDB", 9200: "Elasticsearch"}


# ──────────────────────────────────────────────────────────────────────────────
# AnomalyDetector
# ──────────────────────────────────────────────────────────────────────────────

class AnomalyDetector:
    """
    Detects security anomalies from scan data.

    Usage
    -----
        detector = AnomalyDetector()
        anomalies = detector.detect(nx_graph, report_data, baseline=None)
    """

    def detect(
        self,
        nx_graph: nx.DiGraph,
        report_data: dict[str, Any],
        baseline: Optional[dict[str, Any]] = None,
        provider: str = "aws",
    ) -> list[Anomaly]:
        """
        Run all anomaly detectors on the provided scan data.

        Parameters
        ----------
        nx_graph:
            NetworkX DiGraph from the scanner (can be from AssessmentGraph.to_networkx()
            or graph_service._build_gcp_graph_from_report()).
        report_data:
            Raw scan report dict from the provider (last_report.json).
        baseline:
            Optional previous scan's report_data for configuration drift detection.
        provider:
            "aws" or "gcp" — affects which fields are inspected.

        Returns
        -------
        List of Anomaly objects, sorted by severity.
        """
        anomalies: list[Anomaly] = []

        # Detect across all anomaly types
        anomalies.extend(self._detect_excessive_privilege(nx_graph, report_data, provider))
        anomalies.extend(self._detect_public_exposure(nx_graph, report_data, provider))
        anomalies.extend(self._detect_privilege_escalation(nx_graph))
        anomalies.extend(self._detect_high_privilege_identities(nx_graph))

        if provider == "gcp":
            anomalies.extend(self._detect_firewall_anomalies_gcp(report_data))
        elif provider == "aws":
            anomalies.extend(self._detect_firewall_anomalies_aws(report_data))

        if baseline is not None:
            anomalies.extend(self._detect_configuration_drift(report_data, baseline, provider))
            anomalies.extend(self._detect_unexpected_resources(report_data, baseline, provider))

        # Sort by severity
        _sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        anomalies.sort(key=lambda a: _sev_order.get(a.severity, 99))

        logger.info(
            "AnomalyDetector: %d anomalies detected (provider=%s)",
            len(anomalies), provider,
        )
        return anomalies

    # ── 1. Excessive privilege ─────────────────────────────────────────────

    def _detect_excessive_privilege(
        self,
        nx_graph: nx.DiGraph,
        report_data: dict[str, Any],
        provider: str,
    ) -> list[Anomaly]:
        """
        Detect identities with unusually broad permissions compared to their
        expected role.  Evidence: specific role/action names from the graph.
        """
        anomalies: list[Anomaly] = []

        # Check out-degree in the graph — nodes with very high out-degree
        # (many permissions) may have excessive privilege
        if nx_graph.number_of_nodes() == 0:
            return anomalies

        # Compute mean out-degree as baseline
        out_degrees = dict(nx_graph.out_degree())
        if not out_degrees:
            return anomalies

        mean_out = sum(out_degrees.values()) / len(out_degrees)
        threshold = max(mean_out * 2.5, 3)  # 2.5× average or minimum 3

        for node_id, out_deg in out_degrees.items():
            if out_deg < threshold:
                continue

            attrs = nx_graph.nodes.get(node_id, {})
            nt = attrs.get("node_type") or attrs.get("type", "")

            # Only flag identity nodes (users, roles, service accounts)
            if nt not in ("IAMUser", "user", "IAMRole", "role",
                          "GCPServiceAccount", "ServiceAccount"):
                continue

            # Collect evidence: list the relation types of outgoing edges
            out_rels = [
                nx_graph[node_id][v].get("relation", "?")
                for v in nx_graph.successors(node_id)
            ]
            evidence = [
                f"Out-degree: {out_deg} (mean: {mean_out:.1f})",
                f"Relations: {', '.join(sorted(set(out_rels)))}",
                f"Node type: {nt}",
            ]

            # Add specific roles from graph attributes if available
            roles = attrs.get("attached_policies", []) or attrs.get("roles", [])
            if roles:
                evidence.append(f"Roles/policies: {', '.join(str(r) for r in roles[:5])}")

            anomalies.append(Anomaly(
                type="EXCESSIVE_PRIVILEGE",
                severity="HIGH",
                resource=node_id,
                description=(
                    f"Identity '{attrs.get('display_name', node_id.split('/')[-1])}' "
                    f"has {out_deg} outgoing permission edges "
                    f"({out_deg / max(mean_out, 1):.1f}× the average of {mean_out:.1f}). "
                    f"This may indicate over-provisioned access."
                ),
                evidence=evidence,
                recommendation=(
                    "Apply least-privilege: review and remove permissions not "
                    "required for this identity's function. Use permission boundaries "
                    "or IAM conditions to constrain access scope."
                ),
            ))

        return anomalies

    # ── 2. Public exposure ─────────────────────────────────────────────────

    def _detect_public_exposure(
        self,
        nx_graph: nx.DiGraph,
        report_data: dict[str, Any],
        provider: str,
    ) -> list[Anomaly]:
        """
        Detect publicly accessible resources (storage buckets, compute instances).
        """
        anomalies: list[Anomaly] = []
        resources = report_data.get("resources", {})

        # Storage buckets
        buckets = resources.get("s3_buckets", []) + resources.get("storage_buckets", [])
        for b in buckets:
            bucket_name = b.get("name", b.get("bucket_name", ""))
            is_pub_read  = b.get("is_public_read", False)
            is_pub_write = b.get("is_public_write", False)
            acl = b.get("acl", "")

            if is_pub_read or is_pub_write or "public" in str(acl).lower():
                evidence = [f"Bucket: {bucket_name}"]
                if is_pub_read:
                    evidence.append("Public READ access detected")
                if is_pub_write:
                    evidence.append("Public WRITE access detected — CRITICAL risk")
                if acl:
                    evidence.append(f"ACL setting: {acl}")

                anomalies.append(Anomaly(
                    type="PUBLIC_EXPOSURE",
                    severity="CRITICAL" if is_pub_write else "HIGH",
                    resource=bucket_name,
                    description=(
                        f"Storage bucket '{bucket_name}' is publicly accessible. "
                        f"{'Write access exposes data to modification.' if is_pub_write else 'Read access exposes data.'}"
                    ),
                    evidence=evidence,
                    recommendation=(
                        "Disable public access on this bucket. Enable Block Public Access "
                        "settings and review bucket ACL/IAM policies. "
                        "Enable bucket versioning and access logging."
                    ),
                ))

        # Compute instances with public IPs
        instances = resources.get("ec2_instances", []) + resources.get("compute_instances", [])
        for inst in instances:
            inst_name = inst.get("name", inst.get("instance_id", ""))
            has_pub_ip = inst.get("has_public_ip", False)

            if has_pub_ip:
                # Only flag as anomaly if combined with other risk factors
                attrs = {}
                if nx_graph.has_node(inst_name):
                    attrs = nx_graph.nodes.get(inst_name, {})
                elif any(inst_name in str(n) for n in nx_graph.nodes()):
                    pass  # just note it

                # Check if the instance has an instance profile (elevated risk)
                has_profile = any(
                    nx_graph[u][v].get("relation") == "HAS_INSTANCE_PROFILE"
                    for u, v in nx_graph.edges()
                    if inst_name in u
                )

                if has_pub_ip and has_profile:
                    anomalies.append(Anomaly(
                        type="PUBLIC_EXPOSURE",
                        severity="HIGH",
                        resource=inst_name,
                        description=(
                            f"Compute instance '{inst_name}' has a public IP address "
                            f"AND an attached instance profile/service account. "
                            f"This combination allows privilege escalation from the public internet."
                        ),
                        evidence=[
                            f"Instance: {inst_name}",
                            "Has public IP address",
                            "Has attached instance profile/service account",
                        ],
                        recommendation=(
                            "Move this instance behind a load balancer or NAT gateway. "
                            "Restrict instance profile permissions to the minimum required. "
                            "Apply security groups/firewall rules to limit inbound access."
                        ),
                    ))

        return anomalies

    # ── 3. Privilege escalation paths ─────────────────────────────────────

    def _detect_privilege_escalation(self, nx_graph: nx.DiGraph) -> list[Anomaly]:
        """
        Detect graph relationships that create privilege escalation opportunities.
        Specifically looks for:
          - PRIVESC_TO edges (direct escalation)
          - Low-privilege identity → CAN_IMPERSONATE → high-privilege identity chain
        """
        anomalies: list[Anomaly] = []

        for u, v, edata in nx_graph.edges(data=True):
            relation = edata.get("relation", "")
            if relation != "PRIVESC_TO":
                continue

            u_attrs = nx_graph.nodes.get(u, {})
            v_attrs = nx_graph.nodes.get(v, {})
            u_name  = u_attrs.get("display_name", u.split("/")[-1])
            v_name  = v_attrs.get("display_name", v.split("/")[-1])
            actions = edata.get("actions", [])

            evidence = [
                f"Source: {u} ({u_attrs.get('node_type', 'unknown')})",
                f"Target: {v} ({v_attrs.get('node_type', 'unknown')})",
                f"Relation: PRIVESC_TO",
            ]
            if actions:
                evidence.append(f"Required actions: {', '.join(str(a) for a in actions[:5])}")
            if edata.get("evidence"):
                raw_ev = edata["evidence"]
                if raw_ev and isinstance(raw_ev[0], dict):
                    evidence.append(
                        f"Policy source: {raw_ev[0].get('type', 'unknown')}"
                    )

            anomalies.append(Anomaly(
                type="PRIVILEGE_ESCALATION",
                severity="CRITICAL",
                resource=u,
                description=(
                    f"'{u_name}' can escalate privileges to '{v_name}' "
                    f"via {relation}. This represents a confirmed privilege "
                    f"escalation path in the cloud environment."
                ),
                evidence=evidence,
                recommendation=(
                    f"Remove or restrict the IAM permissions that allow '{u_name}' "
                    f"to assume/escalate to '{v_name}'. Apply permission boundaries. "
                    f"Review trust policies and ensure least-privilege is enforced."
                ),
            ))

        # Detect low-priv → impersonate → high-priv chains
        for u, v, edata in nx_graph.edges(data=True):
            if edata.get("relation") not in ("CAN_IMPERSONATE", "CAN_ASSUME"):
                continue

            # Check if v has further escalation edges
            v_out_rels = [
                nx_graph[v][w].get("relation", "")
                for w in nx_graph.successors(v)
            ]
            if "PRIVESC_TO" in v_out_rels or "CAN_IMPERSONATE" in v_out_rels:
                u_attrs = nx_graph.nodes.get(u, {})
                v_attrs = nx_graph.nodes.get(v, {})
                u_name  = u_attrs.get("display_name", u.split("/")[-1])
                v_name  = v_attrs.get("display_name", v.split("/")[-1])

                anomalies.append(Anomaly(
                    type="PRIVILEGE_ESCALATION",
                    severity="HIGH",
                    resource=u,
                    description=(
                        f"'{u_name}' can impersonate/assume '{v_name}', which itself "
                        f"has further escalation paths. This creates an indirect "
                        f"privilege escalation chain."
                    ),
                    evidence=[
                        f"Source: {u}",
                        f"Intermediate: {v}",
                        f"Chain relation: {edata.get('relation')}",
                        f"Intermediate has further escalation: {', '.join(v_out_rels)}",
                    ],
                    recommendation=(
                        "Review the chain of impersonation/assumption permissions. "
                        "Apply least-privilege to prevent multi-hop escalation. "
                        "Consider using workload identity federation instead of "
                        "direct service account impersonation."
                    ),
                ))

        return anomalies

    # ── 4. High-privilege identities ───────────────────────────────────────

    def _detect_high_privilege_identities(self, nx_graph: nx.DiGraph) -> list[Anomaly]:
        """
        Detect identities that appear to have admin/owner-level privilege
        based on graph node attributes.
        """
        anomalies: list[Anomaly] = []

        for node_id, attrs in nx_graph.nodes(data=True):
            nt = attrs.get("node_type") or attrs.get("type", "")
            if nt not in ("IAMUser", "user", "IAMRole", "role",
                          "GCPServiceAccount", "ServiceAccount"):
                continue

            display = str(attrs.get("display_name", "") or node_id).lower()

            # Check for admin/owner keywords in display name
            matched_kw = [kw for kw in _ADMIN_KEYWORDS if kw.lower() in display]
            if not matched_kw:
                # Check attached policies/roles
                policies = attrs.get("attached_policies", []) or []
                roles = attrs.get("roles", []) or []
                all_perms = [str(p) for p in policies + roles]
                matched_kw = [
                    kw for kw in _ADMIN_KEYWORDS
                    if any(kw.lower() in p.lower() for p in all_perms)
                ]

            if matched_kw:
                evidence = [
                    f"Identity: {node_id}",
                    f"Type: {nt}",
                    f"Admin indicators: {', '.join(matched_kw[:3])}",
                ]

                disabled = attrs.get("disabled", False)
                if disabled:
                    # Disabled admin accounts are lower severity
                    severity = "MEDIUM"
                    evidence.append("Note: account is currently disabled")
                else:
                    severity = "HIGH"

                anomalies.append(Anomaly(
                    type="HIGH_PRIVILEGE_IDENTITY",
                    severity=severity,
                    resource=node_id,
                    description=(
                        f"Identity '{attrs.get('display_name', node_id.split('/')[-1])}' "
                        f"appears to have admin/owner-level privileges "
                        f"(detected via: {', '.join(matched_kw[:3])})."
                    ),
                    evidence=evidence,
                    recommendation=(
                        "Verify this identity actually requires admin-level access. "
                        "If not, apply least-privilege. Enable MFA for admin accounts. "
                        "Audit recent activity for this identity. "
                        "Consider using short-lived credentials instead of long-term admin keys."
                    ),
                ))

        return anomalies

    # ── 5. Firewall anomalies (GCP) ────────────────────────────────────────

    def _detect_firewall_anomalies_gcp(self, report_data: dict[str, Any]) -> list[Anomaly]:
        """Detect suspicious GCP firewall rules."""
        anomalies: list[Anomaly] = []
        resources = report_data.get("resources", {})
        findings  = report_data.get("findings", {})

        compute_findings = findings.get("compute", [])
        for f in compute_findings:
            if not isinstance(f, dict):
                continue

            title = f.get("title", f.get("check_id", "")).lower()
            desc  = f.get("description", "")
            sev   = f.get("severity", "MEDIUM")
            if isinstance(sev, dict):
                sev = sev.get("value", "MEDIUM")

            if "firewall" in title or "firewall" in desc.lower():
                resource_name = (
                    f.get("instance_name", "") or
                    f.get("resource_id", "") or
                    "firewall-rule"
                )
                anomalies.append(Anomaly(
                    type="FIREWALL_ANOMALY",
                    severity=str(sev).upper() if str(sev).upper() in ("CRITICAL","HIGH","MEDIUM","LOW") else "MEDIUM",
                    resource=resource_name,
                    description=f.get("description", "Suspicious firewall configuration detected."),
                    evidence=[
                        f"Finding title: {f.get('title', '')}",
                        f"Resource: {resource_name}",
                        f"Severity from scanner: {sev}",
                    ],
                    recommendation=f.get("recommendation", "Review and tighten firewall rules."),
                ))

        return anomalies

    # ── 6. Firewall anomalies (AWS) ────────────────────────────────────────

    def _detect_firewall_anomalies_aws(self, report_data: dict[str, Any]) -> list[Anomaly]:
        """Detect suspicious AWS security group configurations from EC2 findings."""
        anomalies: list[Anomaly] = []
        findings = report_data.get("findings", {})
        ec2_findings = findings.get("ec2", [])

        for f in ec2_findings:
            if not isinstance(f, dict):
                continue

            title = f.get("title", "").lower()
            sev   = f.get("severity", "MEDIUM")
            if isinstance(sev, dict):
                sev = sev.get("value", "MEDIUM")

            if any(kw in title for kw in ("security group", "inbound", "unrestricted", "0.0.0.0", "open port")):
                anomalies.append(Anomaly(
                    type="FIREWALL_ANOMALY",
                    severity=str(sev).upper() if str(sev).upper() in ("CRITICAL","HIGH","MEDIUM","LOW") else "MEDIUM",
                    resource=f.get("instance_id", f.get("resource_arn", "ec2-security-group")),
                    description=f.get("description", "Suspicious security group configuration detected."),
                    evidence=[
                        f"Finding title: {f.get('title', '')}",
                        f"Instance: {f.get('instance_id', '')}",
                    ],
                    recommendation=f.get("recommendation", "Restrict inbound rules to required ports and IP ranges."),
                ))

        return anomalies

    # ── 7. Configuration drift ─────────────────────────────────────────────

    def _detect_configuration_drift(
        self,
        current: dict[str, Any],
        baseline: dict[str, Any],
        provider: str,
    ) -> list[Anomaly]:
        """
        Compare current scan with a baseline to detect meaningful configuration changes.
        Only flags security-relevant changes (not every diff).
        """
        anomalies: list[Anomaly] = []

        current_sum  = current.get("summary", {})
        baseline_sum = baseline.get("summary", {})

        # Detect significant increases in findings count
        curr_findings = current_sum.get("total_findings", 0)
        base_findings = baseline_sum.get("total_findings", 0)

        if curr_findings > base_findings + 2:
            delta = curr_findings - base_findings
            anomalies.append(Anomaly(
                type="CONFIGURATION_DRIFT",
                severity="MEDIUM",
                resource=f"{provider}_environment",
                description=(
                    f"Security findings increased by {delta} since the baseline scan "
                    f"({base_findings} → {curr_findings}). This may indicate "
                    f"new misconfigurations or security regressions."
                ),
                evidence=[
                    f"Baseline findings: {base_findings}",
                    f"Current findings:  {curr_findings}",
                    f"Delta: +{delta}",
                ],
                recommendation=(
                    "Review newly introduced findings and remediate any new "
                    "misconfigurations. Investigate whether recent infrastructure "
                    "changes introduced security regressions."
                ),
            ))

        # Detect increase in privesc paths
        curr_privesc = current_sum.get("privesc_paths", len(current.get("privilege_escalation_paths", [])))
        base_privesc = baseline_sum.get("privesc_paths", len(baseline.get("privilege_escalation_paths", [])))

        if curr_privesc > base_privesc:
            delta = curr_privesc - base_privesc
            anomalies.append(Anomaly(
                type="CONFIGURATION_DRIFT",
                severity="HIGH",
                resource=f"{provider}_iam",
                description=(
                    f"Privilege escalation paths increased by {delta} since the baseline "
                    f"({base_privesc} → {curr_privesc}). New escalation paths may have "
                    f"been introduced by recent IAM changes."
                ),
                evidence=[
                    f"Baseline privesc paths: {base_privesc}",
                    f"Current privesc paths:  {curr_privesc}",
                    f"Delta: +{delta}",
                ],
                recommendation=(
                    "Audit recent IAM policy changes. Review newly created trust "
                    "relationships and role assumptions. Apply least-privilege to "
                    "prevent new escalation paths."
                ),
            ))

        return anomalies

    # ── 8. Unexpected resources ────────────────────────────────────────────

    def _detect_unexpected_resources(
        self,
        current: dict[str, Any],
        baseline: dict[str, Any],
        provider: str,
    ) -> list[Anomaly]:
        """
        Detect newly appearing resources that were not present in the baseline.
        Only flags resources of security significance.
        """
        anomalies: list[Anomaly] = []

        def _get_resources(report: dict, key: str) -> set[str]:
            items = report.get("resources", {}).get(key, [])
            if not items:
                items = report.get("resource_inventory", {}).get(key, [])
            names: set[str] = set()
            for item in items:
                if isinstance(item, dict):
                    names.add(
                        item.get("email", "") or
                        item.get("name", "") or
                        item.get("UserName", "") or
                        item.get("RoleName", "") or
                        ""
                    )
                elif isinstance(item, str):
                    names.add(item)
            return {n for n in names if n}

        if provider == "aws":
            resource_keys = [
                ("iam_users",     "IAM User",     "HIGH"),
                ("iam_roles",     "IAM Role",     "MEDIUM"),
                ("s3_buckets",    "S3 Bucket",    "MEDIUM"),
                ("ec2_instances", "EC2 Instance", "LOW"),
            ]
        else:  # gcp
            resource_keys = [
                ("service_accounts",  "Service Account", "HIGH"),
                ("storage_buckets",   "Storage Bucket",  "MEDIUM"),
                ("compute_instances", "Compute Instance","LOW"),
            ]

        for key, rtype, severity in resource_keys:
            current_names  = _get_resources(current,  key)
            baseline_names = _get_resources(baseline, key)
            new_names = current_names - baseline_names

            for name in new_names:
                if not name:
                    continue
                anomalies.append(Anomaly(
                    type="UNEXPECTED_RESOURCE",
                    severity=severity,
                    resource=name,
                    description=(
                        f"New {rtype} '{name}' detected that was not present in the "
                        f"baseline scan. Unexpected resources may indicate "
                        f"unauthorized provisioning or configuration drift."
                    ),
                    evidence=[
                        f"Resource type: {rtype}",
                        f"Resource name: {name}",
                        "Not present in baseline scan",
                    ],
                    recommendation=(
                        f"Verify that this {rtype} was intentionally created. "
                        f"Review creation logs and confirm authorization. "
                        f"If unauthorized, investigate and decommission."
                    ),
                ))

        return anomalies


# ──────────────────────────────────────────────────────────────────────────────
# Storage helpers
# ──────────────────────────────────────────────────────────────────────────────

def save_anomalies(anomalies: list[Anomaly], path: str) -> None:
    """Persist anomaly results to JSON."""
    import json
    data = [a.to_dict() for a in anomalies]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
    logger.info("Anomalies saved: %d to %s", len(anomalies), path)


def load_anomalies(path: str) -> list[Anomaly]:
    """Load persisted anomaly results from JSON."""
    import json
    from pathlib import Path as _Path
    p = _Path(path)
    if not p.exists():
        return []
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        return [Anomaly(**item) for item in data]
    except Exception as exc:
        logger.warning("Could not load anomalies from %s: %s", path, exc)
        return []
