"""
anomaly/ — Cloud security anomaly detection.

This package analyses the scanner-produced graph and resource data
to identify security anomalies without fabricating evidence.
"""
from anomaly.detector import AnomalyDetector, Anomaly

__all__ = ["AnomalyDetector", "Anomaly"]
